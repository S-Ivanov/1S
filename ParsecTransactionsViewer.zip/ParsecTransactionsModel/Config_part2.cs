﻿using System;
using System.Linq;

namespace ParsecTransactionsModel.Configuration
{
    public partial class Config
    {
        /// <summary>
        /// Доступные проходные и шлагбаумы
        /// </summary>
        public IdName[] TerritoryObjects
        {
            get
            {
                if (territoryObjects == null)
                {
                    territoryObjects = this.Territories == null ? EmptyTerritoryObjects : this.Territories.Select(x => new IdName { Id = new Guid(x.Id), Name = x.Name }).ToArray();
                }
                return territoryObjects;
            }
        }
        IdName[] territoryObjects = null;

        public static IdName[] EmptyTerritoryObjects = new IdName[] { };
    }

    public partial class ConfigUser
    {
        public static Guid[] EmptyIDs = new Guid[] { };

        /// <summary>
        /// Идентификаторы доступных подразделений
        /// </summary>
        public Guid[] DepartmentIDs
        {
            get
            {
                if (departmentIDs == null)
                {
                    departmentIDs = this.Departments == null ? EmptyIDs : this.Departments.Select(x => new Guid(x.Id)).ToArray();
                }
                return departmentIDs;
            }
        }
        Guid[] departmentIDs = null;

        /// <summary>
        /// Идентификаторы вложенных подразделений, исключаемых из обработки
        /// </summary>
        public Guid[] ExcludeDepartmentIDs
        {
            get
            {
                if (excludeDepartmentIDs == null)
                {
                    excludeDepartmentIDs = this.ExcludeDepartments == null ? EmptyIDs : this.ExcludeDepartments.Select(x => new Guid(x.Id)).ToArray();
                }
                return excludeDepartmentIDs;
            }
        }
        Guid[] excludeDepartmentIDs = null;

        /// <summary>
        /// Идентификаторы людей, исключаемых из обработки
        /// </summary>
        public Guid[] ExcludePersonIDs
        {
            get
            {
                if (excludePersonIDs == null)
                {
                    excludePersonIDs = this.ExcludePersons == null ? EmptyIDs : this.ExcludePersons.Select(x => new Guid(x.Id)).ToArray();
                }
                return excludePersonIDs;
            }
        }
        Guid[] excludePersonIDs = null;
    }
}
