﻿using ParsecIntegrationClient;
using ParsecTransactionsModel.ParsecIntegrationService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using TimeLines;

namespace ParsecTransactionsModel
{
    public class Model
    {
        /// <summary>
        /// Загрузить пользователей из файла
        /// </summary>
        /// <param name="fileName">имя файла</param>
        /// <returns></returns>
        public static Configuration.Config LoadConfiguration(string fileName)
        {
            using (FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                return (new XmlSerializer(typeof(Configuration.Config))).Deserialize(fileStream) as Configuration.Config;
            }
        }

        /// <summary>
        /// Загрузка иерархии подразделений, доступных пользователю
        /// </summary>
        /// <param name="user">пользователь</param>
        /// <returns></returns>
        public static Department[] LoadDepartments(Configuration.ConfigUser user)
        {
            using (IntegrationServiceSoapClient service = new IntegrationServiceSoapClient())
            {
                var session = service.OpenSession("", ParsecOperatorName, ParsecOperatorPassword);
                if (session.Result == 0)
                {
                    Department[] userDepartments;
                    try
                    {
                        userDepartments = LoadDepartments(service, session.Value.SessionID, user);
                    }
                    finally
                    {
                        service.CloseSession(session.Value.SessionID);
                    }
                    return userDepartments;
                }
                else
                    return new Department[] { };
            }
        }

        /// <summary>
        /// Загрузка иерархии подразделений, доступных пользователю
        /// </summary>
        /// <param name="service">сервис Парсека</param>
        /// <param name="sessionId">идентификатор сессии сервиса Парсека</param>
        /// <param name="user">пользователь</param>
        /// <returns></returns>
        public static Department[] LoadDepartments(IntegrationServiceSoapClient service, Guid sessionId, Configuration.ConfigUser user)
        {
            List<Department> departments = new List<Department>();

            // подразделения отдаются отсортированными
            OrgUnit[] ouHierarhy = service.GetOrgUnitsHierarhy(sessionId);

            var orgUnitDictionary = ouHierarhy
                .Where(x => !user.ExcludeDepartmentIDs.Contains(x.ID))
                .GroupBy(x => x.PARENT_ID)
                .Where(x => !user.ExcludeDepartmentIDs.Contains(x.Key))
                .ToDictionary(x => x.Key);

            foreach (var depId in user.DepartmentIDs)
            {
                var orgUnit = ouHierarhy.FirstOrDefault(x => x.ID == depId);
                if (orgUnit != null)
                {
                    Department department = new Department { Id = orgUnit.ID, Name = orgUnit.NAME };
                    FillChildDepartments(department, user, orgUnitDictionary);
                    departments.Add(department);
                }
            }

            return departments.ToArray();
        }

        /// <summary>
        /// Загрузка вложенных подразделений
        /// </summary>
        /// <param name="department">подразделение, для которого нужно загрузить вложенные</param>
        /// <param name="user">пользователь</param>
        /// <param name="orgUnitDictionary">все подразделения из Парсек, сгруппированные по PARENT_ID</param>
        private static void FillChildDepartments(Department department, Configuration.ConfigUser user, Dictionary<Guid, IGrouping<Guid, OrgUnit>> orgUnitDictionary)
        {
            IGrouping<Guid, OrgUnit> childUnits;
            if (orgUnitDictionary.TryGetValue(department.Id, out childUnits))
            {
                department.Childs.AddRange(childUnits.Select(x => new Department { Id = x.ID, Name = x.NAME }));
                foreach (var childDepartment in department.Childs)
                {
                    FillChildDepartments(childDepartment, user, orgUnitDictionary);
                }
            }
        }

        /// <summary>
        /// Загрузить людей с транзакциями
        /// </summary>
        /// <param name="user">пользователь</param>
        /// <param name="territoryIDs">коды проходных и шлагбаумов</param>
        /// <param name="departmentId">идентификатор подразделения из Парсек</param>
        /// <param name="from">с, только дата</param>
        /// <param name="to">по, только дата</param>
        /// <returns></returns>
        /// <remarks>
        /// Диапазон дат - [from, to]
        /// Например, запрос транзакций за 19.10.2017:
        /// - from = 19.10.2017
        /// - to = 19.10.2017
        /// </remarks>
        //public static Person[] LoadPersons(Guid[] territoryIDs, Guid departmentId, Guid[] excludePersonIDs, DateTime from, DateTime to)
        public static Person[] LoadPersons(IdName[] territories, Guid departmentId, Guid[] excludePersonIDs, DateTime from, DateTime to)
        {
            CheckEventsPeriod(ref from, ref to);

            using (IntegrationServiceSoapClient service = new IntegrationServiceSoapClient())
            {
                var session = service.OpenSession("", ParsecOperatorName, ParsecOperatorPassword);
                if (session.Result == 0)
                {
                    Person[] persons;
                    try
                    {
                        persons = LoadPersons(service, session.Value.SessionID, territories, departmentId, excludePersonIDs, from, to);
                    }
                    finally
                    {
                        service.CloseSession(session.Value.SessionID);
                    }
                    return persons;
                }
                else
                    return new Person[] { };
            }
        }

        /// <summary>
        /// Скорректировать период запроса транзакций
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        private static void CheckEventsPeriod(ref DateTime from, ref DateTime to)
        {
            @from = @from.Date;
            to = to.Date;
            if (@from > to)
                throw new ArgumentOutOfRangeException();
        }

        //public static Person[] LoadPersons(IntegrationServiceSoapClient service, Guid sessionId, Guid[] territoryIDs, Guid departmentId, Guid[] excludePersonIDs, DateTime from, DateTime to)
        public static Person[] LoadPersons(IntegrationServiceSoapClient service, Guid sessionId, IdName[] territories, Guid departmentId, Guid[] excludePersonIDs, DateTime from, DateTime to)
        {
            CheckEventsPeriod(ref from, ref to);

            DateTime from2 = from.AddDays(-1);
            DateTime to2 = to.AddDays(2);

            // загрузить транзакции по подразделению
            // транзакции грузить за период -+ день, затем обрезать по исходному периоду
            //var allTransactions = LoadTransactions(service, sessionId, territoryIDs, departmentId, from2, to2);
            var allTransactions = LoadTransactions(service, sessionId, territories.Select(t => t.Id).ToArray(), departmentId, from2, to2);

            if (allTransactions.Count == 0)
                return new Person[] { };

            // загрузить территории
            Territory[] allTerritories = service.GetTerritoriesHierarhy(sessionId);

            // заменить полные названия постов на краткие синонимы
            foreach (var kvp in allTransactions)
            {
                kvp.Value.ForEach(workPeriod =>
                {
                    Territory territory;
                    if (!string.IsNullOrEmpty(workPeriod.InPost))
                    {
                        territory = allTerritories.FirstOrDefault(t => t.NAME == workPeriod.InPost);
                        if (territory == null)
                            workPeriod.InPost = "";
                        else
                        {
                            IdName shortTerritory = territories.FirstOrDefault(t => t.Id == territory.ID);
                            if (shortTerritory == null)
                                workPeriod.InPost = "";
                            else
                                workPeriod.InPost = shortTerritory.Name;
                        }
                    }
                    if (!string.IsNullOrEmpty(workPeriod.OutPost))
                    {
                        territory = allTerritories.FirstOrDefault(t => t.NAME == workPeriod.OutPost);
                        if (territory == null)
                            workPeriod.OutPost = "";
                        else
                        {
                            IdName shortTerritory = territories.FirstOrDefault(t => t.Id == territory.ID);
                            if (shortTerritory == null)
                                workPeriod.OutPost = "";
                            else
                                workPeriod.OutPost = shortTerritory.Name;
                        }
                    }
                });
            }

            // загрузить людей (люди отдаются отсортированными по ФИО)
            var orgUnitSubItems = service.GetOrgUnitSubItems(sessionId, departmentId);

            // формировать результат
            List<Person> persons = new List<Person>();

            IEnumerable<IPeriod> basePeriod = new Period[] { new Period { Start = from, End = to.AddDays(1) } };
            foreach (var orgUnitSubItem in orgUnitSubItems.Where(x => x is BasePerson && !excludePersonIDs.Contains((x as BasePerson).ID)))
            {
                var basePerson = orgUnitSubItem as BasePerson;
                var person = new Person { Id = basePerson.ID, LastName = basePerson.LAST_NAME, FirstName = basePerson.FIRST_NAME, MiddleName = basePerson.MIDDLE_NAME, TabNum = basePerson.TAB_NUM };
                List<WorkPeriod> personAllTransactions = null;
                if (allTransactions.TryGetValue(person.Id, out personAllTransactions))
                {
                    var personTransactions = TimeLineUtils.And(
                        new IEnumerable<IPeriod>[] { personAllTransactions, basePeriod },
                        (start, end, periods) => new WorkPeriod
                        {
                            InPost = (periods[0] as WorkPeriod).InPost,
                            OutPost = (periods[0] as WorkPeriod).OutPost,
                            Start = start,
                            End = end,
                            //IsStartUnknown = (periods[0] as WorkPeriod).IsStartUnknown,
                            //IsEndUnknown = (periods[0] as WorkPeriod).IsEndUnknown,
                            Data = (periods[0] as WorkPeriod).Data
                        });
                    person.Transactions = personTransactions.Cast<WorkPeriod>().ToList();
                }
                persons.Add(person);
            }

            return persons.ToArray();
        }

        public static Territory[] GetTerritories()
        {
            using (IntegrationServiceSoapClient service = new IntegrationServiceSoapClient())
            {
                var session = service.OpenSession("", ParsecOperatorName, ParsecOperatorPassword);
                if (session.Result == 0)
                {
                    Territory[] result;
                    try
                    {
                        result = service.GetTerritoriesHierarhy(session.Value.SessionID);
                    }
                    finally
                    {
                        service.CloseSession(session.Value.SessionID);
                    }
                    return result;
                }
                else
                    return new Territory[] { };
            }
        }

        /// <summary>
        /// Загрузить транзакции
        /// </summary>
        /// <param name="config"></param>
        /// <param name="departmentId"></param>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static Dictionary<Guid, List<WorkPeriod>> LoadTransactions(Guid[] territoryIDs, Guid departmentId, DateTime from, DateTime to)
        {
            using (IntegrationServiceSoapClient service = new IntegrationServiceSoapClient())
            {
                var session = service.OpenSession("", ParsecOperatorName, ParsecOperatorPassword);
                if (session.Result == 0)
                {
                    Dictionary<Guid, List<WorkPeriod>> transactions;
                    try
                    {
                        transactions = LoadTransactions(service, session.Value.SessionID, territoryIDs, departmentId, from, to);
                    }
                    finally
                    {
                        service.CloseSession(session.Value.SessionID);
                    }
                    return transactions;
                }
                else
                    return new Dictionary<Guid, List<WorkPeriod>>();
            }
        }

        /// <summary>
        /// Загрузить транзакции
        /// </summary>
        /// <param name="service"></param>
        /// <param name="sessionId"></param>
        /// <param name="config"></param>
        /// <param name="departmentId"></param>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static Dictionary<Guid, List<WorkPeriod>> LoadTransactions(IntegrationServiceSoapClient service, Guid sessionId, Guid[] territoryIDs, Guid departmentId, DateTime from, DateTime to)
        {
            Dictionary<Guid, List<WorkPeriod>> transactions = null;

            EventHistoryQueryParams param = new EventHistoryQueryParams();
            param.StartDate = from.ToUniversalTime();
            param.EndDate = to.ToUniversalTime();

            var transactionTypes = new ArrayOfUnsignedInt();
            transactionTypes.AddRange(new uint[] { NORMAL_INPUT, NORMAL_OUTPUT, FACT_INPUT, FACT_OUTPUT });
            param.TransactionTypes = transactionTypes;

            var organizations = new ArrayOfGuid();
            organizations.Add(departmentId);
            param.Organizations = organizations;

            var territories = new ArrayOfGuid();
            territories.AddRange(territoryIDs);
            param.Territories = territories;

            GuidResult eventSession = service.OpenEventHistorySession(sessionId, param);
            try
            {
                int eventCount = service.GetEventHistoryResultCount(sessionId, eventSession.Value);

                var fields = new ArrayOfGuid();
                fields.AddRange(new Guid[]
                    {
                        EVENT_PERSON_ID,
                        EVENT_DATE_TIME,
                        EVENT_CODE,
                        EVENT_TERRITORY
                    });

                var events = service.GetEventHistoryResult(sessionId, eventSession.Value, fields, 0, eventCount);
                var groups = events.GroupBy(evt => evt.Values[0].ToString());
                transactions = groups.ToDictionary(g => new Guid(g.Key), g => EventsToPeriods(g));
            }
            finally
            {
                service.CloseEventHistorySession(sessionId, eventSession.Value);
            }

            return transactions;
        }

        /// <summary>
        /// Преобразование списка событий во временной ряд
        /// </summary>
        /// <param name="eventObjects"></param>
        /// <returns></returns>
        public static List<WorkPeriod> EventsToPeriods(IEnumerable<EventObject> eventObjects)
        {
            List<WorkPeriod> allPeriods = new List<WorkPeriod>();
            //var events = eventObjects
            //    .Select(evt => new Tuple<DateTime, uint>(DateTime.ParseExact(evt.Values[1].ToString(), DateTimeFormat, null), uint.Parse(evt.Values[2].ToString())))
            //    .OrderBy(x => x.Item1)
            //    .ToArray();
            var events = eventObjects
                .Select(evt =>
                    new
                    {
                        DT = DateTime.ParseExact(evt.Values[1].ToString(), DateTimeFormat, null),
                        EventCode = uint.Parse(evt.Values[2].ToString()),
                        Post = evt.Values[3].ToString()
                    })
                .OrderBy(x => x.DT)
                .ToArray();
            DateTime? start = null, end = null;
            string inPost = null;
            for (int i = 0; i < events.Length; i++)
            {
                DateTime dt = events[i].DT;
                switch (events[i].EventCode)
                {
                    case NORMAL_INPUT:
                    case FACT_INPUT:
                        if (start != null)
                        {
                            if (end == null)
                                end = start.Value + millisecond;
                            var period = new WorkPeriod
                            {
                                InPost = inPost,
                                //IsEndUnknown = true,
                                Start = start.Value,
                                End = end.Value,
                                Data = new Period { Start = start.Value , End = end.Value}
                            };
                            allPeriods.Add(period);
                        }
                        start = dt;
                        inPost = events[i].Post;
                        end = null;
                        break;
                    case NORMAL_OUTPUT:
                    case FACT_OUTPUT:
                        if (end == null)
                        {
                            end = dt;
                            if (start != null)
                            {
                                var period = new WorkPeriod
                                {
                                    InPost = inPost,
                                    OutPost = events[i].Post,
                                    Start = start.Value,
                                    End = end.Value,
                                    Data = new Period { Start = start.Value, End = end.Value }
                                };
                                allPeriods.Add(period);
                                start = end = null;
                            }
                        }
                        else
                        {
                            if (start == null)
                                start = end.Value - millisecond;
                            var period = new WorkPeriod
                            {
                                OutPost = events[i].Post,
                                //IsStartUnknown = true,
                                Start = start.Value,
                                End = end.Value,
                                Data = new Period { Start = start.Value, End = end.Value }
                            };
                            allPeriods.Add(period);
                            start = null;
                            end = dt;
                        }
                        break;
                    default:
                        break;
                }
            }
            if (start != null || end != null)
            {
                if (start == null)
                {
                    start = end.Value - millisecond;
                    var period = new WorkPeriod
                    {
                        //IsStartUnknown = true,
                        Start = start.Value,
                        End = end.Value,
                        Data = new Period { Start = start.Value, End = end.Value }
                    };
                    allPeriods.Add(period);
                }
                else // if (end == null)
                {
                    end = start.Value + millisecond;
                    var period = new WorkPeriod
                    {
                        //IsEndUnknown = true,
                        Start = start.Value,
                        End = end.Value,
                        Data = new Period { Start = start.Value, End = end.Value }
                    };
                    allPeriods.Add(period);
                }
            }

            //// оставляем в результате кроме нормальных периодов только первый период с неизвестным входом и последний период с неизвестным выходом
            //allPeriods = allPeriods.Where(p => p.IsStartUnknown || p.IsEndUnknown || p.Duration() >= minEventDuration).ToList();
            //List<WorkPeriod> periods = new List<WorkPeriod>();
            //if (allPeriods.Count > 0)
            //{
            //    periods.Add(allPeriods[0]);
            //    periods.AddRange(allPeriods.Skip(1).Take(allPeriods.Count - 2).Where(p => !(p.IsStartUnknown || p.IsEndUnknown)));
            //    if (allPeriods.Count > 1)
            //        periods.Add(allPeriods[allPeriods.Count - 1]);
            //}
            //return periods;
            return allPeriods.Where(p => p.Duration() >= minEventDuration).ToList(); ;
        }

        const string DateTimeFormat = "dd.MM.yyyy H:mm:ss";

        // Миллисекунда
        static TimeSpan millisecond = new TimeSpan(0, 0, 0, 0, 1);

        // Минимальная длительность учитываемого периода = 10 минут
        static TimeSpan minEventDuration = new TimeSpan(0, 10, 0);

        //// Допустимый интервал между повторами событий = 1 минута
        //static TimeSpan eventDelta = new TimeSpan(0, 1, 0);

        // типы транзакций - константы в SDK Парсек:
        // - 590144 - Нормальный вход по ключу
        // - 590145 - Нормальный выход по ключу
        // - 590152 - Фактический вход
        // - 590153 - Фактический выход 
        const uint NORMAL_INPUT = 590144;
        const uint NORMAL_OUTPUT = 590145;
        const uint FACT_INPUT = 590152;
        const uint FACT_OUTPUT = 590153;

        // Типы полей для отбора транзакций - константы в SDK Парсек:
        // Идентификатор субъекта (PERS_ID - Guid)
        static Guid EVENT_PERSON_ID = new Guid("7C6D82A0-C8C8-495B-9728-357807193D23");
        // Дата + время в формате ДД.ММ.ГГГГ ЧЧ:ММ:СС
        static Guid EVENT_DATE_TIME = new Guid("2C5EE108-28E3-4dcc-8C95-7F3222D8E67F");
        // Тип события (код в 10-чной сист. счисления)
        static Guid EVENT_CODE = new Guid("57CA38E4-ED6F-4D12-ADCB-2FAA16F950D7");

        static Guid EVENT_TERRITORY = new Guid("633904b5-971b-4751-96a0-92dc03d5f616");

        /// <summary>
        /// Логин оператора Парсек
        /// </summary>
        static string ParsecOperatorName
        {
            get { return ConfigurationManager.AppSettings["ParsecOperatorName"]; }
        }

        /// <summary>
        /// Пароль оператора Парсек
        /// </summary>
        static string ParsecOperatorPassword
        {
            get { return ConfigurationManager.AppSettings["ParsecOperatorPassword"]; }
        }
    }
}
