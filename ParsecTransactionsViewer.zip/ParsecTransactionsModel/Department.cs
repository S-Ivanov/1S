﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParsecTransactionsModel
{
    /// <summary>
    /// Подразделение
    /// </summary>
    public class Department
    {
        /// <summary>
        /// Идентификатор подразделения из Парсек
        /// </summary>
        /// <remarks>значение поля [Parsec3].[dbo].[ORGANIZATION].[ORG_ID]</remarks>
        public Guid Id { get; set; }

        /// <summary>
        /// Наименование подразделения из Парсек
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Вложенные подразделения
        /// </summary>
        public List<Department> Childs { get; set; } = new List<Department>();
    }
}
