﻿using TimeLines;

namespace ParsecTransactionsModel
{
    public class WorkPeriod : Period<Period>
    {
        //public bool IsStartUnknown { get; set; }
        public string InPost { get; set; }
        //public bool IsEndUnknown { get; set; }
        public string OutPost { get; set; }
    }
}
