﻿using System;

namespace ParsecTransactionsModel
{
    public class IdName
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
