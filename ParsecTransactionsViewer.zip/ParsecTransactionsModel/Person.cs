﻿using System;
using System.Collections.Generic;

namespace ParsecTransactionsModel
{
    /// <summary>
    /// Работник
    /// </summary>
    public class Person
    {
        /// <summary>
        /// Идентификатор Парсек
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Табельный
        /// </summary>
        public string TabNum { get; set; }

        /// <summary>
        /// Фамилия
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Имя
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Отчество
        /// </summary>
        public string MiddleName { get; set; }

        // транзакции
        public List<WorkPeriod> Transactions { get; set; } = new List<WorkPeriod>();
    }
}
