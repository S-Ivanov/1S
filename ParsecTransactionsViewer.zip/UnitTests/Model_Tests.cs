﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParsecTransactionsModel;
using ParsecTransactionsModel.ParsecIntegrationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using TimeLines;

namespace ParsecTransactionsModel.Tests
{
    [TestClass()]
    public class Model_Tests
    {
        [TestMethod()]
        public void Model_LoadConfiguration_Test()
        {
            string fileName = @"..\..\..\ParsecTransactionsModel\Config.xml";
            Configuration.Config config = Model.LoadConfiguration(fileName);
            Assert.IsNotNull(config);
        }

        [TestMethod()]
        public void Model_LoadDepartments_Test()
        {
            Configuration.ConfigUser user = new Configuration.ConfigUser();
            user.Departments = new Configuration.IdObject[]
            {
                // ПАО "Дорогобуж"
                new Configuration.IdObject { Id = "C119418A-E549-475A-B9E6-E9EC361A2111" }
            };
            // исключая вложенные подразделения:
            user.ExcludeDepartments = new Configuration.IdObject[]
            {
                // Автотранспортный цех
                new Configuration.IdObject { Id = "E2C28529-99B0-4F63-913A-32853CB162A2" }
            };

            var departments = Model.LoadDepartments(user).ToArray();

            Assert.IsNotNull(departments);
        }

        [TestMethod()]
        public void Model_EventsToPeriods_Test()
        {
            EventObject[] eventObjects = new EventObject[]
            {
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 8:19:28", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:19:43", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:22:48", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:22:52", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:22:56", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:22:59", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:23:02", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:23:08", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:23:11", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:23:15", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:23:18", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:26:11", "590153" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:26:22", "590153" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:27:15", "590153" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:27:34", "590152" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:27:44", "590153" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:27:58", "590153" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:28:35", "590152" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:28:42", "590152" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:28:47", "590152" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:29:44", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:29:59", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:30:06", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:30:11", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:30:15", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:30:21", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:32:09", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:32:18", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:32:31", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:32:41", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:32:47", "590144" // вход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 10:55:03", "590145" // выход
                    }
                },
                new EventObject
                {
                    Values = new ArrayOfAnyType
                    {
                        "9f24e645-ec64-4547-9383-0583dd429c9d", "09.10.2017 11:33:09", "590144" // вход
                    }
                },
            };

            var periods = Model.EventsToPeriods(eventObjects);
            Assert.AreEqual(3, periods.Count);
        }

        [TestMethod()]
        public void Model_LoadPersons_Test()
        {
            // Центр информ.технологий
            Guid departmentId = new Guid("1B0034E4-07A8-4E86-8C0F-2FD25ABB214D");
            Guid[] excludePersonIDs = new Guid[] { };
            DateTime from = new DateTime(2017, 10, 30);
            DateTime to = from;
            var persons = Model.LoadPersons(territories, departmentId, excludePersonIDs, from, to);
            Assert.IsNotNull(persons);
        }

        [TestMethod()]
        public void Model_DepartmentsToJson_Test()
        {
            Department[] departments = new Department[]
            {
                new Department
                {
                    Id = Guid.NewGuid(),
                    Name = "gfgfggf",
                    Childs =
                    {
                        new Department { Id = Guid.NewGuid(), Name = "ffjfjh" },
                        new Department { Id = Guid.NewGuid(), Name = "bcbcbbc" },
                    }
                }
            };
            var serializer = new JavaScriptSerializer();
            serializer.RegisterConverters(new JavaScriptConverter[] { new DepartmentJavaScriptConverter() });
            string s = serializer.Serialize(departments);
            Assert.IsNotNull(s);
        }

        [TestMethod()]
        public void Model_LoadTransactions_Test()
        {
            // Центр информ. технологий
            Dictionary<Guid, List<WorkPeriod>> transactions = Model.LoadTransactions(territoryIDs, new Guid("1B0034E4-07A8-4E86-8C0F-2FD25ABB214D"), new DateTime(2017, 10, 30), new DateTime(2017, 10, 31));
            Assert.IsNotNull(transactions);
        }

        [TestMethod()]
        public void Model_GetTerritories_Test()
        {
            Territory[] territories = Model.GetTerritories();
            Assert.IsNotNull(territories);
        }

        [TestMethod()]
        public void Model_LoadPersonsJson_Test()
        {
            // Центр информ.технологий
            Guid departmentId = new Guid("1B0034E4-07A8-4E86-8C0F-2FD25ABB214D");
            Guid[] excludePersonIDs = new Guid[] { };
            DateTime from = new DateTime(2017, 10, 30);
            DateTime to = from;
            var persons = Model.LoadPersons(territories, departmentId, excludePersonIDs, from, to);
            Assert.IsNotNull(persons);

            var serializer = new JavaScriptSerializer();
            serializer.RegisterConverters(new JavaScriptConverter[] { new PersonJavaScriptConverter() });
            string json = serializer.Serialize(persons);
            Assert.IsNotNull(json);
        }

        [TestMethod()]
        public void TimeSpan_Test()
        {
            DateTime from = new DateTime(2017, 10, 30);
            DateTime to = from.AddHours(1.5);
            TimeSpan delta = to - from;
            string s = delta.ToString("hh\\:mm");
            Assert.IsNotNull(s);
        }

        Guid[] territoryIDs = new Guid[]
        {
            new Guid("9DDB6D7F-90A9-4AFE-8CC0-54429D6025F4"),
            new Guid("79179BD3-AC6C-4835-ADCD-EB99DEB43F98"),
            new Guid("DFEC19FE-4C29-4D3D-A391-AB3E073B3A73"),
            new Guid("E78AD206-1A77-48E1-8D3F-4080C7A504FB"),
            new Guid("B989E10C-06BB-4CA0-81F1-59A4B7B1C7B3"),
            new Guid("E02DDBBA-015E-4CC4-A53F-49CEAB4766F1"),
            new Guid("D2BB3967-300A-4429-96E2-77E37A5F0012"),
            new Guid("FF758905-D53B-4376-91A6-EDC76A53A568"),
            new Guid("02682A74-5258-4E40-A61E-243EA4062E43"),
            new Guid("FA737D76-19C4-4A0D-8F82-7749FCE2899D"),
            new Guid("7716215E-18D2-4B9D-BA03-4670448C8BFF"),
            new Guid("D0C88445-19E0-43A1-AD28-BBD72FB316DF"),
            new Guid("223BBDEE-D4B0-4745-8EC6-294180B4CF6F"),
        };

        IdName[] territories = new IdName[]
        {
            new IdName { Id = new Guid("9DDB6D7F-90A9-4AFE-8CC0-54429D6025F4"), Name = "ЖДЦ" },
            new IdName { Id = new Guid("79179BD3-AC6C-4835-ADCD-EB99DEB43F98"), Name = "Пост №1" },
            new IdName { Id = new Guid("DFEC19FE-4C29-4D3D-A391-AB3E073B3A73"), Name = "Пост №1" },
            new IdName { Id = new Guid("E78AD206-1A77-48E1-8D3F-4080C7A504FB"), Name = "Пост №1" },
            new IdName { Id = new Guid("B989E10C-06BB-4CA0-81F1-59A4B7B1C7B3"), Name = "Пост №2" },
            new IdName { Id = new Guid("E02DDBBA-015E-4CC4-A53F-49CEAB4766F1"), Name = "Пост №2" },
            new IdName { Id = new Guid("D2BB3967-300A-4429-96E2-77E37A5F0012"), Name = "Пост №3" },
            new IdName { Id = new Guid("FF758905-D53B-4376-91A6-EDC76A53A568"), Name = "Пост №3" },
            new IdName { Id = new Guid("02682A74-5258-4E40-A61E-243EA4062E43"), Name = "Пост №3" },
            new IdName { Id = new Guid("FA737D76-19C4-4A0D-8F82-7749FCE2899D"), Name = "Шлагбаум №4" },
            new IdName { Id = new Guid("7716215E-18D2-4B9D-BA03-4670448C8BFF"), Name = "Пост №5" },
            new IdName { Id = new Guid("D0C88445-19E0-43A1-AD28-BBD72FB316DF"), Name = "Пост №5" },
            new IdName { Id = new Guid("223BBDEE-D4B0-4745-8EC6-294180B4CF6F"), Name = "УНПСВ" },
        };
    }

    public class DepartmentJavaScriptConverter : JavaScriptConverter
    {
        public override IEnumerable<Type> SupportedTypes
        {
            get
            {
                return new Type[] { typeof(Department) };
            }
        }

        public override object Deserialize(IDictionary<string, object> dictionary, Type type, JavaScriptSerializer serializer)
        {
            throw new NotImplementedException();
        }

        public override IDictionary<string, object> Serialize(object obj, JavaScriptSerializer serializer)
        {
            Department department = obj as Department;
            if (department == null)
                return new Dictionary<string, object>();
            else
            {
                Dictionary<string, object> result = new Dictionary<string, object>();
                result.Add("id", department.Id);
                result.Add("text", department.Name);
                if (department.Childs.Count != 0)
                {
                    //result.Add("children", serializer.Serialize(department.Childs.ToArray()));
                    result.Add("children", department.Childs.ToArray());
                }
                return result;
            }
        }
    }

    public class PersonJavaScriptConverter : JavaScriptConverter
    {
        public override IEnumerable<Type> SupportedTypes
        {
            get
            {
                return new Type[] { typeof(ParsecTransactionsModel.Person) };
            }
        }

        public override object Deserialize(IDictionary<string, object> dictionary, Type type, JavaScriptSerializer serializer)
        {
            throw new NotImplementedException();
        }

        public override IDictionary<string, object> Serialize(object obj, JavaScriptSerializer serializer)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();
            if (obj is ParsecTransactionsModel.Person)
            {
                ParsecTransactionsModel.Person person = obj as ParsecTransactionsModel.Person;
                result.Add("id", id);
                id++;
                result.Add("tn", person.TabNum);
                result.Add("name", person.LastName + " " + person.FirstName + " " + person.MiddleName);
                if (person.Transactions.Count == 1)
                {
                    WorkPeriod workPeriod = person.Transactions[0];
                    result.Add("inpost", workPeriod.InPost);
                    result.Add("input", workPeriod.Start != workPeriod.Data.Start ? "..." : workPeriod.Start.ToString(TIME_FORMAT));
                    result.Add("outpost", workPeriod.OutPost);
                    result.Add("output", workPeriod.End != workPeriod.Data.End ? "..." : workPeriod.End.ToString(TIME_FORMAT));

                    AddDuration(result, workPeriod);
                }
                else
                {
                    // первый и последний периоды
                    WorkPeriod firstWorkPeriod = person.Transactions.First();
                    result.Add("inpost", firstWorkPeriod.InPost);
                    result.Add("input", firstWorkPeriod.Start != firstWorkPeriod.Data.Start ? "..." : firstWorkPeriod.Start.ToString(TIME_FORMAT));

                    WorkPeriod lastWorkPeriod = person.Transactions.Last();
                    result.Add("outpost", lastWorkPeriod.OutPost);
                    result.Add("output", lastWorkPeriod.End != lastWorkPeriod.Data.End ? "..." : lastWorkPeriod.End.ToString(TIME_FORMAT));

                    // суммарная длительность ?
                }
            }
            else
            {
                // периоды
            }

            return result;
        }

        void AddDuration(Dictionary<string, object> dict, WorkPeriod workPeriod)
        {
            Period period = workPeriod.Data;
            if (workPeriod.Start != period.Start && workPeriod.End != period.End)
            {
                if (period.Start != DateTime.MinValue && period.End != DateTime.MaxValue)
                {
                    dict.Add("duration", string.Format("{0:hh\\:mm} ({1:hh\\:mm})", workPeriod.Duration(), period.Duration()));
                    dict.Add("duration2", string.Format("{0:F2} ({1:F2})", workPeriod.Duration(), period.Duration()));
                }
            }
            else if (workPeriod.Start != period.Start)
            {
                if (period.Start != DateTime.MinValue)
                {
                    dict.Add("duration", string.Format("{0:hh\\:mm} ({1:hh\\:mm})", workPeriod.Duration(), period.Duration()));
                    dict.Add("duration2", string.Format("{0:F2} ({1:F2})", workPeriod.Duration(), period.Duration()));
                }
            }
            else if (workPeriod.End != period.End)
            {
                if (period.End != DateTime.MaxValue)
                {
                    dict.Add("duration", string.Format("{0:hh\\:mm} ({1:hh\\:mm})", workPeriod.Duration(), period.Duration()));
                    dict.Add("duration2", string.Format("{0:F2} ({1:F2})", workPeriod.Duration(), period.Duration()));
                }
            }
            else
            {
                dict.Add("duration", string.Format("{0:hh\\:mm}", workPeriod.Duration()));
                dict.Add("duration2", string.Format("{0:F2}", workPeriod.Duration().TotalHours));
            }
        }

        int id = 1;

        const string TIME_FORMAT = "HH:mm:ss";
        //const string DURATION_FORMAT = "hh\\:mm";
    }
}