﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public class SearchResult
    {
        public string MedicamentName { get; set; }
        public string CompanyName { get; set; }
        public string CountryName { get; set; }
        public string FormName { get; set; }
        public decimal Count { get; set; }
        public string Pharmacy { get; set; }
        public string Address { get; set; }
        public decimal Price { get; set; }
    }
}