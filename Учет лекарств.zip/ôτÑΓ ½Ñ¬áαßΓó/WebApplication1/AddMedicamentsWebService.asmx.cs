﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication1
{
    /// <summary>
    /// Сводное описание для AddMedicamentsWebService
    /// </summary>
    [WebService(Namespace = "http://zxzxmolchanov.com/medicaments/soap/add")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Чтобы разрешить вызывать веб-службу из скрипта с помощью ASP.NET AJAX, раскомментируйте следующую строку. 
    // [System.Web.Script.Services.ScriptService]
    public class AddMedicamentsWebService : System.Web.Services.WebService
    {
        [WebMethod]
        //public void AddMedicaments(MedicamentsData medicamentsData)
        public void AddMedicaments(string medicamentsXml)
        {
        }

        [WebMethod]
        public IdNameObject[] GetDosageForms()
        {
            return null;
        }

        [WebMethod]
        public IdNameObject[] GetPharmacologicalClassifier()
        {
            return null;
        }

        [WebMethod]
        public PharmacyShopInfo[] GetPharmacyShopsByUser()
        {
            return null;
        }

    }
}
