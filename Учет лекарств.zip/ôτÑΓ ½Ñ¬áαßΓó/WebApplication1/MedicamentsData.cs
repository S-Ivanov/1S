﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public class MedicamentsData
    {
        /// <summary>
        /// Идентификатор точки продажи
        /// </summary>
        public int PharmacyShopId { get; set; }

        /// <summary>
        /// Производители, участвующие в передаче данных
        /// </summary>
        public Company[] Companies { get; set; }

        /// <summary>
        /// Медикаменты, участвующие в передаче данных
        /// </summary>
        public Medicament[] Medicaments { get; set; }

        /// <summary>
        /// Формы лекарственных средств, участвующие в передаче данных
        /// </summary>
        public IdNameObject[] DosageForms { get; set; }

        /// <summary>
        /// Передаваемые данные
        /// </summary>
        public DataItem[] Data { get; set; }
    }

    public class DataItem
    {
        public string MedicamentId { get; set; }
        public string CompanyId { get; set; }
        public string DosageFormId { get; set; }
        public decimal Count { get; set; }
        public decimal Price { get; set; }
    }

    public class IdNameObject
    {
        /// <summary>
        /// Внутренний код
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }
    }

    /// <summary>
    /// Медикамент
    /// </summary>
    public class Medicament : IdNameObject
    {
        /// <summary>
        /// Код фармакологического классификатора
        /// </summary>
        public string PharmacologyId { get; set; }
    }

    public class Company : IdNameObject
    {
        /// <summary>
        /// Код страны по ОКСМ
        /// </summary>
        public int CountryCode { get; set; }

        public string Address { get; set; }
    }

    public class PharmacyShopInfo
    {
        /// <summary>
        /// Идентификатор точки продажи
        /// </summary>
        public int PharmacyShopId { get; set; }

        public string PharmacyName { get; set; }

        public string Address { get; set; }

        public string Phones { get; set; }
    }
}