<?php
include "DataModel/DataBase.php";

$result = [];
if (isset($_POST["fname"]))
    $result["rows"] = (new DataBase())->Search([ "NameMask" => $_POST["fname"] ]);
echo json_encode($result);
?>