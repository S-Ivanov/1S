<?php
require_once ('XmlDataProcessorBase.php');
require_once ('Guid.php');

class XmlDataProcessorData extends XmlDataProcessorBase
{
    public function __construct(
        mysqli $dataBase, 
        int $queryMaxSize, 
        XmlDataProcessorBase $companiesProcessor,
        XmlDataProcessorBase $dosageformsProcessor,
        XmlDataProcessorBase $medicamentsProcessor)
    {
        parent::__construct($dataBase, $queryMaxSize);
        
        $this->companiesProcessor = $companiesProcessor;
        $this->dosageformsProcessor = $dosageformsProcessor;
        $this->medicamentsProcessor = $medicamentsProcessor;
    }

    protected function GetProcessingXmlNodeName() : string
    {
        return "DataItem";
    }

    protected function GetData(XMLReader &$reader) : array
    {
        return [
            "CompanyId" => strtoupper($reader->getAttribute("CompanyId")),
            "DosageFormId" => $reader->getAttribute("DosageFormId"),
            "MedicamentId" => strtoupper($reader->getAttribute("MedicamentId")),
            "Count" => floatval($reader->getAttribute("Count")),
            "Price" => floatval($reader->getAttribute("Price")),
        ];
    }

    protected function GetSqlTableName() : string
    {
        return "medicamentsforsale";
    }
    
    protected function GetSqlTableFields() : string
    {
        return "";
    }

    protected function GetInsertFields() : string
    {
        return "Id, MedicamentId, CompanyId, DosageFormId, Count, PharmacyShopId, Price";
    }
    
    protected function GetInsertValues(array &$dataItem) : array
    {
        if (in_array($dataItem['CompanyId'], $this->companiesProcessor->idMap)) {
            $dataItem['CompanyId'] = $this->companiesProcessor->idMap[$dataItem['CompanyId']];
        }
        if (in_array($dataItem['DosageFormId'], $this->dosageformsProcessor->idMap)) {
            $dataItem['DosageFormId'] = $this->dosageformsProcessor->idMap[$dataItem['DosageFormId']];
        }
        if (in_array($dataItem['MedicamentId'], $this->medicamentsProcessor->idMap)) {
            $dataItem['MedicamentId'] = $this->medicamentsProcessor->idMap[$dataItem['MedicamentId']];
        }
        return [ 
            strtoupper(GUIDv4()), 
            $dataItem['MedicamentId'], 
            $dataItem['CompanyId'], 
            $dataItem['DosageFormId'], 
            $dataItem['Count'], 
            $this->PharmacyShopId, 
            $dataItem['Price'] ];
    }
    
    protected function GetSqlTableLogicalKey() : string
    {
        return "";
    }
    
    protected function GetLogicalKeyString(array &$dataItem) : string
    {
        return "";
    }
    
    protected function CompareKeys(array &$dbDataItem, array &$dataItem) : int
    {
        return 0;
    }
    
    protected function GetIdMapRow(array &$dbDataItem, array &$dataItem) : array
    {
        return NULL;
    }
    
    protected function BeforeInsert() : void
    {
        $this->dataBase->query("delete from medicamentsforsale where PharmacyShopId = $this->PharmacyShopId");
    }
    
    
    public $PharmacyShopId;
    
    private $companiesProcessor;
    private $dosageformsProcessor;
    private $medicamentsProcessor;
}

