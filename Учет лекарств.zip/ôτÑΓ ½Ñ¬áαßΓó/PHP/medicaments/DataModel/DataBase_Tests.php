<?php
//include "DataBase.php";
require_once ('DataModel/DataBase.php');

//$resultData = (new DataBase())->Search([ "NameMask" => "ана" ]);

//$resultData = (new DataBase())->GetDosageForms();

//$resultData = (new DataBase())->GetPharmacyShopsByUser("alex", "alex123");

//$resultData = (new DataBase())->LoadCountryCodes();

//var_dump($resultData);

/*
$xml = '<?xml version="1.0"?>
<step number="9">
  <s_name>test</s_name>
  <b_sel>12345</b_sel>
  <b_ind>7</b_ind>
</step>';

$obj = simplexml_load_string($xml);

var_dump($obj);
*/

$xml = '<?xml version="1.0" encoding="utf-8"?>
<Medicaments PharmacyShopId="2">
  <Companies>
    <Company Id="00F1B332-8536-43F0-9FA3-5C575AAC5CD9" Name="meda Pharma GmbH &amp; Co.KG" CountryCode="276" />
    <Company Id="1F8FEA61-282A-49B2-84D8-045D351E49C5" Name="test" CountryCode="643" Address="Адрес" />
    <Company Id="D4E14277-815A-4A74-8C29-237AEF9EEFF4" Name="test-2" CountryCode="643" Address="Адрес-2" />
    <Company Id="2BBAB70A-F0D3-4B0A-B322-0E2329F82CA1" Name="test-3" CountryCode="643" Address="Адрес-3" />
  </Companies>
  <MedicamentsReference>
    <Medicament Id="00AD9EF8-546A-470C-92AD-8823824AD401" Name="Гуанексил" PharmacologyId="1.1.4" />
    <Medicament Id="08F2C3FD-C2A2-4CCC-A45B-80FCAE148F41" Name="Гексопреналин" PharmacologyId="1.2.3" />
    <Medicament Id="EBCC692C-B0C9-422E-BCAA-2D1BE3FD28BC" Name="Гепарин" PharmacologyId="2.2" />
    <Medicament Id="DD2D30C2-CCA9-4211-BEBC-EE47CED1F8F3" Name="Гирудин" PharmacologyId="2.2" />
  </MedicamentsReference>
  <DosageForms>
    <DosageForm Id="1" Name="Таблетки" />
    <DosageForm Id="2" Name="Жидкость" />
  </DosageForms>
  <Data>
    <DataItem MedicamentId="00AD9EF8-546A-470C-92AD-8823824AD401" CompanyId="00F1B332-8536-43F0-9FA3-5C575AAC5CD9" DosageFormId="1" Count="100" Price="123.45" />
    <DataItem MedicamentId="08F2C3FD-C2A2-4CCC-A45B-80FCAE148F41" CompanyId="00F1B332-8536-43F0-9FA3-5C575AAC5CD9" DosageFormId="2" Count="50" Price="234.5" />
  </Data>
</Medicaments>';

/*
 * SHOW VARIABLES LIKE 'max_allowed_packet'
 * 
$reader = new XMLReader();
$reader->xml($xml);

while ($reader->read()) {
    if ($reader->nodeType == XMLReader::END_ELEMENT) {
        continue; //skips the rest of the code in this iteration
    }
    //do something with desired node type
    if ($reader->name == 'Company') {
        $name = $reader->getAttribute("Name");
        print($name); print("\n");
    }
}
*/

(new DataBase())->AddMedicamentsXML("alex", "alex123", $xml, "Medicaments.xsd");

print("Ok");

?>