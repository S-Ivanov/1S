<?php

require_once ('XmlDataProcessorBase.php');

class XmlDataProcessorCompanies extends XmlDataProcessorBase
{
    public function __construct(mysqli $dataBase, int $queryMaxSize) 
    {
        parent::__construct($dataBase, $queryMaxSize);
    }
    
    protected function GetProcessingXmlNodeName() : string 
    {
        return "Company";
    }
    
    protected function GetData(XMLReader &$reader) : array 
    {
        return [
            "Id" => strtoupper($reader->getAttribute("Id")),
            "Name" => $reader->getAttribute("Name"),
            "CountryCode" => $reader->getAttribute("CountryCode"),
            "Address" => $reader->getAttribute("Address")
        ];
    }

    protected function GetSqlTableName() : string 
    {
        return "companies";
    }
    
    protected function GetSqlTableFields() : string 
    {
        return "Id, Name, CountryCode";
    }
    
    protected function GetInsertFields() : string 
    {
        return "Id, Name, CountryCode, Address";
    }
    
    protected function GetInsertValues(array &$dataItem) : array 
    {
        return [ $dataItem['Id'], $dataItem['Name'], $dataItem['CountryCode'], $dataItem['Address'] ];
    }
    
    protected function GetSqlTableLogicalKey() : string 
    {
        return "CONCAT(Name, '^', CountryCode)";
    }

    protected function GetLogicalKeyString(array &$dataItem) : string 
    {
        return $dataItem["Name"] . "^" . $dataItem["CountryCode"];
    }

    protected function CompareKeys(array &$dbDataItem, array &$dataItem) : int 
    {
        if (strcasecmp($dbDataItem["Name"], $dataItem["Name"]) == 0 && $dbDataItem["CountryCode"] == $dataItem["CountryCode"]) {
            return strcasecmp($dbDataItem["Id"], $dataItem["Id"]) == 0 ? 0 : 1;
        }
        else 
            return -1;
    }
    
    protected function GetIdMapRow(array &$dbDataItem, array &$dataItem) : array 
    {
        return [ $dataItem["Id"] => $dbDataItem["Id"] ];
    }
}

