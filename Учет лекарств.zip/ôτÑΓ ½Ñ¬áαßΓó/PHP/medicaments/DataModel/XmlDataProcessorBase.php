<?php

/**
 * Обработка узлов XML - базовый класс
 */
abstract class XmlDataProcessorBase
{
    /**
     * Конструктор
     * @param mysqli $dataBase База данных
     * @param int $queryMaxSize Максимальный размер запроса к БД
     */
    public function __construct(mysqli $dataBase, int $queryMaxSize) {
        $this->dataBase = $dataBase;
        $this->queryMaxSize = $queryMaxSize;
        $this->data = [];
        $this->idMap = [];
    }
    
    /**
     * Полученные из XML данные, которые нужно добавить в БД
     * @var array
     */
    public $data;
    
    /**
     * Таблица соответствия между идентификаторами записей в исходном XML 
     * и идентификаторами соответствующих записей в БД
     * @var array
     */
    public $idMap;
    
    /**
     * Имя XML-узла, который может быть обработан
     * @return string
     */
    protected abstract function GetProcessingXmlNodeName() : string;
    
    /**
     * Преобразование данных XML-узла в ассоциативный массив
     * @param XMLReader $reader
     * @return array
     */
    protected abstract function GetData(XMLReader &$reader) : array;
    
    /**
     * Имя таблицы в БД
     * @return string
     */
    protected abstract function GetSqlTableName() : string;
    
    /**
     * Список полей таблицы БД для выборки данных
     * @return string
     */
    protected abstract function GetSqlTableFields() : string;
    
    /**
     * Список полей таблицы БД для добавления данных
     * @return string
     */
    protected abstract function GetInsertFields() : string;
    
    /**
     * SQL-выражение для выборки логического ключа 
     * @return string
     */
    protected abstract function GetSqlTableLogicalKey() : string;
    
    /**
     * Преобразование записи данных в строковое представление логического ключа
     * @param array $dataItem
     * @return string
     */
    protected abstract function GetLogicalKeyString(array &$dataItem) : string;
    
    /**
     * Сравнение записи из базы данных с исходной записью из XML  
     * @param array $dbDataItem Запись из базы данных 
     * @param array $dataItem Исходная запись из XML
     * @return int -1 - записи не совпадают; 0 - точное совпадение; 1 - примерное совпадение
     */
    protected abstract function CompareKeys(array &$dbDataItem, array &$dataItem) : int;
    
    /**
     * Формирование записи для таблицы соответствия идентификатров
     * @param array $dbDataItem Запись из базы данных 
     * @param array $dataItem Исходная запись из XML
     * @return array 
     *      Ассоциативный массив из одного элемента, где ключ - идентификатор записи из XML, 
     *      а значение - идентификатор записи из БД 
     */
    protected abstract function GetIdMapRow(array &$dbDataItem, array &$dataItem) : array;
    
    /**
     * Преобразование записи данных в набор данных для добавления в БД
     * @param array $dataItem
     * @return array 
     */
    protected abstract function GetInsertValues(array &$dataItem) : array;
    
    /**
     * Действия перед записью подготовленных данных
     */
    protected function BeforeInsert() : void
    {
    }
    
    /**
     * Попытка добавить информацию из XML
     * @param array $reader Исходная запись из XML
     * @return bool TRUE - если запись удалось добавить, FALSE - в противном случае 
     */
    function AddXmlNode(XMLReader &$reader) : bool 
    {
        if ($reader->name == $this->GetProcessingXmlNodeName()) {
            $this->data[] = $this->GetData($reader);
            return TRUE;
        }
        else {
            return FALSE;
        }
    }
    
    /**
     * Обработка данных. В результате обработки массив $data содержит записи, которые были добавлены в БД,
     * а массив $idMap содержит таблицу соответствий идентификаторов
     */
    function Process() : void 
    {
        $tableFields = $this->GetSqlTableFields();
        if (isset($tableFields)) {
            
            $selectBegin = "SELECT " . $tableFields . " FROM " . $this->GetSqlTableName() . " WHERE " . $this->GetSqlTableLogicalKey() . " IN ('";
            $selectEnd = "')";
            $select = $selectBegin;
            $selectStart = TRUE;
            
            foreach ($this->data as $dataItem) {
                $key = $this->GetLogicalKeyString($dataItem);
                
                if (strlen($key) < $this->queryMaxSize - strlen($select) - strlen($selectEnd) - 1) {
                    if (!$selectStart) {
                        $select .= "','";
                    }
                    $selectStart = FALSE;
                    $select .= $key;
                }
                else {
                    $select .= $selectEnd;
                    // выборка из базы данных
                    $this->ProcessSelect($select);
                    // повторить построение запроса к БД
                    $select = $selectBegin;
                    $selectStart = TRUE;
                }
            }
            if (!$selectStart) {
                $select .= $selectEnd;
                // выборка из базы данных
                $this->ProcessSelect($select);
            }
        }
        
        $this->BeforeInsert();
        
        // записать в БД данные из массива $data
        $insertBegin = "INSERT INTO " . $this->GetSqlTableName() . " (" . $this->GetInsertFields() . ") VALUES ";
        $insert = $insertBegin;
        $insertStart = TRUE;
        foreach ($this->data as $dataItem) {
            $insertValues = $this->GetInsertValues($dataItem);
            if (isset($insertValues)) {
                
                $insertValuesString = "";
                foreach ($insertValues as $value) {
                    $valueString = $value == NULL ? "NULL" : "'$value'";
                    if ($insertValuesString != "") {
                        $insertValuesString .= ",";
                    }
                    $insertValuesString .= $valueString;
                }
                
                if (strlen($insertValuesString) < $this->queryMaxSize - strlen($insert) - 3 - 1) {
                    if (!$insertStart) {
                        $insert .= ",";
                    }
                    $insertStart = FALSE;
                    $insert .= "(" . $insertValuesString . ")";
                }
                else {
                    // добавление записей в базу данных
                    $this->dataBase->query($insert);
                    // повторить построение запроса к БД
                    $insert = $insertBegin;
                    $insertStart = TRUE;
                }
            }
        }
        if (!$insertStart) {
            // добавление записей в базу данных
            $this->dataBase->query($insert);
        }
    }

    /**
     * Обработка блока данных из БД
     * @param string $query Текст запроса для выборки блока данных
     */
    private function ProcessSelect(string $query) : void
    {
        if ($result = $this->dataBase->query($query)) {
            
            $deleteIndexes = [];
            
            while ($row = $result->fetch_assoc()) {
                for ($i = 0, $size = count($this->data); $i < $size; $i++) {
                    $dataItem = $this->data[$i];
                    $compareKeysResult = $this->CompareKeys($row, $dataItem);
                    if ($compareKeysResult >= 0) {
                        if ($compareKeysResult > 0) {
                            $idMapRow = $this->GetIdMapRow($row, $dataItem);
                            $this->idMap[] = $idMapRow;
                        }

                        if (!in_array($i, $deleteIndexes)) {
                            $deleteIndexes[] = $i;
                        }
                    }
                }
            }
            
            $result->close();
            
            foreach ($deleteIndexes as $index) {
                unset($this->data[$index]);
            }
        }
    }
    
    /**
     * Максимальный размер запроса к БД
     * @var int
     */
    private $queryMaxSize;
    
    /**
     * База данных
     * @var mysqli
     */
    protected $dataBase;
}

