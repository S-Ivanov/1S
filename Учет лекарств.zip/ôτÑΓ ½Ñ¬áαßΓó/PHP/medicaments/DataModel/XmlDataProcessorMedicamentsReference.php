<?php
require_once ('XmlDataProcessorBase.php');

class XmlDataProcessorMedicamentsReference extends XmlDataProcessorBase
{
    public function __construct(mysqli $dataBase, int $queryMaxSize)
    {
        parent::__construct($dataBase, $queryMaxSize);
    }

    protected function GetProcessingXmlNodeName() : string
    {
        return "Medicament";
    }
    
    protected function GetData(XMLReader &$reader) : array
    {
        return [
            "Id" => strtoupper($reader->getAttribute("Id")),
            "Name" => $reader->getAttribute("Name"),
            "PharmacologyId" => $reader->getAttribute("PharmacologyId")
        ];
    }
    
    protected function GetSqlTableName() : string
    {
        return "medicaments";
    }
    
    protected function GetSqlTableFields() : string
    {
        return "Id, Name, PharmacologyId";
    }
    
    protected function GetInsertFields() : string
    {
        return "Id, Name, PharmacologyId";
    }
    
    protected function GetInsertValues(array &$dataItem) : array
    {
        return [ $dataItem['Id'], $dataItem['Name'], $dataItem['PharmacologyId'] ];
    }
    
    protected function GetSqlTableLogicalKey() : string
    {
        return "CONCAT(Name, '^', PharmacologyId)";
    }
    
    protected function GetLogicalKeyString(array &$dataItem) : string
    {
        return $dataItem["Name"] . "^" . $dataItem["PharmacologyId"];
    }
    
    protected function CompareKeys(array &$dbDataItem, array &$dataItem) : int
    {
        if (strcasecmp($dbDataItem["Name"], $dataItem["Name"]) == 0 && strcasecmp($dbDataItem["PharmacologyId"], $dataItem["PharmacologyId"]) == 0) {
            return strcasecmp($dbDataItem["Id"], $dataItem["Id"]) == 0 ? 0 : 1;
        }
        else
            return -1;
    }
    
    protected function GetIdMapRow(array &$dbDataItem, array &$dataItem) : array
    {
        return [ $dataItem["Id"] => $dbDataItem["Id"] ];
    }
}

