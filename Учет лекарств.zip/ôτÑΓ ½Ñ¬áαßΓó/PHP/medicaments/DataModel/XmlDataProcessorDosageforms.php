<?php
require_once ('XmlDataProcessorBase.php');

class XmlDataProcessorDosageforms extends XmlDataProcessorBase
{
    public function __construct(mysqli &$dataBase, int &$queryMaxSize)
    {
        parent::__construct($dataBase, $queryMaxSize);
    }

    protected function GetIdMapRow(array &$dbDataItem, array &$dataItem) : array
    {
        return [ $dataItem["Id"] => $dbDataItem["Id"] ];
    }
    
    protected function GetLogicalKeyString(array &$dataItem) : string
    {
        return $dataItem["Name"];
    }

    protected function GetData(XMLReader &$reader) : array
    {
        return [
            "Id" => $reader->getAttribute("Id"),
            "Name" => $reader->getAttribute("Name")
        ];
    }

    protected function GetInsertFields() : string
    {
        return "Id, Name";
    }
    
    protected function GetInsertValues(array &$dataItem) : array
    {
        return [ $dataItem['Id'], $dataItem['Name'] ];
    }

    protected function GetSqlTableName() : string
    {
        return "dosageforms";
    }

    protected function CompareKeys(array &$dbDataItem, array &$dataItem) : int
    {
        if (strcasecmp($dbDataItem["Name"], $dataItem["Name"]) == 0) {
            return strcasecmp($dbDataItem["Id"], $dataItem["Id"]) == 0 ? 0 : 1;
        }
        else
            return -1;
    }

    protected function GetSqlTableFields() : string
    {
        return "Id, Name";
    }

    protected function GetSqlTableLogicalKey() : string
    {
        return "Name";
    }
    
    protected function GetProcessingXmlNodeName() : string
    {
        return "DosageForm";
    }
}

