<?php

include "XmlDataProcessorCompanies.php";
include "XmlDataProcessorDosageforms.php";
include "XmlDataProcessorMedicamentsReference.php";
include "XmlDataProcessorData.php";

/**
 * Работа с базой данных
 */
class DataBase
{
    /**
     * Конструктор
     * @param string $host Сервер
     * @param string $database Имя базы данных
     * @param string $user Логин 
     * @param string $password Пароль
     */
    function __construct($host = "localhost", $database = "medicaments", $user = "root", $password = "")
    {
        $this->db = new mysqli($host, $user, $password, $database);
        
        // указание серверу MySql работать с кодировкой UTF-8
        $this->db->query("SET NAMES utf8");
        
        // определить максимальный размер запроса к БД
        $this->queryMaxSize = intval($this->LoadData("SHOW VARIABLES LIKE 'max_allowed_packet'")[0]["Value"]);
        
    }
    
    /**
     * Добавление лекарств
     *
     * @param string $login Логин - регистронезависимый
     * @param string $password Пароль - регистрозависимый
     * @param object $xml Данные для добавления в виде xml-строки
     * @param object $schemaFilename Имя файла xsd-схемы для проверки xml - опционально
     */
    function AddMedicamentsXML(string $login, string $password, string $xml, string $schemaFilename = "") {
        
        $xmlDataProcessors = [
            // процессор для обработки справочника компаний
            new XmlDataProcessorCompanies($this->db, $this->queryMaxSize),
            // процессор для обработки справочника лекарственных форм
            new XmlDataProcessorDosageforms($this->db, $this->queryMaxSize),
            // процессор для обработки справочника лекарственных средств
            new XmlDataProcessorMedicamentsReference($this->db, $this->queryMaxSize)
        ];
        // процессор для обработки блока данных о наличии лекарственных средств
        $xmlDataProcessors[3] = new XmlDataProcessorData($this->db, $this->queryMaxSize, $xmlDataProcessors[0], $xmlDataProcessors[1], $xmlDataProcessors[2]);
        
        // создать объект для построчного чтения XML
        $reader = new XMLReader();
        // подключить исходный xml-файл
        $reader->xml($xml);
        
        // если указано, подключить xsd-схему для проверки корректности входного xml
        if (isset($schemaFilename)) {
            $reader->setSchema($schemaFilename);
        }
        
        while ($reader->read()) {
            if ($reader->nodeType == XMLReader::END_ELEMENT) {
                continue;
            }
            else if ($reader->name == "Medicaments") {
                // зафиксировать код точки продажи
                $pharmacyShopId = $reader->getAttribute("PharmacyShopId");
                
                // проверить доступность точки продажи
                $pharmacyShopsByUser = $this->GetPharmacyShopsByUser($login, $password);
                if (array_search($pharmacyShopId, array_column($pharmacyShopsByUser, "PharmacyShopId")) == NULL)
                {
                    throw new Exception("Не найден идентификатор пункта продаж");
                }
                
                // запомнить код точки продажи в процессор данных для последующей записи в БД
                $xmlDataProcessors[3]->PharmacyShopId = $pharmacyShopId;
            }
            else {
                foreach ($xmlDataProcessors as $xmlDataProcessor) {
                    if ($xmlDataProcessor->AddXmlNode($reader)) {
                        break;
                    }
                }
            }
        }

        // все действия, связанные с БД, выполняем в контексте транзакции
        $this->db->begin_transaction();
        
        try
        {
            foreach ($xmlDataProcessors as $xmlDataProcessor) {
                $xmlDataProcessor->Process();
            }
            
            $this->db->commit();
        }
        catch (Exception $e)
        {
            $this->db->rollback();
            throw $e;
        }
    }
    
    /**
     * Универсальная загрузка данных в виде массива записей, где каждая запись - ассоциативный массив
     * @param string $selectCommand SELECT-выражение
     * @return array
     */
    function LoadData($selectCommand)
    {
        return DataBase::LoadDataToArray($this->db, $selectCommand);
    }

    /**
     * Универсальная загрузка данных в виде массива записей, где каждая запись - ассоциативный массив
     * @param object $db База данных
     * @param string $selectCommand SELECT-выражение
     * @return array
     */
    static function LoadDataToArray(&$db, $selectCommand)
    {
        if ($result = $db->query($selectCommand))
            return $result->fetch_all(MYSQLI_ASSOC);
        else
            return [];
    }
    
    /**
     * Получить список лекарственных форм
     * 
     * @return array Массив записей, каждая запись - ассоциативный массив
     * <p>
     *      Состав записи (ключи):
     *      - Id - string - идентификатор
     *      - Name - string - наименование лекарственной формы
     * </p>
     */
    function GetDosageForms()
    {
        return $this->LoadData("select Id, Name from dosageforms");
    }
    
    /**
     * Получить фармакологическую классификацию
     * 
     * @return array Массив записей, каждая запись - ассоциативный массив
     * <p>
     *      Состав записи (ключи):
     *      - Id - string - идентификатор
     *      - Name - string - наименование лекарственной формы
     * </p>
     */
    function GetPharmacologicalClassifier()
    {
        return $this->LoadData("select Id, Name from pharmacologicalhierarchy");
    }
    
    /**
     * Получить список доступных пользователю пунктов продаж
     * 
     * @param string $login Логин - регистронезависимый
     * @param string $password Пароль - регистрозависимый
     * @return array Массив записей, каждая запись - ассоциативный массив
     * <p>
     *      Состав записи (ключи):
     *      - PharmacyShopId - int - идентификатор пункта продажи
     *      - PharmacyName - string - наименование аптеки
     *      - Address - string - адрес пункта продажи
     *      - Phones - string - телефоны
     * </p>
     */
    function GetPharmacyShopsByUser($login, $password)
    {
        $sql = 
"SELECT 
    ps.Id as PharmacyShopId, 
    p.Name as PharmacyName, 
    ps.Address as Address, 
    ps.Phones as Phones
FROM 
	users u inner JOIN
    users_pharmacyshops up on up.UserId = u.Id INNER JOIN
    pharmacyshops ps on ps.Id = up.PharmacyShopId inner join
    pharmacies p on p.Id = ps.PharmacyId
WHERE Login = '" . $login . "' and Password = '" . $password . "'";
        
        return $this->LoadData($sql);
    }
    
    /**
     * Поиск лекарств
     * 
     * @param array $searchParams Параметры поиска в виде ассоциативного массива
     * <p>
     *      Состав массива (ключи):
     *      - NameMask - string - маска для поиска наименования лекарства
     * </p>
     * @return array Массив записей, каждая запись - ассоциативный массив
     * <p>
     *      Состав записи (ключи):
     *      - MedicamentName - string - наименование лекарства
     *      - CompanyName - string - название компании-производителя
     *      - CountryName - string - название страны-производителя
     *      - FormName - string - наименование лекарственной формы
     *      - Count - string - decimal(8, 3) - количество в упаковке
     *      - Pharmacy - string - название аптеки
     *      - Address - string - адрес
     *      - Price - string - decimal(8, 2) - цена
     * </p>
     */
    function Search(&$searchParams)
    {
        // real_escape_string используется для экранирования строк во избежание SQL-инъекций
        $nameMask = isset($searchParams["NameMask"]) ? $this->db->real_escape_string($searchParams["NameMask"]) : "";
        
        if (!isset($nameMask))
            return [];
        
        $sql = 
"SELECT 
	medicaments.Name AS MedicamentName, 
    companies.Name AS CompanyName, 
    oksm.Name AS CountryName, 
    dosageforms.Name AS FormName, 
    medicamentsforsale.Count, 
    pharmacies.Name AS Pharmacy, 
    pharmacyshops.Address, 
    medicamentsforsale.Price
FROM 
	medicamentsforsale 
    INNER JOIN medicaments ON medicamentsforsale.MedicamentId = medicaments.Id 
    INNER JOIN companies ON medicamentsforsale.CompanyId = companies.Id 
    INNER JOIN oksm ON companies.CountryCode = oksm.Code 
    INNER JOIN dosageforms ON medicamentsforsale.DosageFormId = dosageforms.Id
    INNER JOIN pharmacyshops ON medicamentsforsale.PharmacyShopId = pharmacyshops.Id
    INNER JOIN pharmacies ON pharmacyshops.PharmacyId = pharmacies.Id
WHERE 
    medicaments.Name LIKE '%" . $nameMask . "%'
ORDER BY 
	medicaments.Name, 
    companies.Name, 
    oksm.Name, 
    dosageforms.Name, 
    medicamentsforsale.Count, 
    pharmacies.Name, 
    pharmacyshops.Address, 
    medicamentsforsale.Price"; 
        
        return $this->LoadData($sql);
    }
    
    /**
     * База данных
     * @var mysqli
     */
    private $db;
    
    /**
     * Максимальный размер запроса к БД
     */
    private $queryMaxSize;
}
?>