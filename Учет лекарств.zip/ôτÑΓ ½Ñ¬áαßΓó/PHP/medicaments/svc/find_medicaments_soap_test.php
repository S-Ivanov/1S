<?php
$client = new SoapClient("find_medicaments_soap.wsdl");
$searchParams = array("searchParams" => array("NameMask" => "ана"));
$result = $client->Search($searchParams);
var_dump($result);
?>