<?php
include "../DataModel/DataBase.php";

$authenticated = isset($_SERVER['PHP_AUTH_USER']);
if ($authenticated)
{
    $login = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];
    $pharmacyShopsByUser = (new DataBase())->GetPharmacyShopsByUser($login, $password);
    $authenticated = !empty($pharmacyShopsByUser);
}

if (!$authenticated) 
{
    header('WWW-Authenticate: Basic realm="Medicament Storage Service"');
    header('HTTP/1.0 401 Unauthorized');
    exit;
}

// настройка и запуск Web-сервиса
//$server = new SoapServer("add_medicaments_soap.wsdl", [ "send_errors" => FALSE ]);
$server = new SoapServer("add_medicaments_soap.wsdl");

$server->addFunction("AddMedicaments");
$server->addFunction("GetDosageForms");
$server->addFunction("GetPharmacologicalClassifier");
$server->addFunction("GetPharmacyShopsByUser");

$server->handle();

/**
 * Добавление лекарств
 * @param object $medicamentsData Данные для добавления в соответствии с WSDL-описанием сервиса
 */
function AddMedicaments($data)
{
    (new DataBase())->AddMedicamentsXML($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'], $data->medicamentsXml); //, string $schemaFilename = "")
}

/**
 * Получить список лекарственных форм
 * @return array Результаты в соответствии с WSDL-описанием сервиса
 */
function GetDosageForms()
{
    return [ "GetDosageFormsResult" => (new DataBase())->GetDosageForms() ];
}

/**
 * Получить фармакологическую классификацию
 * @return array Результаты в соответствии с WSDL-описанием сервиса
 */
function GetPharmacologicalClassifier()
{
    return [ "GetPharmacologicalClassifierResult" => (new DataBase())->GetPharmacologicalClassifier() ];
}

/**
 * Получить список доступных пользователю пунктов продаж
 * @return array Результаты в соответствии с WSDL-описанием сервиса
 */
function GetPharmacyShopsByUser()
{
    return [ "GetPharmacyShopsByUserResult" => (new DataBase())->GetPharmacyShopsByUser($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) ];
}

?>