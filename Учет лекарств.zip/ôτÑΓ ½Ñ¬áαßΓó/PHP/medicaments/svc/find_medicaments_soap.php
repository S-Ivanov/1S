<?php
include "../DataModel/DataBase.php";

/* Настройка и запуск Web-сервиса */
$server = new SoapServer("find_medicaments_soap.wsdl");
$server->addFunction("Search");
$server->handle();

/**
 * Поиск лекарств
 * @param object $searchParams Параметры поиска в виде объекта, соответствующего WSDL сервиса
 * <p>
 *      Состав объекта (свойства):
 *      - searchParams - object - параметры поиска в виде свойств:
 *          - NameMask - string - маска для поиска наименования лекарства
 * </p>
 * @return array Результаты в соответствии с WSDL-описанием сервиса
 */
function Search($searchParams)
{
    $nameMask = $searchParams->searchParams->NameMask;
    
    $result = [ "SearchResult" => array() ];
    
    if (isset($nameMask))
        $result["SearchResult"] = (new DataBase())->Search([ "NameMask" => $nameMask ]);
    
    return $result;
}

?>