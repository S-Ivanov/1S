<?php
$client = new SoapClient("add_medicaments_soap.wsdl", [ "login" => "alex", "password" => "alex123" ]);

//$result = $client->GetDosageForms();
//$result = $client->GetPharmacologicalClassifier();
//$result = $client->GetPharmacyShopsByUser();

$medicamentsData = [ "medicamentsData" => [ "PharmacyShopId" => 1 ]];
$client->AddMedicaments($medicamentsData);

//var_dump($result);

?>