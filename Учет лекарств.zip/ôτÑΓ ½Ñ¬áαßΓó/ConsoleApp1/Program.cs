﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceReference1.SearchMedicamentsWebServiceSoapClient client = new ServiceReference1.SearchMedicamentsWebServiceSoapClient("SearchMedicamentsWebServiceSoap"))
            {
                var searchResult = client.Search(new ServiceReference1.SearchParams { NameMask = "ана" });
                Console.WriteLine(searchResult[0].Address);
            }

            Console.WriteLine();
            Console.Write("Press Enter to exit ...");
            Console.ReadLine();
        }
    }
}
