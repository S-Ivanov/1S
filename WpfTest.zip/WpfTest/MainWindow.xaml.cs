﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// <remarks>
    /// Многоколоночный ListView
    /// https://kristofmattei.be/2010/03/16/multi-column-listview/
    /// Скроллирование
    /// http://kiwigis.blogspot.com/2010/12/how-to-add-scrollintoview-to.html
    /// </remarks>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Ok");
            OnScrollUp(sender, e);
        }

        /// <summary>
        /// Программное скроллирование
        /// </summary>
        /// <param name="o"></param>
        /// <returns></returns>
        /// <remarks>
        /// https://stackoverflow.com/questions/1009036/how-can-i-programmatically-scroll-a-wpf-listview
        /// ответ 27
        /// </remarks>
        public static DependencyObject GetScrollViewer(DependencyObject o)
        {
            // Return the DependencyObject if it is a ScrollViewer
            if (o is ScrollViewer)
            { return o; }

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++)
            {
                var child = VisualTreeHelper.GetChild(o, i);

                var result = GetScrollViewer(child);
                if (result == null)
                {
                    continue;
                }
                else
                {
                    return result;
                }
            }
            return null;
        }

        private void OnScrollUp(object sender, RoutedEventArgs e)
        {
            var scrollViwer = GetScrollViewer(menuItemsList) as ScrollViewer;

            if (scrollViwer != null)
            {
                // Logical Scrolling by Item
                // scrollViwer.LineUp();
                // Physical Scrolling by Offset
                scrollViwer.ScrollToVerticalOffset(scrollViwer.VerticalOffset + 3);
            }
        }
    }
}
