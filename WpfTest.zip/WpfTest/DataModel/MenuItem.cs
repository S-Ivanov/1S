﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WpfTest.DataModel
{
    public class MenuItem : INotifyPropertyChanged
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("IsSelected"));
                }
            }
        }
        bool isSelected = false;

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
