﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для PayWindow.xaml
    /// </summary>
    public partial class PayWindow : Window
    {
        public PayWindow()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // установить начальные координаты окна так, чтобы не перекрывался список элементов заказа
            Window mainWindow = Application.Current.MainWindow;
            this.Left = mainWindow.Left + mainWindow.ActualWidth / 2;
            this.Top = mainWindow.Top + (mainWindow.ActualHeight - this.ActualHeight) / 2;

            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;

            viewModel.BankPaymentEvent += ViewModel_BankPaymentEvent;
            viewModel.CashPaymentEvent += ViewModel_CashPaymentEvent;
            viewModel.OkCommandEvent += ViewModel_OkCommandEvent;
        }

        private void ViewModel_OkCommandEvent(object sender, EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void ViewModel_CashPaymentEvent(object sender, System.ComponentModel.CancelEventArgs e)
        {
            CalcSurrenderWindow calcSurrenderWindow = new CalcSurrenderWindow
            {
                Sum = viewModel.PaymentInfo.Payments[Payment.Cash]
            };
            e.Cancel = calcSurrenderWindow.ShowDialog() != true;
        }

        private void ViewModel_BankPaymentEvent(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show($"Оплата банковской картой = {viewModel.PaymentInfo.Payments[Payment.BankCard]}", "Сообщение", MessageBoxButton.OKCancel, MessageBoxImage.Information, MessageBoxResult.Cancel) == MessageBoxResult.Cancel;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModel.DataModelEventArgs<string> e)
        {
            viewModel.KeyboardCommand.Execute(e.Data);
        }

        private void DigitButton_Click(object sender, RoutedEventArgs e)
        {
            viewModel.KeyboardCommand.Execute((sender as Button).Content.ToString());
        }
    }
}
