﻿using System.Collections.ObjectModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Группа элементов меню
    /// </summary>
    public class MenuItemGroup : MenuItemBase
    {
        public MenuItemGroup(CashDeskLib.DataModel.MenuItemGroup rawMenuItemGroup)
        {
            this.rawMenuItemGroup = rawMenuItemGroup;
            items = new ObservableCollection<MenuItem>(rawMenuItemGroup.Items.Select(item => new MenuItem(item)));
        }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name => rawMenuItemGroup.Name;

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItem> Items => items;
        ObservableCollection<MenuItem> items;

        private CashDeskLib.DataModel.MenuItemGroup rawMenuItemGroup;
    }
}
