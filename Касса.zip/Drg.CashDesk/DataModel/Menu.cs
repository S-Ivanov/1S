﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk.DataModel
{
    public class Menu
    {
        public Menu(CashDeskLib.DataModel.Menu rawMenu)
        {
            this.rawMenu = rawMenu;
        }

        /// <summary>
        /// Номер меню
        /// </summary>
        public string Number => rawMenu.Number;

        /// <summary>
        /// Дата меню
        /// </summary>
        public DateTime Date => rawMenu.Date;

        /// <summary>
        /// Группы элементов меню
        /// </summary>
        public List<MenuItemGroup> Items { get; set; }

        public ObservableCollection<MenuItemGroup> MenuGroups
        {
            get
            {
                if (menuGroups == null)
                    menuGroups = new ObservableCollection<MenuItemGroup>(rawMenu.Items.Select(menuItemGroup => new MenuItemGroup(menuItemGroup)));
                return menuGroups;
            }
        }
        ObservableCollection<MenuItemGroup> menuGroups = null;

        private CashDeskLib.DataModel.Menu rawMenu;
    }
}
