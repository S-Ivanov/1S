﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        public MainWindow()
        {
            menu = new Menu(CashDeskLib.CashDesk.Instance.GetMenu());
        }

        /// <summary>
        /// Меню
        /// </summary>
        public Menu Menu => menu;
        Menu menu;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
