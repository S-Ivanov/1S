﻿using Drg.Equipment;
using Drg.Equipment.KKM;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Обеспечивает работу эмулятора ККМ
    /// </summary>
    public class KKMInfo
    {
        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        public int SlipCharLineLength { get; set; }

        /// <summary>
        /// Номер смены
        /// </summary>
        public int Session { get; set; }

        /// <summary>
        /// Состояние смены
        /// </summary>
        public SessionState SessionState { get; set; }

        /// <summary>
        /// Номер текущего чека
        /// </summary>
        public int CheckNumber { get; set; }

        /// <summary>
        /// Состояние текущего чека
        /// </summary>
        public CheckState CheckState { get; set; }

        /// <summary>
        /// Документ закрыт, но не допечатан
        /// </summary>
        public bool DocumentNotPrinted { get; set; }

        /// <summary>
        /// Касса фискализирована
        /// </summary>
        public bool Fiscal { get; set; }

        public string OperatorFIO { get; set; }
        public string OperatorPost { get; set; }
        public string OperatorINN { get; set; }
        public DeviceError DeviceError { get; set; }
    }
}
