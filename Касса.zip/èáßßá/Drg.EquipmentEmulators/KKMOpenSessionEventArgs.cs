﻿using Drg.Equipment.KKM;
using System;

namespace Drg.EquipmentEmulators
{
    public class KKMOpenSessionEventArgs : EventArgs
    {
        public KKMOpenSessionEventArgs(string operatorFIO, string operatorPost, string operatorINN)
        {
            OperatorFIO = operatorFIO;
            OperatorPost = operatorPost;
            OperatorINN = operatorINN;
        }

        public string OperatorFIO { get; private set; }

        public string OperatorPost { get; private set; }

        public string OperatorINN { get; private set; }

        public SessionState SessionState { get; set; }
    }
}
