﻿using Drg.Equipment;
using Drg.Equipment.PayTerminal;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор банковского терминала
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл в формате Json, в котором записывается результат операции.
    /// </remarks>
    public class PayTerminal : IPayTerminal
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public PayTerminal(string fileName)
        {
            this.fileName = fileName;
        }

        #region Реализация интерфейса IPayTerminal

        public PayResult Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (StreamReader reader = new StreamReader(fs))
                {
                    var reading = reader.ReadToEnd();
                    var serializer = new JavaScriptSerializer();
                    return serializer.Deserialize<PayResult>(reading);
                }
            }
        }

        public DeviceError CheckState()
        {
            return
                File.Exists(fileName) ?
                DeviceError.NoError :
                // Drivers8_PayCARD_PM.pdf стр.64
                new DeviceError(-199, "Неизвестная ошибка");
        }

        #endregion Реализация интерфейса IPayTerminal

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        public void CheckErrors()
        {
        }

        public void DoAction<T>(int actionType, T parameters)
        {
        }

        public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token)
        {
            throw new System.NotImplementedException();
        }

        #endregion Реализация интерфейса IDisposable

        string fileName;

        public event PropertyChangedEventHandler PropertyChanged;

        public bool IsBusy => throw new System.NotImplementedException();

        public DeviceError LastError => throw new System.NotImplementedException();

        //public DeviceError DeviceError => DeviceError.NoError;
    }
}
