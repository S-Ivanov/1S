﻿using Drg.Equipment.PayTerminal;
using System;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор банковского терминала
    /// </summary>
    public class PayTerminal : IPayTerminal
    {
        #region Реализация интерфейса IPayTerminal

        public PayResult Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)
        {
            PayResult payResult = null;
            if (Operationing != null)
            {
                PayTerminalOperationEventArgs eventArgs = new PayTerminalOperationEventArgs(payOperation, sessionNumber, checkNumber, sum);
                Operationing(this, eventArgs);
                payResult = eventArgs.PayResult;
            }
            return payResult;
        }

        #endregion Реализация интерфейса IPayTerminal

        /// <summary>
        /// Событие для получения результатов операции
        /// </summary>
        public event EventHandler<PayTerminalOperationEventArgs> Operationing;
    }
}
