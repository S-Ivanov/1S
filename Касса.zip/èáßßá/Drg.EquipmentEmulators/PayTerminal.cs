﻿using Drg.Equipment;
using Drg.Equipment.PayTerminal;
using System.IO;
using System.Web.Script.Serialization;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор банковского терминала
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл в формате Json, в котором записывается результат операции.
    /// </remarks>
    public class PayTerminal : IPayTerminal
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public PayTerminal(string fileName)
        {
            this.fileName = fileName;
        }

        #region Реализация интерфейса IPayTerminal

        public PayResult Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (StreamReader reader = new StreamReader(fs))
                {
                    var reading = reader.ReadToEnd();
                    var serializer = new JavaScriptSerializer();
                    return serializer.Deserialize<PayResult>(reading);
                }
            }
        }

        public DeviceError CheckState()
        {
            return
                File.Exists(fileName) ?
                DeviceError.NoError :
                // Drivers8_PayCARD_PM.pdf стр.64
                new DeviceError(-199, "Неизвестная ошибка");
        }

        #endregion Реализация интерфейса IPayTerminal

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

        string fileName;

        //public DeviceError DeviceError => DeviceError.NoError;
    }
}
