﻿using Drg.Equipment;
using Drg.Equipment.PayTerminal;
using System.IO;
using System.Web.Script.Serialization;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор банковского терминала
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл в формате Json, в котором записывается результат операции.
    /// </remarks>
    public class PayTerminal : IPayTerminal
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public PayTerminal(string fileName)
        {
            if (!File.Exists(fileName))
                throw new FileNotFoundException("Не найден банковский терминал");
            this.fileName = fileName;
        }

        #region Реализация интерфейса IPayTerminal

        public PayResult Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)
        {
            ReadPayResult();
            return payResult;
        }

        public DeviceError DeviceError
        {
            get
            {
                ReadPayResult();
                return payResult.ResultInfo.DeviceError;
            }
        }

        #endregion Реализация интерфейса IPayTerminal

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

        void ReadPayResult()
        {
            if (payResult == null)
            {
                var reading = File.ReadAllText(fileName);
                var serializer = new JavaScriptSerializer();
                payResult = serializer.Deserialize<PayResult>(reading);
            }
        }

        PayResult payResult = null;
        string fileName;
    }
}
