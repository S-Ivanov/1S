﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using System;
using System.IO;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор считывателя пропусков
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл, в котором записывается номер пропуска.
    /// Вне программы, использующей эмулятор, текстовый файл открывается в блокноте.
    /// При изменении содержимого файла и сохранении генерируется событие считывателя (блокнот закрывать необязательно).
    /// Отсутствие управляющего текстового файла соответствует отсутствию готовности считывателя.
    /// </remarks>
    public class CardReader : ICardReader
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public CardReader(string fileName)
        {
            this.fileName = fileName;
            if (File.Exists(fileName))
            {
                try
                {
                    string folder = Path.GetDirectoryName(fileName);
                    string filter = Path.GetFileName(fileName);
                    watcher = new FileSystemWatcher(folder, filter)
                    {
                        NotifyFilter = NotifyFilters.LastWrite
                    };
                    watcher.Changed += Watcher_Changed;
                    watcher.EnableRaisingEvents = true;
                }
                catch
                {
                }
            }
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            if (DataEvent != null)
            {
                try
                {
                    using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader reader = new StreamReader(fs))
                        {
                            string cardCode = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(cardCode) && cardCode != lastCardCode)
                            {
                                lastCardCode = cardCode;
                                DataEvent(this, new CardReaderEventArgs(cardCode));
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }

        #region Реализация интерфейса ICardReader

        public event EventHandler<CardReaderEventArgs> DataEvent;

        public DeviceError CheckState()
        {
            return 
                watcher == null ?
                // Drivers8_Scaner_PM.pdf стр.11
                new DeviceError(-9, "Устройство не найдено") : 
                DeviceError.NoError;
        }

        #endregion Реализация интерфейса ICardReader

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            watcher?.Dispose();
        }

        #endregion Реализация интерфейса IDisposable

        FileSystemWatcher watcher = null;
        string fileName;
        string lastCardCode = null;
    }
}
