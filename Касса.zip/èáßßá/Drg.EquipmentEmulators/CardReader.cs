﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using System;
using System.IO;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор считывателя пропусков
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл, в котором записывается номер пропуска.
    /// Вне программы, использующей эмулятор, текстовый файл открывается в блокноте.
    /// При изменении содержимого файла и сохранении генерируется событие считывателя (блокнот закрывать необязательно).
    /// Отсутствие управляющего текстового файла соответствует отсутствию готовности считывателя.
    /// </remarks>
    public class CardReader : ICardReader
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public CardReader(string fileName)
        {
            this.fileName = fileName;
            if (DeviceError.ErrorCode != DeviceError.NO_ERROR)
                throw new DeviceException(DeviceError);

            string path = Path.GetDirectoryName(fileName);
            string filter = Path.GetFileName(fileName);
            watcher = new FileSystemWatcher(path, filter)
            {
                NotifyFilter = NotifyFilters.LastWrite
            };
            watcher.Changed += Watcher_Changed;
            watcher.EnableRaisingEvents = true;
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            if (DataEvent != null)
            {
                try
                {
                    using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader reader = new StreamReader(fs))
                        {
                            string cardCode = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(cardCode) && cardCode != lastCardCode)
                            {
                                lastCardCode = cardCode;
                                DataEvent(this, new CardReaderEventArgs(cardCode));
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }

        #region Реализация интерфейса ICardReader

        public DeviceError DeviceError
        {
            get
            {
                return File.Exists(fileName) ? DeviceError.NoError : new DeviceError(-9, "Устройство не найдено");
            }
        }

        public event EventHandler<CardReaderEventArgs> DataEvent;

        #endregion Реализация интерфейса ICardReader

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            watcher.Dispose();
        }

        #endregion Реализация интерфейса IDisposable

        FileSystemWatcher watcher;
        string fileName;
        string lastCardCode = null;
    }
}
