﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using System;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор считывателя пропусков
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл, в котором записывается номер пропуска.
    /// Вне программы, использующей эмулятор, текстовый файл открывается в блокноте.
    /// При изменении содержимого файла и сохранении генерируется событие считывателя (блокнот закрывать необязательно).
    /// Отсутствие управляющего текстового файла соответствует отсутствию готовности считывателя.
    /// </remarks>
    public class CardReader : ICardReader
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public CardReader(string fileName)
        {
            this.fileName = fileName;

            if (File.Exists(fileName))
            {
                try
                {
                    string folder = Path.GetDirectoryName(fileName);
                    string filter = Path.GetFileName(fileName);
                    watcher = new FileSystemWatcher(folder, filter)
                    {
                        NotifyFilter = NotifyFilters.LastWrite
                    };
                    watcher.Changed += Watcher_Changed;
                    watcher.EnableRaisingEvents = true;
                }
                catch
                {
                }
            }
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            if (DataEvent != null)
            {
                try
                {
                    using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader reader = new StreamReader(fs))
                        {
                            string cardCodeStr = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(cardCodeStr) && cardCodeStr != lastCardCodeStr && uint.TryParse(cardCodeStr, out uint cardCode))
                            {
                                lastCardCodeStr = cardCodeStr;
                                DataEvent(this, new CardReaderEventArgs(cardCode));
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }

        #region Реализация интерфейса ICardReader

        public event EventHandler<CardReaderEventArgs> DataEvent;
        public event PropertyChangedEventHandler PropertyChanged;

        public void Dispose()
        {
            watcher?.Dispose();
        }

        public void CheckErrors()
        {
            if (watcher == null || !File.Exists(fileName))
                throw new DeviceException(-9, "Устройство не найдено");
        }

        public void DoAction<T>(int actionType, T parameters)
        {
        }

        public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        #endregion Реализация интерфейса ICardReader

        FileSystemWatcher watcher = null;
        string fileName;
        string lastCardCodeStr = null;

        public bool IsBusy => false;

        public DeviceError LastError => DeviceError.NoError;
    }
}
