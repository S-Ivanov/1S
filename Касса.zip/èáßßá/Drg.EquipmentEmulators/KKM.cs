﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using System.IO;
using System.Web.Script.Serialization;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор ККМ
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл в формате Json, в котором записывается результат операции.
    /// </remarks>
    public class KKM : IKKM
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public KKM(string fileName)
        {
            this.fileName = fileName;
        }

        #region Реализация интерфеса IKKM

        public DeviceError CheckState()
        {
            return
                File.Exists(fileName) ?
                DeviceError.NoError :
                // Drivers8_FprnM_PM.pdf стр.341
                new DeviceError(-1, "Нет связи");
        }

        public int SlipCharLineLength
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.SlipCharLineLength;
            }
        }

        public int Session
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.Session;
            }
        }

        public int CheckNumber
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.CheckNumber;
            }
        }

        //public CheckState CheckState
        //{
        //    get
        //    {
        //        ReadKKMInfo();
        //        return kkmInfo.CheckState;
        //    }
        //}

        public SessionState SessionState
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.SessionState;
            }
        }

        public bool DocumentNotPrinted
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.DocumentNotPrinted;
            }
        }

        public bool Fiscal
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.Fiscal;
            }
        }

        //public CheckState CheckState => throw new System.NotImplementedException();

        //public DeviceError DeviceError => DeviceError.NoError;

        public void CloseSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            // пок ничего не делаем
        }

        public SessionState OpenSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            ReadKKMInfo();
            return kkmInfo.SessionState;
        }

        public void PrintNotFiscalCheck()
        {
        }

        public void PrintFiscalCheck()
        {
        }

        public void SaveFiscalInfo()
        {
        }

        #endregion Реализация интерфеса IKKM

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

        void ReadKKMInfo()
        {
            if (kkmInfo == null)
            {
                var reading = File.ReadAllText(fileName);
                var serializer = new JavaScriptSerializer();
                kkmInfo = serializer.Deserialize<KKMInfo>(reading);
            }
        }

        void WriteKKMInfo()
        {
            if (kkmInfo != null)
            {
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(kkmInfo);
                File.WriteAllText(fileName, json);
            }
        }

        string fileName;

        KKMInfo kkmInfo = null;
    }
}
