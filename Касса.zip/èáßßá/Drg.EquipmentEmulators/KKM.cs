﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using System.IO;
using System.Web.Script.Serialization;

namespace Drg.EquipmentEmulators
{
    /// <summary>
    /// Эмулятор ККМ
    /// </summary>
    /// <remarks>
    /// Для управления эмулятором используется текстовый файл в формате Json, в котором записывается результат операции.
    /// </remarks>
    public class KKM : IKKM
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="fileName">полное имя файла управления эмулятором</param>
        public KKM(string fileName)
        {
            if (!File.Exists(fileName))
                throw new DeviceException(-1, "Нет связи");
            this.fileName = fileName;
        }

        #region Реализация интерфеса IKKM

        public DeviceError DeviceError
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.DeviceError;
            }
        }

        public int SlipCharLineLength
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.SlipCharLineLength;
            }
        }

        public int Session
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.Session;
            }
        }

        public int CheckNumber
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.CheckNumber;
            }
        }

        public CheckState CheckState
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.CheckState;
            }
        }

        public SessionState SessionState
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.SessionState;
            }
        }

        public bool DocumentNotPrinted
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.DocumentNotPrinted;
            }
        }

        public bool Fiscal
        {
            get
            {
                ReadKKMInfo();
                return kkmInfo.Fiscal;
            }
        }

        public void CloseSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            // пок ничего не делаем
        }

        public SessionState OpenSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            ReadKKMInfo();
            return kkmInfo.SessionState;
        }

        #endregion Реализация интерфеса IKKM

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

        void ReadKKMInfo()
        {
            if (kkmInfo == null)
            {
                var reading = File.ReadAllText(fileName);
                var serializer = new JavaScriptSerializer();
                kkmInfo = serializer.Deserialize<KKMInfo>(reading);
            }
        }

        string fileName;

        KKMInfo kkmInfo = null;
    }
}
