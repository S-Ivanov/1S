﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.EquipmentEmulators
{
    public class KKM : IKKM
    {
        #region Реализация интерфеса IKKM

        public int SlipCharLineLength => 48;

        public int Session => session;

        public int CheckNumber => throw new NotImplementedException();

        public CheckState CheckState => throw new NotImplementedException();

        public SessionState SessionState => sessionState;

        public bool DocumentNotPrinted => throw new NotImplementedException();

        public void CloseSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            throw new NotImplementedException();
        }

        public SessionState OpenSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            sessionState = SessionState.Opened;
            if (SessionOpening != null)
            {
                KKMOpenSessionEventArgs eventArgs = new KKMOpenSessionEventArgs(operatorFIO, operatorPost, operatorINN);
                SessionOpening(this, eventArgs);
                sessionState = eventArgs.SessionState;
            }
            return sessionState;
        }

        #endregion Реализация интерфеса IKKM

        /// <summary>
        /// Событие открытия смены
        /// </summary>
        public event EventHandler<KKMOpenSessionEventArgs> SessionOpening;

        int session;
        SessionState sessionState;
    }
}
