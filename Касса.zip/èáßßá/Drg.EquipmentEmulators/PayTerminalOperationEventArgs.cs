﻿using Drg.Equipment.PayTerminal;
using System;

namespace Drg.EquipmentEmulators
{
    public class PayTerminalOperationEventArgs : EventArgs
    {
        public PayTerminalOperationEventArgs(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)
        {
            PayOperation = payOperation;
            SessionNumber = sessionNumber;
            CheckNumber = checkNumber;
            Sum = sum;
        }

        public PayResult PayResult { get; set; }

        public PayOperation PayOperation { get; private set; }

        public int SessionNumber { get; private set; }

        public int CheckNumber { get; private set; }

        public decimal Sum { get; private set; }
    }
}
