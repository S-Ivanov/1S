﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;

namespace KKM10ConsoleTest2
{
    /// <summary>
    /// ККМ - версия 10.2.0.0
    /// </summary>
    /// <remarks>
    /// Используется динамическое подключение dll
    /// Источник:
    /// https://blogs.msdn.microsoft.com/jonathanswift/2006/10/03/dynamically-calling-an-unmanaged-dll-from-net-c/
    /// Доработка: Исключен вызов NativeMethods.FreeLibrary из-за зависания программы. 
    /// Предположительная причина зависания - некорректная попытка вызвать функцию DllMain (см. https://msdn.microsoft.com/ru-ru/library/windows/desktop/ms683152(v=vs.85).aspx)
    /// </remarks>
    public class KKM10 : IDisposable
    {
        public KKM10(string dllFileName, string settings)
        {
            // загружаем библиотеку только 1 раз
            if (dllHandle == IntPtr.Zero)
                dllHandle = NativeMethods.LoadLibrary(dllFileName);

            if (dllHandle == IntPtr.Zero)
                throw new DllNotFoundException(dllFileName);

            int result;

            libfptr_create _libfptr_create = (libfptr_create)GetFunction("libfptr_create", typeof(libfptr_create));
            result = _libfptr_create(out driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_create: {result}");

            libfptr_set_settings _libfptr_set_settings = (libfptr_set_settings)GetFunction("libfptr_set_settings", typeof(libfptr_set_settings));
            result = _libfptr_set_settings(driverHandle, settings);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_set_settings: {result}");

            libfptr_open _libfptr_open = (libfptr_open)GetFunction("libfptr_open", typeof(libfptr_open));
            result = _libfptr_open(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_open: {result}");
        }

        public void PrintString(string s)
        {
            libfptr_set_param_str _libfptr_set_param_str = (libfptr_set_param_str)GetFunction("libfptr_set_param_str", typeof(libfptr_set_param_str));
            _libfptr_set_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_TEXT, s);

            libfptr_print_text _libfptr_print_text = (libfptr_print_text)GetFunction("libfptr_print_text", typeof(libfptr_print_text));
            int result = _libfptr_print_text(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_print_text: {result}");
        }

        public void PrintStringJson(string s)
        {
            var jsonParams = new { type = "nonFiscal", items = new[]
                {
                    new { type = "text", text = s }
                }
            };
            PrintStringJson2(jsonParams);
        }

        public void PrintStringJson2(object jsonParams)
        {
            libfptr_set_param_str _libfptr_set_param_str = (libfptr_set_param_str)GetFunction("libfptr_set_param_str", typeof(libfptr_set_param_str));
            _libfptr_set_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_JSON_DATA, (new JavaScriptSerializer()).Serialize(jsonParams));

            libfptr_process_json _libfptr_process_json = (libfptr_process_json)GetFunction("libfptr_process_json", typeof(libfptr_process_json));
            int result = _libfptr_process_json(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_process_json: {result}");
        }

        public uint GetCharLineLength()
        {
            libfptr_set_param_int _libfptr_set_param_int = (libfptr_set_param_int)GetFunction("libfptr_set_param_int", typeof(libfptr_set_param_int));
            _libfptr_set_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_DATA_TYPE, (uint)libfptr_kkt_data_type.LIBFPTR_DT_RECEIPT_LINE_LENGTH);

            libfptr_query_data _libfptr_query_data = (libfptr_query_data)GetFunction("libfptr_query_data", typeof(libfptr_query_data));
            int result = _libfptr_query_data(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_query_data: {result}");

            libfptr_get_param_int _libfptr_get_param_int = (libfptr_get_param_int)GetFunction("libfptr_get_param_int", typeof(libfptr_get_param_int));
            return _libfptr_get_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_RECEIPT_LINE_LENGTH);
        }

        public string GetCharLineLengthJson()
        {
            libfptr_set_param_str _libfptr_set_param_str = (libfptr_set_param_str)GetFunction("libfptr_set_param_str", typeof(libfptr_set_param_str));
            _libfptr_set_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_JSON_DATA, "{ \"type\": \"getDeviceInfo\" }");

            int result;

            libfptr_process_json _libfptr_process_json = (libfptr_process_json)GetFunction("libfptr_process_json", typeof(libfptr_process_json));
            result = _libfptr_process_json(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_process_json: {result}");

            StringBuilder sb = new StringBuilder(1024);
            libfptr_get_param_str _libfptr_get_param_str = (libfptr_get_param_str)GetFunction("libfptr_get_param_str", typeof(libfptr_get_param_str));
            result = _libfptr_get_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_JSON_DATA, sb, 1024);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_get_param_str: {result}");

            return sb.ToString();
        }

        Delegate GetFunction(string functionName, Type t) 
        {
            IntPtr functionHandle = NativeMethods.GetProcAddress(dllHandle, functionName);
            if (functionHandle == IntPtr.Zero)
                throw new MethodAccessException(functionName);
            return Marshal.GetDelegateForFunctionPointer(functionHandle, t);
        }

        #region Делегаты, соответствующие функциям dll

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_create(out IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_close(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_destroy(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_set_settings(IntPtr handle, string settings);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_open(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate void libfptr_set_param_str(IntPtr handle, libfptr_param param_id, string value);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_print_text(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate uint libfptr_get_param_int(IntPtr handle, libfptr_param param_id);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_set_param_int(IntPtr handle, libfptr_param param_id, uint value);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_query_data(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_process_json(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_get_param_str(IntPtr handle, libfptr_param param_id, StringBuilder value, int size);

        #endregion Делегаты, соответствующие функциям dll

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            if (driverHandle != IntPtr.Zero)
            {
                try
                {
                    libfptr_close _libfptr_close = (libfptr_close)GetFunction("libfptr_close", typeof(libfptr_close));
                    _libfptr_close(driverHandle);

                    libfptr_destroy _libfptr_destroy = (libfptr_destroy)GetFunction("libfptr_destroy", typeof(libfptr_destroy));
                    _libfptr_destroy(driverHandle);
                }
                catch
                {
                    // все ошибки игнорируем
                }
            }
        }

        #endregion Реализация интерфейса IDisposable

        IntPtr driverHandle = IntPtr.Zero;
        static IntPtr dllHandle = IntPtr.Zero;

        enum libfptr_param : int
        {
            LIBFPTR_PARAM_FIRST = 65536,
            LIBFPTR_PARAM_TEXT = LIBFPTR_PARAM_FIRST,
            LIBFPTR_PARAM_TEXT_WRAP,
            LIBFPTR_PARAM_ALIGNMENT,

            LIBFPTR_PARAM_FONT,
            LIBFPTR_PARAM_FONT_DOUBLE_WIDTH,
            LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT,
            LIBFPTR_PARAM_LINESPACING,
            LIBFPTR_PARAM_BRIGHTNESS,

            LIBFPTR_PARAM_MODEL,
            LIBFPTR_PARAM_RECEIPT_TYPE,
            LIBFPTR_PARAM_REPORT_TYPE,
            LIBFPTR_PARAM_MODE,
            LIBFPTR_PARAM_EXTERNAL_DEVICE_TYPE,
            LIBFPTR_PARAM_EXTERNAL_DEVICE_DATA,
            LIBFPTR_PARAM_FREQUENCY,
            LIBFPTR_PARAM_DURATION,
            LIBFPTR_PARAM_CUT_TYPE,
            LIBFPTR_PARAM_DRAWER_ON_TIMEOUT,
            LIBFPTR_PARAM_DRAWER_OFF_TIMEOUT,
            LIBFPTR_PARAM_DRAWER_ON_QUANTITY,
            LIBFPTR_PARAM_TIMEOUT_ENQ,
            LIBFPTR_PARAM_COMMAND_BUFFER,
            LIBFPTR_PARAM_ANSWER_BUFFER,
            LIBFPTR_PARAM_SERIAL_NUMBER,
            LIBFPTR_PARAM_MANUFACTURER_CODE,
            LIBFPTR_PARAM_NO_NEED_ANSWER,
            LIBFPTR_PARAM_INFO_DISCOUNT_SUM,
            LIBFPTR_PARAM_USE_ONLY_TAX_TYPE,
            LIBFPTR_PARAM_PAYMENT_TYPE,
            LIBFPTR_PARAM_PAYMENT_SUM,
            LIBFPTR_PARAM_REMAINDER,
            LIBFPTR_PARAM_CHANGE,
            LIBFPTR_PARAM_DEPARTMENT,
            LIBFPTR_PARAM_TAX_TYPE,
            LIBFPTR_PARAM_TAX_SUM,
            LIBFPTR_PARAM_TAX_MODE,
            LIBFPTR_PARAM_RECEIPT_ELECTRONICALLY,
            LIBFPTR_PARAM_USER_PASSWORD,
            LIBFPTR_PARAM_SCALE,
            LIBFPTR_PARAM_LEFT_MARGIN,
            LIBFPTR_PARAM_BARCODE,
            LIBFPTR_PARAM_BARCODE_TYPE,
            LIBFPTR_PARAM_BARCODE_PRINT_TEXT,
            LIBFPTR_PARAM_BARCODE_VERSION,
            LIBFPTR_PARAM_BARCODE_CORRECTION,
            LIBFPTR_PARAM_BARCODE_COLUMNS,
            LIBFPTR_PARAM_BARCODE_INVERT,
            LIBFPTR_PARAM_HEIGHT,
            LIBFPTR_PARAM_WIDTH,
            LIBFPTR_PARAM_FILENAME,
            LIBFPTR_PARAM_PICTURE_NUMBER,
            LIBFPTR_PARAM_DATA_TYPE,
            LIBFPTR_PARAM_OPERATOR_ID,
            LIBFPTR_PARAM_LOGICAL_NUMBER,
            LIBFPTR_PARAM_DATE_TIME,
            LIBFPTR_PARAM_FISCAL,
            LIBFPTR_PARAM_SHIFT_STATE,
            LIBFPTR_PARAM_CASHDRAWER_OPENED,
            LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT,
            LIBFPTR_PARAM_COVER_OPENED,
            LIBFPTR_PARAM_SUBMODE,
            LIBFPTR_PARAM_RECEIPT_NUMBER,
            LIBFPTR_PARAM_DOCUMENT_NUMBER,
            LIBFPTR_PARAM_SHIFT_NUMBER,
            LIBFPTR_PARAM_RECEIPT_SUM,
            LIBFPTR_PARAM_RECEIPT_LINE_LENGTH,
            LIBFPTR_PARAM_RECEIPT_LINE_LENGTH_PIX,
            LIBFPTR_PARAM_MODEL_NAME,
            LIBFPTR_PARAM_UNIT_VERSION,
            LIBFPTR_PARAM_PRINTER_CONNECTION_LOST,
            LIBFPTR_PARAM_PRINTER_ERROR,
            LIBFPTR_PARAM_CUT_ERROR,
            LIBFPTR_PARAM_PRINTER_OVERHEAT,
            LIBFPTR_PARAM_UNIT_TYPE,
            LIBFPTR_PARAM_LICENSE_NUMBER,
            LIBFPTR_PARAM_LICENSE_ENTERED,
            LIBFPTR_PARAM_LICENSE,
            LIBFPTR_PARAM_SUM,
            LIBFPTR_PARAM_COUNT,
            LIBFPTR_PARAM_COUNTER_TYPE,
            LIBFPTR_PARAM_STEP_COUNTER_TYPE,
            LIBFPTR_PARAM_ERROR_TAG_NUMBER,
            LIBFPTR_PARAM_TABLE,
            LIBFPTR_PARAM_ROW,
            LIBFPTR_PARAM_FIELD,
            LIBFPTR_PARAM_FIELD_VALUE,
            LIBFPTR_PARAM_FN_DATA_TYPE,
            LIBFPTR_PARAM_TAG_NUMBER,
            LIBFPTR_PARAM_TAG_VALUE,
            LIBFPTR_PARAM_DOCUMENTS_COUNT,
            LIBFPTR_PARAM_FISCAL_SIGN,
            LIBFPTR_PARAM_DEVICE_FFD_VERSION,
            LIBFPTR_PARAM_FN_FFD_VERSION,
            LIBFPTR_PARAM_FFD_VERSION,
            LIBFPTR_PARAM_CHECK_SUM,
            LIBFPTR_PARAM_COMMODITY_NAME,
            LIBFPTR_PARAM_PRICE,
            LIBFPTR_PARAM_QUANTITY,
            LIBFPTR_PARAM_POSITION_SUM,
            LIBFPTR_PARAM_FN_TYPE,
            LIBFPTR_PARAM_FN_VERSION,
            LIBFPTR_PARAM_REGISTRATIONS_REMAIN,
            LIBFPTR_PARAM_REGISTRATIONS_COUNT,
            LIBFPTR_PARAM_NO_ERROR_IF_NOT_SUPPORTED,
            LIBFPTR_PARAM_OFD_EXCHANGE_STATUS,
            LIBFPTR_PARAM_FN_ERROR_DATA,
            LIBFPTR_PARAM_FN_ERROR_CODE,
            LIBFPTR_PARAM_ENVD_MODE,
            LIBFPTR_PARAM_DOCUMENT_CLOSED,
            LIBFPTR_PARAM_JSON_DATA,
            LIBFPTR_PARAM_COMMAND_SUBSYSTEM,
            LIBFPTR_PARAM_FN_OPERATION_TYPE,
            LIBFPTR_PARAM_FN_STATE,
            LIBFPTR_PARAM_ENVD_MODE_ENABLED,
            LIBFPTR_PARAM_SETTING_ID,
            LIBFPTR_PARAM_SETTING_VALUE,
            LIBFPTR_PARAM_MAPPING_KEY,
            LIBFPTR_PARAM_MAPPING_VALUE,
            LIBFPTR_PARAM_COMMODITY_PIECE,
            LIBFPTR_PARAM_POWER_SOURCE_TYPE,
            LIBFPTR_PARAM_BATTERY_CHARGE,
            LIBFPTR_PARAM_VOLTAGE,
            LIBFPTR_PARAM_USE_BATTERY,
            LIBFPTR_PARAM_BATTERY_CHARGING,
            LIBFPTR_PARAM_CAN_PRINT_WHILE_ON_BATTERY,
            LIBFPTR_PARAM_MAC_ADDRESS,
            LIBFPTR_PARAM_FN_FISCAL,
            LIBFPTR_PARAM_NETWORK_ERROR,
            LIBFPTR_PARAM_OFD_ERROR,
            LIBFPTR_PARAM_FN_ERROR,
            LIBFPTR_PARAM_COMMAND_CODE,
            LIBFPTR_PARAM_PRINTER_TEMPERATURE,
            LIBFPTR_PARAM_RECORDS_TYPE,
            LIBFPTR_PARAM_OFD_FISCAL_SIGN,
            LIBFPTR_PARAM_HAS_OFD_TICKET,
            LIBFPTR_PARAM_NO_SERIAL_NUMBER,
            LIBFPTR_PARAM_RTC_FAULT,
            LIBFPTR_PARAM_SETTINGS_FAULT,
            LIBFPTR_PARAM_COUNTERS_FAULT,
            LIBFPTR_PARAM_USER_MEMORY_FAULT,
            LIBFPTR_PARAM_SERVICE_COUNTERS_FAULT,
            LIBFPTR_PARAM_ATTRIBUTES_FAULT,
            LIBFPTR_PARAM_FN_FAULT,
            LIBFPTR_PARAM_INVALID_FN,
            LIBFPTR_PARAM_HARD_FAULT,
            LIBFPTR_PARAM_MEMORY_MANAGER_FAULT,
            LIBFPTR_PARAM_SCRIPTS_FAULT,
            LIBFPTR_PARAM_FULL_RESET,
            LIBFPTR_PARAM_WAIT_FOR_REBOOT,
            LIBFPTR_PARAM_SCALE_PERCENT,
            LIBFPTR_PARAM_FN_NEED_REPLACEMENT,
            LIBFPTR_PARAM_FN_RESOURCE_EXHAUSTED,
            LIBFPTR_PARAM_FN_MEMORY_OVERFLOW,
            LIBFPTR_PARAM_FN_OFD_TIMEOUT,
            LIBFPTR_PARAM_FN_CRITICAL_ERROR,
            LIBFPTR_PARAM_OFD_MESSAGE_READ,
            LIBFPTR_PARAM_DEVICE_MIN_FFD_VERSION,
            LIBFPTR_PARAM_DEVICE_MAX_FFD_VERSION,
            LIBFPTR_PARAM_DEVICE_UPTIME,
            LIBFPTR_PARAM_NOMENCLATURE_TYPE,
            LIBFPTR_PARAM_GTIN,
            LIBFPTR_PARAM_FN_DOCUMENT_TYPE,
            LIBFPTR_PARAM_NETWORK_ERROR_TEXT,
            LIBFPTR_PARAM_FN_ERROR_TEXT,
            LIBFPTR_PARAM_OFD_ERROR_TEXT,
            LIBFPTR_PARAM_USER_SCRIPT_ID,
            LIBFPTR_PARAM_USER_SCRIPT_PARAMETER,
            LIBFPTR_PARAM_USER_MEMORY_OPERATION,
            LIBFPTR_PARAM_USER_MEMORY_DATA,
            LIBFPTR_PARAM_USER_MEMORY_STRING,
            LIBFPTR_PARAM_USER_MEMORY_ADDRESS,
            LIBFPTR_PARAM_FN_PRESENT,
            LIBFPTR_PARAM_BLOCKED,
            LIBFPTR_PARAM_DOCUMENT_PRINTED,
            LIBFPTR_PARAM_DISCOUNT_SUM,
            LIBFPTR_PARAM_SURCHARGE_SUM,
            LIBFPTR_PARAM_LK_USER_CODE,
            LIBFPTR_PARAM_LICENSE_COUNT,

            LIBFPTR_PARAM_LAST
        };

        enum libfptr_kkt_data_type : uint
        {
            LIBFPTR_DT_STATUS = 0,
            LIBFPTR_DT_CASH_SUM,
            LIBFPTR_DT_UNIT_VERSION,
            LIBFPTR_DT_PICTURE_INFO,
            LIBFPTR_DT_LICENSE_ACTIVATED,
            LIBFPTR_DT_REGISTRATIONS_SUM,
            LIBFPTR_DT_REGISTRATIONS_COUNT,
            LIBFPTR_DT_PAYMENT_SUM,
            LIBFPTR_DT_CASHIN_SUM,
            LIBFPTR_DT_CASHIN_COUNT,
            LIBFPTR_DT_CASHOUT_SUM,
            LIBFPTR_DT_CASHOUT_COUNT,
            LIBFPTR_DT_REVENUE,
            LIBFPTR_DT_DATE_TIME,
            LIBFPTR_DT_SHIFT_STATE,
            LIBFPTR_DT_RECEIPT_STATE,
            LIBFPTR_DT_SERIAL_NUMBER,
            LIBFPTR_DT_MODEL_INFO,
            LIBFPTR_DT_RECEIPT_LINE_LENGTH,
            LIBFPTR_DT_CUTTER_RESOURCE,
            LIBFPTR_DT_STEP_RESOURCE,
            LIBFPTR_DT_TERMAL_RESOURCE,
            LIBFPTR_DT_ENVD_MODE,
            LIBFPTR_DT_SHIFT_TAX_SUM,
            LIBFPTR_DT_RECEIPT_TAX_SUM,
            LIBFPTR_DT_NON_NULLABLE_SUM,
            LIBFPTR_DT_RECEIPT_COUNT,
            LIBFPTR_DT_CANCELLATION_COUNT_ALL,
            LIBFPTR_DT_CANCELLATION_SUM,
            LIBFPTR_DT_CANCELLATION_SUM_ALL,
            LIBFPTR_DT_POWER_SOURCE_STATE,
            LIBFPTR_DT_CANCELLATION_COUNT,
            LIBFPTR_DT_NON_NULLABLE_SUM_BY_PAYMENTS,
            LIBFPTR_DT_PRINTER_TEMPERATURE,
            LIBFPTR_DT_FATAL_STATUS,
            LIBFPTR_DT_MAC_ADDRESS,
            LIBFPTR_DT_DEVICE_UPTIME,
            LIBFPTR_DT_RECEIPT_BYTE_COUNT,
            LIBFPTR_DT_DISCOUNT_AND_SURCHARGE_SUM
        };

#pragma warning disable 0649

        public struct KKM10_DeviceInfoWrapper
        {
            public KKM10_DeviceInfo deviceInfo;
        }

        /// <summary>
        /// Информация о ККТ
        /// </summary>
        public struct KKM10_DeviceInfo
        {
            /// <summary>
            /// Версия прошивки
            /// </summary>
            public string firmwareVersion;

            /// <summary>
            /// Код модели
            /// </summary>
            public int model;

            /// <summary>
            /// Наименование модели
            /// </summary>
            public string modelName;

            /// <summary>
            /// Ширина чековой ленты в символах
            /// </summary>
            public int receiptLineLength;

            /// <summary>
            /// Ширина чековой ленты в пикселях
            /// </summary>
            public int receiptLineLengthPix;

            /// <summary>
            /// Заводской номер ККТ
            /// </summary>
            public string serial;
        }

#pragma warning restore 0649

    }
}
