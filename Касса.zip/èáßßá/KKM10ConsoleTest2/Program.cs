﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace KKM10ConsoleTest2
{
    class Program
    {
        static void Main(string[] args)
        {
            using (KKM10 kkm = new KKM10(ConfigurationManager.AppSettings["dllFileName"], "{ \"Model\":63, \"Port\":1 }"))
            {
                //kkm.PrintString("Тестовая строка");
                //kkm.PrintStringJson("Тестовая строка");
                kkm.PrintStringJson2(new
                {
                    type = "nonFiscal",
                    items = new[]
                    {
                        new { type = "text", text = "Тестовая строка" }
                    }
                });

                ////uint charLineLength = kkm.GetCharLineLength();
                ////Console.WriteLine($"CharLineLength = {charLineLength}");
                //Console.WriteLine(kkm.GetCharLineLengthJson());
            }

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}
