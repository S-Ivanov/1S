﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfScrollTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;
        }

        private void RootItemButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ok");
        }

        public List<string> Items => new List<string>
        {
            "Text 1",
            "Text 2",
            "Text 3",
            "Text 4",
            "Text 5",
            "Text 6",
            "Text 7",
            "Text 8",
            "Text 9",
            "Text 10",
            "Text 11",
            "Text 12",
            "Text 13",
            "Text 14",
            "Text 15",
            "Text 16",
            "Text 17",
            "Text 18",
            "Text 19",
            "Text 20",
        };

        private void RootItemButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Ok");
        }

        private void RootItemButton_TouchUp(object sender, TouchEventArgs e)
        {
            MessageBox.Show("Ok");
        }
    }
}
