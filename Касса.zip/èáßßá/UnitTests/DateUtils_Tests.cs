﻿using System;
using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class DateUtils_Tests
    {
        [TestMethod]
        public void DateUtils_GetPeriodsBetween_Test()
        {
            List<DateTime> dates = new List<DateTime>
            {
                new DateTime(2018, 06, 10),
                new DateTime(2018, 06, 11),
                new DateTime(2018, 06, 20),
            };
            DateTime start = new DateTime(2018, 06, 9);
            DateTime end = new DateTime(2018, 06, 22);
            List<DateRange> ranges = dates.GetPeriodsBetween(start, end);
            Assert.IsNotNull(ranges);
        }
    }
}
