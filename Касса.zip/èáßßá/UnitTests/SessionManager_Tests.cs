﻿using System;
using System.Collections.Generic;
using System.Linq;
using Drg.CashDeskLib.Session;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class SessionManager_Tests
    {
        [TestMethod]
        public void SessionManager_OpenSession_Test()
        {
            SessionManager sessionManager = new SessionManager();
            List<string> actions = new List<string>();

            actions.Clear();
            SessionManagerParameters parameters = new SessionManagerParameters
            {
                HasKKM = true,
                KkmHasError = false,
                KkmSessionState = Drg.Equipment.KKM.SessionState.Opened,
                FnChanged = true,
                DbSessionState = Drg.Equipment.KKM.SessionState.Opened,
                OperatorChanged = true
            };

            sessionManager.OpenSession(
                parameters,
                closeKKMSessionAction: () => actions.Add("Закрыть смену ККМ"),
                closeDbSessionAction: () => actions.Add("Закрыть смену БД"),
                openKKMSessionAction: () => actions.Add("Открыть смену ККМ"),
                openDbSessionAction: () => actions.Add("Открыть смену БД")
                );
            Assert.IsTrue(Enumerable.SequenceEqual(
                actions, 
                new List<string>
                {
                    "Закрыть смену ККМ",
                    "Открыть смену ККМ",
                    "Закрыть смену БД",
                    "Открыть смену БД"
                }));

            //actions.Clear();
            //sessionManager.Run(
            //    hasKKM: true,
            //    kkmHasError: false,
            //    kkmSessionState: Drg.Equipment.KKM.SessionState.Opened,
            //    fnChanged: true,
            //    dbSessionState: Drg.Equipment.KKM.SessionState.Opened,
            //    operatorChanged: false
            //    );
            //Assert.IsTrue(Enumerable.SequenceEqual(
            //    actions,
            //    new List<string>
            //    {
            //        "Закрыть смену ККМ",
            //        "Открыть смену ККМ",
            //        "Закрыть смену БД",
            //        "Открыть смену БД"
            //    }));

            //actions.Clear();
            //sessionManager.Run(
            //    hasKKM: true,
            //    kkmHasError: false,
            //    kkmSessionState: Drg.Equipment.KKM.SessionState.Opened,
            //    fnChanged: true,
            //    dbSessionState: Drg.Equipment.KKM.SessionState.Closed,
            //    operatorChanged: false
            //    );
            //Assert.IsTrue(Enumerable.SequenceEqual(
            //    actions,
            //    new List<string>
            //    {
            //        "Закрыть смену ККМ",
            //        "Открыть смену ККМ",
            //        "Открыть смену БД"
            //    }));
        }
    }
}
