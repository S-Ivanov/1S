﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class PaymentManagerExt_Tests
    {
        //[TestMethod]
        //public void PaymentManagerExt_PayReceipt_Test()
        //{
        //    PaymentManagerExt paymentManager = new PaymentManagerExt(kkm, payTerminal, localDB, true);
        //    paymentManager.FixErrorEvent += PaymentManager_FixErrorEvent;

        //    Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
        //    {
        //        Order = new Order
        //        {
        //            Items = new List<OrderItem>
        //            {
        //                new OrderItem
        //                {
        //                    Payment = Payment.ZP,
        //                    MenuItem = new MenuItem
        //                    {
        //                        Name = "position 3",
        //                        Price = 100,
        //                        VATCode = 1,
        //                        VATCoefficient = 0
        //                    },
        //                    Price = 100,
        //                    Count = 1
        //                },
        //                new OrderItem
        //                {
        //                    Payment = Payment.Cash,
        //                    MenuItem = new MenuItem
        //                    {
        //                        Name = "position 2",
        //                        Price = 100,
        //                        VATCode = 1,
        //                        VATCoefficient = 0
        //                    },
        //                    Price = 100,
        //                    Count = 1
        //                },
        //                new OrderItem
        //                {
        //                    Payment = Payment.BankCard,
        //                    MenuItem = new MenuItem
        //                    {
        //                        Name = "position 1",
        //                        Price = 100,
        //                        VATCode = 1,
        //                        VATCoefficient = 0
        //                    },
        //                    Price = 100,
        //                    Count = 1
        //                }
        //            }
        //        }
        //    };

        //    var noPayments = paymentManager.PayReceipt(null, receipt);
        //    Assert.IsTrue(noPayments.Any());
        //}

        private void PaymentManager_FixErrorEvent(object sender, FixErrorEventArgs e)
        {
            bool errorFixed = true;
            e.ErrorFixed = errorFixed;
        }

        IKKM kkm = new KKMMock();
        IPayTerminal payTerminal = new PayTerminalMock();
        ILocalDBPayment localDB = new LocalDBPaymentMock();

        class LocalDBPaymentMock : ILocalDBPayment
        {
            public void SaveAuthorizationInfo(Guid authorizationInfoId, AuthorizationInfo authorizationInfo)
            {
                Console.WriteLine(authorizationInfo);
            }

            public void SaveAuthorizationInfo(Guid authorizationInfoId, Guid sessionId, Guid orderId, AuthorizationInfo authorizationInfo)
            {
                throw new NotImplementedException();
            }

            public void SavePayment(Guid sessionId, Drg.CashDeskLib.DataModel.Receipt receipt, bool isTestMode)
            {
                Console.WriteLine(receipt);
            }

            public void SavePayTerminalReturnError(Guid authorizationInfoId, int sessionNumber, int checkNumber)
            {
            }
        }

        class PayTerminalMock : IPayTerminal
        {
            public PayResult Pay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine(sum);
                PayResult payResult = new PayResult
                {
                    DeviceError = DeviceError.NoError,
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        Sum = sum
                    }
                };
                return payResult;
            }

            public PayResult ReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine(sum);
                PayResult payResult = new PayResult
                {
                    DeviceError = DeviceError.NoError,
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        Sum = sum
                    }
                };
                return payResult;
            }

            public bool IsBusy => throw new NotImplementedException();

            public DeviceError LastError => throw new NotImplementedException();

            public uint LineLength { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

            public void CheckErrors()
            {
                throw new NotImplementedException();
            }

            public void Dispose()
            {
                throw new NotImplementedException();
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public string Report(ReportType reportType, IEnumerable<AuthorizationInfo> authorizationInfoCollection)
            {
                throw new NotImplementedException();
            }

            public PayResult CancelPay(int sessionNumber, int checkNumber, decimal sum)
            {
                throw new NotImplementedException();
            }

            public PayResult CancelReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                throw new NotImplementedException();
            }
        }

        class KKMMock : IKKM
        {
            public event EventHandler<CloseFiscalDocumentErrorEventArgs> OnCloseFiscalDocumentError;

            public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
            {
                //throw new DeviceException(new DeviceError(101, "Облом ККМ"));
                //Console.WriteLine(textInfo);
            }

            public void PrintReceipt(Drg.Equipment.KKM.Receipt receipt)
            {
                throw new DeviceException(new DeviceError { ErrorCode = 101, Description = "Облом ККМ" });
                //Console.WriteLine(receipt);
            }

            public uint LineLength => throw new NotImplementedException();

            public SessionState SessionState => throw new NotImplementedException();

            public uint SessionNumber => throw new NotImplementedException();

            public string FnNumber => throw new NotImplementedException();

            public bool Fiscal => throw new NotImplementedException();

            public bool IsBusy => throw new NotImplementedException();

            public DeviceError LastError => throw new NotImplementedException();

            public FnInfo FnInfo => throw new NotImplementedException();

            public void CheckErrors()
            {
                throw new NotImplementedException();
            }

            public void CloseSession()
            {
                throw new NotImplementedException();
            }

            public void Dispose()
            {
                throw new NotImplementedException();
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public void OpenSession(string operatorInfo, string operatorINN)
            {
                throw new NotImplementedException();
            }

            public Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument)
            {
                throw new NotImplementedException();
            }

            public void CancelReceipt()
            {
                throw new NotImplementedException();
            }

            public void CasheChange(decimal sum)
            {
                throw new NotImplementedException();
            }

            public void CloseSession(string operatorInfo, string operatorINN)
            {
                throw new NotImplementedException();
            }
        }
    }
}
