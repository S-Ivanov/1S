﻿using System;
using Drg.CashDeskLib.Session;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class SessionManagerExt_Tests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionManagerExt_ctor_Exception_Test()
        {
            SessionManagerExt sessionManagerExt = new SessionManagerExt(null, null);
        }
    }
}
