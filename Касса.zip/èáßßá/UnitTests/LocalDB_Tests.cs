﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTests
{
    [TestClass]
    public class LocalDB_Tests
    {
        const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";

        [TestMethod]
        public void LocalDB_SaveMenus_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.CashDeskLib\MenuReader\ToFront.xml");
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SaveMenus(menus);
        }

        [TestMethod]
        public void LocalDB_GetNewOrderNumber_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderNumber = localDB.GetNewOrderNumber();
            Assert.AreNotEqual(0, orderNumber);
        }

        [TestMethod]
        public void LocalDB_LoadMenus_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var menus = localDB.LoadMenus(new DateTime(2018, 06, 29), 2);
            Assert.IsNotNull(menus);
        }

        [TestMethod]
        public void LocalDB_GetClient_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            Client client = localDB.GetClient(123456);
            Assert.IsNotNull(client);
        }

        [TestMethod]
        public void LocalDB_GetClients_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var clients = localDB.GetClients();
            Assert.IsNotNull(clients);
        }

        [TestMethod]
        public void LocalDB_LoadReportFO_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var reportFO = localDB.LoadReportFO(new Guid("6360bf3f-ca40-4464-8225-0f0af6dedf9a"));
            Assert.IsNotNull(reportFO);
        }

    }
}
