﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace UnitTests
{
    [TestClass]
    public class LocalDB_Tests
    {
        const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";

        [TestMethod]
        public void LocalDB_LoadMenusExt_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var menu = localDB.LoadMenusExt(DateTime.Today, 2);
            Assert.IsNotNull(menu);
        }

        [TestMethod]
        public void LocalDB_LoadOrder_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderInfo = localDB.LoadOrder(new Guid("1a73a5fd-ba8d-4765-9b3d-6ff2bf37613b"));
            Assert.IsNotNull(orderInfo);
        }

        [TestMethod]
        public void LocalDB_LoadReturns_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderReturns = localDB.LoadReturns(new Guid("1a73a5fd-ba8d-4765-9b3d-6ff2bf37613b"));
            Assert.IsNotNull(orderReturns);
        }

        [TestMethod]
        public void LocalDB_SaveMenus_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.CashDeskLib\MenuReader\ToFront.xml");
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SaveMenus(menus);
        }

        [TestMethod]
        public void LocalDB_GetNewOrderNumber_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderNumber = localDB.GetNewOrderNumber();
            Assert.AreNotEqual(0, orderNumber);
        }

        [TestMethod]
        public void LocalDB_LoadMenus_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var menus = localDB.LoadMenus(new DateTime(2018, 06, 29), 2);
            Assert.IsNotNull(menus);
        }

        [TestMethod]
        public void LocalDB_LoadOrderSources_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            List<OrderSource> orderSources = localDB.LoadOrderSources(true);
            Assert.IsNotNull(orderSources);
        }

        [TestMethod]
        public void LocalDB_GetClients_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var clients = localDB.LoadClients();
            Assert.IsNotNull(clients);
        }

        [TestMethod]
        public void LocalDB_LoadReportFO_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var reportFO = localDB.LoadReportFO(new Guid("6360bf3f-ca40-4464-8225-0f0af6dedf9a"));
            Assert.IsNotNull(reportFO);
        }

        [TestMethod]
        public void LocalDB_LoadTransactionDocument_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var transactionDocument = localDB.LoadTransactionDocument(null, DateTime.UtcNow, true);
            Assert.IsNotNull(transactionDocument);
        }

        /// <summary>
        /// Тест записи иерархических данных
        /// </summary>
        /// <remarks>
        /// По результатам теста: иерархия должна записываться последовательно от верхнего уровня к нижним
        /// </remarks>
        [TestMethod]
        public void LocalDB_SaveHierarchy_Test()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    SqlCommand command = new SqlCommand(
@"insert into Номенклатура (Id, Наименование, IdРодителя)
values (@Id, @Наименование, @IdРодителя)", 
                        connection, transaction);
                    command.Parameters.Add("@Id", SqlDbType.VarChar, 15);
                    command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
                    command.Parameters.Add("@IdРодителя", SqlDbType.VarChar, 15);

                    command.Parameters["@Id"].Value = "99-00000002";
                    command.Parameters["@Наименование"].Value = "Тест 1";
                    command.Parameters["@IdРодителя"].Value = "99-00000001";
                    command.ExecuteNonQuery();

                    command.Parameters["@Id"].Value = "99-00000001";
                    command.Parameters["@Наименование"].Value = "Тест 1 - родитель";
                    command.Parameters["@IdРодителя"].Value = DBNull.Value;
                    command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        //[TestMethod]
        //public void LocalDB_SaveExchangeData_Test()
        //{
        //    LocalDB localDB = new LocalDB(ConnectionString);

        //    DateTime? lastExchangeDateTime = localDB.GetLastExchangeDateTime();

        //    using (FrontServiceReference.FrontServicePortTypeClient frontServiceClient = new FrontServiceReference.FrontServicePortTypeClient("FrontServiceSoap12"))
        //    {
        //        FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
        //        {
        //            IdCashDesk = "00000006",
        //            //TransactionDocument = new FrontServiceReference.Transaction[]
        //        };

        //        // дата/время последнего сеанса обмена данными
        //        if (lastExchangeDateTime != null)
        //            parameter.ClientTimeStamp = lastExchangeDateTime.Value;

        //        FrontServiceReference.ResultData resultData = frontServiceClient.ExchangeData(parameter);

        //        // записать полученные данные
        //        localDB.SaveExchangeData(TranslateResultData(resultData), 248);
        //    }
        //}

        //Drg.CashDeskLib.FrontServiceReference.ResultData TranslateResultData(FrontServiceReference.ResultData resultData)
        //{
        //    return new Drg.CashDeskLib.FrontServiceReference.ResultData
        //    {
        //        TimeStamp = resultData.TimeStamp,
        //        ClientDocument =
        //            resultData
        //            .ClientDocument
        //            .Select(client => new Drg.CashDeskLib.FrontServiceReference.Client
        //            {
        //                TabNum = client.TabNum,
        //                FIO = client.FIO,
        //                CardCode = client.CardCode,
        //                IsZP = client.IsZP,
        //                LimitZP = client.LimitZP
        //            })
        //            .ToArray(),
        //        LPPDocument = 
        //            resultData
        //            .LPPDocument
        //            .Select(lpp => new Drg.CashDeskLib.FrontServiceReference.LPP
        //            {
        //                TabNum = lpp.TabNum,
        //                MonthLPP = lpp.MonthLPP,
        //                SumLPP = lpp.SumLPP
        //            })
        //            .ToArray(),
        //        PhotoDocument = 
        //            resultData
        //            .PhotoDocument
        //            .Select(photo => new Drg.CashDeskLib.FrontServiceReference.Photo
        //            {
        //                TabNum = photo.TabNum,
        //                Data = photo.Data
        //            })
        //            .ToArray()
        //    };
        //}
    }
}
