﻿using System;
using Drg.CashDeskLib.LocalDB;
using Drg.PlanMenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class LocalDB_Tests
    {
        [TestMethod]
        public void LocalDB_SaveMenus_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.PlanMenuReader\ToFront.xml");
            LocalDB localDB = new LocalDB(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True");
            localDB.SaveMenus(menus);
        }
    }
}
