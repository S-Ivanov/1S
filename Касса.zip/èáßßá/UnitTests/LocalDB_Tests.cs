﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.LocalDB;
using Drg.CashDeskLib.MenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTests
{
    [TestClass]
    public class LocalDB_Tests
    {
        [TestMethod]
        public void LocalDB_SaveMenus_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.CashDeskLib\MenuReader\ToFront.xml");
            LocalDB localDB = new LocalDB(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True", "", "");
            localDB.SaveMenus(menus);
        }

        [TestMethod]
        public void LocalDB_GetMenu_Test()
        {
            LocalDB localDB = new LocalDB(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True", "", "");
            Drg.CashDeskLib.DataModel.Menu menu = localDB.GetMenu(new DateTime(2018, 06, 07));
            Assert.IsNotNull(menu);
        }

        [TestMethod]
        public void LocalDB_GetClient_Test()
        {
            LocalDB localDB = new LocalDB(
                @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True",
                @"Data Source=DRGSKD01\PARSECSQLEXPRESS;Initial Catalog=Parsec3;Persist Security Info=True;User ID=sa;Password=Parsec3DBpass",
                "select PHOTO from PERSON where TAB_NUM = @TAB_NUM");
            Client client = localDB.GetClient(123456);
            Assert.IsNotNull(client);
        }
    }
}
