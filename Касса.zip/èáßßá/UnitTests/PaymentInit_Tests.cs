﻿using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class PaymentInit_Tests
    {
        [TestMethod]
        public void PaymentInit_Init_Test()
        {
            var result = new Dictionary<Payment, decimal>();
            Payment payment;

            result.Clear();
            payment = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.ZP, 10000 }
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 1000,
                result: result);
            Assert.AreEqual(Payment.ZP, payment);
            Assert.AreEqual(1, result.Count);
            Assert.IsTrue(result.ContainsKey(Payment.ZP));
            Assert.AreEqual(1000, result[Payment.ZP]);

            result.Clear();
            payment = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.LPP, 248 },
                    { Payment.ZP, 10000 }
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 250,
                result: result);
            Assert.AreEqual(Payment.ZP, payment);
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.ContainsKey(Payment.LPP));
            Assert.IsTrue(result.ContainsKey(Payment.ZP));
            Assert.AreEqual(248, result[Payment.LPP]);
            Assert.AreEqual(2, result[Payment.ZP]);

            result.Clear();
            payment = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.LPP, 248 },
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 250,
                result: result);
            Assert.AreEqual(Payment.None, payment);
            Assert.AreEqual(1, result.Count);
            Assert.IsTrue(result.ContainsKey(Payment.LPP));
            Assert.AreEqual(248, result[Payment.LPP]);
        }

        [TestMethod]
        public void PaymentInit_Init0_Test()
        {
            Payment startPaymentType;

            startPaymentType = Payment.ZP;
            var result1 = PaymentInit.Init0(
                paymentTypes: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 1 },
                    { Payment.Cash, 1 },
                    { Payment.LPP, 248 },
                    { Payment.Talon120, 120 },
                    { Payment.ZP, 1 }
                },
                limits: new Dictionary<Payment, decimal>
                {
                    { Payment.LPP, 1 },
                    { Payment.ZP, 10000 }
                },
                sum: 1000,
                startPaymentType: ref startPaymentType);
            Assert.AreEqual(1, result1.Count);
            Assert.AreEqual(1000, result1[Payment.ZP]);
            Assert.AreEqual(Payment.ZP, startPaymentType);

            startPaymentType = Payment.LPP;
            var result2 = PaymentInit.Init0(
                paymentTypes: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 1 },
                    { Payment.Cash, 1 },
                    { Payment.LPP, 248 },
                    { Payment.Talon120, 120 },
                    { Payment.ZP, 1 }
                },
                limits: new Dictionary<Payment, decimal>
                {
                    { Payment.LPP, 1 },
                    { Payment.ZP, 10000 }
                },
                sum: 250,
                startPaymentType: ref startPaymentType);
            Assert.AreEqual(2, result2.Count);
            Assert.AreEqual(1, result2[Payment.LPP]);
            Assert.AreEqual(2, result2[Payment.ZP]);
            Assert.AreEqual(Payment.ZP, startPaymentType);
        }
    }
}
 