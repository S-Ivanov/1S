﻿using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class PaymentInit_Tests
    {
        [TestMethod]
        public void PaymentInit_Init_Test()
        {
            var result1 = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.ZP, 10000 }
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 1000);
            Assert.AreEqual(1, result1.Count);
            Assert.IsTrue(result1.ContainsKey(Payment.ZP));
            Assert.AreEqual(1000, result1[Payment.ZP]);

            var result2 = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.LPP, 248 },
                    { Payment.ZP, 10000 }
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 250);
            Assert.AreEqual(2, result2.Count);
            Assert.IsTrue(result2.ContainsKey(Payment.LPP));
            Assert.IsTrue(result2.ContainsKey(Payment.ZP));
            Assert.AreEqual(248, result2[Payment.LPP]);
            Assert.AreEqual(2, result2[Payment.ZP]);

            var result3 = PaymentInit.Init(
                payments: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 0 },
                    { Payment.Cash, 0 },
                    { Payment.Talon120, 0 },
                    { Payment.LPP, 248 },
                },
                lppNominal: 248,
                talon120Nominal: 120,
                sum: 250);
            Assert.AreEqual(1, result3.Count);
            Assert.IsTrue(result3.ContainsKey(Payment.LPP));
            Assert.AreEqual(248, result3[Payment.LPP]);
        }

        [TestMethod]
        public void PaymentInit_Init0_Test()
        {
            Payment startPaymentType;

            startPaymentType = Payment.ZP;
            var result1 = PaymentInit.Init0(
                paymentTypes: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 1 },
                    { Payment.Cash, 1 },
                    { Payment.LPP, 248 },
                    { Payment.Talon120, 120 },
                    { Payment.ZP, 1 }
                },
                limits: new Dictionary<Payment, decimal>
                {
                    { Payment.LPP, 1 },
                    { Payment.ZP, 10000 }
                },
                sum: 1000,
                startPaymentType: ref startPaymentType);
            Assert.AreEqual(1, result1.Count);
            Assert.AreEqual(1000, result1[Payment.ZP]);
            Assert.AreEqual(Payment.ZP, startPaymentType);

            startPaymentType = Payment.LPP;
            var result2 = PaymentInit.Init0(
                paymentTypes: new Dictionary<Payment, decimal>
                {
                    { Payment.BankCard, 1 },
                    { Payment.Cash, 1 },
                    { Payment.LPP, 248 },
                    { Payment.Talon120, 120 },
                    { Payment.ZP, 1 }
                },
                limits: new Dictionary<Payment, decimal>
                {
                    { Payment.LPP, 1 },
                    { Payment.ZP, 10000 }
                },
                sum: 250,
                startPaymentType: ref startPaymentType);
            Assert.AreEqual(2, result2.Count);
            Assert.AreEqual(1, result2[Payment.LPP]);
            Assert.AreEqual(2, result2[Payment.ZP]);
            Assert.AreEqual(Payment.ZP, startPaymentType);
        }
    }
}
 