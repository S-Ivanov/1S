﻿using System;
using Drg.PlanMenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class MenuReader_Tests
    {
        [TestMethod]
        public void MenuReader_Read_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.PlanMenuReader\ToFront.xml");
            Assert.IsNotNull(menus);
        }
    }
}
