﻿using Drg.CashDeskLib.MenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class MenuReader_Tests
    {
        [TestMethod]
        public void MenuReader_Read_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.CashDeskLib\MenuReader\ToFront.xml");
            Assert.IsNotNull(menus);
        }
    }
}
