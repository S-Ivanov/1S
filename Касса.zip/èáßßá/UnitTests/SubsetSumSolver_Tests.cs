﻿using System;
using System.Collections.Generic;
using System.Linq;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class SubsetSumSolver_Tests
    {
        [TestMethod]
        public void SubsetSumSolver_SubsetSums_Test()
        {
            List<int> items;
            List<int> result;
            decimal target;
            Func<int, decimal> amountGetter = _ => _;

            items = new List<int> { 100, 100, 200, 300, 400, 500 };
            target = 600;
            result = SubsetSumSolver.SubsetSums(items, target, amountGetter);
            Assert.AreEqual(600, result.Sum());
        }
    }
}
