﻿using System;
using Drg.CashDeskLib.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class StringUtils_Tests
    {
        [TestMethod]
        public void StringUtils_FrameSubstringAll_Test()
        {
            string s = "aaBBcc DdDd eeeEEE ffff";
            string result;

            result = StringUtils.FrameSubstringAll(s, "xx", "<", ">");
            Assert.AreEqual("aaBBcc DdDd eeeEEE ffff", result);

            result = StringUtils.FrameSubstringAll(s, "dd", "<", ">");
            Assert.AreEqual("aaBBcc <Dd><Dd> eeeEEE ffff", result);

            result = StringUtils.FrameSubstringAll(s, "e", "<", ">");
            Assert.AreEqual("aaBBcc DdDd <e><e><e><E><E><E> ffff", result);
        }

        [TestMethod]
        public void StringUtils_FrameSubstring_Test()
        {
            string s = "aaBBcc DdDd eeeEEE ffff";
            string result;

            result = StringUtils.FrameSubstring(s, "xx", "<", ">");
            Assert.AreEqual("aaBBcc DdDd eeeEEE ffff", result);

            result = StringUtils.FrameSubstring(s, "dd", "<", ">");
            Assert.AreEqual("aaBBcc <Dd>Dd eeeEEE ffff", result);

            result = StringUtils.FrameSubstring(s, "e", "<", ">");
            Assert.AreEqual("aaBBcc DdDd <e>eeEEE ffff", result);
        }
    }
}
