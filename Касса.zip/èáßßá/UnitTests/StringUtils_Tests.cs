﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class StringUtils_Tests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
