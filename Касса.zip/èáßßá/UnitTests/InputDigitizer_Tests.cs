﻿using System;
using Drg.CashDesk.DataModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class InputDigitizer_Tests
    {
        [TestMethod]
        public void InputDigitizer_AddSymbols_Test()
        {
            InputDigitizer digitizer;

            digitizer = new InputDigitizer();
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols(".");
            Assert.AreEqual(0.5m, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("00");
            digitizer.AddSymbols("0");
            Assert.AreEqual(0, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("1");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("0");
            Assert.AreEqual(10.55m, digitizer.Value);

            digitizer = new InputDigitizer(useDot: false);
            digitizer.AddSymbols("1");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("0");
            Assert.AreEqual(10550m, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("1");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("0");
            Assert.AreEqual(10000000.55m, digitizer.Value);

            digitizer = new InputDigitizer(limit: 100);
            digitizer.AddSymbols("1");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            Assert.AreEqual(100, digitizer.Value);

            digitizer = new InputDigitizer(limit: 100);
            digitizer.AddSymbols("1");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            digitizer.AddSymbols("0");
            Assert.AreEqual(100, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("1");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.AddSymbols("5");
            digitizer.BackSpace();
            Assert.AreEqual(1.5m, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("1");
            digitizer.AddSymbols(".");
            digitizer.AddSymbols("5");
            digitizer.BackSpace();
            Assert.AreEqual(1, digitizer.Value);

            digitizer = new InputDigitizer();
            digitizer.AddSymbols("1");
            digitizer.BackSpace();
            Assert.AreEqual(0, digitizer.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void InputDigitizer_AddSymbols_Exception1_Test()
        {
            InputDigitizer digitizer = new InputDigitizer();
            digitizer.AddSymbols(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void InputDigitizer_AddSymbols_Exception2_Test()
        {
            InputDigitizer digitizer = new InputDigitizer();
            digitizer.AddSymbols("a");
        }
    }
}
