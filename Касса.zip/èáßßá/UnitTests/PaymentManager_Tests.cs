﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Drg.CashDeskLib.Payment;

namespace UnitTests
{
    [TestClass]
    public class PaymentManager_Tests
    {
        /// <summary>
        /// Оплата в счет ЗП
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_01_Test()
        {
            IKKMPayment kkm = new KKMMock(DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.ZP,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// Оплата в счет ЗП с ошибкой ККМ
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_02_Test()
        {
            IKKMPayment kkm = new KKMMock(new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.ZP,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// Оплата по банковской карте
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_03_Test()
        {
            IKKMPayment kkm = new KKMMock(DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// Оплата по банковской карте с регистрируемой ошибкой терминала во время оплаты
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_04_Test()
        {
            IKKMPayment kkm = new KKMMock(DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(false, false, new DeviceError { ErrorCode = 2, Description = "Регистрируемая ошибка терминала" }, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// Оплата по банковской карте с ошибкой ККМ во время оплаты
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_05_Test()
        {
            IKKMPayment kkm = new KKMMock(new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой оплаты
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_06_Test()
        {
            IKKMPayment kkm = new KKMMock(DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(true, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsFalse(result);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой отката оплаты при ошибке ККМ
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_07_Test()
        {
            IKKMPayment kkm = new KKMMock(new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(false, true, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsFalse(result);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой отката оплаты при ошибке ККМ - отмена возврата пользователем
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_08_Test()
        {
            IKKMPayment kkm = new KKMMock(new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock();

            PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
            {
                SlipCount = 1,
                IsTestMode = false,
                ReturnCopies = 1,
                NominalLPP = 250,
                NominalTalon120 = 120
            };
            PaymentManager paymentManager = new PaymentManager(kkm, payTerminal, localDB, null, configuration);
            paymentManager.OnBeforePayTerminalCancel += (sender, e) => e.Cancel = true;

            Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

            Drg.CashDeskLib.DataModel.Receipt receipt = new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new Order
                {
                    Number = 200,
                    DateTime = DateTime.Now,
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Payment = Payment.BankCard,
                            MenuItem = new MenuItem
                            {
                                Name = "Блюдо 1",
                                Price = 100,
                                VATCode = 1,
                                VATCoefficient = 0
                            },
                            Price = 100,
                            Count = 1
                        },
                    }
                }
            };

            var result = paymentManager.PayReceipt(session, receipt);
            Assert.IsFalse(result);
        }

        class LocalDBPaymentMock : ILocalDBPayment
        {
            public void SaveAuthorizationInfo(Guid authorizationInfoId, Guid sessionId, Guid orderId, AuthorizationInfo authorizationInfo)
            {
                Console.WriteLine("ILocalDBPayment.SaveAuthorizationInfo:");
                Console.WriteLine("  " + authorizationInfo);
            }

            public void SavePayment(Guid sessionId, Drg.CashDeskLib.DataModel.Receipt receipt, bool isTestMode)
            {
                Console.WriteLine("ILocalDBPayment.SavePayment:");
                Console.WriteLine("  " + receipt);
            }

            public void SavePayTerminalReturnError(Guid authorizationInfoId, int sessionNumber, int checkNumber)
            {
                Console.WriteLine("ILocalDBPayment.SavePayTerminalReturnError:");
            }
        }

        class PayTerminalMock : IPayTerminal
        {
            public PayTerminalMock(bool cancelPay, bool cancelUndo, DeviceError payError, DeviceError cancelError)
            {
                this.cancelPay = cancelPay;
                this.cancelUndo = cancelUndo;
                this.payError = payError;
                this.cancelError = cancelError;
            }

            public PayResult Pay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine("PayTerminal.Pay:");
                if (cancelPay)
                    return null;
                else
                    return new PayResult
                    {
                        DeviceError = payError,
                        SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                        AuthorizationInfo = new AuthorizationInfo
                        {
                            Sum = sum
                        }
                    };
            }

            public PayResult ReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine("PayTerminal.ReturnPay:");
                PayResult payResult = new PayResult
                {
                    DeviceError = DeviceError.NoError,
                    SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        Sum = sum
                    }
                };
                return payResult;
            }

            public bool IsBusy => false;

            public DeviceError LastError => DeviceError.NoError;

            public uint LineLength { get; set; }

            public void CheckErrors()
            {
            }

            public void Dispose()
            {
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public string Report(ReportType reportType, IEnumerable<AuthorizationInfo> authorizationInfoCollection)
            {
                throw new NotImplementedException();
            }

            public PayResult CancelPay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine("PayTerminal.CancelPay:");
                if (cancelUndo)
                    return null;
                else
                    return new PayResult
                    {
                        DeviceError = cancelError,
                        SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                        AuthorizationInfo = new AuthorizationInfo
                        {
                            Sum = sum
                        }
                    };
            }

            public PayResult CancelReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                throw new NotImplementedException();
            }

            DeviceError payError;
            DeviceError cancelError;
            private bool cancelPay;
            private bool cancelUndo;
        }

        class KKMMock : IKKMPayment
        {
            public KKMMock(DeviceError error)
            {
                this.error = error;
            }

            public uint LineLength => 48;

            public bool IsBusy => false;

            public DeviceError LastError => error;

            public void CheckErrors()
            {
            }

            public void Dispose()
            {
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument)
            {
                Console.WriteLine("PrintNonFiscalDocument:");
                foreach (var ti in textInfo)
                {
                    Console.WriteLine("  " + ti.ToString((int)LineLength));
                }
            }

            public void PrintReceipt(Drg.Equipment.KKM.Receipt receipt)
            {
                Console.WriteLine("PrintReceipt:");
                Console.WriteLine($"ReceiptType - {receipt.ReceiptType}");
            }

            DeviceError error;
        }
    }
}
