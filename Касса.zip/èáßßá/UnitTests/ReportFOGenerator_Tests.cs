﻿using System;
using System.Xml;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class ReportFOGenerator_Tests
    {
        [TestMethod]
        public void ReportFOGenerator_Generate_1_Test()
        {
            ReportFO reportFO = new ReportFO
            {
                Date = DateTime.Now,
                PeriodBegin = DateTime.Today,
                PeriodEnd = DateTime.Today.AddDays(1).AddSeconds(-1),
                Reports = new ReportFOReport[]
                {
                    new ReportFOReport
                    {
                        Date = DateTime.Today,
                        Number = "18-027-0023",
                        Record = new ReportFOReportRecord[]
                        {
                            new ReportFOReportRecord
                            {
                                ID="E4024B9F-0952-4EC4-BA67-15824C8CC400",
                                Nomenclature ="00-00004723",
                                Unit ="796",
                                Price =25.4m,
                                Count =2,
                                Sum =50.8m,
                                Payment ="00000006"
                            },
                            new ReportFOReportRecord
                            {
                                ID="EF903906-6F6D-4AE4-B0B6-3D12812E6A18",
                                Nomenclature ="00-00003822",
                                Unit ="796",
                                Price =29.13m,
                                Count =1,
                                Sum =29.13m,
                                Payment ="00000006"
                            },
                            new ReportFOReportRecord
                            {
                                ID="82135239-BF66-43CF-AB74-76E2B12D1FAC",
                                Nomenclature ="00-00003822",
                                Unit ="796",
                                Price =29.13m,
                                Count =2,
                                Sum =58.26m,
                                Payment ="00000002"
                            },
                        }
                    }
                },
                Departments = new Item[]
                {
                    new Item
                    {
                        Code = "00-000027",
                        Value = "Аммиак"
                    }
                },
                Units = new Item[]
                {
                    new Item
                    {
                        Code = "166",
                        Value = "кг"
                    },
                    new Item
                    {
                        Code = "796",
                        Value = "шт"
                    },
                },
                Payments = new Item[]
                {
                    new Item
                    {
                        Code = "00000002",
                        Value = "ТАЛОН 248"
                    },
                    new Item
                    {
                        Code ="00000005",
                        Value ="Банк. карта"
                    },
                    new Item
                    {
                        Code ="00000006",
                        Value ="В счёт ЗП"
                    },
                },
                Nomenclature = new Item[]
                {
                    new Item
                    {
                        Code ="00-00004723",
                        Value ="Буженина со свеж.капустой и огурцами."
                    },
                    new Item
                    {
                        Code ="00-00003822",
                        Value ="Бутерброд с сыром и маслом "
                    },
                },
            };

            ReportFOGenerator generator = new ReportFOGenerator(@"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\МакетОбработки.xslt");

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            using (XmlWriter xmlWriter = XmlWriter.Create(@"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\2.xml", settings))
            {
                generator.Generate(reportFO, xmlWriter);
            }
        }
    }
}
