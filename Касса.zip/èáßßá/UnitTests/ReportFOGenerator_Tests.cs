﻿using System;
using System.Xml;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class ReportFOGenerator_Tests
    {
        const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";

        [TestMethod]
        public void ReportFOGenerator_GenerateFromDB_Test()
        {
            ReportFOGenerator generator = new ReportFOGenerator(new LocalDB(ConnectionString), @"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\МакетОбработки.xslt");
            var periodBegin = new DateTime(2018, 07, 24);
            var periodEnd = new DateTime(2018, 07, 25).AddSeconds(-1);
            string cashDescId = "00000006";
            string cashDescName = "Столовая №8 Касса №2";
            string cashDescNumber = "082";

            XmlWriterSettings settings = new XmlWriterSettings
            {
                Indent = true
            };
            using (XmlWriter xmlWriter = XmlWriter.Create(@"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\ToBack3.xml", settings))
            {
                generator.Generate(cashDescId, cashDescName, cashDescNumber, periodBegin, periodEnd, xmlWriter);
            }
        }

        [TestMethod]
        public void ReportFOGenerator_GenerateFromObject_Test()
        {
            ReportFO reportFO = new ReportFO
            {
                Date = new DateTime(2018, 07, 25, 15, 50, 26),
                PeriodBegin = new DateTime(2018, 07, 25, 00, 00, 00),
                PeriodEnd = new DateTime(2018, 07, 25, 23, 59, 59),
                Reports = new ReportFOReport[]
                {
                    new ReportFOReport
                    {
                        Date = new DateTime(2018, 07, 25, 23, 59, 04),
                        Number = "тест",
                        Record = new ReportFOReportRecord[]
                        {
                            new ReportFOReportRecord
                            {
                                ID = "E4024B9F-0952-4EC4-BA67-15824C8CC400",
                                Nomenclature = "00-00004503",
                                Unit = "796",
                                Price = 61.41m,
                                Count = 2,
                                Sum = 122.82m,
                                Payment = "00000006"
                            },
                            new ReportFOReportRecord
                            {
                                ID = "EF903906-6F6D-4AE4-B0B6-3D12812E6A18",
                                Nomenclature = "00-00002721",
                                Unit = "796",
                                Price = 17.74m,
                                Count = 1,
                                Sum = 17.74m,
                                Payment = "00000006"
                            },
                            new ReportFOReportRecord
                            {
                                ID = "82135239-BF66-43CF-AB74-76E2B12D1FAC",
                                Nomenclature = "00-00002721",
                                Unit = "796",
                                Price = 17.74m,
                                Count = 2,
                                Sum = 35.48m,
                                Payment = "00000002"
                            },
                        }
                    }
                },
                Departments = new Item[]
                {
                    new Item
                    {
                        Code = "00-000027",
                        Value = "Аммиак"
                    }
                },
                Units = new Item[]
                {
                    new Item
                    {
                        Code = "796",
                        Value = "шт"
                    },
                },
                Payments = new Item[]
                {
                    new Item
                    {
                        Code = "00000002",
                        Value = "ТАЛОН 248"
                    },
                    new Item
                    {
                        Code = "00000006",
                        Value = "В счёт ЗП"
                    },
                },
                Nomenclature = new Item[]
                {
                    new Item
                    {
                        Code = "00-00004503",
                        Value = "Мясо отварное говядина (гов.1 кат.)"
                    },
                    new Item
                    {
                        Code = "00-00002721",
                        Value = "Салат из свежей капусты."
                    },
                },
            };

            ReportFOGenerator generator = new ReportFOGenerator(null, @"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\МакетОбработки.xslt");

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            using (XmlWriter xmlWriter = XmlWriter.Create(@"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\ToBack2.xml", settings))
            {
                generator.Generate(reportFO, xmlWriter);
            }
        }
    }
}
