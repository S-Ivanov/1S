﻿using Drg.CashDeskLib.DataModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests
{
    [TestClass]
    public class KKMNotFiscalTransaction_Tests
    {
        [TestMethod]
        public void KKMNotFiscalTransaction_GetNotFiscalReceipt_Test()
        {
            MenuItem[] menuItems =
            {
                new MenuItem
                {
                    Name = "Сосиска в тесте",
                    Unit = "шт.",
                },
                new MenuItem
                {
                    Name = "Котлета в тесте",
                    Unit = "шт.",
                },
                new MenuItem
                {
                    Name = "Соус красный основной с печёными фрикадельками",
                    Unit = "порц.",
                },
                new MenuItem
                {
                    Name = "Кисель из сухофруктов",
                    Unit = "шт.",
                },
            };

            Receipt receipt = new Receipt
            {
                Order = new Order
                {
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[0],
                            Payment = Payment.BankCard,
                            Price = 100,
                            Sum = 100
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[1],
                            Payment = Payment.BankCard,
                            Price = 39,
                            Sum = 39
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[2],
                            Payment = Payment.ZP,
                            Price = 2.89M,
                            Sum = 2.89M
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[3],
                            Payment = Payment.ZP,
                            Price = 8.89M,
                            Sum = 8.89M
                        },
                    }
                },
                Payments = new Dictionary<Payment, List<OrderItem>>
                {
                    {
                        Payment.BankCard,
                        new List<OrderItem>
                        {
                            new OrderItem
                            {
                                Payment = Payment.BankCard,
                                Count = 1,
                                Price = 100,
                                Sum = 100,
                                MenuItem = menuItems[0]
                            },
                            new OrderItem
                            {
                                Payment = Payment.BankCard,
                                Count = 1,
                                Price = 39.00M,
                                Sum = 39.00M,
                                MenuItem = menuItems[1]
                            },
                        }
                    },
                    {
                        Payment.ZP,
                        new List<OrderItem>
                        {
                            new OrderItem
                            {
                                Payment = Payment.ZP,
                                Count = 1,
                                Price = 2.89M,
                                Sum = 2.89M,
                                MenuItem = menuItems[2]
                            },
                            new OrderItem
                            {
                                Payment = Payment.ZP,
                                Count = 1,
                                Price = 8.89M,
                                Sum = 8.89M,
                                MenuItem = menuItems[3]
                            },
                        }
                    }
                }
            };

            //Dictionary<Payment, List<OrderItem>> parameters = new Dictionary<Payment, List<OrderItem>>
            //{
            //    {
            //        Payment.BankCard,
            //        new List<OrderItem>
            //        {
            //            new OrderItem
            //            {
            //                Payment = Payment.BankCard,
            //                Count = 1,
            //                Price = 100,
            //                Sum = 100,
            //                MenuItem = new MenuItem
            //                {
            //                    Name = "Сосиска в тесте",
            //                    Unit = "шт.",

            //                }
            //            },
            //            new OrderItem
            //            {
            //                Payment = Payment.BankCard,
            //                Count = 1,
            //                Price = 39.00M,
            //                Sum = 39.00M,
            //                MenuItem = new MenuItem
            //                {
            //                    Name = "Котлета в тесте",
            //                    Unit = "шт.",

            //                }
            //            },
            //        }
            //    },
            //    {
            //        Payment.ZP,
            //        new List<OrderItem>
            //        {
            //            new OrderItem
            //            {
            //                Payment = Payment.ZP,
            //                Count = 1,
            //                Price = 2.89M,
            //                Sum = 2.89M,
            //                MenuItem = new MenuItem
            //                {
            //                    Name = "Соус красный основной с печёными фрикадельками",
            //                    Unit = "порц.",

            //                }
            //            },
            //            new OrderItem
            //            {
            //                Payment = Payment.ZP,
            //                Count = 1,
            //                Price = 8.89M,
            //                Sum = 8.89M,
            //                MenuItem = new MenuItem
            //                {
            //                    Name = "Кисель из сухофруктов",
            //                    Unit = "шт.",

            //                }
            //            },
            //        }
            //    }
            //};

            var result = KKMNotFiscalTransaction.GetNotFiscalReceipt(receipt, 48);
            Assert.IsNotNull(result);
        }
    }
}
