﻿using Drg.CashDeskLib.DataModel;
using Drg.TextWrapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests
{
    [TestClass]
    public class KKMNotFiscalTransaction_Tests
    {
        [TestMethod]
        public void KKMNotFiscalTransaction_GetNotFiscalReceipt_Test()
        {
            MenuItem[] menuItems =
            {
                new MenuItem
                {
                    Name = "Сосиска в тесте",
                    Unit = "шт.",
                    Price = 999999
                },
                new MenuItem
                {
                    Name = "Котлета в тесте",
                    Unit = "шт.",
                    Price = 39
                },
                new MenuItem
                {
                    Name = "Соус красный основной с печёными фрикадельками",
                    Unit = "порц.",
                    Price = 2.89M,
                },
                new MenuItem
                {
                    Name = "Кисель из сухофруктов",
                    Unit = "шт.",
                    Price = 8.89M,
                },
                new MenuItem
                {
                    Name = "Сангрита",
                    Unit = "шт.",
                    Price = 248,
                },
                new MenuItem
                {
                    Name = "Сауза",
                    Unit = "шт.",
                    Price = 120,
                },
            };

            Receipt receipt = new Receipt
            {
                Order = new Order
                {
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[0],
                            Payment = Payment.BankCard,
                            Sum = 999999
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[1],
                            Payment = Payment.BankCard,
                            Sum = 39
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[2],
                            Payment = Payment.ZP,
                            Sum = 2.89M
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[3],
                            Payment = Payment.ZP,
                            Sum = 8.89M
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[4],
                            Payment = Payment.LPP,
                            Sum = 248
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[5],
                            Payment = Payment.Talon120,
                            Sum = 120
                        },
                    },
                    DateTime = DateTime.Now,
                    Number = 10101
                },
                Client = new Client
                {
                    FIO = "Белышев И.А",
                    MonthLimitZP = 15000,
                    TabNum = "5188",
                    UsedZP = 1000,
                    MonthLimitLPP = 2
                }
            };

            TextWrapper textWrapper = new TextWrapper(@"C:\Проекты\Касса\NHyphenator\Resources\hyph-ru.pat.txt", @"C:\Проекты\Касса\NHyphenator\Resources\hyph-ru.hyp.txt");

            var result = KKMNotFiscalTransaction.GetNotFiscalReceipt(receipt, textWrapper, 48, 248, 120);
            Assert.IsNotNull(result);

            //string text = string.Join(Environment.NewLine, result.Select(_ => _.ToString(48)));
            //Assert.IsNotNull(text);
        }

        [TestMethod]
        public void KKMNotFiscalTransaction_GetNotFiscalReceiptReturn_Test()
        {
            MenuItem[] menuItems =
            {
                new MenuItem
                {
                    Name = "Сосиска в тесте",
                    Unit = "шт.",
                    Price = 999999
                },
                new MenuItem
                {
                    Name = "Котлета в тесте",
                    Unit = "шт.",
                    Price = 39
                },
                new MenuItem
                {
                    Name = "Соус красный основной с печёными фрикадельками",
                    Unit = "порц.",
                    Price = 2.89M,
                },
                new MenuItem
                {
                    Name = "Кисель из сухофруктов",
                    Unit = "шт.",
                    Price = 8.89M,
                },
                new MenuItem
                {
                    Name = "Сангрита",
                    Unit = "шт.",
                    Price = 248,
                },
                new MenuItem
                {
                    Name = "Сауза",
                    Unit = "шт.",
                    Price = 120,
                },
            };

            Receipt receipt = new Receipt
            {
                Order = new OrderReturn
                {
                    Items = new List<OrderItem>
                    {
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[0],
                            Payment = Payment.BankCard,
                            Sum = 999999
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[1],
                            Payment = Payment.BankCard,
                            Sum = 39
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[2],
                            Payment = Payment.ZP,
                            Sum = 2.89M
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[3],
                            Payment = Payment.ZP,
                            Sum = 8.89M
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[4],
                            Payment = Payment.LPP,
                            Sum = 248
                        },
                        new OrderItem
                        {
                            Count = 1,
                            MenuItem = menuItems[5],
                            Payment = Payment.Talon120,
                            Sum = 120
                        },
                    },
                    DateTime = DateTime.Now,
                    Number = 10101
                },
                Client = new Client
                {
                    FIO = "Белышев И.А",
                    MonthLimitZP = 15000,
                    TabNum = "5188",
                    UsedZP = 1000,
                    MonthLimitLPP = 2
                }
            };

            TextWrapper textWrapper = new TextWrapper(@"C:\Проекты\Касса\NHyphenator\Resources\hyph-ru.pat.txt", @"C:\Проекты\Касса\NHyphenator\Resources\hyph-ru.hyp.txt");

            var result = KKMNotFiscalTransaction.GetNotFiscalReceipt(receipt, textWrapper, 48, 248, 120);
            Assert.IsNotNull(result);

            //string text = string.Join(Environment.NewLine, result.Select(_ => _.ToString(48)));
            //Assert.IsNotNull(text);
        }
    }
}
