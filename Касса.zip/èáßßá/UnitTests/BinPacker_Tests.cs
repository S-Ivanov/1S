﻿using System.Collections.Generic;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class BinPacker_Tests
    {
        [TestMethod]
        public void BinPacker_First_Test()
        {
            int[] items = { 25, 20, 5, 15, 2, 3, 6, 4 };
            int[] bins = { 20, 50, 10 };
            BinPacker binPacker = new BinPacker(bins, items);
            List<int> result = binPacker.First();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void BinPacker_All_Test()
        {
            int[] items = { 6, 4, 2, 2 };
            int[] bins = { 8, 4, 2 };
            BinPacker binPacker = new BinPacker(bins, items);
            List<List<int>> result = binPacker.All();
            Assert.IsNotNull(result);
        }
    }
}
