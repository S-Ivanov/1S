﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Drg.CashDeskLib;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class CashDesk_Tests
    {
        //const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";
        const string ConnectionString = @"Data Source=compit130comp\sqlexpress;Initial Catalog=Касса;Persist Security Info=True;User ID=sa;Password=zto1f5;Connection Timeout=60";

        [TestMethod]
        public void CashDesk_FrontDataExchange_Test()
        {
            string idCashDesk = "000000006";
            LocalDB localDB = new LocalDB(ConnectionString);
            CashDesk.FrontDataExchange("FrontServiceSoap12", localDB, idCashDesk, 248, true);
        }

        [TestMethod]
        public void CashDesk_MenuLoad_Test()
        {
            string exchangeBuhID = "00000007";
            LocalDB localDB = new LocalDB(ConnectionString);
            CashDesk.MenuLoad("ExtCashDeskExchange_MenuServiceSoap12", localDB, exchangeBuhID);
        }

        [TestMethod]
        public void CashDesk_SaveReportFO_Test()
        {
            string exchangeBuhID = "00000007";
            string reportFOXslt = @"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\МакетОбработки.xslt";
            string eateryID = "00-000004";
            string eateryName = "Столовая №21";
            string cashDescNumber = "212";
            LocalDB localDB = new LocalDB(ConnectionString);
            ReportFOGenerator reportFOGenerator = new ReportFOGenerator(localDB, reportFOXslt, eateryID, eateryName, cashDescNumber);

            CashDesk.SaveReportFO(
                "ExtCashDeskExchange_ReportFOServiceSoap12",
                reportFOGenerator,
                cashDescNumber,
                exchangeBuhID,
                //() => new Session[]
                //{
                //    new Session
                //    {
                //        Id = new Guid("180497a9-83ba-4c7e-b487-4d93b012cb59"),
                //        Number = 1,
                //    },
                //    new Session
                //    {
                //        Id = new Guid("2dffa323-4b8f-4171-81b1-e659768f0c65"),
                //        Number = 2,
                //    },
                //},
                () => new Guid[] { new Guid("180497a9-83ba-4c7e-b487-4d93b012cb59"), new Guid("2dffa323-4b8f-4171-81b1-e659768f0c65") },
                sessionIds =>
                {
                    return;
                });
        }
    }
}
