﻿using System;
using Drg.CashDeskLib;
using Drg.CashDeskLib.DB;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class CashDesk_Tests
    {
        const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";

        [TestMethod]
        public void CashDesk_FrontDataExchange_Test()
        {
            string idCashDesk = "000000006";
            LocalDB localDB = new LocalDB(ConnectionString);
            CashDesk.FrontDataExchange("FrontServiceSoap12", localDB, idCashDesk, 248, true);
        }
    }
}
