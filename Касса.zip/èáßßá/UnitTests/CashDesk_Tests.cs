﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Drg.CashDeskLib;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class CashDesk_Tests
    {
        const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";

        [TestMethod]
        public void CashDesk_FrontDataExchange_Test()
        {
            string idCashDesk = "000000006";
            LocalDB localDB = new LocalDB(ConnectionString);
            CashDesk.FrontDataExchange("FrontServiceSoap12", localDB, idCashDesk, 248, true);
        }

        [TestMethod]
        public void CashDesk_MenuLoad_Test()
        {
            string exchangeBuhID = "00000002";
            LocalDB localDB = new LocalDB(ConnectionString);
            CashDesk.MenuLoad("ExtCashDeskExchange_MenuServiceSoap12", localDB, exchangeBuhID);
        }

        [TestMethod]
        public void CashDesk_SaveReportFO_Test()
        {
            string exchangeBuhID = "00000008";
            string reportFOXslt = @"C:\Проекты\Касса\Drg.CashDeskLib\ReportFO\МакетОбработки.xslt";
            string eateryID = "00-000031";
            string eateryName = "Тестовый склад";
            string cashDescNumber = "tst";
            LocalDB localDB = new LocalDB(ConnectionString);
            ReportFOGenerator reportFOGenerator = new ReportFOGenerator(localDB, reportFOXslt, null, null, eateryID, eateryName, cashDescNumber);

            CashDesk.SaveReportFO(
                "ExtCashDeskExchange_ReportFOServiceSoap12",
                reportFOGenerator,
                cashDescNumber,
                exchangeBuhID,
                () => new Session[]
                {
                    new Session
                    {
                        Id = new Guid("8A2AB4FD-5E40-474F-AAA8-528688B92B66"),
                        Number = 15,
                        Begin = new DateTime(2018, 8, 10)
                    },
                    new Session
                    {
                        Id = new Guid("8929C71D-6FBB-48A9-9D19-6DBB31BA9061"),
                        Number = 13,
                        Begin = new DateTime(2018, 8, 8)
                    },
                },
                sessionIds =>
                {
                    return;
                });
        }
    }
}
