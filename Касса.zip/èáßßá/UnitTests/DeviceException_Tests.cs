﻿using System;
using System.Threading.Tasks;
using Drg.Equipment;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class DeviceException_Tests
    {
        //[TestMethod]
        //public void DeviceException_Task_Test()
        //{
        //    var task = new Task(() =>
        //    {
        //        //throw new DeviceException(15, "Error task");
        //    });
        //    task.Start();

        //    try
        //    {
        //        var result = task.Wait(500);
        //        //if (!result)
        //        //    throw new DeviceException(100, "Нет связи с ККМ");
        //    }
        //    catch (Exception ae)
        //    {
        //        //throw ae.Flatten();
        //        throw ae;
        //    }
        //}
    }
}
