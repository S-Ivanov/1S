﻿using System;
using Drg.CashDeskLib.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class NetworkUtils_Tests
    {
        [TestMethod]
        public void NetworkUtils_HasPing_Test()
        {
            Assert.IsTrue(NetworkUtils.HasPing("drg1c"));
        }
    }
}
