﻿using System;
using Drg.CashDeskLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class EnumExtensions_Tests
    {
        const string CardReaderDescription = "Считыватель";

        [TestMethod]
        public void EnumExtensions_Tests_GetDescription()
        {
            Device device = Device.CardReader;
            string deviceName = EnumExtensions.GetDescription(device);
            Assert.AreEqual(CardReaderDescription, deviceName);
        }

        [Flags]
        public enum Device
        {
            None = 0,

            /// <summary>
            /// Считыватель пропусков
            /// </summary>
            [System.ComponentModel.Description(CardReaderDescription)]
            CardReader = 1,

            /// <summary>
            /// ККМ
            /// </summary>
            KKM = 2,

            /// <summary>
            /// Банковский терминал
            /// </summary>
            PayTerminal = 4
        }

    }
}
