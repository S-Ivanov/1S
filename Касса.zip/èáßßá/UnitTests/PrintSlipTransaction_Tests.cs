﻿using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment.KKM;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class PrintSlipTransaction_Tests
    {
        [TestMethod]
        public void PrintSlipTransaction_MakeSlip_Test()
        {
            string slipText = 
@"строка 1
строка 2";
            IEnumerable<TextInfo> result = PrintSlipTransaction.MakeSlip(slipText);
            Assert.IsNotNull(result);
        }
    }
}
