﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TypeConsoleTest
{
    class Program
    {
        delegate int Sum(int a, int b);

        static void Main(string[] args)
        {
            Sum sum = GetT<Sum>();

            //Console.WriteLine(sum.ToString());

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }

        static T GetT<T>() where T: class
        {
            Type t = typeof(T);
            Console.WriteLine(t.Name);

            return default(T);
        }

        public class A
        {
        }
    }
}
