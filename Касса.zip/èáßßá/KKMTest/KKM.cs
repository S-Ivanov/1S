﻿using System;

namespace PayCardTest
{
    /// <summary>
    /// ККМ
    /// </summary>
    /// <remarks>
    /// Исходники кассы C# (только ККМ):
    /// https://github.com/pistol88/dvizh-seller
    /// </remarks>
    public class KKM : IDisposable
    {
        public KKM()
        {
            Type f = Type.GetTypeFromProgID("AddIn.FprnM45", true);
            _driver = Activator.CreateInstance(f);
            if (_driver == null)
                throw new NotSupportedException();
        }

        //#region Низкоуровневые свойства и методы

        //#region Низкоуровневые свойства
        ///// <summary>
        ///// Имя шрифта диалогов
        ///// </summary>
        //public string DialogFontName
        //{
        //    get => _driver.DialogFontName;
        //    set => _driver.DialogFontName = value;
        //}

        ///// <summary>
        ///// Имя шрифта диалогов
        ///// </summary>
        //public int DialogFontSize
        //{
        //    get => _driver.DialogFontSize;
        //    set => _driver.DialogFontSize = value;
        //}

        ///// <summary>
        ///// Стиль шрифта диалогов
        ///// </summary>
        //public int DialogFontStyle
        //{
        //    get => _driver.DialogFontStyle;
        //    set => _driver.DialogFontStyle = value;
        //}

        ///// <summary>
        ///// Код результата
        ///// </summary>
        //public int ResultCode
        //{
        //    get => _driver.ResultCode;
        //}

        ///// <summary>
        ///// Описание результата
        ///// </summary>
        //public string ResultDescription
        //{
        //    get => _driver.ResultDescription;
        //}

        ///// <summary>
        ///// Код уточняющей ошибки
        ///// </summary>
        //public int BadParam
        //{
        //    get => _driver.BadParam;
        //}

        ///// <summary>
        ///// Описание уточняющего кода ошибки
        ///// </summary>
        //public string BadParamDescription
        //{
        //    get => _driver.BadParamDescription;
        //}

        ///// <summary>
        ///// Признак тестового режима
        ///// </summary>
        //public bool TestMode
        //{
        //    get => _driver.TestMode;
        //    set => _driver.TestMode = value;
        //}

        ///// <summary>
        ///// Положение десятичной точки
        ///// </summary>
        //public int PointPosition
        //{
        //    get => _driver.PointPosition;
        //    set => _driver.PointPosition = value;
        //}

        ///// <summary>
        ///// Проверять модель ККМ
        ///// </summary>
        //public bool ModelCheck
        //{
        //    get => _driver.ModelCheck;
        //    set => _driver.ModelCheck = value;
        //}

        ///// <summary>
        ///// Признак поддержки ККМ ФЗ-54
        ///// </summary>
        //public bool Is54FZ
        //{
        //    get => _driver.Is54FZ;
        //}

        ///// <summary>
        ///// Длина строки символов на текущей станции
        ///// </summary>
        //public int CharLineLength
        //{
        //    get => _driver.CharLineLength;
        //}

        ///// <summary>
        ///// Длина строки в точках на текущей станции
        ///// </summary>
        //public int PixelLineLength
        //{
        //    get => _driver.PixelLineLength;
        //}

        ///// <summary>
        ///// Длина строки символов на ЧЛ: в зависимости от модели ККМ
        ///// </summary>
        //public int RcpCharLineLength
        //{
        //    get => _driver.RcpCharLineLength;
        //}

        ///// <summary>
        ///// Длина строки в точках на ЧЛ: в зависимости от модели ККМ
        ///// </summary>
        //public int RcpPixelLineLength
        //{
        //    get => _driver.RcpPixelLineLength;
        //}

        ///// <summary>
        ///// Длина строки символов на КЛ: в зависимости от модели ККМ
        ///// </summary>
        //public int JrnCharLineLength
        //{
        //    get => _driver.JrnCharLineLength;
        //}

        ///// <summary>
        ///// Длина строки в точках на КЛ: в зависимости от модели ККМ
        ///// </summary>
        //public int JrnPixelLineLength
        //{
        //    get => _driver.JrnPixelLineLength;
        //}

        ///// <summary>
        ///// Длина строки символов на ПД: в зависимости от модели ККМ
        ///// </summary>
        //public int SlipCharLineLength
        //{
        //    get => _driver.SlipCharLineLength;
        //}

        ///// <summary>
        ///// Длина строки в точках на ПД: в зависимости от модели ККМ
        ///// </summary>
        //public int SlipPixelLineLength
        //{
        //    get => _driver.SlipPixelLineLength;
        //}

        ///// <summary>
        ///// Версия драйвера
        ///// </summary>
        //public string Version
        //{
        //    get => _driver.Version;
        //}

        ///// <summary>
        ///// Версия сервера
        ///// </summary>
        //public string ServerVersion
        //{
        //    get => _driver.ServerVersion;
        //}

        ///// <summary>
        ///// Дескриптор главного окна клиентского приложения
        ///// </summary>
        //public int ApplicationHandle
        //{
        //    get => _driver.ApplicationHandle;
        //    set => _driver.ApplicationHandle = value;
        //}

        ///// <summary>
        ///// Название драйвера
        ///// </summary>
        //public string DeviceDescription
        //{
        //    get => _driver.DeviceDescription;
        //}

        ///// <summary>
        ///// Включен бесплатный режим драйвера
        ///// </summary>
        //public bool IsDemo
        //{
        //    get => _driver.IsDemo;
        //}

        ///// <summary>
        ///// Индекс текущего устройства
        ///// </summary>
        //public int CurrentDeviceIndex
        //{
        //    get => _driver.CurrentDeviceIndex;
        //    set => _driver.CurrentDeviceIndex = value;
        //}

        ///// <summary>
        ///// Номер текущего устройства
        ///// </summary>
        //public int CurrentDeviceNumber
        //{
        //    get => _driver.CurrentDeviceNumber;
        //    set => _driver.CurrentDeviceNumber = value;
        //}

        ///// <summary>
        ///// Имя ПК в сети
        ///// </summary>
        //public string MachineName
        //{
        //    get => _driver.MachineName;
        //    set => _driver.MachineName = value;
        //}

        ///// <summary>
        ///// Номер порта
        ///// </summary>
        //public int PortNumber
        //{
        //    get => _driver.PortNumber;
        //    set => _driver.PortNumber = value;
        //}

        ///// <summary>
        ///// Номер порта
        ///// </summary>
        //public int BaudRate
        //{
        //    get => _driver.BaudRate;
        //    set => _driver.BaudRate = value;
        //}

        ///// <summary>
        ///// IP адрес и порт ПК
        ///// </summary>
        //public string HostAddress
        //{
        //    get => _driver.HostAddress;
        //    set => _driver.HostAddress = value;
        //}

        ///// <summary>
        ///// Модель ККМ
        ///// </summary>
        //public int Model
        //{
        //    get => _driver.Model;
        //    set => _driver.Model = value;
        //}

        ///// <summary>
        ///// Пароль доступа к ККМ: строка цифр длиной не более 8
        ///// </summary>
        //public string AccessPassword
        //{
        //    get => _driver.AccessPassword;
        //    set => _driver.AccessPassword = value;
        //}

        ///// <summary>
        ///// Использовать пароль доступа к ККМ
        ///// </summary>
        //public bool UseAccessPassword
        //{
        //    get => _driver.UseAccessPassword;
        //    set => _driver.UseAccessPassword = value;
        //}

        ///// <summary>
        ///// Пароль оператора ККМ, используемый по умолчанию
        ///// </summary>
        //public string DefaultPassword
        //{
        //    get => _driver.DefaultPassword;
        //    set => _driver.DefaultPassword = value;
        //}

        ///// <summary>
        ///// Расширенный журнал
        ///// </summary>
        //public int WriteLogFile
        //{
        //    get => _driver.WriteLogFile;
        //    set => _driver.WriteLogFile = value;
        //}


        //#endregion Низкоуровневые свойства

        //#region Низкоуровневые методы
        //#endregion Низкоуровневые методы

        //#endregion Низкоуровневые свойства и методы

        public void PrintString(string s)
        {
            _driver.DeviceEnabled = true;
            _driver.Caption = s;
            _driver.PrintString();
        }

        public void Dispose()
        {
            _driver = null;
        }

        dynamic _driver = null;
    }
}
