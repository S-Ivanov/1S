﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace MailConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // drg;25;1ctraktir@drg.dol.ru;hTRv475;1ctraktir@drg.dol.ru;Сервер 1С:Трактиръ
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress("sivanov@drg.dol.ru");
            //mail.To.Add("sivanov@drg.dol.ru");
            mail.To.Add("belyshev@drg.dol.ru");
            mail.Subject = "TEST";
            mail.Body = "This is the c sharp mail content";
            SmtpClient smtp = new SmtpClient("drg");
            //NetworkCredential Credentials = new NetworkCredential("1ctraktir", "hTRv475");
            NetworkCredential Credentials = new NetworkCredential("sivanov", "S53zxa");
            smtp.Credentials = Credentials;
            smtp.Send(mail);

            Console.WriteLine();
            Console.Write("Press Enter to exit ...");
            Console.ReadLine();
        }
    }
}
