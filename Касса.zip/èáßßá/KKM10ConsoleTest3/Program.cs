﻿using System;
using System.Threading;
using Atol.Drivers10.Fptr;

namespace KKM10ConsoleTest3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Инициализация драйвера
            IFptr fptr = new Fptr();

            // настройка драйвера
            fptr.setSingleSetting(Constants.LIBFPTR_SETTING_MODEL, Constants.LIBFPTR_MODEL_ATOL_AUTO.ToString());
            fptr.setSingleSetting(Constants.LIBFPTR_SETTING_PORT, Constants.LIBFPTR_PORT_USB.ToString());
            fptr.applySingleSettings();

            // открытие драйвера
            fptr.open();

            //while (true)
            //{
            //    //fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
            //    //fptr.queryData();

            //    //uint mode = fptr.getParamInt(Constants.LIBFPTR_PARAM_MODE);
            //    //uint submode = fptr.getParamInt(Constants.LIBFPTR_PARAM_SUBMODE);
            //    //uint shiftState = fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_NUMBER);

            //    //bool isPrinterError = fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_ERROR);
            //    //bool isPrinterConnectionLost = fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_CONNECTION_LOST);

            //    fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_FN_INFO);
            //    fptr.fnQueryData();

            //    uint fnState = fptr.getParamInt(Constants.LIBFPTR_PARAM_FN_STATE);

            //    Console.WriteLine($"fnState: {fnState}");

            //    Thread.Sleep(500);
            //}

            //// Информация о ФН
            //fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_FN_INFO);
            //fptr.fnQueryData();

            //// +
            //uint fnState = fptr.getParamInt(Constants.LIBFPTR_PARAM_FN_STATE);
            //bool fnNeedReplacement = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_NEED_REPLACEMENT);
            //bool fnExhausted = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_RESOURCE_EXHAUSTED);
            //bool fnMemoryOverflow = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_MEMORY_OVERFLOW);
            //bool fnCriticalError = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_CRITICAL_ERROR);

            //// Срок действия ФН
            //fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_VALIDITY);
            //fptr.fnQueryData();

            //DateTime fnExpire = fptr.getParamDateTime(Constants.LIBFPTR_PARAM_DATE_TIME);

            //// Статус информационного обмена
            //fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_OFD_EXCHANGE_STATUS);
            //fptr.fnQueryData();

            //DateTime firstNonSendDateTime = fptr.getParamDateTime(Constants.LIBFPTR_PARAM_DATE_TIME);

            #region Проверка печати кассира

            #region Открытие смены

            //RegisterOperator(fptr);
            //fptr.openShift();

            #endregion Открытие смены

            #region Печать чека

            //// Открытие чека
            //RegisterOperator(fptr);
            //ShowError(fptr, "Регистрация кассира");

            //// LIBFPTR_RT_SELL - чек прихода(продажи)
            //// LIBFPTR_RT_SELL_RETURN - чек возврата прихода(продажи)
            //fptr.setParam(Constants.LIBFPTR_PARAM_RECEIPT_TYPE, Constants.LIBFPTR_RT_SELL);
            //fptr.openReceipt();

            //// Регистрация позиции без указания суммы налога
            //fptr.setParam(Constants.LIBFPTR_PARAM_COMMODITY_NAME, "Пакеты фасовочные");

            // флаг штучного товара. В количестве не будут напечатаны нули в дробной части
            //  LIBFPTR_PARAM_COMMODITY_PIECE

            //fptr.setParam(Constants.LIBFPTR_PARAM_PRICE, 0.46);
            //fptr.setParam(Constants.LIBFPTR_PARAM_QUANTITY, 1);
            //fptr.setParam(Constants.LIBFPTR_PARAM_TAX_TYPE, Constants.LIBFPTR_TAX_VAT18);
            //fptr.registration();

            //// Зарегистрировать оплату
            //fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_TYPE, Constants.LIBFPTR_PT_CASH);
            //fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_SUM, 0.46);
            //fptr.payment();

            //// Закрытие полностью оплаченного чека
            //fptr.closeReceipt();
            //ShowError(fptr, "Закрытие чека");

            #endregion Печать чека

            #region Закрытие смены

            RegisterOperator(fptr);
            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_CLOSE_SHIFT);
            fptr.report();

            #endregion Закрытие смены

            #endregion Проверка печати кассира

            // Деинициализация драйвера
            fptr.close();

            //Console.WriteLine($"Состояние ФН: {fnState}");
            //Console.WriteLine($"Требуется срочная замена ФН: {fnNeedReplacement}");
            //Console.WriteLine($"Исчерпан ресурс ФН: {fnExhausted}");
            //Console.WriteLine($"Память ФН переполнена: {fnMemoryOverflow}");
            //Console.WriteLine($"Критическая ошибка ФН: {fnCriticalError}");
            //Console.WriteLine($"Срок действия ФН: {fnExpire}");
            //Console.WriteLine($"Дата и время первого неотправленного документа: {firstNonSendDateTime}");

            Console.WriteLine();
            Console.Write("Press Enter to exit ...");
            Console.ReadLine();
        }

        private static void ShowError(IFptr fptr, string errorLabel)
        {
            int errorCode = fptr.errorCode();
            if (errorCode != 0)
                Console.WriteLine($"{errorLabel}: {errorCode} - {fptr.errorDescription()}");
        }

        private static void RegisterOperator(IFptr fptr)
        {
            fptr.setParam(1021, "Кассир Иванов С.В.");
            fptr.setParam(1203, "123456789047");
            fptr.operatorLogin();
        }
    }
}
