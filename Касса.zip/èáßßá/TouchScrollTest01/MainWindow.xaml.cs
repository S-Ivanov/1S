﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TouchScrollTest01
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            scrollDragger = new ScrollDragger(listview, scrollViewer);

            MyCommand = new ICommandImplementation();
            DataContext = this;
        }

        ScrollDragger scrollDragger;

        //private void DropHandler(object sender, DragEventArgs e)
        //{
        //    var source = e.Data.GetData("Source") as string;
        //    if (source != null)
        //    {
        //        int newIndex = listview.Items.IndexOf((sender as Button).Content);
        //        var list = listview.ItemsSource as ObservableCollection<string>;
        //        list.RemoveAt(list.IndexOf(source));
        //        list.Insert(newIndex, source);
        //    }
        //}

        //private void PreviewMouseMoveHandler(object sender, MouseEventArgs e)
        //{
        //    if (e.LeftButton == MouseButtonState.Pressed)
        //    {
        //        Task.Factory.StartNew(new Action(() =>
        //        {
        //            Thread.Sleep(500);
        //            App.Current.Dispatcher.BeginInvoke(new Action(() =>
        //            {
        //                if (e.LeftButton == MouseButtonState.Pressed)
        //                {
        //                    var data = new DataObject();
        //                    data.SetData("Source", (sender as Button).Content);
        //                    DragDrop.DoDragDrop(sender as DependencyObject, data, DragDropEffects.Move);
        //                    e.Handled = true;
        //                }
        //            }), null);
        //        }), CancellationToken.None);
        //    }
        //}

        public string[] MyData
        {
            get
            {
                return new string[]{
                "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"
            };
            }
        }

        public ICommand MyCommand { get; private set; }

        private class ICommandImplementation : ICommand
        {
            public bool CanExecute(object parameter) { return true; }
            public event EventHandler CanExecuteChanged;
            public void Execute(object parameter) { System.Windows.MessageBox.Show("Button clicked! " + (parameter ?? "").ToString()); }
        }
    }
}
