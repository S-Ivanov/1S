﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest_01
{
    public class OrderPayment
    {
        private bool usedTerminal;
        private bool usedKKMFiscal;
        Receipt receipt = null;

        public void Start(Order order)
        {
            do
            {
                // очистить историю действий
                ClearActionHistory();

                // сформировать чек
                receipt = MakeReceipt(order);

                // если чек сформирован
                if (receipt != null)
                {
                    if (receipt.PaymentTypes.Contains(PaymentType.Card))
                    {
                        bool? terminalResult = DoTerminalPayment();
                        if (terminalResult == true)
                        {
                            // сохранить подтверждение оплаты в БД
                            usedTerminal = true;
                        }
                        else if (terminalResult == false)
                        {
                            // сохранить информацию об ошибке в БД
                            LockPaymentType(PaymentType.Card);

                        }
                        else
                        {

                        }
                    }
                    else if (receipt.PaymentTypes.Contains(PaymentType.Cash))
                    {

                    }
                    else
                    {

                    }
                }
            } while (receipt != null);
        }

        private void LockPaymentType(PaymentType card)
        {
            throw new NotImplementedException();
        }

        private bool? DoTerminalPayment()
        {
            throw new NotImplementedException();
        }

        private Receipt MakeReceipt(Order order)
        {
            throw new NotImplementedException();
        }

        private void ClearActionHistory()
        {
            usedTerminal = usedKKMFiscal = false;
        }
    }
}
