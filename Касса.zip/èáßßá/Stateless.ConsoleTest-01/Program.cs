﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest_01
{
    class Program
    {
        static void Main(string[] args)
        {
            InitStateMachine();
            TestStateMachine();

            Console.WriteLine();
            Console.ReadLine();
        }

        static void TestOrderPayment()
        {

        }

        static void InitStateMachine()
        {
            paymentManager.CheckPaymentTypes += PaymentManager_CheckPaymentTypes;
            paymentManager.GetOperationResult += PaymentManager_GetOperationResult;
        }

        static void TestStateMachine()
        {
            paymentManager.Start(new Order());

            Console.WriteLine(paymentManager.GetState());
        }

        private static void PaymentManager_GetOperationResult(object sender, OperationResultEventArgs e)
        {
            Console.WriteLine($"Операция: {e.Operation}");
            Console.WriteLine("Введите результат операции:");
            string s = Console.ReadLine();
            e.Result = int.Parse(s);
        }

        private static void PaymentManager_CheckPaymentTypes(object sender, CheckPaymentTypesEventArgs e)
        {
            Console.WriteLine($"Текущее состояние: {paymentManager.GetState()}");
            Console.WriteLine($"Блокированные варианты оплаты: {string.Join(",", e.PaymentTypes)}");

            Console.WriteLine("Введите через пробел допустимые варианты оплаты (Card = 1):");
            string s = Console.ReadLine();
            if (string.IsNullOrEmpty(s))
                e.PaymentTypes = new List<PaymentType>();
            else
            {
                e.PaymentTypes = s.Split().Select(_ => (PaymentType)int.Parse(_)).Except(e.PaymentTypes).ToList();
            }
        }

        static PaymentManager paymentManager = new PaymentManager();
    }
}
