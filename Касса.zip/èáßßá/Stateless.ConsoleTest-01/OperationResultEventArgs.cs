﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest_01
{
    public class OperationResultEventArgs : EventArgs
    {
        public string Operation { get; set; }
        public int Result { get; set; }
    }
}
