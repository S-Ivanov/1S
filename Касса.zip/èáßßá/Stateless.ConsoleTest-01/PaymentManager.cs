﻿using Stateless;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest_01
{
    public class PaymentManager
    {
        public PaymentManager()
        {
            machine = new StateMachine<State, Trigger>(State.Start);

            machine.Configure(State.Start)
                .Permit(Trigger.Start, State.MakePayment);

            machine.Configure(State.MakePayment)
                .OnEntry(
                    () =>
                    {
                        usedTerminal = usedKKMFiscal = false;
                        receipt = MakeReceipt();
                        machine.Fire(Trigger.StartPayment);
                    })
                .PermitDynamic(Trigger.StartPayment,
                    () =>
                    {
                        if (!receipt.PaymentTypes.Any())
                            return State.PaymentFailed;
                        else if (receipt.PaymentTypes.Contains(PaymentType.Card))
                            return State.TerminalPayment;
                        else if (receipt.PaymentTypes.Contains(PaymentType.Cash))
                            return State.KKMFiscal;
                        else
                            return State.KKMNotFiscal;
                    });

            machine.Configure(State.TerminalPayment)
                .OnEntry(
                    () =>
                    {
                        terminalResult = DoTerminalPayment();
                        machine.Fire(Trigger.FinishTerminal);
                    })
                .PermitDynamic(Trigger.FinishTerminal,
                    () =>
                    {
                        if (terminalResult == NO_ERROR)
                        {
                            // сохранить результаты в БД
                            usedTerminal = true;
                            return State.KKMFiscal;
                        }
                        else
                        {
                            if (terminalResult == ERROR)
                            {
                                // сохранить результаты в БД
                                LockPaymentType(PaymentType.Card);
                            }
                            return State.MakePayment;
                        }
                    });

            machine.Configure(State.KKMFiscal)
                .OnEntry(
                    () =>
                    {
                        kkmResult = DoKKMFiscal();
                        machine.Fire(Trigger.FinishKKMFiscal);
                    })
                .PermitDynamic(Trigger.FinishKKMFiscal, 
                    () =>
                    {
                        if (kkmResult == ERROR)
                            return State.KKMFiscalFixError;
                        else
                        {
                            usedKKMFiscal = true;
                            if (receipt.PaymentTypes.Contains(PaymentType.ZP) || receipt.PaymentTypes.Contains(PaymentType.LPP))
                                return State.KKMNotFiscal;
                            else
                                return State.FinishedOK;
                        }
                    });

            machine.Configure(State.KKMFiscalFixError)
                .OnEntry(
                    () =>
                    {
                        kkmResult = DoKKMFiscalFixError();
                        machine.Fire(Trigger.FinishKKMFiscalFixError);
                    })
                .PermitDynamic(Trigger.FinishKKMFiscalFixError,
                    () =>
                    {
                        if (kkmResult == NO_ERROR)
                            return State.KKMFiscal;
                        else
                        {
                            if (usedTerminal)
                                CancelTerminal();
                            if (usedKKMFiscal)
                                CancelKKMFiscal();

                            LockPaymentType(PaymentType.Card);
                            LockPaymentType(PaymentType.Cash);

                            return State.MakePayment;
                        }
                    });

            machine.Configure(State.KKMNotFiscal)
                .OnEntry(
                    () =>
                    {
                        kkmResult = DoKKMNotFiscal();
                        machine.Fire(Trigger.FinishKKMNotFiscal);
                    })
                .PermitDynamic(Trigger.FinishKKMNotFiscal, () => kkmResult == NO_ERROR ? State.FinishedOK : State.KKMNotFiscalFixError);

            machine.Configure(State.KKMNotFiscalFixError)
                .OnEntry(
                    () =>
                    {
                        kkmResult = DoKKMNotFiscalFixError();
                        machine.Fire(Trigger.FinishKKMNotFiscalFixError);
                    })
                .PermitDynamic(Trigger.FinishKKMNotFiscalFixError,
                    () =>
                    {
                        if (kkmResult == NO_ERROR)
                            return State.KKMNotFiscal;
                        else
                        {
                            if (usedTerminal)
                                CancelTerminal();
                            if (usedKKMFiscal)
                                CancelKKMFiscal();

                            LockPaymentType(PaymentType.ZP);
                            LockPaymentType(PaymentType.LPP);

                            return State.PaymentFailed;
                        }
                    });
        }

        private void CancelKKMFiscal()
        {
            Console.WriteLine("CancelKKMFiscal");
        }

        private void CancelTerminal()
        {
            Console.WriteLine("CancelTerminal");
        }

        void LockPaymentType(PaymentType paymentType)
        {
            NoPaymentTypes.Add(paymentType);
        }

        enum Trigger
        {
            /// <summary>
            /// Начать работу
            /// </summary>
            Start,

            /// <summary>
            /// Начать оплату
            /// </summary>
            StartPayment,

            /// <summary>
            /// Закончить оплату через теримнал
            /// </summary>
            FinishTerminal,

            /// <summary>
            /// ККМ - закончить обработку фискального чека
            /// </summary>
            FinishKKMFiscal,

            /// <summary>
            /// ККМ - закончить обработку ошибки фискального чека
            /// </summary>
            FinishKKMFiscalFixError,

            /// <summary>
            /// ККМ - закончить обработку нефискального чека
            /// </summary>
            FinishKKMNotFiscal,

            /// <summary>
            /// ККМ - закончить обработку ошибки нефискального чека
            /// </summary>
            FinishKKMNotFiscalFixError,

            Finish
        }

        public enum State
        {
            Start,

            /// <summary>
            /// Формирование оплаты
            /// </summary>
            MakePayment,

            /// <summary>
            /// Оплата через терминал
            /// </summary>
            TerminalPayment,

            /// <summary>
            /// Выход - нет доступных вариантов оплаты
            /// </summary>
            PaymentFailed,

            /// <summary>
            /// ККМ - обработка фискального чека
            /// </summary>
            KKMFiscal,

            /// <summary>
            /// ККМ - обработка ошибки фискального чека
            /// </summary>
            KKMFiscalFixError,

            /// <summary>
            /// ККМ - обработка нефискального чека
            /// </summary>
            KKMNotFiscal,

            /// <summary>
            /// ККМ - обработка ошибки нефискального чека
            /// </summary>
            KKMNotFiscalFixError,

            /// <summary>
            /// Выход - оплата завершена успешно
            /// </summary>
            FinishedOK
        }

        public void Start(Order order)
        {
            NoPaymentTypes.Clear();

            this.order = order;

            machine.Fire(Trigger.Start);
        }

        public State GetState() => machine.State;

        Receipt MakeReceipt()
        {
            var checkPaymentTypesEventArgs = new CheckPaymentTypesEventArgs { PaymentTypes = NoPaymentTypes.ToList() };
            CheckPaymentTypes?.Invoke(this, checkPaymentTypesEventArgs);

            return new Receipt { PaymentTypes = checkPaymentTypesEventArgs.PaymentTypes };
        }

        /// <summary>
        /// Оплата по терминалу
        /// </summary>
        private int DoTerminalPayment()
        {
            // ...

            // результат оплаты
            OperationResultEventArgs operationResultEventArgs = new OperationResultEventArgs { Operation = "DoTerminalPayment" };
            GetOperationResult?.Invoke(this, operationResultEventArgs);
            return operationResultEventArgs.Result;

        }

        /// <summary>
        /// ККМ - обработка фискального чека
        /// </summary>
        private int DoKKMFiscal()
        {
            OperationResultEventArgs operationResultEventArgs = new OperationResultEventArgs { Operation = "DoKKMFiscal" };
            GetOperationResult?.Invoke(this, operationResultEventArgs);
            return operationResultEventArgs.Result;
        }

        private int DoKKMFiscalFixError()
        {
            OperationResultEventArgs operationResultEventArgs = new OperationResultEventArgs { Operation = "DoKKMFiscalFixError" };
            GetOperationResult?.Invoke(this, operationResultEventArgs);
            return operationResultEventArgs.Result;
        }

        /// <summary>
        /// ККМ - обработка нефискального чека
        /// </summary>
        private int DoKKMNotFiscal()
        {
            OperationResultEventArgs operationResultEventArgs = new OperationResultEventArgs { Operation = "DoKKMNotFiscal" };
            GetOperationResult?.Invoke(this, operationResultEventArgs);
            return operationResultEventArgs.Result;
        }

        private int DoKKMNotFiscalFixError()
        {
            OperationResultEventArgs operationResultEventArgs = new OperationResultEventArgs { Operation = "DoKKMNotFiscalFixError" };
            GetOperationResult?.Invoke(this, operationResultEventArgs);
            return operationResultEventArgs.Result;
        }

        /// <summary>
        /// Событие проверки возможных вариантов оплаты
        /// </summary>
        public event EventHandler<CheckPaymentTypesEventArgs> CheckPaymentTypes;

        /// <summary>
        /// Событие получения результата операции
        /// </summary>
        public event EventHandler<OperationResultEventArgs> GetOperationResult;

        public HashSet<PaymentType> NoPaymentTypes { get; set; } = new HashSet<PaymentType>();

        int terminalResult;
        bool usedTerminal;
        bool usedKKMFiscal;
        int kkmResult;

        StateMachine<State, Trigger> machine;

        Order order;
        Receipt receipt;

        const int NO_ERROR = 0;
        const int ERROR = 1;
        const int CANCEL = 2;
    }
}
