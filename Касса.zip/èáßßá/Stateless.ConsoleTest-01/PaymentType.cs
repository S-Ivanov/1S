﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest_01
{
    /// <summary>
    /// Варианты оплаты
    /// </summary>
    public enum PaymentType
    {
        None = 0,
        Card = 1,
        Cash = 2,
        ZP = 3,
        LPP = 4
    }
}
