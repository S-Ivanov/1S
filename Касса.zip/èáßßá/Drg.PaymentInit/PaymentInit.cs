﻿using Drg.PaymentInitInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.PaymentInit
{
    public class PaymentInit : IPaymentInit
    {
        #region Реализация интерфейса IPaymentInit

        public bool TryInit(IDictionary<int, decimal> paymentTypes, IDictionary<int, decimal> limits, int startPaymentType, decimal sum, out IDictionary<int, decimal> result)
        {
            result = new Dictionary<int, decimal>();
            decimal limit;
            switch (startPaymentType)
            {
                case ZP:
                    if (limits.TryGetValue(ZP, out limit))
                    {
                        if (limit >= sum)
                            result.Add(ZP, sum);
                        else
                        {
                            result.Add(ZP, limit);
                            if (paymentTypes.ContainsKey(BankCard))
                                result.Add(BankCard, sum - limit);
                            else if (paymentTypes.ContainsKey(Cash))
                                result.Add(Cash, sum - limit);
                            else
                                // TODO возможна оплата талоном 120 - ?
                                return false;
                        }

                    }
                    else
                        result.Add(ZP, sum);
                    return true;
            }
            return false;
        }

        #endregion Реализация интерфейса IPaymentInit

        // см. Drg.CashDeskLib.DataModel.Payment
        const int ZP = 0;
        const int LPP = 1;
        const int Talon120 = 2;
        const int BankCard = 3;
        const int Cash = 4;
    }
}
