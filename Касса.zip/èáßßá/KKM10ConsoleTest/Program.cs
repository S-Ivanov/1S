﻿using Drg.KKM10;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KKM10ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            IntPtr handle;
            int result;
            result = KkmDllInterface.libfptr_create(out handle);
            if (result < 0)
            {
                Console.WriteLine("Ошибка libfptr_create: {0}", result);
                goto Exit;
            }

            try
            {
                //// Model - libfptr_model.LIBFPTR_MODEL_ATOL_22F
                //// Port - libfptr_port.LIBFPTR_PORT_USB
                string settings = "{ \"Model\":63, \"Port\":1 }";
                result = KkmDllInterface.libfptr_set_settings(handle, settings);
                if (result < 0)
                {
                    result = KkmDllInterface.libfptr_error_code(handle);
                    throw new ApplicationException("libfptr_set_settings: " + result.ToString());
                }

                result = KkmDllInterface.libfptr_open(handle);
                if (result < 0)
                {
                    result = KkmDllInterface.libfptr_error_code(handle);
                    throw new ApplicationException("libfptr_open: " + result.ToString());
                }

                //result = KkmDllInterface.libfptr_begin_nonfiscal_document(handle);
                //if (result < 0)
                //    throw new ApplicationException("libfptr_begin_nonfiscal_document: " + result.ToString());

                KkmDllInterface.libfptr_set_param_str(handle, libfptr_param.LIBFPTR_PARAM_TEXT, "Тестовая строка");
                KkmDllInterface.libfptr_set_param_int(handle, libfptr_param.LIBFPTR_PARAM_ALIGNMENT, (uint)libfptr_alignment.LIBFPTR_ALIGNMENT_CENTER);
                result = KkmDllInterface.libfptr_print_text(handle);
                if (result < 0)
                {
                    result = KkmDllInterface.libfptr_error_code(handle);
                    throw new ApplicationException("libfptr_print_text: " + result.ToString());
                }

                //result = KkmDllInterface.libfptr_end_nonfiscal_document(handle);
                //if (result < 0)
                //    throw new ApplicationException("libfptr_end_nonfiscal_document: " + result.ToString());
            }
            finally
            {
                result = KkmDllInterface.libfptr_close(handle);
                if (result < 0)
                {
                    Console.WriteLine("Ошибка libfptr_close: {0}", result);
                }
                KkmDllInterface.libfptr_destroy(handle);
            }

            Exit:
            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}
