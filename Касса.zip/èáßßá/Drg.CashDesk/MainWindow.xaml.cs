﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, {cashDesk.Operator.FIO}";
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            //abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;
            abilityIndicator.OnExit += AbilityIndicator_OnExit;

            viewModel.LocalMenuItemDelete += ViewModel_LocalMenuItemDelete;
            //viewModel.AddOrderItemEvent += ViewModel_AddOrderItemEvent;
            //viewModel.CashDeskModeChangedEvent += ViewModel_CashDeskModeChangedEvent;

            OrderReturnControl.ReturnEvent += OrderReturnControl_ReturnEvent;
            //OrderReturnControl.WholeOrderReturnEvent += OrderReturnControl_WholeOrderReturnEvent; 

            OrderControl.Order = new DataModel.Order();
            OrderControl.OnChangeCashDeskMode += OrderControl_OnChangeCashDeskMode;

            MenuControl.MenuManager = menuManager;
            MenuControl.Menu = menuManager.TodayMenu;
            MenuControl.IsCurrentMenu = true;
            MenuControl.SelectMenuItemEvent += MenuControl_SelectMenuItemEvent;
            MenuControl.ServiceEvent += MenuControl_ServiceEvent;

            OldMenuControl.MenuManager = menuManager;
            OldMenuControl.Menu = menuManager.PreviousMenu;
            OldMenuControl.IsCurrentMenu = false;
        }

        private void MenuControl_ServiceEvent(object sender, EventArgs e)
        {
            if (MenuControl.IsServiceMode)
            {
                MenuControl.IsServiceMode = OldMenuControl.IsServiceMode = false;
                SetCashDeskMode(CashDeskMode.Work);
            }
            else
                SelectServiceMode();
        }

        private void MenuControl_SelectMenuItemEvent(object sender, DataModelEventArgs<DataModel.MenuItemExt> e)
        {
            OrderControl.AddOrderItem(e.Data);
        }

        MenuManager menuManager = new MenuManager();

        private void OrderControl_OnChangeCashDeskMode(object sender, ChangeCashDeskModeEventArgs e)
        {
            viewModel.CashDeskMode = e.CashDeskMode;
        }

        private void OrderReturnControl_ReturnEvent(object sender, EventArgs e)
        {
            SetCashDeskMode(CashDeskMode.Work);
        }

        //private void ViewModel_AddOrderItemEvent(object sender, DataModelEventArgs<DataModel.MenuItem> e)
        //{
        //    //OrderControl.AddOrderItem(e.Data);
        //}

        private void AbilityIndicator_OnExit(object sender, CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Закрыть текущую смену?", "Подтверждение", MessageBoxButton.YesNoCancel, MessageBoxImage.Question, MessageBoxResult.No);
            if (result == MessageBoxResult.Yes)
                CashDeskLib.CashDesk.Instance.CloseSession();

            e.Cancel = result == MessageBoxResult.Cancel;
        }

        private void ViewModel_LocalMenuItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенный элемент меню?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (viewModel.CashDeskMode == CashDeskMode.Work && OrderControl.Order.Client.RawClient.CardCode != e.CardCode)
                    {
                        CashDeskLib.DataModel.Client client = CashDeskLib.CashDesk.Instance.GetClient(e.CardCode);
                        OrderControl.SetOrderClient(client == null ? DataModel.Client.Empty : new DataModel.Client(client));
                    }
                }));
        }

        //private void ServiceButton_Click(object sender, RoutedEventArgs e)
        //{
        //    SelectServiceMode();
        //}

        private void SelectServiceMode()
        {
            CashDeskMode cashDeskMode = viewModel.CashDeskMode;
            switch (cashDeskMode)
            {
                // переходы из рабочего состояния
                case CashDeskMode.Work:
                    viewModel.CashDeskMode = CashDeskMode.None;

                    SelectModeDialog selectModeDialog = new SelectModeDialog();
                    if (selectModeDialog.ShowDialog() == true)
                    {
                        var serviceCashDeskMode = selectModeDialog.CashDeskMode;
                        switch (serviceCashDeskMode)
                        {
                            case CashDeskMode.MenuService:
                                MenuControl.IsServiceMode = OldMenuControl.IsServiceMode = true;
                                SetCashDeskMode(CashDeskMode.MenuService);
                                return;
                            case CashDeskMode.OrderReturn:
                                if (StartReturnOrder())
                                {
                                    SetCashDeskMode(CashDeskMode.OrderReturn);
                                    return;
                                }
                                break;
                            case CashDeskMode.TotalMoney:
                                ShowTotalMoneyReport();
                                break;
                            case CashDeskMode.TotalProduct:
                                ShowTotalProductReport();
                                break;
                        }
                    }
                    break;
                case CashDeskMode.MenuService:
                case CashDeskMode.OrderReturn:
                    SetCashDeskMode(CashDeskMode.Work);
                    return;
            }

            viewModel.CashDeskMode = CashDeskMode.Work;
        }

        private void ShowTotalProductReport()
        {
            Session session = CashDeskLib.CashDesk.Instance.Session;
            List<CashDeskLib.DataModel.ProductReportItem> productReportItems = CashDeskLib.CashDesk.Instance.LoadProductReportItemList();
            if (productReportItems.Any())
            {
                TotalProductReport totalProductReport = new TotalProductReport(session, productReportItems);
                totalProductReport.ShowDialog();
            }
            else
            {
                MessageBox.Show("Нет данных для отображения", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ShowTotalMoneyReport()
        {
            Session session = CashDeskLib.CashDesk.Instance.Session;
            List<CashDeskLib.DataModel.MoneyReportItem> moneyReportItems = CashDeskLib.CashDesk.Instance.LoadMoneyReportItems();
            if (moneyReportItems.Any())
            {
                TotalMoneyReport totalMoneyReport = new TotalMoneyReport(abilityIndicator, session, moneyReportItems);
                totalMoneyReport.ShowDialog();
            }
            else
            {
                MessageBox.Show("Нет данных для отображения", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        bool StartReturnOrder()
        {
            // вызвать диалог для выбора заказа для возврата
            SelectOrderDialog selectOrderDialog = new SelectOrderDialog();
            if (selectOrderDialog.ShowDialog() != true)
            {
                return false;
            }
            else
            {
                // TODO: возврат заказа:

                // загрузить детальную информацию об исходном заказе
                var orderToReturn = selectOrderDialog.viewModel.SelectedOrder.Order;
                var orderInfo = CashDeskLib.CashDesk.Instance.LoadOrder(orderToReturn.Id);
                CashDesk.DataModel.Client client = CashDesk.DataModel.Client.Empty;
                if (!string.IsNullOrEmpty(orderInfo.Item1) && CashDeskLib.CashDesk.Instance.Clients.TryGetValue(orderInfo.Item1, out CashDeskLib.DataModel.Client rawClient))
                    client = new DataModel.Client(rawClient);

                var returns = orderToReturn.HasReturns ? CashDeskLib.CashDesk.Instance.LoadReturns(orderToReturn.Id) : null;
                ObservableCollection<OrderReturnItem> orderReturnAllItems =
                    returns == null ?
                    new ObservableCollection<OrderReturnItem>() :
                    new ObservableCollection<OrderReturnItem>(returns.SelectMany(order => order.Items.Select(orderItem => new OrderReturnItem(order, orderItem))));

                DataModel.OrderReturn orderReturn = new DataModel.OrderReturn(orderReturnAllItems);

                DataModel.OrderSource orderSource = new DataModel.OrderSource(client, orderInfo.Item2, orderReturn);

                orderReturn.OrderSource = orderSource;

                OrderSourceControl.OrderSource = orderSource;
                OrderReturnControl.OrderReturn = orderReturn;

                return true;
            }
        }

        private void SetCashDeskMode(CashDeskMode cashDeskMode)
        {
            if (viewModel.CashDeskMode != cashDeskMode)
            {
                viewModel.CashDeskMode = cashDeskMode;
                switch (cashDeskMode)
                {
                    case CashDeskMode.Work:
                        OrderControl.Visibility = MenuControl.Visibility = Visibility.Visible;
                        OrderControl.Order = new DataModel.Order();
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = Visibility.Hidden;
                        break;
                    case CashDeskMode.MenuService:
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = OrderControl.Visibility = Visibility.Hidden;
                        MenuControl.Visibility = OldMenuControl.Visibility = Visibility.Visible;
                        break;
                    case CashDeskMode.OrderReturn:
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Visible;
                        OrderControl.Visibility = MenuControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = Visibility.Hidden;
                        break;
                }
            }
        }
    }
}
