﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, кассир: {cashDesk.Operator.FIO}";
            //abilityIndicator.Title = menuGroupBox.ActualHeight.ToString();
            //cardReaderCheckBox.IsChecked = abilityIndicator.HasCardReader;
            abilityIndicator.PropertyChanged += AbilityIndicator_PropertyChanged;
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            //Dispatcher.BeginInvoke(
            //    DispatcherPriority.Background,
            //    new Action(() =>
            //    {
            //        cardCodeLabel.Content = e.CardCode.ToString();
            //    }));
        }

        private void AbilityIndicator_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //if (e.PropertyName == "HasCardReader")
            //    cardReaderCheckBox.IsChecked = abilityIndicator.HasCardReader;
        }
    }
}
