﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, {cashDesk.Operator.FIO}";
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            //abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;
            abilityIndicator.OnExit += AbilityIndicator_OnExit;

            viewModel.LocalMenuItemDelete += ViewModel_LocalMenuItemDelete;
            viewModel.AddOrderItemEvent += ViewModel_AddOrderItemEvent;
            //viewModel.CashDeskModeChangedEvent += ViewModel_CashDeskModeChangedEvent;

            OrderReturnControl.ReturnEvent += OrderReturnControl_ReturnEvent;

            OrderControl.Order = new DataModel.Order();
        }

        private void OrderReturnControl_ReturnEvent(object sender, EventArgs e)
        {
            SetCashDeskMode(CashDeskMode.Work);
        }

        //private void ViewModel_CashDeskModeChangedEvent(object sender, DataModelEventArgs<CashDeskMode> e)
        //{
        //    switch (e.Data)
        //    {
        //        case CashDeskMode.Work:
        //            OrderControl.Visibility = Visibility.Visible;
        //            CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = Visibility.Hidden;
        //            break;
        //        case CashDeskMode.MenuService:
        //            OrderControl.Visibility = Visibility.Hidden;
        //            break;
        //    }
        //}

        private void ViewModel_AddOrderItemEvent(object sender, DataModelEventArgs<DataModel.MenuItem> e)
        {
            OrderControl.AddOrderItem(e.Data);
        }

        private void AbilityIndicator_OnExit(object sender, CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Закрыть текущую смену?", "Подтверждение", MessageBoxButton.YesNoCancel, MessageBoxImage.Question, MessageBoxResult.No);
            if (result == MessageBoxResult.Yes)
                CashDeskLib.CashDesk.Instance.CloseSession(DateTime.Now);

            e.Cancel = result == MessageBoxResult.Cancel;
        }

        private void ViewModel_LocalMenuItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенный элемент меню?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    viewModel.SetClient(e.CardCode);
                }));
        }

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            CashDeskMode cashDeskMode = viewModel.CashDeskMode;
            switch (cashDeskMode)
            {
                case CashDeskMode.Work:
                    SelectModeDialog selectModeDialog = new SelectModeDialog();
                    if (selectModeDialog.ShowDialog() == true)
                    {
                        cashDeskMode = selectModeDialog.CashDeskMode;
                        if (cashDeskMode == CashDeskMode.OrderReturn)
                        {
                            // вызвать диалог для выбора заказа для возврата
                            SelectOrderDialog selectOrderDialog = new SelectOrderDialog();
                            if (selectOrderDialog.ShowDialog() == true)
                            {
                                // TODO: возврат заказа:

                                // загрузить детальную информацию об исходном заказе
                                var orderToReturn = selectOrderDialog.viewModel.SelectedOrder.Order;
                                var orderInfo = CashDeskLib.CashDesk.Instance.LoadOrder(orderToReturn.Id);
                                CashDesk.DataModel.Client client = CashDesk.DataModel.Client.Empty;
                                if (!string.IsNullOrEmpty(orderInfo.Item1) && CashDeskLib.CashDesk.Instance.Clients.TryGetValue(orderInfo.Item1, out CashDeskLib.DataModel.Client rawClient))
                                    client = new DataModel.Client(rawClient);

                                var returns = orderToReturn.HasReturns ? CashDeskLib.CashDesk.Instance.LoadReturns(orderToReturn.Id) : null;
                                ObservableCollection<OrderReturnItem> orderReturnAllItems = 
                                    returns == null ?
                                    new ObservableCollection<OrderReturnItem>() :
                                    new ObservableCollection<OrderReturnItem>(returns.SelectMany(order => order.Items.Select(orderItem => new OrderReturnItem(order, orderItem))));

                                OrderReturn orderReturn = new OrderReturn(orderReturnAllItems);

                                DataModel.OrderSource orderSource = new DataModel.OrderSource(client, orderInfo.Item2, orderReturn);

                                orderReturn.OrderSource = orderSource;

                                OrderSourceControl.OrderSource = orderSource;
                                OrderReturnControl.OrderReturn = orderReturn;
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    break;
                case CashDeskMode.MenuService:
                    cashDeskMode = CashDeskMode.Work;
                    break;
                case CashDeskMode.OrderReturn:
                    cashDeskMode = CashDeskMode.Work;
                    break;
            }

            SetCashDeskMode(cashDeskMode);
        }

        private void SetCashDeskMode(CashDeskMode cashDeskMode)
        {
            if (viewModel.CashDeskMode != cashDeskMode)
            {
                viewModel.CashDeskMode = cashDeskMode;
                switch (cashDeskMode)
                {
                    case CashDeskMode.Work:
                        OrderControl.Visibility = MenuControl.Visibility = Visibility.Visible;
                        OrderControl.Order = new DataModel.Order();
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = Visibility.Hidden;
                        ServiceButton.Content = "Сервис";
                        break;
                    case CashDeskMode.MenuService:
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = OrderControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = Visibility.Visible;
                        ServiceButton.Content = "К работе";
                        break;
                    case CashDeskMode.OrderReturn:
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Visible;
                        OrderControl.Visibility = MenuControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = Visibility.Hidden;
                        break;
                }
            }
        }
    }
}
