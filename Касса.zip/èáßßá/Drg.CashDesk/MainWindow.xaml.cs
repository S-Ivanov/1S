﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, кассир: {cashDesk.Operator.FIO}";
            //abilityIndicator.PropertyChanged += AbilityIndicator_PropertyChanged;
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;

            viewModel.OrderItemChangeCount += ViewModel_OrderItemChangeCount;
            viewModel.OrderItemDelete += ViewModel_OrderItemDelete;
            viewModel.NewOrder += ViewModel_NewOrder;
            viewModel.SelectClient += ViewModel_SelectClient;

            // TODO: остаток по ЗП и талоны - совместить с кнопками
        }

        private void ViewModel_SelectClient(object sender, DataModel.DataModelEventArgs<CashDeskLib.DataModel.Client> e)
        {
            SelectClientWindow selectClientWindow = new SelectClientWindow();
            selectClientWindow.ShowDialog();
        }

        private void AbilityIndicator_EquipmentChecked(object sender, EventArgs e)
        {
            viewModel.PaymentAbilitiesRefresh();
        }

        private void ViewModel_NewOrder(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить имеющиеся строки и создать новый заказ?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Exclamation, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_OrderItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_OrderItemChangeCount(object sender, DataModel.DataModelEventArgs<decimal> e)
        {
            OrderItemChangeCount orderItemChangeCount = new OrderItemChangeCount
            {
                Count = e.Data
            };
            orderItemChangeCount.ShowDialog();
            if (e.Data != orderItemChangeCount.Count)
                e.Data = orderItemChangeCount.Count;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            viewModel.SetClient(e.CardCode);
        }

        //private void AbilityIndicator_PropertyChanged(object sender, PropertyChangedEventArgs e)
        //{
        //    //Dispatcher.BeginInvoke(
        //    //    DispatcherPriority.Background,
        //    //    new Action(() =>
        //    //    {
        //    //        cardCodeLabel.Content = e.CardCode.ToString();
        //    //    }));

        //    //if (e.PropertyName == "HasCardReader")
        //    //    cardReaderCheckBox.IsChecked = abilityIndicator.HasCardReader;
        //}

    }
}
