﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.Utils;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, кассир: {cashDesk.Operator.FIO}";
            //abilityIndicator.PropertyChanged += AbilityIndicator_PropertyChanged;
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;

            viewModel.ChangeCount += ViewModel_ChangeCount;
            viewModel.OrderItemDelete += ViewModel_OrderItemDelete;
            viewModel.NewOrder += ViewModel_NewOrder;
            viewModel.SelectClient += ViewModel_SelectClient;
            viewModel.Payment += ViewModel_Payment;
            viewModel.LocalMenuItemDelete += ViewModel_LocalMenuItemDelete;

            // TODO: остаток по ЗП и талоны - совместить с кнопками
        }

        private void ViewModel_LocalMenuItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенный элемент меню?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_Payment(object sender, DataModel.DataModelEventArgs<DataModel.PaymentInfo> e)
        {
            PayWindow payWindow = new PayWindow();
            payWindow.viewModel.PaymentInfo = e.Data;
            if (payWindow.ShowDialog() == true)
            {
                // TODO: обработать результат управления оплатами

                viewModel.Clear();
            }
        }

        private void ViewModel_SelectClient(object sender, DataModel.DataModelEventArgs<CashDeskLib.DataModel.Client> e)
        {
            SelectClientWindow selectClientWindow = new SelectClientWindow();
            if (selectClientWindow.ShowDialog() == true)
                e.Data = selectClientWindow.viewModel.SelectedClient.RawClient;
            else
                e.Data = null;
        }

        private void AbilityIndicator_EquipmentChecked(object sender, EventArgs e)
        {
            viewModel.PaymentAbilitiesRefresh();
        }

        private void ViewModel_NewOrder(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить имеющиеся строки и создать новый заказ?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_OrderItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_ChangeCount(object sender, ChangeCountEventArgs e)
        {
            ChangeCount changeCount = new ChangeCount(e.Value);

            changeCount.Top = Top + (ActualHeight - changeCount.Height) / 2;
            changeCount.Left = Left + ActualWidth / 2;

            if (e.Type == typeof(OrderItem))
            {
                // установить начальные координаты окна так, чтобы не перекрывался список элементов заказа - установлено changeCount.Left = ...
            }
            else // if (e.Type == typeof(DataModel.MenuItem))
            {
                // установить начальные координаты окна так, чтобы не перекрывался список элементов меню
                changeCount.Left -= changeCount.Width;
            }

            e.Cancel = changeCount.ShowDialog() != true;
            if (!e.Cancel)
                e.Value = changeCount.Count;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            //this.Dispatcher.Invoke((Action)(() => viewModel.SetClient(e.CardCode)));

            Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    viewModel.SetClient(e.CardCode);
                }));
        }

        //void 
        //private void AbilityIndicator_PropertyChanged(object sender, PropertyChangedEventArgs e)
        //{
        //    //Dispatcher.BeginInvoke(
        //    //    DispatcherPriority.Background,
        //    //    new Action(() =>
        //    //    {
        //    //        cardCodeLabel.Content = e.CardCode.ToString();
        //    //    }));

        //    //if (e.PropertyName == "HasCardReader")
        //    //    cardReaderCheckBox.IsChecked = abilityIndicator.HasCardReader;
        //}

    }
}
