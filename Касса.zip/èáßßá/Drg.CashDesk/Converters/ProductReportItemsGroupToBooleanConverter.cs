﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    public class ProductReportItemsGroupToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is ReadOnlyObservableCollection<Object> items)
            {
                if (items.All(_ => ((ProductReportItem)_).IsSelected))
                {
                    return true;
                }
                else if (items.Any(_ => ((ProductReportItem)_).IsSelected))
                {
                    return null;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            //return Binding.DoNothing;
            return value;
        }
    }
}
