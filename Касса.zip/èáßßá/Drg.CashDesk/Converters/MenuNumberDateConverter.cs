﻿using Drg.CashDesk.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    /// <summary>
    /// Конвертер для преобразования объекта меню к строке вида "Меню №{menu.Number} от {menu.Date:dd.MM.yyyy}"
    /// </summary>
    [ValueConversion(typeof(Menu), typeof(string))]
    public class MenuNumberDateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Menu menu = value as Menu;
            return menu == null ? (string)null : $"Меню №{menu.Number} от {menu.Date:dd.MM.yyyy}";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
