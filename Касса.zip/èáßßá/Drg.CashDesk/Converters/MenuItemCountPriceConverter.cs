﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    /// <summary>
    /// Конвертер для преобразования объекта элемента меню к строке вида "(Количество) = (Цена)"
    /// </summary>
    [ValueConversion(typeof(CashDeskLib.DataModel.MenuItem), typeof(string))]
    public class MenuItemCountPriceConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(value is CashDeskLib.DataModel.MenuItem rawItem))
                return ". . .";
            else
            {
                string menuItemCount = rawItem.Count % 1 == 0 ? ((int)rawItem.Count).ToString() : rawItem.Count.ToString();
                return $"{menuItemCount} = {rawItem.Count * rawItem.Price:C}";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
