﻿using Drg.CashDesk.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    /// <summary>
    /// Конвертер для преобразования количества талонов ЛПП к строке вида "(Количество талонов ЛПП) = (Сумма)"
    /// </summary>
    [ValueConversion(typeof(int), typeof(string))]
    public class LppCountSumConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var lpp = (int)value;
            return lpp > 0 ? $"{lpp} = {lpp * CashDeskLib.CashDesk.Instance.Configuration.LPPNominal:N2}" : (string)null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
