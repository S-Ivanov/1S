﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    [ValueConversion(typeof(Payment), typeof(string))]
    public class PaymentToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
              return CashDeskLib.Utils.PaymentUtils.GetPaymentName((Payment)value);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
