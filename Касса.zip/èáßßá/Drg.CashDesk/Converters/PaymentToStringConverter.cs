﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    [ValueConversion(typeof(Payment), typeof(string))]
    public class PaymentToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Payment payment = (Payment)value;
            switch (payment)
            {
                case Payment.BankCard: return "По банковской карте";
                case Payment.Cash: return "Наличными";
                case Payment.LPP: return "Талоны ЛПП";
                case Payment.Talon120: return "Талоны 120";
                case Payment.ZP: return "В счёт зарплаты";
                default: return "";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
