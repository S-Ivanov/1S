﻿using System;
using System.Windows.Input;

namespace Drg.CashDesk.Commands
{
    /// <summary>
    /// Универсальная параметризованны команда
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <remarks>
    /// https://stackoverflow.com/questions/22285866/why-relaycommand/22286816#22286816
    /// ответ 49
    /// </remarks>
    public class RelayCommand<T> : ICommand
    {
        private Action<T> execute;
        private Func<T, bool> canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<T> execute, Func<T, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return this.canExecute == null || this.canExecute((T)parameter);
        }

        public void Execute(object parameter)
        {
            this.execute((T)parameter);
        }
    }

}
