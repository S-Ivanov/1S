﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Drg.CashDesk.DataModel;
using System.Runtime.InteropServices;
using System.Threading;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.CashDesk.Dialogs;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalProductReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<CashDeskLib.DataModel.ProductReportItem> productReportItems)
        {
            InitializeComponent();

            DataContext = this;

            Session = session;

            // формирование записей для вывода на экран
            ProductReportItems = new ObservableCollection<DataModel.ProductReportItem>(productReportItems.Select(_ => new DataModel.ProductReportItem(_)));
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        #region Печать

        // Закрытие окна ответ 4:
        // https://stackoverflow.com/questions/19635749/teardown-a-messagebox-programmatically-without-user-input

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(ProductReportItems.Count(_ => _.IsSelected).ToString(), "", MessageBoxButton.OK);

            //MessageBox messageBox = new MessageBox();

            // начало печати
            //CashDeskLib.CashDesk.Instance.PrintTotalProductReport(cancelTokenSource.Token);
            var kkm = CashDeskLib.CashDesk.Instance.GetKKM();
            if (kkm != null && kkm.LastError == DeviceError.NoError)
            {
                //cancelTokenSource = new CancellationTokenSource();

                //// показать окно отмены
                //thread = new Thread(ShowMessageBox);
                //thread.Start();

                //DoPrint(kkm);

                //// закрыть окно отмены
                //CloseMessageBox();

                ProgressBarDialog progressBarDialog = new ProgressBarDialog();

                CancellationTokenSource cancelTokenSource = new CancellationTokenSource();
                CancellationToken cancelTokenSourceToken = cancelTokenSource.Token;

                //Task.Run(() =>
                //{
                //    for (int i = 0; i < 100; i++)
                //    {
                //        if (token.CanBeCanceled && token.IsCancellationRequested)
                //        {
                //            break;
                //        }

                //        Thread.Sleep(25);
                //        Dispatcher.Invoke(() => progressBarDialog.ProcessProgressBar.Value = i);
                //    }

                //    Dispatcher.Invoke(() => progressBarDialog.Close());
                //    MessageBox.Show("Finish");
                //},
                //token);

                DoPrint(kkm, cancelTokenSourceToken, progressBarDialog);

                if (progressBarDialog.ShowDialog() == true)
                {
                    cancelTokenSource.Cancel();
                }
            }
        }

        private void DoPrint(IKKM kkm, CancellationToken cancelTokenSourceToken, ProgressBarDialog progressBarDialog)
        {
            int lineCount = 0;
            // строки для печати
            List<TextInfo> textInfo = new List<TextInfo>();

            // формирование отчета
            // ...

            // формирование строк данных
            var gg = ProductReportItems
                .Where(_ => _.IsSelected)
                .Select(_ => _.RawItem)
                .OrderBy(_ => _.GroupName)
                .ThenBy(_ => _.Name)
                .ThenBy(_ => _.MeasureName)
                .GroupBy(_ => _.GroupName);

            //var lineLength = kkm.LineLength;
            foreach (var g in gg)
            {
                textInfo.Add(
                    new TextInfo
                    {
                        Text = g.Key,
                        DoubleHeight = true
                    });
                lineCount++;

                // можно заменить ?
                //textInfo.AddRange()
                foreach (var x in g)
                {
                    textInfo.Add(
                        new TextInfo
                        {
                            Text = x.Name,
                            Wrap = TextWrap.Words
                        });
                    textInfo.Add(
                        new TextInfo
                        {
                            Text = x.Balance.ToString(),
                            Alignment = Equipment.KKM.TextAlignment.Right
                        });
                    lineCount++;
                }
            }

            progressBarDialog.ProcessProgressBar.Minimum = 0;
            progressBarDialog.ProcessProgressBar.Maximum = lineCount;
            int currentLine = 0;

            // печать с прерыванием
            kkm.DoActionAsync(
                (int)PrintAction.PrintNotFiscal, 
                textInfo, 
                cancelTokenSourceToken, 
                () =>
                {
                    currentLine++;
                    Dispatcher.Invoke(() => progressBarDialog.ProcessProgressBar.Value = currentLine);
                },
                () => Dispatcher.Invoke(() => progressBarDialog.Close()));
        }

        //[DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        //static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);

        //[DllImport("user32.Dll")]
        //static extern int PostMessage(IntPtr hWnd, UInt32 msg, int wParam, int lParam);

        //const UInt32 WM_CLOSE = 0x0010;

        //Thread thread;

        //void CloseMessageBox()
        //{
        //    IntPtr hWnd = FindWindowByCaption(IntPtr.Zero, "Caption");
        //    if (hWnd != IntPtr.Zero)
        //        PostMessage(hWnd, WM_CLOSE, 0, 0);

        //    if (thread.IsAlive)
        //        thread.Abort();
        //}

        //void ShowMessageBox()
        //{
        //    if (MessageBox.Show("Message", "Caption", MessageBoxButton.OK) == MessageBoxResult.OK)
        //    {
        //        cancelTokenSource.Cancel();
        //    }
        //}

        //CancellationTokenSource cancelTokenSource = new CancellationTokenSource();

        #endregion Печать

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool check = (sender as CheckBox).IsChecked == true;
            foreach (var item in ProductReportItems)
            {
                item.IsSelected = check;
            }

            // TODO: нужно переключеие чекбоксов в заголовках групп
            SetGroupChecks(check);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="check"></param>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        private void SetGroupChecks(bool check)
        {
            // Border
            var child = VisualTreeHelper.GetChild(DataGridProduct, 0);

            // ScrollViewer
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // Grid
            var child3 = VisualTreeHelper.GetChild(child2, 0);

            // ScrollContentPresenter
            var child4 = VisualTreeHelper.GetChild(child3, 2);

            // ItemsPresenter
            var child5 = VisualTreeHelper.GetChild(child4, 0);

            // StackPanel
            var child6 = VisualTreeHelper.GetChild(child5, 0);

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(child6); i++)
            {
                // обработка группы

                // GroupItem
                var group = VisualTreeHelper.GetChild(child6, i);

                // StackPanel
                var child7 = VisualTreeHelper.GetChild(group, 0);

                // Border
                var child8 = VisualTreeHelper.GetChild(child7, 0);

                // DockPanel
                var child9 = VisualTreeHelper.GetChild(child8, 0);

                // CheckBox
                if (VisualTreeHelper.GetChild(child9, 1) is CheckBox checkBox)
                {
                    checkBox.IsChecked = check;
                }
            }
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                (row.Item as CashDesk.DataModel.ProductReportItem).IsSelected = !(row.Item as CashDesk.DataModel.ProductReportItem).IsSelected;
                SetAllCheckBox();
                CheckBox groupHeaderCheckBox = GetGroupHeaderCheckBox(row);
                if (groupHeaderCheckBox != null)
                {
                    SetCheckBoxChecked(groupHeaderCheckBox, ProductReportItems.Where(_ => _.RawItem.GroupName == (row.Item as DataModel.ProductReportItem).RawItem.GroupName));
                }
            }
        }

        /// <summary>
        /// Найти в визуальном дереве CheckBox заголовка группы DataGridProduct
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        CheckBox GetGroupHeaderCheckBox(DataGridRow row)
        {
            // DataGridRowsPresenter
            var parent = VisualTreeHelper.GetParent(row);

            // ItemsPresenter
            var parent2 = VisualTreeHelper.GetParent(parent);

            // StackPanel
            var parent3 = VisualTreeHelper.GetParent(parent2);

            // StackPanel
            var parent4 = VisualTreeHelper.GetParent(parent3);

            // Border
            var child = VisualTreeHelper.GetChild(parent4, 0);

            // DockPanel
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // CheckBox
            var child3 = VisualTreeHelper.GetChild(child2, 1);

            return child3 as CheckBox;
        }

        private void SetAllCheckBox()
        {
            SetCheckBoxChecked(AllCheckBox, ProductReportItems);
        }

        private void SetCheckBoxChecked(CheckBox checkBox, IEnumerable<DataModel.ProductReportItem> items)
        {
            if (items.All(_ => _.IsSelected))
            {
                checkBox.IsChecked = true;
            }
            else if (items.Any(_ => _.IsSelected))
            {
                checkBox.IsChecked = null;
            }
            else
            {
                checkBox.IsChecked = false;
            }
        }

        private void GroupCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            string groupName = checkBox.Tag.ToString();

            foreach (var item in ProductReportItems.Where(_ => _.RawItem.GroupName == groupName))
            {
                item.IsSelected = checkBox.IsChecked == true;
            }

            SetAllCheckBox();
        }
    }
}
