﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<ProductReportItem> productReportItems)
        {
            InitializeComponent();
            Session = session;
            ProductReportItems = new ObservableCollection<CashDesk.DataModel.ProductReportItem>();
            foreach (var productReportItem in productReportItems)
            {
                ProductReportItems.Add(new CashDesk.DataModel.ProductReportItem(productReportItem));
            }
            DataContext = this;
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<CashDesk.DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(ProductReportItems.Count(_ => _.IsSelected).ToString());
        }
    }
}
