﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<ProductReportItem> productReportItems)
        {
            InitializeComponent();

            DataContext = this;

            Session = session;
            ProductReportItems = new ObservableCollection<CashDesk.DataModel.ProductReportItem>();
            foreach (var productReportItem in productReportItems)
            {
                ProductReportItems.Add(new CashDesk.DataModel.ProductReportItem(productReportItem));
            }
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<CashDesk.DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(ProductReportItems.Count(_ => _.IsSelected).ToString());
        }

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in ProductReportItems)
            {
                item.IsSelected = (sender as CheckBox).IsChecked == true;
            }
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                (row.Item as CashDesk.DataModel.ProductReportItem).IsSelected = !(row.Item as CashDesk.DataModel.ProductReportItem).IsSelected;
                SetAllCheckBox();
                CheckBox groupHeaderCheckBox = GetGroupHeaderCheckBox(row);
                if (groupHeaderCheckBox != null)
                {
                    SetCheckBoxChecked(groupHeaderCheckBox, ProductReportItems.Where(_ => _.RawItem.GroupName == (row.Item as DataModel.ProductReportItem).RawItem.GroupName));
                }
            }
        }

        /// <summary>
        /// Найти в визуальном дереве CheckBox заголовка группы DataGridProduct
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// <remarks>
        /// ВАЖНО! Код метода зависит от разметки DataGridProduct
        /// </remarks>
        CheckBox GetGroupHeaderCheckBox(DataGridRow row)
        {
            // DataGridRowsPresenter
            var parent = VisualTreeHelper.GetParent(row);

            // ItemsPresenter
            var parent2 = VisualTreeHelper.GetParent(parent);

            // StackPanel
            var parent3 = VisualTreeHelper.GetParent(parent2);

            // StackPanel
            var parent4 = VisualTreeHelper.GetParent(parent3);

            // DockPanel
            var child = VisualTreeHelper.GetChild(parent4, 0);

            // CheckBox
            var child2 = VisualTreeHelper.GetChild(child, 1);

            return child2 as CheckBox;
        }

        private void SetAllCheckBox()
        {
            SetCheckBoxChecked(AllCheckBox, ProductReportItems);
        }

        private void SetCheckBoxChecked(CheckBox checkBox, IEnumerable<DataModel.ProductReportItem> items)
        {
            if (items.All(_ => _.IsSelected))
            {
                checkBox.IsChecked = true;
            }
            else if (items.Any(_ => _.IsSelected))
            {
                checkBox.IsChecked = null;
            }
            else
            {
                checkBox.IsChecked = false;
            }
        }

        private void GroupCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            string groupName = checkBox.Tag.ToString();

            foreach (var item in ProductReportItems.Where(_ => _.RawItem.GroupName == groupName))
            {
                item.IsSelected = checkBox.IsChecked == true;
            }

            SetAllCheckBox();
        }
    }
}
