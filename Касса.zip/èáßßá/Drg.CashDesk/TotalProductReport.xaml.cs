﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Data;
using System.Windows.Controls;
using Drg.CashDesk.Utils;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<ProductReportItem> productReportItems)
        {
            InitializeComponent();

            DataContext = this;

            Session = session;
            ProductReportItems = new ObservableCollection<CashDesk.DataModel.ProductReportItem>();
            foreach (var productReportItem in productReportItems)
            {
                ProductReportItems.Add(new CashDesk.DataModel.ProductReportItem(productReportItem));
            }

            ListCollectionView listCollectionView = new ListCollectionView(ProductReportItems);
            listCollectionView.GroupDescriptions.Add(new PropertyGroupDescription("RawItem.GroupName"));
            DataGridProduct.ItemsSource = listCollectionView;

        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<CashDesk.DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(ProductReportItems.Count(_ => _.IsSelected).ToString());
        }

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in ProductReportItems)
            {
                item.IsSelected = (sender as CheckBox).IsChecked == true;
            }
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                (row.Item as CashDesk.DataModel.ProductReportItem).IsSelected = !(row.Item as CashDesk.DataModel.ProductReportItem).IsSelected;

                SetAllCheckBox();

                //dynamic groupName = row.VisualParent.DataContext.Name;

                SetGroupCheckBox((row.Item as CashDesk.DataModel.ProductReportItem).RawItem.GroupName);
            }
        }

        private void SetAllCheckBox()
        {
            if (ProductReportItems.All(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = true;
            }
            else if (ProductReportItems.Any(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = null;
            }
            else
            {
                AllCheckBox.IsChecked = false;
            }
        }

        private void GroupCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            string groupName = checkBox.Tag.ToString();

            foreach (var item in ProductReportItems.Where(_ => _.RawItem.GroupName == groupName))
            {
                item.IsSelected = checkBox.IsChecked == true;
            }

            SetAllCheckBox();
        }

        void SetGroupCheckBox(string groupName)
        {
            //foreach (CheckBox img in DataGridProduct.FindChildren<CheckBox>())
            //{
            //    //Console.WriteLine("Image source: " + img.Source);
            //}

            //var xx = DataGridProduct.FindChildren<CheckBox>().ToList();

            //CheckBox checkBox = DataGridProduct.GetChildObjects().FirstOrDefault(_ => (_ is CheckBox) && ((CheckBox)_).Tag.ToString() == groupName);
            //if (checkBox != null)
            //{
            //    MessageBox.Show(groupName);
            //}

            //var xx = DataGridProduct.FindChildren<CheckBox>().ToList();
            //MessageBox.Show(xx.Count.ToString());
        }
    }
}
