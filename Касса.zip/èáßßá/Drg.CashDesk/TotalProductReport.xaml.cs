﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Drg.CashDesk.DataModel;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalProductReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<CashDeskLib.DataModel.ProductReportItem> productReportItems)
        {
            InitializeComponent();

            DataContext = this;

            Session = session;

            // формирование записей для вывода на экран
            ProductReportItems = CreateProductReportItems(HierarchyToList(productReportItems));
        }

        List<CashDeskLib.DataModel.ProductReportItem> HierarchyToList(List<CashDeskLib.DataModel.ProductReportItem> productReportItems)
        {
            List<CashDeskLib.DataModel.ProductReportItem> result = new List<CashDeskLib.DataModel.ProductReportItem>();
            FillResult(result, productReportItems);
            return result;
        }

        private void FillResult(List<CashDeskLib.DataModel.ProductReportItem> result, List<CashDeskLib.DataModel.ProductReportItem> items)
        {
            bool IsLeaf(CashDeskLib.DataModel.ProductReportItem item) => !item.Children.Any();

            result.AddRange(items.Where(_ => IsLeaf(_)));
            foreach (var item in items.Where(_ => !IsLeaf(_)))
            {
                FillResult(result, item.Children);
            }
        }

        ObservableCollection<DataModel.ProductReportItem> CreateProductReportItems(List<CashDeskLib.DataModel.ProductReportItem> productReportItems)
        {
            string GetGroupName(CashDeskLib.DataModel.ProductReportItem item)
            {
                string groupName = "";
                var parent = item.Parent;
                while (parent != null)
                {
                    groupName = string.IsNullOrEmpty(groupName) ? parent.Name : parent.Name + " / " + groupName;
                    parent = parent.Parent;
                }
                return groupName;
            };

            var xx = productReportItems
                .Where(_ => !_.Children.Any())
                .Select(_ => new DataModel.ProductReportItem
                    {
                        Name = _.Name,
                        MeasureName = _.MeasureName,
                        Count = _.Count,
                        ReturnCount = _.ReturnCount,
                        GroupName = GetGroupName(_)
                    })
                .OrderBy(_ => _.GroupName)
                .ThenBy(_ => _.Name)
                .ThenBy(_ => _.MeasureName);

            return new ObservableCollection<DataModel.ProductReportItem>(xx); 
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(ProductReportItems.Count(_ => _.IsSelected).ToString());
        }

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool check = (sender as CheckBox).IsChecked == true;
            foreach (var item in ProductReportItems)
            {
                item.IsSelected = check;
            }

            // TODO: нужно переключеие чекбоксов в заголовках групп
            SetGroupChecks(check);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="check"></param>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        private void SetGroupChecks(bool check)
        {
            // Border
            var child = VisualTreeHelper.GetChild(DataGridProduct, 0);

            // ScrollViewer
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // Grid
            var child3 = VisualTreeHelper.GetChild(child2, 0);

            // ScrollContentPresenter
            var child4 = VisualTreeHelper.GetChild(child3, 2);

            // ItemsPresenter
            var child5 = VisualTreeHelper.GetChild(child4, 0);

            // StackPanel
            var child6 = VisualTreeHelper.GetChild(child5, 0);

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(child6); i++)
            {
                // обработка группы

                // GroupItem
                var group = VisualTreeHelper.GetChild(child6, i);

                // StackPanel
                var child7 = VisualTreeHelper.GetChild(group, 0);

                // Border
                var child8 = VisualTreeHelper.GetChild(child7, 0);

                // DockPanel
                var child9 = VisualTreeHelper.GetChild(child8, 0);

                // CheckBox
                if (VisualTreeHelper.GetChild(child9, 1) is CheckBox checkBox)
                {
                    checkBox.IsChecked = check;
                }
            }
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                (row.Item as CashDesk.DataModel.ProductReportItem).IsSelected = !(row.Item as CashDesk.DataModel.ProductReportItem).IsSelected;
                SetAllCheckBox();
                CheckBox groupHeaderCheckBox = GetGroupHeaderCheckBox(row);
                if (groupHeaderCheckBox != null)
                {
                    SetCheckBoxChecked(groupHeaderCheckBox, ProductReportItems.Where(_ => _.GroupName == (row.Item as DataModel.ProductReportItem).GroupName));
                }
            }
        }

        /// <summary>
        /// Найти в визуальном дереве CheckBox заголовка группы DataGridProduct
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        CheckBox GetGroupHeaderCheckBox(DataGridRow row)
        {
            // DataGridRowsPresenter
            var parent = VisualTreeHelper.GetParent(row);

            // ItemsPresenter
            var parent2 = VisualTreeHelper.GetParent(parent);

            // StackPanel
            var parent3 = VisualTreeHelper.GetParent(parent2);

            // StackPanel
            var parent4 = VisualTreeHelper.GetParent(parent3);

            // Border
            var child = VisualTreeHelper.GetChild(parent4, 0);

            // DockPanel
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // CheckBox
            var child3 = VisualTreeHelper.GetChild(child2, 1);

            return child3 as CheckBox;
        }

        private void SetAllCheckBox()
        {
            SetCheckBoxChecked(AllCheckBox, ProductReportItems);
        }

        private void SetCheckBoxChecked(CheckBox checkBox, IEnumerable<DataModel.ProductReportItem> items)
        {
            if (items.All(_ => _.IsSelected))
            {
                checkBox.IsChecked = true;
            }
            else if (items.Any(_ => _.IsSelected))
            {
                checkBox.IsChecked = null;
            }
            else
            {
                checkBox.IsChecked = false;
            }
        }

        private void GroupCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            string groupName = checkBox.Tag.ToString();

            foreach (var item in ProductReportItems.Where(_ => _.GroupName == groupName))
            {
                item.IsSelected = checkBox.IsChecked == true;
            }

            SetAllCheckBox();
        }
    }
}
