﻿using Drg.CashDeskLib.Utils;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace Drg.CashDesk.Utils
{
    /// <summary>
    /// Кнопочное управление скроллингом датагрида
    /// </summary>
    public class DataGridScroller
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="dataGrid">управляемый датагрид</param>
        /// <param name="buttonPageUp">кнопка PageUp</param>
        /// <param name="buttonPageDown">кнопка PageDown</param>
        public DataGridScroller(DataGrid dataGrid, Button buttonPageUp, Button buttonPageDown)
        {
            Contract.Requires<ArgumentNullException>(dataGrid != null, nameof(dataGrid));
            Contract.Requires<ArgumentNullException>(buttonPageUp != null, nameof(buttonPageUp));
            Contract.Requires<ArgumentNullException>(buttonPageDown != null, nameof(buttonPageDown));

            this.dataGrid = dataGrid;
            this.buttonPageUp = buttonPageUp;
            this.buttonPageDown = buttonPageDown;

            this.buttonPageUp.Click += ButtonPageUp_Click;
            this.buttonPageDown.Click += ButtonPageDown_Click;
        }

        /// <summary>
        /// Установить видимость кнопок управления скроллингом списка людей
        /// </summary>
        public void SetScrollButtonsVisibility()
        {
            if (dataGrid.Items == null || dataGrid.Items.Count == 0)
            {
                buttonPageUp.Visibility = buttonPageDown.Visibility = Visibility.Collapsed;
            }
            else
            {
                dataGrid.UpdateLayout();

                var verticalScrollBar = GetScrollbar(dataGrid, Orientation.Vertical);
                var count = dataGrid.Items.Count;
                var firstRow = verticalScrollBar.Value;
                var lastRow = firstRow + count - verticalScrollBar.Maximum;

                buttonPageUp.Visibility = firstRow > 0 ? Visibility.Visible : Visibility.Collapsed;
                buttonPageDown.Visibility = lastRow < count - 1 ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки PageUp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonPageUp_Click(object sender, RoutedEventArgs e)
        {
            if (dataGridScrollViewer == null)
                dataGridScrollViewer = VisualTreeHelperExt.GetVisualChild<ScrollViewer>(dataGrid);

            dataGridScrollViewer.PageUp();
            SetScrollButtonsVisibility();
        }

        /// <summary>
        /// Обработчик нажатия кнопки PageDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonPageDown_Click(object sender, RoutedEventArgs e)
        {
            if (dataGridScrollViewer == null)
                dataGridScrollViewer = VisualTreeHelperExt.GetVisualChild<ScrollViewer>(dataGrid);

            dataGridScrollViewer.PageDown();
            SetScrollButtonsVisibility();
        }

        /// <summary>
        /// Найти скроллбар
        /// </summary>
        /// <param name="dep"></param>
        /// <param name="orientation"></param>
        /// <returns></returns>
        /// <remarks>
        /// https://stackoverflow.com/questions/29671558/check-if-item-in-a-datagrid-is-already-in-view
        /// ответ 1
        /// </remarks>
        private static ScrollBar GetScrollbar(DependencyObject dep, Orientation orientation)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(dep); i++)
            {
                var child = VisualTreeHelper.GetChild(dep, i);
                var bar = child as ScrollBar;
                if (bar != null && bar.Orientation == orientation)
                    return bar;
                else
                {
                    ScrollBar scrollBar = GetScrollbar(child, orientation);
                    if (scrollBar != null)
                        return scrollBar;
                }
            }
            return null;
        }

        DataGrid dataGrid;
        Button buttonPageUp;
        Button buttonPageDown;
        ScrollViewer dataGridScrollViewer = null;
    }
}
