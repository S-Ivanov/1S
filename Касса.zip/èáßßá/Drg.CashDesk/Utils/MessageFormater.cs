﻿namespace Drg.CashDesk.Utils
{
    public static class MessageFormater
    {
        public static string GetErrorMessage(CashDeskLib.DataModel.PaymentManagerExtException exception)
        {
            string message = "Ошибка ";
            switch (exception.Device)
            {
                case Equipment.Device.KKM:
                    message += "ККМ";
                    break;
                case Equipment.Device.PayTerminal:
                    message += "платежного терминала";
                    break;
            }
            message += ".\n\n";
            if (exception.DeviceError != null)
            {
                message += "Код ошибки: " + exception.DeviceError.ErrorCode;
                if (!string.IsNullOrEmpty(exception.DeviceError.Description))
                {
                    message += "\n";
                    message += "Описание: " + exception.DeviceError.Description;
                }
                if (!string.IsNullOrEmpty(exception.DeviceError.Recomendation))
                {
                    message += "\n";
                    message += "Рекомендации: " + exception.DeviceError.Recomendation;
                }
            }
            return message;
        }
    }
}
