﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для StartupWindow.xaml
    /// </summary>
    public partial class StartupWindow : Window
    {
        public StartupWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (dispatcherTimer != null)
            {
                dispatcherTimer.Stop();
                dispatcherTimer.Tick -= new EventHandler(dispatcherTimer_Tick);
            }
            this.Close();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            //// Updating the Label which displays the current second
            //lblSeconds.Content = DateTime.Now.Second;

            //// Forcing the CommandManager to raise the RequerySuggested event
            //CommandManager.InvalidateRequerySuggested();

            if (deviceCounter < 4)
            {
                switch (deviceCounter)
                {
                    case 0:
                        cbCardReader.IsChecked = true;
                        break;
                    case 1:
                        cbPayTerminal.IsChecked = true;
                        break;
                    case 2:
                        cbMoneyBox.IsChecked = true;
                        break;
                    case 3:
                        cbKKM.IsChecked = true;
                        break;
                }

                deviceCounter++;
            }
        }

        DispatcherTimer dispatcherTimer = null;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (dispatcherTimer == null)
            {
                dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
                dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
                dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
                dispatcherTimer.Start();
            }
        }

        int deviceCounter = 0;
    }
}
