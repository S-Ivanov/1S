﻿using Drg.CashDeskLib;
using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для StartupWindow.xaml
    /// </summary>
    public partial class StartupWindow : Window
    {
        public StartupWindow()
        {
            InitializeComponent();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;

            switch (imageCounter)
            {
                case 0:
                    if ((cashDesk.Configuration.Devices & Device.CardReader) == Device.CardReader)
                    {
                        string deviceName = "Считыватель пропусков";
                        if (!cashDesk.Devices.TryGetValue(Device.CardReader, out DeviceInfo di) || di.Device == null)
                            deviceShowInfoList.Add(new DeviceShowInfo { Name = deviceName, Enabled = false, DeviceError = DeviceError.CreateError($"{deviceName} не подключен") });
                        else if (di.DeviceError == null)
                            deviceShowInfoList.Add(new DeviceShowInfo { Name = deviceName, Enabled = true });
                        else if (di.DeviceError.ErrorCode == DeviceError.NO_ERROR)
                            deviceShowInfoList.Add(new DeviceShowInfo { Name = deviceName, Enabled = true });
                        else
                            deviceShowInfoList.Add(new DeviceShowInfo { Name = deviceName, Enabled = null, DeviceError = di.DeviceError });
                    }
                    //SetDeviceImage(imgCardReader, Device.CardReader, cashDesk);
                    break;
                case 1:
                    //SetDeviceImage(imgKKM, Device.KKM, cashDesk);
                    break;
                case 2:
                    //SetDeviceImage(imgPayTerminal, Device.PayTerminal, cashDesk);
                    break;
                case 3:
                    //SetDeviceImage(imgMoneyBox, Device.MoneyBox, cashDesk);
                    break;
                case 4:
                    //SetPaymentMethodImage(imgPass, PaymentMethod.Pass, cashDesk);
                    //if ((cashDesk.PaymentMethod & PaymentMethod.Pass) != PaymentMethod.Pass)
                    //    lblPass.Content = "По списку работников";
                    break;
                case 5:
                    //SetPaymentMethodImage(imgBankCard, PaymentMethod.BankCard, cashDesk);
                    break;
                case 6:
                    //SetPaymentMethodImage(imgCash, PaymentMethod.Cash, cashDesk);
                    break;
                case 7:
                    //SetPaymentMethodImage(imgTalons, PaymentMethod.Talon, cashDesk);
                    break;
            }

            if (imageCounter == 3)
            {
                dispatcherTimer.Stop();
                dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
                dispatcherTimer.Start();
            }

            if (imageCounter < 7)
                imageCounter++;
            else
            {
                dispatcherTimer.Stop();
                btnCancel.IsEnabled = btnOk.IsEnabled = true;
            }
        }

        private void SetPaymentMethodImage(Image image, PaymentMethod paymentMethod, CashDeskLib.CashDesk cashDesk)
        {
            if ((cashDesk.Configuration.PaymentMethods & paymentMethod) != paymentMethod)
                image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-cancel-30.png", UriKind.Relative));
            else if ((cashDesk.PaymentMethod & paymentMethod) == paymentMethod)
                image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-ok-30.png", UriKind.Relative));
            else
                image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-warning-30.png", UriKind.Relative));
        }

        private void SetDeviceImage(Image image, Device device, CashDeskLib.CashDesk cashDesk)
        {
            if ((cashDesk.Configuration.Devices & device) != device)
                image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-cancel-30.png", UriKind.Relative));
            else if (cashDesk.Devices.TryGetValue(device, out DeviceInfo di))
            {
                if (di.Device != null && (di.DeviceError == null || di.DeviceError.ErrorCode == DeviceError.NO_ERROR))
                    image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-ok-30.png", UriKind.Relative));
                else
                {
                    image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-warning-30.png", UriKind.Relative));
                    image.Tag = new DeviceErrorInfo { Device = device, DeviceError = di.DeviceError };
                }
            }
            else
            {
                image.Source = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/icons8-warning-30.png", UriKind.Relative));
                image.Tag = new DeviceErrorInfo { Device = device };
            }
        }

        DispatcherTimer dispatcherTimer = null;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgDevices.ItemsSource = deviceShowInfoList;

            //var cashDesk = CashDeskLib.CashDesk.Instance;

            try
            {
                var operators = CashDeskLib.CashDesk.Instance.GetOperators();
                if (operators.Count > 0)
                {
                    cbOperators.ItemsSource = operators;
                    cbOperators.DisplayMemberPath = "FIO";
                    cbOperators.SelectedIndex = 0;
                }
            }
            catch
            {
            }

            if (dispatcherTimer == null)
            {
                dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
                dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
                dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
                dispatcherTimer.Start();
            }
        }

        int imageCounter = 0;

        public ObservableCollection<DeviceShowInfo> DeviceShowInfoList
        {
            get 
            {
                return deviceShowInfoList;
            }
            set
            {
            }
        }
        ObservableCollection<DeviceShowInfo> deviceShowInfoList = new ObservableCollection<DeviceShowInfo>();

        public class DeviceShowInfo
        {
            public string Name { get; set; }
            public bool? Enabled { get; set; }
            public DeviceError DeviceError { get; set; }
        }

        class DeviceErrorInfo
        {
            public Device Device { get; set; }
            public DeviceError DeviceError { get; set; }
        }

        private void imgDevice_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var deviceErrorInfo = (sender as Image).Tag as DeviceErrorInfo;
            if (deviceErrorInfo != null)
            {
                string caption = "";
                switch (deviceErrorInfo.Device)
                {
                    case Device.CardReader:
                        caption = "Ошибка считывателя пропусков";
                        break;
                    case Device.KKM:
                        caption = "Ошибка ККМ";
                        break;
                    case Device.PayTerminal:
                        caption = "Ошибка банковского терминала";
                        break;
                }
                string message = deviceErrorInfo.DeviceError == null ? "Неизвестная ошибка инициализации" : $"Код ошибки: {deviceErrorInfo.DeviceError.ErrorCode}\n{deviceErrorInfo.DeviceError.Description}";
                MessageBox.Show(message, caption, MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void digitButton_Click(object sender, RoutedEventArgs e)
        {
            if (tbPassword.Text.Length < 10)
                tbPassword.Text += (sender as Button).Content.ToString();
        }

        private void backSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tbPassword.Text))
                tbPassword.Text = tbPassword.Text.Substring(0, tbPassword.Text.Length - 1);
        }

        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            tbPassword.Text = "";
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ok");
        }

        private void Window_Closed(object sender, EventArgs e)
        {

            if (dispatcherTimer != null)
            {
                dispatcherTimer.Stop();
                dispatcherTimer.Tick -= new EventHandler(dispatcherTimer_Tick);
            }
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.Operator = null;

            this.Close();
        }

        private void cbOperators_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //MessageBox.Show(((sender as ComboBox).SelectedItem as Operator).FIO);
        }

        //Operator selectedOperator = null;
    }
}
