﻿using Drg.CashDeskLib.DataModel;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для StartupWindow.xaml
    /// </summary>
    public partial class StartupWindow : Window
    {
        public StartupWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            abilityIndicator.Title = "";

            try
            {
                var operators = CashDeskLib.CashDesk.Instance.GetOperators();
                if (operators.Count > 0)
                {
                    cbOperators.ItemsSource = operators;
                    cbOperators.DisplayMemberPath = "FInitials";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
$@"Ошибка доступа к локальной базе данных, работа программы невозможна.

Комментарий: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                Application.Current.Shutdown();
            }

            ShowUseCardReader();
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
        }

        private void ShowUseCardReader()
        {
            lblUsePass.Visibility = cardReaderImage.Visibility = abilityIndicator.HasCardReader ? Visibility.Visible : Visibility.Hidden;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            var @operator = CashDeskLib.CashDesk.Instance.GetOperators().FirstOrDefault(op => op.CardID == e.CardCode);
            if (@operator == null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    cardCodeError.Visibility = Visibility.Visible;
                    cardCodeError.Content = e.CardCode.ToString();
                    cardCodeErrorBorder.BorderBrush = Brushes.Red;
                }));
            }
            else
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    OpenSession(@operator);
                    this.Close();
                }));
            }
        }

        private static void OpenSession(Operator @operator)
        {
            CashDeskLib.CashDesk.Instance.OpenSession(@operator);
        }

        void SetOkButtonEnabled()
        {
            btnOk.IsEnabled = cbOperators.SelectedItem != null && !string.IsNullOrEmpty(tbPassword.Text);
        }

        private void DigitButton_Click(object sender, RoutedEventArgs e)
        {
            if (tbPassword.Text.Length < 10)
            {
                tbPassword.Text += (sender as Button).Content.ToString();
                SetOkButtonEnabled();
            }
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tbPassword.Text))
            {
                tbPassword.Text = tbPassword.Text.Substring(0, tbPassword.Text.Length - 1);
                SetOkButtonEnabled();
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            tbPassword.Text = "";
            btnOk.IsEnabled = false;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Operator @operator = cbOperators.SelectedItem as Operator;
            if (tbPassword.Text != @operator.Password)
                MessageBox.Show("Неверный пароль", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                OpenSession(@operator);
                this.Close();
            }
        }

        private void CbOperators_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetOkButtonEnabled();
        }
    }
}
