﻿using Drg.CashDeskLib;
using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для StartupWindow.xaml
    /// </summary>
    public partial class StartupWindow : Window
    {
        public StartupWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgDevices.ItemsSource = deviceShowInfoList;

            try
            {
                var operators = CashDeskLib.CashDesk.Instance.GetOperators();
                if (operators.Count > 0)
                {
                    cbOperators.ItemsSource = operators;
                    cbOperators.DisplayMemberPath = "FInitials";
                    dbConnectOk = true;
                }
            }
            catch
            {
            }

            Thread thread = new Thread(ExecuteInForeground);
            thread.Start();
        }

        private void ExecuteInForeground()
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;

            foreach (var device in cashDesk.Configuration.Devices.GetIndividualFlags().Cast<Device>())
            {
                Thread.Sleep(500);
                DeviceShowInfo deviceShowInfo = new DeviceShowInfo { Name = device.GetDescription(), Enabled = true };
                if ((cashDesk.Configuration.Devices & device) == device)
                {
                    if (!cashDesk.Devices.TryGetValue(device, out DeviceInfo di) || di.Device == null)
                    {
                        deviceShowInfo.Enabled = false;
                        deviceShowInfo.ErrorDescription = "Устройство не подключено";
                    }
                    else if (di.DeviceError == null) { }
                    else if (di.DeviceError.ErrorCode == DeviceError.NO_ERROR) { }
                    else
                    {
                        deviceShowInfo.Enabled = false;
                        deviceShowInfo.ErrorDescription = di.DeviceError.Description;
                    }
                }

                if (device == Device.CardReader)
                    cardReaderEnabled = deviceShowInfo.Enabled;

                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (cardReaderEnabled == true)
                        lblIdentify.Content = "Приложите личный пропуск к считывателю или выберите себя из списка и введите пароль";
                    deviceShowInfoList.Add(deviceShowInfo);
                }));
            }

            Thread.Sleep(500);
            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                deviceShowInfoList.Add(new DeviceShowInfo { Name = "Локальная база данных", Enabled = dbConnectOk, ErrorDescription = dbConnectOk ? "" : "Ошибка подключения" });
            }));

            foreach (var paymentMethod in cashDesk.Configuration.PaymentMethods.GetIndividualFlags().Cast<PaymentMethod>())
            {
                Thread.Sleep(100);
                bool paymentMethodEnabled = (cashDesk.PaymentMethod & paymentMethod) == paymentMethod;

                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    deviceShowInfoList.Add(new DeviceShowInfo
                    {
                        Name = paymentMethod.GetDescription(),
                        Enabled = paymentMethodEnabled,
                        ErrorDescription = paymentMethodEnabled ? "" : "Не обеспечивается оборудованием" });
                }));
            }

            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                btnCancel.IsEnabled = btnOk.IsEnabled = true;
            }));
        }

        bool dbConnectOk;
        bool? cardReaderEnabled = null;

        ObservableCollection<DeviceShowInfo> deviceShowInfoList = new ObservableCollection<DeviceShowInfo>();

        public class DeviceShowInfo
        {
            public string Name { get; set; }
            public bool Enabled { get; set; }
            public string ErrorDescription { get; set; }
        }

        class DeviceErrorInfo
        {
            public Device Device { get; set; }
            public DeviceError DeviceError { get; set; }
        }

        private void digitButton_Click(object sender, RoutedEventArgs e)
        {
            if (tbPassword.Text.Length < 10)
                tbPassword.Text += (sender as Button).Content.ToString();
        }

        private void backSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tbPassword.Text))
                tbPassword.Text = tbPassword.Text.Substring(0, tbPassword.Text.Length - 1);
        }

        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            tbPassword.Text = "";
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            if (cbOperators.SelectedItem == null)
                MessageBox.Show("Не выбран кассир", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else if (string.IsNullOrEmpty(tbPassword.Text))
                MessageBox.Show("Не введен пароль", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                Operator @operator = cbOperators.SelectedItem as Operator;
                if (tbPassword.Text != @operator.Password)
                    MessageBox.Show("Неверный пароль", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    CashDeskLib.CashDesk.Instance.Operator = @operator;
                    this.Close();
                }
            }
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.Operator = null;
            this.Close();
        }
    }
}
