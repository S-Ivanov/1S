﻿using System;
using System.Linq;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для SelectOrderDialog.xaml
    /// </summary>
    public partial class SelectOrderDialog : Window
    {
        public SelectOrderDialog()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            alphabeticKeyboard.DisableSymbols = ".,";
            alphabeticKeyboard.okButton.IsEnabled = false;
            alphabeticKeyboard.PropertyChanged += AlphabeticKeyboard_PropertyChanged;
            alphabeticKeyboard.OkEvent += AlphabeticKeyboard_OkEvent;
            alphabeticKeyboard.CancelEvent += AlphabeticKeyboard_CancelEvent;

            viewModel.PropertyChanged += ViewModel_PropertyChanged;
        }

        private void ViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(viewModel.SelectedOrder))
                alphabeticKeyboard.okButton.IsEnabled = viewModel.SelectedOrder != null;
        }

        private void AlphabeticKeyboard_OkEvent(object sender, EventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void AlphabeticKeyboard_CancelEvent(object sender, EventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void AlphabeticKeyboard_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var searchText = alphabeticKeyboard.Text;
            viewModel.SearchText = searchText;

            if (string.IsNullOrEmpty(searchText))
                alphabeticKeyboard.DisableSymbols = ".,";
            else if (searchText.Any(ch => char.IsDigit(ch)))
                alphabeticKeyboard.DisableSymbols = "-ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ., ";
            else
                alphabeticKeyboard.DisableSymbols = "0123456789.,";
        }

        private void ComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            viewModel.SetMode(ModeComboBox.SelectedIndex);
        }
    }
}
