﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для SelectClientWindow.xaml
    /// </summary>
    public partial class SelectClientWindow : Window
    {
        public SelectClientWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            alphabeticKeyboard.DisableSymbols = ".,";
            alphabeticKeyboard.PropertyChanged += AlphabeticKeyboard_PropertyChanged;
            alphabeticKeyboard.CancelEvent += AlphabeticKeyboard_CancelEvent;
        }

        private void AlphabeticKeyboard_CancelEvent(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AlphabeticKeyboard_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var searchText = alphabeticKeyboard.Text;
            viewModel.SearchText = searchText;
            
            if (string.IsNullOrEmpty(searchText))
                alphabeticKeyboard.DisableSymbols = ".,";
            else if (searchText.Any(ch => char.IsDigit(ch)))
                alphabeticKeyboard.DisableSymbols = "-ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ., ";
            else
                alphabeticKeyboard.DisableSymbols = "0123456789.,";
        }
    }
}
