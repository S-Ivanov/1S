﻿using Drg.CashDesk.Utils;
using System;
using System.Linq;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для SelectClientWindow.xaml
    /// </summary>
    public partial class SelectClientWindow : Window
    {
        public SelectClientWindow()
        {
            InitializeComponent();

            dataGridScroller = new DataGridScroller(PersonsDataGrid, ButtonPageUp, ButtonPageDown);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            alphabeticKeyboard.DisableSymbols = ".,";
            alphabeticKeyboard.okButton.IsEnabled = false;
            alphabeticKeyboard.PropertyChanged += AlphabeticKeyboard_PropertyChanged;
            alphabeticKeyboard.OkEvent += AlphabeticKeyboard_OkEvent;
            alphabeticKeyboard.CancelEvent += AlphabeticKeyboard_CancelEvent;

            viewModel.PropertyChanged += ViewModel_PropertyChanged;

            dataGridScroller.SetScrollButtonsVisibility();
        }

        private void ViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(viewModel.SelectedClient))
                alphabeticKeyboard.okButton.IsEnabled = viewModel.SelectedClient != null;
            else if (e.PropertyName == nameof(viewModel.Clients))
                dataGridScroller.SetScrollButtonsVisibility();
        }

        private void AlphabeticKeyboard_OkEvent(object sender, EventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void AlphabeticKeyboard_CancelEvent(object sender, EventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void AlphabeticKeyboard_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var searchText = alphabeticKeyboard.Text;
            viewModel.SearchText = searchText;
            
            if (string.IsNullOrEmpty(searchText))
                alphabeticKeyboard.DisableSymbols = ".,";
            else if (searchText.Any(ch => char.IsDigit(ch)))
                alphabeticKeyboard.DisableSymbols = "-ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ., ";
            else
                alphabeticKeyboard.DisableSymbols = "0123456789.,";
        }

        DataGridScroller dataGridScroller;

        #region Скроллинг датагрида - 1
        // https://stackoverflow.com/questions/37465759/scroll-over-datagrid-with-click-drag
        // не работает

        //private void PersonsDataGrid_LoadingRow(object sender, System.Windows.Controls.DataGridRowEventArgs e)
        //{
        //    e.Row.DragOver += new DragEventHandler(MyRow_DragOver);
        //}

        //private void MyRow_DragOver(object sender, DragEventArgs e)
        //{
        //    DataGridRow r = (DataGridRow)sender;
        //    PersonsDataGrid.SelectedItem = r.Item;

        //    // Scroll while dragging...
        //    DependencyObject d = PersonsDataGrid;
        //    while (!(d is ScrollViewer))
        //    {
        //        d = VisualTreeHelper.GetChild(d, 0);
        //    }
        //    ScrollViewer scroll = d as ScrollViewer;

        //    Point position = PersonsDataGrid.PointToScreen(Mouse.GetPosition(r));

        //    double topMargin = scroll.ActualHeight * .15;
        //    double bottomMargin = scroll.ActualHeight * .80;

        //    if (position.Y * -1 < topMargin)
        //        scroll.LineUp(); // <-- needs a mechanism to control the speed of the scroll.
        //    if (position.Y * -1 > bottomMargin)
        //        scroll.LineDown(); // <-- needs a mechanism to control the speed of the scroll.

        //}

        #endregion Скроллинг датагрида - 1
    }
}
