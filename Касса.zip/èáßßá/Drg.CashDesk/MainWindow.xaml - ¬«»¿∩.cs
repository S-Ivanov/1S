﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, {cashDesk.Operator.FIO}";
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            //abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;
            abilityIndicator.OnExit += AbilityIndicator_OnExit;

            viewModel.ChangeCount += ViewModel_ChangeCount;
            viewModel.OrderItemDelete += ViewModel_OrderItemDelete;
            viewModel.NewOrder += ViewModel_NewOrder;
            viewModel.SelectClient += ViewModel_SelectClient;
            viewModel.PaymentEvent += ViewModel_Payment;
            viewModel.LocalMenuItemDelete += ViewModel_LocalMenuItemDelete;
        }

        private void AbilityIndicator_OnExit(object sender, CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Закрыть текущую смену?", "Подтверждение", MessageBoxButton.YesNoCancel, MessageBoxImage.Question, MessageBoxResult.No);
            if (result == MessageBoxResult.Yes)
                CashDeskLib.CashDesk.Instance.CloseSession(DateTime.Now);

            e.Cancel = result == MessageBoxResult.Cancel;
        }

        private void ViewModel_LocalMenuItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенный элемент меню?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_Payment(object sender, DataModelEventArgs<DataModel.PaymentInfo> e)
        {
            PayWindow payWindow = new PayWindow();
            // TODO: исключить обращение к viewModel
            payWindow.viewModel.PaymentInfo = e.Data;
            e.Data = payWindow.ShowDialog() == true ? payWindow.viewModel.PaymentInfo : null;
        }

        private void ViewModel_SelectClient(object sender, DataModelEventArgs<CashDeskLib.DataModel.Client> e)
        {
            SelectClientWindow selectClientWindow = new SelectClientWindow();
            if (selectClientWindow.ShowDialog() == true)
                e.Data = selectClientWindow.viewModel.SelectedClient.RawClient;
            else
                e.Data = null;
        }

        //private void AbilityIndicator_EquipmentChecked(object sender, EventArgs e)
        //{
        //    //viewModel.PaymentAbilitiesRefresh();
        //}

        private void ViewModel_NewOrder(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить имеющиеся строки и создать новый заказ?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_OrderItemDelete(object sender, CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.No;
        }

        private void ViewModel_ChangeCount(object sender, ChangeCountEventArgs e)
        {
            ChangeCount changeCount = new ChangeCount(e.Value);

            changeCount.Top = Top + (ActualHeight - changeCount.Height) / 2;
            changeCount.Left = Left + ActualWidth / 2;

            if (e.Type == typeof(DataModel.OrderItem))
            {
                // установить начальные координаты окна так, чтобы не перекрывался список элементов заказа - установлено changeCount.Left = ...
            }
            else // if (e.Type == typeof(DataModel.MenuItem))
            {
                // установить начальные координаты окна так, чтобы не перекрывался список элементов меню
                changeCount.Left -= changeCount.Width;
            }

            e.Cancel = changeCount.ShowDialog() != true;
            if (!e.Cancel)
                e.Value = changeCount.Count;
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    viewModel.SetClient(e.CardCode);
                }));
        }
    }
}
