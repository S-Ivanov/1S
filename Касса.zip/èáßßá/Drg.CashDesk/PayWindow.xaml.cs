﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для PayWindow.xaml
    /// </summary>
    public partial class PayWindow : Window
    {
        public PayWindow()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // установить начальные координаты окна так, чтобы не перекрывался список элементов заказа
            Window mainWindow = Application.Current.MainWindow;
            this.Left = mainWindow.Left + mainWindow.ActualWidth / 2;
            this.Top = mainWindow.Top + (mainWindow.ActualHeight - this.ActualHeight) / 2;

            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModel.DataModelEventArgs<string> e)
        {
        }
    }
}
