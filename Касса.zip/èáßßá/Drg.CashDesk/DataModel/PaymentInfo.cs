﻿using Drg.CashDeskLib.DataModel;
using System.Collections.Generic;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Информация об оплате
    /// </summary>
    public class PaymentInfo
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="paymentAbilities">возможные варианты оплаты</param>
        /// <param name="total">общая сумма оплаты</param>
        public PaymentInfo(PaymentAbilities paymentAbilities, decimal total)
        {
            PaymentAbilities = paymentAbilities;
            Total = total;

            List<Payment> payments = paymentAbilities.ToPayments();

            Payments = PaymentInit.Init(
                payments, 
                paymentAbilities.Client.RawClient.LimitZP, 
                CashDeskLib.CashDesk.Instance.Configuration.LPPNominal,
                CashDeskLib.CashDesk.Instance.Configuration.Talon120Nominal, 
                total);
        }

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilities PaymentAbilities { get; private set; }

        /// <summary>
        /// Общая сумма оплаты
        /// </summary>
        public decimal Total { get; private set; }

        /// <summary>
        /// Итоговые результаты оплаты
        /// </summary>
        public Dictionary<Payment, decimal> Payments { get; private set; } 
    }
}
