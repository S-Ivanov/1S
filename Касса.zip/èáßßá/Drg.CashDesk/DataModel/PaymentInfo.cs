﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Информация об оплате
    /// </summary>
    public class PaymentInfo
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="paymentAbilities">возможные варианты оплаты</param>
        /// <param name="initPayment">инициируемый вариант оплаты</param>
        /// <param name="total">общая сумма оплаты</param>
        public PaymentInfo(PaymentAbilitiesBase paymentAbilities, Payment initPayment, decimal total)
        {
            PaymentAbilities = paymentAbilities;
            InitPayment = initPayment;
            Total = total;

            Payments = new Dictionary<Payment, decimal>
            {
                { InitPayment, Total }
            };
        }

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilitiesBase PaymentAbilities { get; private set; }

        /// <summary>
        /// Инициируемый вариант оплаты
        /// </summary>
        public Payment InitPayment { get; private set; }

        /// <summary>
        /// Общая сумма оплаты
        /// </summary>
        public decimal Total { get; private set; }

        /// <summary>
        /// Итоговые результаты оплаты
        /// </summary>
        public Dictionary<Payment, decimal> Payments { get; private set; } 
    }
}
