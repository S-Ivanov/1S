﻿using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Базовый класс для элемента/группы элементов меню
    /// </summary>
    public abstract class MenuItemBase : INotifyPropertyChanged
    {
        /// <summary>
        /// Наименование
        /// </summary>
        public abstract string Name { get; }
        
        /// <summary>
        /// Индикатор выбранного элемента/группы элементов меню
        /// </summary>
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    RaisePropertyChanged(nameof(IsSelected));
                }
            }
        }
        bool isSelected = false;

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
