﻿using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Базовый класс для элемента/группы элементов меню
    /// </summary>
    public abstract class MenuItemBase : INotifyPropertyChanged
    {
        /// <summary>
        /// Наименование
        /// </summary>
        public abstract string Name { get; }
        
        /// <summary>
        /// Индикатор выбранного элемента/группы элементов меню
        /// </summary>
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected = false;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
