﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem : MenuItemBase
    {
        public MenuItem(CashDeskLib.DataModel.MenuItem rawMenuItem)
        {
            this.RawMenuItem = rawMenuItem;
        }

        /// <summary>
        /// Наименование
        /// </summary>
        public override string Name => RawMenuItem.Name;

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit => RawMenuItem.Unit;

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price => RawMenuItem.Price;

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count
        {
            get => RawMenuItem.Count;
            set => RawMenuItem.Count = value;
        }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal => RawMenuItem.IsLocal;

        public readonly CashDeskLib.DataModel.MenuItem RawMenuItem;
    }
}
