﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem : MenuItemBase
    {
        public MenuItem(CashDeskLib.DataModel.MenuItem rawMenuItem)
        {
            this.rawMenuItem = rawMenuItem;
        }

        /// <summary>
        /// Наименование
        /// </summary>
        public override string Name => rawMenuItem.Name;

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit => rawMenuItem.Unit;

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price => rawMenuItem.Price;

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count => rawMenuItem.Count;

        CashDeskLib.DataModel.MenuItem rawMenuItem;
    }
}
