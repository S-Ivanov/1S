﻿using System;
using System.Globalization;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Обработка входного потока символов для формирования значения decimal
    /// </summary>
    public class InputDigitizer
    {
        public InputDigitizer(bool useDot = true, decimal limit = 0)
        {
            this.useDot = useDot;
            this.limit = limit;
        }

        public void AddSymbols(string symbols)
        {
            if (symbols == null)
                throw new ArgumentNullException();

            symbols = symbols.Trim();

            if (!(symbols == "." || symbols == "," || symbols.All(_ => char.IsDigit(_))))
                throw new ArgumentException();

            if (isStarted)
            {
                Value = 0;
                isStarted = false;
            }

            if (useDot && (symbols == "." || symbols == ","))
                fractionStart = (Value % 1) == 0.0m;
            else 
            {
                string s = Value.ToString(CultureInfo.InvariantCulture);
                decimal sum = decimal.Parse(s + (fractionStart ? "." : "") + symbols, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
                if (limit == 0 || sum <= limit)
                    Value = sum;

                fractionStart = false;
            }
        }

        /// <summary>
        /// Удаляется последний знак
        /// </summary>
        public void BackSpace()
        {
            if (Value > 0)
            {
                string s = Value.ToString(CultureInfo.InvariantCulture);
                s = s.Substring(0, s.Length - 1).TrimEnd('.');
                Value = string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
            }
            fractionStart = false;
        }

        public void Clear()
        {
            Value = 0;
            fractionStart = false;
        }

        public decimal Value { get; private set; }

        public string ValueString => Value.ToString(CultureInfo.CreateSpecificCulture("ru-RU")) + (fractionStart ? "," : "");

        decimal limit;
        bool useDot;
        bool fractionStart;
        bool isStarted = true;
    }
}
