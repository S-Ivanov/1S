﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturn : Order
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public OrderReturn(List<CashDeskLib.DataModel.Order> returns) : base()
        {
            Returns = returns;
        }

        public List<CashDeskLib.DataModel.Order> Returns { get; private set; }

    }
}
