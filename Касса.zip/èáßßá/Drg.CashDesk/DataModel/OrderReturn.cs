﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturn : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public OrderReturn(ObservableCollection<OrderReturnItem> allReturnItems) 
        {
            // номер нового заказа
            Number = CashDeskLib.CashDesk.Instance.GetNewOrderNumber();

            AllItems = allReturnItems;

            ReturnOrders =
                allReturnItems == null ?
                new List<OrderReturnListItem>() :
                allReturnItems
                .Select(_ => _.Order)
                .Distinct()
                .OrderBy(order => order.DateTime)
                .Select(order => new OrderReturnListItem(order))
                .ToList();

            ReturnOrders.Add(currentReturn);
        }

        OrderReturnListItem currentReturn = new OrderReturnListItem
        {
            Time = "(сейчас)",
            Number = "(новый)"
        };

        /// <summary>
        /// Исходный заказ для возврата
        /// </summary>
        public OrderSource OrderSource { get; set; }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; private set; }

        public void AddItem(OrderReturnItem item)
        {
            AllItems.Add(item);
        }

        public ObservableCollection<OrderReturnItem> AllItems { get; private set; }

        public List<OrderReturnListItem> ReturnOrders { get; private set; }

        public bool CanAddReturn
        {
            get => canAddReturn;
            set
            {
                if (canAddReturn != value)
                {
                    canAddReturn = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanAddReturn)));
                }
            }
        }
        bool canAddReturn = true;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
