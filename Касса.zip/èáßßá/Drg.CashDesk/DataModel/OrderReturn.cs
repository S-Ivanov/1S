﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturn : Order
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public OrderReturn() : base()
        {
        }

        public List<CashDeskLib.DataModel.Order> Returns { get; set; }

    }
}
