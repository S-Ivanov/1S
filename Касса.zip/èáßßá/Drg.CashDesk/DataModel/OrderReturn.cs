﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturn //: Order
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public OrderReturn(ObservableCollection<OrderReturnItem> allReturnItems) //: base()
        {
            //Returns = returns;
            // Returns => AllItems

            AllItems = allReturnItems;
        }

        //public List<CashDeskLib.DataModel.Order> Returns { get; private set; }

        public ObservableCollection<OrderReturnItem> AllItems { get; private set; }

        //public static ObservableCollection<OrderReturnItem> GetOrderReturnAllItems(List<CashDeskLib.DataModel.Order> returns)
        //{
        //    if (returns == null)
        //        return new ObservableCollection<OrderReturnItem>();
        //    else
        //        return new ObservableCollection<OrderReturnItem>(returns.SelectMany(order => order.Items.Select(orderItem => new OrderReturnItem(order, orderItem))));
        //}
    }
}
