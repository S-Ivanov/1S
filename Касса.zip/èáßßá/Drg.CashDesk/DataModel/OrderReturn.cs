﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturn 
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public OrderReturn(ObservableCollection<OrderReturnItem> allReturnItems) 
        {
            // номер нового заказа
            Number = CashDeskLib.CashDesk.Instance.GetNewOrderNumber();

            AllItems = allReturnItems;

            //ReturnOrders = allReturnItems
            //    .Select(_ => _.Order)
            //    .Distinct()
            //    .OrderBy(order => order.DateTime)
            //    .Select(order => new OrderReturnListItem(order))
            //    .ToList();

            ReturnOrders = new List<OrderReturnListItem>
            {
                new OrderReturnListItem(
                    new CashDeskLib.DataModel.Order
                    {
                        Number = 1,
                        DateTime = new DateTime(2018, 08, 20, 12, 30, 00)
                    }),
                new OrderReturnListItem(
                    new CashDeskLib.DataModel.Order
                    {
                        Number = 2,
                        DateTime = new DateTime(2018, 08, 20, 13, 00, 00)
                    }),
                new OrderReturnListItem(
                    new CashDeskLib.DataModel.Order
                    {
                        Number = 3,
                        DateTime = new DateTime(2018, 08, 20, 14, 00, 00)
                    }),
            };
        }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; private set; }

        /// <summary>
        /// Сумма возврата
        /// </summary>
        // TODO: должна изменяться в зависимости от фильтра
        public decimal Total => AllItems.Sum(_ => _.Sum);

        public ObservableCollection<OrderReturnItem> AllItems { get; private set; }

        public List<OrderReturnListItem> ReturnOrders { get; private set; }

    }
}
