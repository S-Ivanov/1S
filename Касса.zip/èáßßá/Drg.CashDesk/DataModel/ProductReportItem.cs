﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class ProductReportItem : INotifyPropertyChanged
    {
        public ProductReportItem(CashDeskLib.DataModel.ProductReportItem productReportItem)
        {
            RawItem = productReportItem;
        }

        public CashDeskLib.DataModel.ProductReportItem RawItem { get; private set; }

        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected = true;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
