﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class ProductReportItem
    {
        public ProductReportItem(CashDeskLib.DataModel.ProductReportItem productReportItem)
        {
            RawItem = productReportItem;
        }

        public CashDeskLib.DataModel.ProductReportItem RawItem { get; private set; }
        public bool IsSelected { get; set; }
    }
}
