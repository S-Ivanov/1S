﻿using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    public class ProductReportItem : INotifyPropertyChanged
    {
        public ProductReportItem(CashDeskLib.DataModel.ProductReportItem rawItem)
        {
            RawItem = rawItem;
        }

        public CashDeskLib.DataModel.ProductReportItem RawItem { get; private set; }

        //public string Id { get; set; }
        //public string Name { get; set; }
        //public string MeasureName { get; set; }
        //public decimal Count { get; set; }
        //public decimal ReturnCount { get; set; }
        //public decimal Balance => Count - ReturnCount;
        //public string GroupName { get; set; }

        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected = false;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
