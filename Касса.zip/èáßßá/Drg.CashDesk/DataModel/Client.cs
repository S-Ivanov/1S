﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Клиент
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Пустой клиент
        /// </summary>
        public static Client Empty
        {
            get
            {
                if (empty == null)
                    empty = new Client(new CashDeskLib.DataModel.Client());
                return empty;
            }
        }
        static Client empty = null;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="rawClient">объект клиента</param>
        public Client(CashDeskLib.DataModel.Client rawClient)
        {
            RawClient = rawClient;
        }

        /// <summary>
        /// Фотография
        /// </summary>
        public BitmapImage Photo
        {
            get
            {
                if (photo == null)
                    ReloadPhoto();
                return photo;
            }
        }

        public virtual void ReloadPhoto()
        {
            if (RawClient == null || RawClient.Photo == null)
                photo = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/no_avatar.jpg", UriKind.Relative));
            else
            {
                using (MemoryStream memory = new MemoryStream(RawClient.Photo))
                {
                    memory.Position = 0;
                    photo = new BitmapImage();
                    photo.BeginInit();
                    photo.StreamSource = memory;
                    photo.CacheOption = BitmapCacheOption.OnLoad;
                    photo.EndInit();
                }
            }
        }

        BitmapImage photo = null;

        /// <summary>
        /// Табельный + ФИО
        /// </summary>
        public string TabNumFIO => string.IsNullOrEmpty(RawClient?.TabNum) ? string.Empty : $"{RawClient.TabNum} - {RawClient.FIO}";

        public CashDeskLib.DataModel.Client RawClient { get; private set; }
    }
}
