﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Клиент
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Пустой клиент
        /// </summary>
        public static Client Empty
        {
            get
            {
                if (empty == null)
                    empty = new Client(new CashDeskLib.DataModel.Client());
                    //{
                    //    photo = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/no_avatar.jpg", UriKind.Relative))
                    //};
            
                return empty;
            }
        }
        static Client empty = null;

        ///// <summary>
        ///// Клиент с неопознанной картой
        ///// </summary>
        //public static Client NoCard
        //{
        //    get
        //    {
        //        if (noCard == null)
        //            noCard = new Client(new CashDeskLib.DataModel.Client())
        //            {
        //                photo = new BitmapImage(new Uri(@"/Drg.CashDesk;component/Images/bad_card.jpg", UriKind.Relative))
        //            };

        //        return noCard;
        //    }
        //}
        //static Client noCard = null;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="rawClient">объект клиента</param>
        public Client(CashDeskLib.DataModel.Client rawClient)
        {
            RawClient = rawClient;
        }

        ///// <summary>
        ///// Фотография
        ///// </summary>
        //public BitmapImage Photo
        //{
        //    get
        //    {
        //        if (photo == null)
        //            ReloadPhoto();
        //        return photo;
        //    }
        //}
        //BitmapImage photo = null;

        //public virtual void ReloadPhoto()
        //{
        //    if (RawClient.Photo == null)
        //        photo = null;
        //    else
        //    {
        //        using (MemoryStream memory = new MemoryStream(RawClient.Photo))
        //        {
        //            memory.Position = 0;
        //            photo = new BitmapImage();
        //            photo.BeginInit();
        //            photo.StreamSource = memory;
        //            photo.CacheOption = BitmapCacheOption.OnLoad;
        //            photo.EndInit();
        //        }
        //    }
        //}

        /// <summary>
        /// Табельный + ФИО
        /// </summary>
        public string TabNumFIO => string.IsNullOrEmpty(RawClient?.TabNum) ? string.Empty : $"{RawClient.TabNum} - {RawClient.FIO}";

        public CashDeskLib.DataModel.Client RawClient { get; private set; }
    }
}
