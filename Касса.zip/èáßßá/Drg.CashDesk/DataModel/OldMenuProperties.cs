﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OldMenuProperties
    {
        public DateTime DateStart { get; set; }

        public DateTime DateEnd { get; set; }

        public List<DateTime> Dates { get; set; }
    }
}
