﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderSourceItem
    {
        public OrderSourceItem(CashDeskLib.DataModel.OrderItem rawOrderItem, int numder, decimal count, decimal sum)
        {
            RawOrderItem = rawOrderItem;
            Numder = numder;
            Count = count;
            Sum = sum;
        }

        public CashDeskLib.DataModel.OrderItem RawOrderItem { get; private set; }

        public int Numder { get; set; }
        public decimal Count { get; set; }
        public decimal Sum { get; set; }
    }
}
