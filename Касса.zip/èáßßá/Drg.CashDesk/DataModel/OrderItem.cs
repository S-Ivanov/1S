﻿using System;
using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Элемент заказа
    /// </summary>
    public class OrderItem : INotifyPropertyChanged
    {
        public OrderItem(MenuItem menuItem, int number)
            : this(menuItem, number, (menuItem.RawItem as CashDeskLib.DataModel.MenuItem).Count)
        {
        }

        public OrderItem(MenuItem menuItem, int number, decimal count)
        {
            this.number = number;
            MenuItem = menuItem;
            Price = (menuItem.RawItem as CashDeskLib.DataModel.MenuItem).Price;
            this.count = count;
        }

        public OrderItem(CashDeskLib.DataModel.OrderItem orderItem, int number)
        {
            rawOrderItem = orderItem;
            MenuItem = new MenuItem(orderItem.MenuItem);
            Price = orderItem.Price;
            count = orderItem.Count;
            this.number = number;
        }

        CashDeskLib.DataModel.OrderItem rawOrderItem = null;

        /// <summary>
        /// Номер п/п
        /// </summary>
        public int Number
        {
            get => number;
            set
            {
                if (number != value)
                {
                    number = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Number)));
                }
            }
        }
        int number;

        /// <summary>
        /// Цена элемента заказа
        /// </summary>
        public decimal Price { get; private set; }

        /// <summary>
        /// Элемент меню
        /// </summary>
        public MenuItem MenuItem { get; private set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count
        {
            get => count;
            set
            {
                if (count != value)
                {
                    count = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Count)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Sum)));
                }
            }
        }
        decimal count;

        /// <summary>
        /// Сумма
        /// </summary>
        public decimal Sum
        {
            get
            {
                decimal menuItemPrice = MenuItem == null ? 0 : (MenuItem.RawItem as CashDeskLib.DataModel.MenuItem)?.Price ?? 0;
                return rawOrderItem == null ? Math.Round(count * menuItemPrice, 2, MidpointRounding.AwayFromZero) : rawOrderItem.Sum;
            }
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
