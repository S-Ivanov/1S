﻿using System;
using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Элемент заказа
    /// </summary>
    public class OrderItem : INotifyPropertyChanged
    {
        public OrderItem(MenuItem menuItem, int number)
            : this(menuItem, number, menuItem.Count)
        {
        }

        public OrderItem(MenuItem menuItem, int number, decimal count)
        {
            this.number = number;
            MenuItem = menuItem;
            this.count = count;
        }

        /// <summary>
        /// Номер п/п
        /// </summary>
        public int Number
        {
            get => number;
            set
            {
                if (number != value)
                {
                    number = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Number)));
                }
            }
        }
        int number;

        /// <summary>
        /// Элемент меню
        /// </summary>
        public MenuItem MenuItem { get; private set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count
        {
            get => count;
            set
            {
                if (count != value)
                {
                    count = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Count)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Sum)));
                }
            }
        }
        decimal count;

        /// <summary>
        /// Сумма
        /// </summary>
        public decimal Sum => Math.Round(count * MenuItem.Price, 2, MidpointRounding.AwayFromZero);

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
