﻿using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Элемент заказа
    /// </summary>
    public class OrderItem : INotifyPropertyChanged
    {
        public OrderItem(MenuItem menuItem)
        {
            MenuItem = menuItem;
            count = menuItem.Count;
        }

        /// <summary>
        /// Элемент меню
        /// </summary>
        public MenuItem MenuItem { get; private set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count
        {
            get => count;
            set
            {
                if (count != value)
                {
                    count = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Count)));
                }
            }
        }
        decimal count;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
