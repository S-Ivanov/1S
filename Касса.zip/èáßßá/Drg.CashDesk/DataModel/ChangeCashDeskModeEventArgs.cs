﻿using System;
using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Аргумент события изменения количества
    /// </summary>
    public class ChangeCashDeskModeEventArgs : EventArgs
    {
        /// <summary>
        /// Устанавливаемый режим работы
        /// </summary>
        public CashDeskMode CashDeskMode { get; set; }
    }
}
