﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturnItem : OrderSourceItem
    {
        public OrderReturnItem(CashDeskLib.DataModel.Order order, CashDeskLib.DataModel.OrderItem rawOrderItem)
            : base(rawOrderItem, 0, rawOrderItem.Count, rawOrderItem.Sum)
        {
            Order = order;
        }

        /// <summary>
        /// Ссылка на заказ, которому принадлежит элемент
        /// </summary>
        public CashDeskLib.DataModel.Order Order { get; set; }

        //public CashDeskLib.DataModel.OrderItem RawOrderItem { get; private set; }
        //public int Numder { get; private set; }
        //public decimal Count { get; private set; }
        //public decimal Sum { get; private set; }
    }
}
