﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturnItem : INotifyPropertyChanged
    {
        public OrderReturnItem(CashDeskLib.DataModel.Order order, CashDeskLib.DataModel.OrderItem rawOrderItem)
            //: base(rawOrderItem, 0, rawOrderItem.Count, rawOrderItem.Sum)
        {
            Order = order;
            RawOrderItem = rawOrderItem;
            SourceCount = rawOrderItem.Count;
            ReturnCount = rawOrderItem.Count;
        }

        public CashDeskLib.DataModel.OrderItem RawOrderItem { get; private set; }

        /// <summary>
        /// Ссылка на заказ, которому принадлежит элемент
        /// </summary>
        public CashDeskLib.DataModel.Order Order { get; set; }

        public decimal SourceCount { get; set; }

        public decimal ReturnCount
        {
            get => returnCount;
            set
            {
                if (returnCount != value)
                {
                    returnCount = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ReturnCount)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Sum)));
                }
            }
        }
        decimal returnCount;

        public decimal Sum => ReturnCount * RawOrderItem.MenuItem.Price;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
