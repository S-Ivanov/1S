﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Аргумент события полного возврата заказа
    /// </summary>
    public class WholeOrderReturnEventArgs : EventArgs
    {
        /// <summary>
        /// Id исходного заказа
        /// </summary>
        public Guid OrderId { get; set; }

        /// <summary>
        /// Возвраты по вариантам оплат
        /// </summary>
        public List<OrderPaymentItem> Returns { get; set; }
    }
}
