﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public Order()
        {
            // прочитать номер нового заказа
            Number = CashDeskLib.CashDesk.Instance.GetNewOrderNumber();

            items.CollectionChanged += Items_CollectionChanged;
        }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; private set; }

        /// <summary>
        /// Общая сумма
        /// </summary>
        public decimal Total => Items.Sum(item => item.Sum);

        /// <summary>
        /// Свернуть позиции заказа
        /// </summary>
        public void Collapse()
        {
            var groups = Items.GroupBy(orderItem => orderItem.MenuItem.RawMenuItem.ProductId);
            var groupItems = groups.Select((g, index) => new OrderItem(g.First().MenuItem, index + 1, g.Sum(orderItem => orderItem.Count)));
            var collapsed = new ObservableCollection<OrderItem>(groupItems);
            if (items != null)
                items.CollectionChanged -= Items_CollectionChanged;
            items = collapsed;
            items.CollectionChanged += Items_CollectionChanged;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
        }

        /// <summary>
        /// Обработчик события изменения списка позиций заказа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));

            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                // при удалении записи нужно пересчитать нумерацию
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].Number = i + 1;
                }
            }
        }

        /// <summary>
        /// Элементы заказа
        /// </summary>
        public ObservableCollection<OrderItem> Items => items;
        ObservableCollection<OrderItem> items = new ObservableCollection<OrderItem>();

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        public CashDeskLib.DataModel.Order ToRawOrder()
        {
            return new CashDeskLib.DataModel.Order
            {
                Id = Guid.NewGuid(),
                DateTime = DateTime.Now,
                Number = this.Number,
                Items = this.Items.Select(orderItem => new CashDeskLib.DataModel.OrderItem
                {
                    MenuItem = orderItem.MenuItem.RawMenuItem,
                    Count = orderItem.Count
                }).ToList()
            };
        }
    }
}
