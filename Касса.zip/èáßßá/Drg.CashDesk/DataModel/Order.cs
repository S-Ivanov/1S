﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public Order()
        {
            items.CollectionChanged += Items_CollectionChanged;
        }

        /// <summary>
        /// Общая сумма
        /// </summary>
        public decimal Total => Items.Sum(item => item.Sum);

        /// <summary>
        /// Можно свернуть позиции заказа
        /// </summary>
        public bool CanCollapse => Items.GroupBy(orderItem => orderItem.MenuItem).Any(g => g.Count() > 1);

        /// <summary>
        /// Свернуть позиции заказа
        /// </summary>
        public void Collapse()
        {
            var collapsed = new ObservableCollection<OrderItem>(
                Items
                .GroupBy(orderItem => orderItem.MenuItem)
                .Select((g, index) => new OrderItem(g.Key, index + 1, g.Sum(orderItem => orderItem.Count))));
            if (items != null)
                items.CollectionChanged -= Items_CollectionChanged;
            items = collapsed;
            items.CollectionChanged += Items_CollectionChanged;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanCollapse)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
        }

        /// <summary>
        /// Обработчик события изменения списка позиций заказа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanCollapse)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));

            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                // при добавлении записи подключаем обработчик на изменение суммы
                foreach (OrderItem orderItem in e.NewItems)
                {
                    orderItem.PropertyChanged += OrderItem_PropertyChanged;
                }
            }
            else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                // при удалении записи нужно пересчитать нумерацию
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].Number = i + 1;
                }
            }
        }

        private void OrderItem_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Sum")
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
        }

        /// <summary>
        /// Элементы заказа
        /// </summary>
        public ObservableCollection<OrderItem> Items => items;
        ObservableCollection<OrderItem> items = new ObservableCollection<OrderItem>();

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
