﻿using System;
using System.Collections.Generic;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order
    {
        /// <summary>
        /// Элементы заказа
        /// </summary>
        public List<OrderItem> Items => items;
        List<OrderItem> items = new List<OrderItem>();
    }
}
