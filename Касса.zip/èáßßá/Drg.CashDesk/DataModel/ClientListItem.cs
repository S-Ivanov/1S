﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Отображение клиента в списке для поиска
    /// </summary>
    /// <remarks>
    /// Строковые свойства представляются в формате, который используется в TextBlock для выделения текста
    /// https://stackoverflow.com/questions/5263055/formatting-text-in-a-textblock/5263094
    /// ответ 81
    /// http://www.wpf-tutorial.com/basic-controls/the-textblock-control-inline-formatting/
    /// </remarks>
    public class ClientListItem : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="rawClient">объект клиента</param>
        public ClientListItem(CashDeskLib.DataModel.Client rawClient)
        {
            RawClient = rawClient;
            TabNum = rawClient.TabNum;
            FIO = rawClient.FIO;
        }

        /// <summary>
        /// Проверка на соответствие тексту
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool MathText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return true;

            var digitsAndChars = text.ToDigitsAndChars();
            if (digitsAndChars.Item1.Length > 0 && digitsAndChars.Item2.Length > 0)
                return true;
            else if (digitsAndChars.Item1.Length > 0)
                return RawClient.TabNum.IndexOf(digitsAndChars.Item1, StringComparison.CurrentCultureIgnoreCase) >= 0;
            else // if (digitsAndChars.Item2.Length > 0)
                return RawClient.FIO.IndexOf(digitsAndChars.Item2, StringComparison.CurrentCultureIgnoreCase) >= 0;
        }

        /// <summary>
        /// Установить выделенный текст
        /// </summary>
        /// <param name="text"></param>
        public void SetBoldText(string text)
        {
            Tuple<string, string> digitsAndChars = null;
            bool noBold = string.IsNullOrEmpty(text);
            if (!noBold)
            {
                digitsAndChars = text.ToDigitsAndChars();
                if (digitsAndChars.Item1.Length > 0 && digitsAndChars.Item2.Length > 0)
                    noBold = true;
            }

            if (noBold)
            {
                TabNum = RawClient.TabNum;
                FIO = RawClient.FIO;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO)));
            }
            else if (digitsAndChars.Item1.Length > 0)
            {
                //TabNum = RawClient.TabNum.Replace(text, text);

            }
            else // if (digitsAndChars.Item2.Length > 0)
            {

            }
        }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum { get; private set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; private set; }

        /// <summary>
        /// Исходный объект
        /// </summary>
        public CashDeskLib.DataModel.Client RawClient { get; private set; }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
