﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.Utils;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Отображение клиента в списке для поиска
    /// </summary>
    /// <remarks>
    /// Строковые свойства представляются в формате, который используется в TextBlock для выделения текста
    /// https://stackoverflow.com/questions/5263055/formatting-text-in-a-textblock/5263094
    /// ответ 81
    /// http://www.wpf-tutorial.com/basic-controls/the-textblock-control-inline-formatting/
    /// 
    /// Как отобразить форматированный текст в TextBlock
    /// https://stackoverflow.com/questions/5582893/wpf-generate-textblock-inlines
    /// ответ 17
    /// </remarks>
    public class ClientListItem : Client, INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="rawClient">объект клиента</param>
        public ClientListItem(CashDeskLib.DataModel.Client rawClient)
            : base(rawClient)
        {
            TabNum = RawClient.TabNum;
            FIO = RawClient.FIO;
        }

        /// <summary>
        /// Проверка на соответствие тексту
        /// </summary>
        /// <param name="text">текст для поиска: только цифры - поиск по табельному, символы - поиск по ФИО</param>
        /// <returns></returns>
        public bool MathText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return true;

            if (text.Any(ch => char.IsDigit(ch)))
            {
                // поиск по табельному
                return RawClient.TabNum.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0;
            }
            else
            {
                // поиск по ФИО
                return RawClient.FIO.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0;
            }
        }

        /// <summary>
        /// Установить выделенный текст
        /// </summary>
        /// <param name="text">текст для поиска: только цифры - поиск по табельному, символы - поиск по ФИО</param>
        public void SetBoldText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return;

            if (text.Any(ch => char.IsDigit(ch)))
            {
                // поиск по табельному
                //TabNum = StringUtils.InsertTags(RawClient.TabNum, text, "Bold");
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum)));

                int index = RawClient.TabNum.IndexOf(text);
                if (index < 0)
                {
                    TabNum1 = RawClient.TabNum;
                    TabNum2 = TabNum3 = "";
                }
                else
                {
                    TabNum1 = RawClient.TabNum.Substring(0, index);
                    TabNum2 = RawClient.TabNum.Substring(index, text.Length);
                    TabNum3 = RawClient.TabNum.Substring(index + text.Length);
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum1)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum2)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum3)));
            }
            else
            {
                // поиск по ФИО
                FIO = StringUtils.InsertTags(RawClient.FIO, text, "Bold");
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO)));
            }
        }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum { get; private set; }

        public string TabNum1 { get; private set; }
        public string TabNum2 { get; private set; }
        public string TabNum3 { get; private set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; private set; }

        ///// <summary>
        ///// Исходный объект
        ///// </summary>
        //public CashDeskLib.DataModel.Client RawClient { get; private set; }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
