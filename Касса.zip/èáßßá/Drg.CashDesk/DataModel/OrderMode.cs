﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Режимы заказа
    /// </summary>
    public enum OrderMode
    {
        /// <summary>
        /// Нормальный режим работы
        /// </summary>
        Work,

        /// <summary>
        /// Исходный заказ при возврате
        /// </summary>
        Source,

        /// <summary>
        /// Заказ возврата
        /// </summary>
        Return
    }
}
