﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class OrderSource
    {
        public OrderSource(Client client, CashDeskLib.DataModel.Order rawOrder)
        {
            Client = client;
            RawOrder = rawOrder;

            // свернуть элементы исходного заказа
            Items = rawOrder.Items
                .GroupBy(orderItem => orderItem.MenuItem.ProductId)
                .Select((g, index) =>
                {
                    var orderItem = g.First();
                    return new OrderSourceItem(orderItem, index + 1, g.Sum(_ => _.Count), g.Sum(_ => _.Sum));
                })
                .ToList();
        }

        public ObservableCollection<OrderReturnItem> Returns
        {
            get => returns;
            set
            {
                if (returns != value)
                {
                    returns = value;
                }
            }
        }
        ObservableCollection<OrderReturnItem> returns = null;

        /// <summary>
        /// Клиент
        /// </summary>
        public Client Client { get; private set; }

        /// <summary>
        /// Общая сумма
        /// </summary>
        public decimal Total => RawOrder.Items.Sum(item => item.Sum);

        public List<OrderSourceItem> Items { get; private set; } 

        public CashDeskLib.DataModel.Order RawOrder { get; private set; }
    }
}
