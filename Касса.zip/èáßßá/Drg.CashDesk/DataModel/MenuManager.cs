﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Управление меню
    /// </summary>
    public class MenuManager
    {
        public MenuManager()
        {
            var menu = CashDeskLib.CashDesk.Instance.LoadMenusExt(DateTime.Today, 2);

            // меню отсортированы по дате в убывающем порядке
            if (menu != null && menu.Any())
            {
                if (menu[0].Date.Date != DateTime.Today)
                {
                    PreviousMenu = new MenuExt(menu[0]);
                }
                else
                {
                    TodayMenu = new MenuExt(menu[0]);
                    if (menu.Count > 1)
                    {
                        PreviousMenu = new MenuExt(menu[1]);
                    }
                }
            }
        }

        /// <summary>
        /// Сегодняшнее меню
        /// </summary>
        public MenuExt TodayMenu { get; private set; }

        /// <summary>
        /// Предыдущее меню
        /// </summary>
        public MenuExt PreviousMenu { get; private set; }
    }
}
