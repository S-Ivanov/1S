﻿namespace Drg.CashDesk.DataModel
{
    public class OrderReturnListItem
    {
        public OrderReturnListItem(CashDeskLib.DataModel.Order order)
        {
            RawOrder = order;
        }

        public CashDeskLib.DataModel.Order RawOrder { get; private set; }

        public bool IsSelected { get; set; }
    }
}
