﻿using System.ComponentModel;
using System.Globalization;

namespace Drg.CashDesk.DataModel
{
    public class OrderReturnListItem : INotifyPropertyChanged
    {
        public OrderReturnListItem()
        {
        }

        public OrderReturnListItem(CashDeskLib.DataModel.Order order)
        {
            RawOrder = order;
            Time = order.DateTime.ToString("T", CultureInfo.CurrentUICulture);
            Number = order.Number.ToString();
        }

        public CashDeskLib.DataModel.Order RawOrder { get; private set; }

        public string Time { get; set; }

        public string Number { get; set; }

        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected = true;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
