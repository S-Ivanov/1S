﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    public class MenuItemExt : INotifyPropertyChanged
    {
        public MenuItemExt(CashDeskLib.DataModel.MenuItemBaseExt rawItem) 
        {
            RawItem = rawItem;
            Children = new ObservableCollection<MenuItemExt>(rawItem.Children.Select(_ => new MenuItemExt(_)));
        }

        public CashDeskLib.DataModel.MenuItemBaseExt RawItem { get; private set; }

        /// <summary>
        /// Дочерние элементы меню
        /// </summary>
        public ObservableCollection<MenuItemExt> Children { get; private set; }

        public bool IsGroup => Children != null && Children.Count > 0;

        public bool IsLocal => (RawItem as CashDeskLib.DataModel.MenuItemExt)?.IsLocal ?? false;

        /// <summary>
        /// Индикатор выбранного элемента/группы элементов меню
        /// </summary>
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected = false;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
