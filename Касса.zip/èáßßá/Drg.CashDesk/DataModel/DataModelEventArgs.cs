﻿using System;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Параметр универсального события
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DataModelEventArgs<T> : EventArgs
    {
        public T Data { get; set; }
    }
}
