﻿using Drg.CashDesk.Converters;
using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class MoneyReportItem
    {
        public MoneyReportItem(CashDeskLib.DataModel.MoneyReportItem rawMoneyReportItem)
            : this(PaymentToStringConverter.GetPaymentName(rawMoneyReportItem.Payment), rawMoneyReportItem.Incoming, rawMoneyReportItem.Refund, rawMoneyReportItem.Payment)
        {
        }

        public MoneyReportItem(string paymentName, decimal incoming, decimal refund, Payment payment = Payment.None)
        {
            Payment = payment;
            PaymentName = paymentName;
            Incoming = incoming;
            Refund = refund;
        }

        public Payment Payment { get; private set; }

        /// <summary>
        /// Название варианта оплаты
        /// </summary>
        public string PaymentName { get; private set; }

        /// <summary>
        /// Приход
        /// </summary>
        public decimal Incoming { get; private set; }

        /// <summary>
        /// Приход в виде строки
        /// </summary>
        public string IncomingString => GetSumsInFormat(Incoming);

        /// <summary>
        /// Возврат
        /// </summary>
        public decimal Refund { get; private set; }

        /// <summary>
        /// Возврат в виде строки
        /// </summary>
        public string RefundString => GetSumsInFormat(Refund);
   
        /// <summary>
        /// Баланс
        /// </summary>
        public decimal Balance => Incoming - Refund;

        /// <summary>
        /// Баланс в виде строки
        /// </summary>
        public string BalanceString => GetSumsInFormat(Balance);

        /// <summary>
        /// Метод для преобразования суммы к строке вида "(Количество талонов) = (Сумма)"
        /// </summary>
        /// <param name="sum"></param>
        /// <returns></returns>
        string GetSumsInFormat(decimal sum)
        {
            switch (Payment)
            {
                case Payment.LPP:
                    return sum > 0 ? $"{(int)(sum / CashDeskLib.CashDesk.Instance.Configuration.LPPNominal)} = {sum:N2}" : null;
                case Payment.Talon120:
                    return sum > 0 ? $"{(int)(sum / CashDeskLib.CashDesk.Instance.Configuration.Talon120Nominal)} = {sum:N2}" : null;
                default:
                    return sum.ToString("N2");
            }
        }
    }
}
