﻿using Drg.CashDesk.Converters;
using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    public class MoneyReportItem
    {
        public MoneyReportItem(CashDeskLib.DataModel.MoneyReportItem rawMoneyReportItem)
            : this(CashDeskLib.Utils.PaymentUtils.GetPaymentName(rawMoneyReportItem.Payment), rawMoneyReportItem.Incoming, rawMoneyReportItem.IncomingCount, rawMoneyReportItem.Refund, rawMoneyReportItem.RefundCount, rawMoneyReportItem.Payment)
        {
            this.RawItem = rawMoneyReportItem;
        }

        public MoneyReportItem(string paymentName, decimal incoming, int incomingCount, decimal refund, int refundCount, Payment payment = Payment.None)
        {
            Payment = payment;
            PaymentName = paymentName;
            Incoming = incoming;
            IncomingCount = incomingCount;
            Refund = refund;
            RefundCount = refundCount;
        }

        public Payment Payment { get; private set; }

        /// <summary>
        /// Название варианта оплаты
        /// </summary>
        public string PaymentName { get; private set; }

        /// <summary>
        /// Приход сумма
        /// </summary>
        public decimal Incoming { get; private set; }

        /// <summary>
        /// Приход количество
        /// </summary>
        public int IncomingCount { get; private set; }

        ///// <summary>
        ///// Приход в виде строки
        ///// </summary>
        //public string IncomingString => GetSumsInFormat(Incoming);

        /// <summary>
        /// Возврат сумма
        /// </summary>
        public decimal Refund { get; private set; }

        /// <summary>
        /// Возврат количество
        /// </summary>
        public int RefundCount { get; private set; }

        ///// <summary>
        ///// Возврат в виде строки
        ///// </summary>
        //public string RefundString => GetSumsInFormat(Refund);

        /// <summary>
        /// Баланс сумма
        /// </summary>
        public decimal Balance => Incoming - Refund;

        /// <summary>
        /// Баланс количество
        /// </summary>
        public decimal BalanceCount => IncomingCount + RefundCount;

        /// <summary>
        /// Средняя покупка
        /// </summary>
        public decimal Average => IncomingCount != 0 ? Incoming / IncomingCount : 0;

        ///// <summary>
        ///// Баланс в виде строки
        ///// </summary>
        //public string BalanceString => GetSumsInFormat(Balance);

        public CashDeskLib.DataModel.MoneyReportItem RawItem { get; }

        ///// <summary>
        ///// Метод для преобразования суммы к строке вида "(Количество талонов) = (Сумма)"
        ///// </summary>
        ///// <param name="sum"></param>
        ///// <returns></returns>
        //string GetSumsInFormat(decimal sum)
        //{
        //    switch (Payment)
        //    {
        //        case Payment.LPP:
        //            return sum > 0 ? $"{(int)(sum / CashDeskLib.CashDesk.Instance.Nominals.LPP)} = {sum:N2}" : null;
        //        case Payment.Talon120:
        //            return sum > 0 ? $"{(int)(sum / CashDeskLib.CashDesk.Instance.Nominals.Talon120)} = {sum:N2}" : null;
        //        default:
        //            return sum.ToString("N2");
        //    }
        //}
    }
}
