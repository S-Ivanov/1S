﻿using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    public class Menu
    {
        public Menu(CashDeskLib.DataModel.Menu rawMenu)
        {
            this.RawMenu = rawMenu;
        }

        /// <summary>
        /// Номер меню
        /// </summary>
        public string Number => RawMenu?.Number;

        /// <summary>
        /// Дата меню
        /// </summary>
        public DateTime Date => RawMenu?.Date ?? DateTime.Today;

        /// <summary>
        /// Группы элементов меню
        /// </summary>
        public ObservableCollection<MenuItemGroup> MenuGroups
        {
            get
            {
                if (menuGroups == null)
                    menuGroups = RawMenu == null ? new ObservableCollection<MenuItemGroup>() : new ObservableCollection<MenuItemGroup>(RawMenu.Items.Select(menuItemGroup => new MenuItemGroup(menuItemGroup)));
                return menuGroups;
            }
        }
        ObservableCollection<MenuItemGroup> menuGroups = null;

        public readonly CashDeskLib.DataModel.Menu RawMenu;
    }
}
