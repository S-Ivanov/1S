﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    public class Menu
    {
        public Menu(CashDeskLib.DataModel.Menu rawMenu)
        {
            RawMenu = rawMenu;
            Items = new ObservableCollection<MenuItem>(rawMenu.Items.Select(_ => new MenuItem(_)));
        }

        public CashDeskLib.DataModel.Menu RawMenu { get; private set; }

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItem> Items { get; private set; }

    }
}
