﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Варианты оплаты
    /// </summary>
    public enum Payment
    {
        None        = 0,
        ZP          = 1,
        LPP         = 2,
        Talon120    = 3,
        BankCard    = 4,
        Cash        = 5
    }
}
