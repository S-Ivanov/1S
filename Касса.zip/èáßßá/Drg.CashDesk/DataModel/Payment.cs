﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Варианты оплаты
    /// </summary>
    public enum Payment
    {
        None        = -1,
        ZP          = 0,
        LPP         = 1,
        Talon120    = 2,
        BankCard    = 3,
        Cash        = 4
    }
}
