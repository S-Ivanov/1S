﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Режимы работы кассы
    /// </summary>
    public enum CashDeskMode
    {
        /// <summary>
        /// Штатная работа
        /// </summary>
        Work = 0,

        /// <summary>
        /// Сервис меню
        /// </summary>
        MenuService,

        /// <summary>
        /// Возврат заказа
        /// </summary>
        OrderReturn
    }
}
