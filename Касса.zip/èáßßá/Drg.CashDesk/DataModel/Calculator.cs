﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    public class Calculator
    {
        public Calculator(decimal limit = 0, decimal sum = 0)
        {
            this.limit = limit;
            Sum = sum;
        }

        public void AddSymbols(string symbols)
        {
            if (string.IsNullOrEmpty(symbols))
                throw new ArgumentNullException();

            symbols = symbols.Trim();

            if (symbols == "." || symbols == ",")
            {
                isDot = Sum % 1 == 0;
            }
            else if (symbols.All(_ => char.IsDigit(_)))
            {
                if (isDot)
                {
                    // добавление цифр после запятой
                    Sum = decimal.Parse(Sum.ToString() + "." + symbols);
                }
            }
        }

        public void Clear()
        {
            Sum = 0;
        }

        public decimal Sum { get; private set; }

        decimal limit;
        bool isDot;
    }
}
