﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Утилиты для работы со строками
    /// </summary>
    public static class StringUtils
    {
        /// <summary>
        /// Разбить строку на цифры и символы
        /// </summary>
        /// <param name="text">входная строка</param>
        /// <returns>
        /// Tuple:
        ///     - Item1 = цифры
        ///     - Item2 = остальные символы
        /// </returns>
        public static Tuple<string, string> ToDigitsAndChars(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return new Tuple<string, string>("", "");

            string digits = string.Concat(text.Where(ch => char.IsDigit(ch)));
            string chars = string.Concat(text.Where(ch => !char.IsDigit(ch)));
            return new Tuple<string, string>(digits, chars);
        }

        /// <summary>
        /// Поиск всех вхождений подстроки в строку
        /// </summary>
        /// <param name="str">проверяемая строка</param>
        /// <param name="substr">строка для поиска</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns>индексы вхождений</returns>
        /// <remarks>
        /// https://stackoverflow.com/questions/2641326/finding-all-positions-of-substring-in-a-larger-string-in-c-sharp
        /// ответ 4
        /// </remarks>
        public static List<int> AllIndexesOf(this string str, string substr, bool ignoreCase = true)
        {
            if (string.IsNullOrWhiteSpace(str) ||
                string.IsNullOrWhiteSpace(substr))
            {
                throw new ArgumentException("String or substring is not specified.");
            }

            var indexes = new List<int>();
            int index = 0;

            while ((index = str.IndexOf(substr, index, ignoreCase ? StringComparison.CurrentCultureIgnoreCase : StringComparison.CurrentCulture)) != -1)
            {
                indexes.Add(index++);
            }

            return indexes;
        }

        public static string InsertTags(this string str, string substr, string tag, bool ignoreCase = true)
        {
            var allIndexes = AllIndexesOf(str, substr, ignoreCase);
            if (allIndexes.Count == 0)
                return str;

            int substrLength = substr.Length;
            StringBuilder sb = new StringBuilder();
            int startIndex = 0;
            foreach (var index in allIndexes)
            {
                sb.Append(str.Substring(startIndex, index));
                sb.Append($"<{tag}>");
                sb.Append(str.Substring(index, substrLength));
                sb.Append($"</{tag}>");
                startIndex = index + substrLength;
            }

            if (startIndex < str.Length)
                sb.Append(str.Substring(startIndex));

            return sb.ToString();
        }
    }
}
