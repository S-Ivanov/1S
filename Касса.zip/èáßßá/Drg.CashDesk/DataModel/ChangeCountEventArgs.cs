﻿using System;
using System.ComponentModel;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Аргумент события изменения количества
    /// </summary>
    public class ChangeCountEventArgs : CancelEventArgs
    {
        /// <summary>
        /// Тип элемента, для которого ожидается изменение количества
        /// </summary>
        public Type Type { get; set; }

        /// <summary>
        /// Значение
        /// </summary>
        public decimal Value { get; set; }
    }
}
