﻿using Drg.CashDeskLib.DataModel;
using System.Collections.Generic;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Возможные варианты оплаты
    /// </summary>
    public class PaymentAbilities 
    {
        public bool ZP
        {
            get
            {
                var orderTotal = Order == null ? 0 : Order.Total;
                var clientHasZP = Client == null ? false : Client.RawClient.HasZP;
                var cashDesk = CashDeskLib.CashDesk.Instance;
                return zp && clientHasZP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal > 0;
            }
        }
        bool zp = true;

        public bool LPP
        {
            get
            {
                var orderTotal = Order == null ? 0 : Order.Total;
                var clientHasLPP = Client == null ? false : Client.RawClient.HasLPP;
                var cashDesk = CashDeskLib.CashDesk.Instance;
                return lpp && clientHasLPP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal >= cashDesk.Configuration.LPPNominal;
            }
        }
        bool lpp = true;

        public bool Talon120
        {
            get
            {
                var orderTotal = Order == null ? 0 : Order.Total;
                var cashDesk = CashDeskLib.CashDesk.Instance;
                return talon120 && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Talon) == CashDeskLib.DataModel.PaymentMethod.Talon && orderTotal >= cashDesk.Configuration.Talon120Nominal;
            }
        }
        bool talon120 = true;

        public bool Bank
        {
            get
            {
                var orderTotal = Order == null ? 0 : Order.Total;
                var cashDesk = CashDeskLib.CashDesk.Instance;
                return bank && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.BankCard) == CashDeskLib.DataModel.PaymentMethod.BankCard && orderTotal > 0;
            }
        }
        bool bank = true;

        public bool Cash
        {
            get
            {
                var orderTotal = Order == null ? 0 : Order.Total;
                var cashDesk = CashDeskLib.CashDesk.Instance;
                return cash && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Cash) == CashDeskLib.DataModel.PaymentMethod.Cash && orderTotal > 0;
            }
        }
        bool cash = true;

        public Client Client { get; set; }

        public Order Order { get; set; }

        //public void SetPayments(bool enabled, params Payment[] payments)
        public void SetPayments(bool enabled, IEnumerable<Payment> payments)
        {
            foreach (var payment in payments)
            {
                switch (payment)
                {
                    case Payment.ZP:
                        zp = enabled;
                        break;
                    case Payment.LPP:
                        lpp = enabled;
                        break;
                    case Payment.Talon120:
                        talon120 = enabled;
                        break;
                    case Payment.BankCard:
                        bank = enabled;
                        break;
                    case Payment.Cash:
                        cash = enabled;
                        break;
                    default:
                        break;
                }
            }

            //Refresh();
        }

        //public void Refresh()
        //{
        //    var orderTotal = Order == null ? 0 : Order.Total;
        //    var clientHasZP = Client == null ? false : Client.RawClient.HasZP;
        //    var clientHasLPP = Client == null ? false : Client.RawClient.HasLPP;
        //    // обновить с учетом готовности оборудования
        //    var cashDesk = CashDeskLib.CashDesk.Instance;
        //    // TODO: обеспечить возможность оплаты по ЗП и ЛПП без считывателя
        //    //ZP = ZP && clientHasZP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal > 0;
        //    //LPP = LPP && clientHasLPP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal >= cashDesk.Configuration.LPPNominal;
        //    //Talon120 = Talon120 && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Talon) == CashDeskLib.DataModel.PaymentMethod.Talon && orderTotal >= cashDesk.Configuration.Talon120Nominal;
        //    //Bank = Bank && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.BankCard) == CashDeskLib.DataModel.PaymentMethod.BankCard && orderTotal > 0;
        //    //Cash = Cash && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Cash) == CashDeskLib.DataModel.PaymentMethod.Cash && orderTotal > 0;
        //}
    }
}
