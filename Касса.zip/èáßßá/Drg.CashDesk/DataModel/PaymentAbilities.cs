﻿namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Возможные варианты оплаты
    /// </summary>
    public class PaymentAbilities 
    {
        public bool ZP { get; set; }
        public bool LPP { get; set; }
        public bool Talon120 { get; set; } = true;
        public bool Bank { get; set; } = true;
        public bool Cash { get; set; } = true;

        public Client Client { get; set; }

        public Order Order { get; set; }

        public void Refresh()
        {
            var orderTotal = Order == null ? 0 : Order.Total;
            var clientHasZP = Client == null ? false : Client.RawClient.HasZP;
            var clientHasLPP = Client == null ? false : Client.RawClient.HasLPP;
            // обновить с учетом готовности оборудования
            var cashDesk = CashDeskLib.CashDesk.Instance;
            // TODO: обеспечить возможность оплаты по ЗП и ЛПП без считывателя
            ZP = clientHasZP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal > 0;
            LPP = clientHasLPP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass && orderTotal >= cashDesk.Configuration.LPPNominal;
            Talon120 = (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Talon) == CashDeskLib.DataModel.PaymentMethod.Talon && orderTotal >= cashDesk.Configuration.Talon120Nominal;
            Bank = (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.BankCard) == CashDeskLib.DataModel.PaymentMethod.BankCard && orderTotal > 0;
            Cash = (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Cash) == CashDeskLib.DataModel.PaymentMethod.Cash && orderTotal > 0;
        }
    }
}
