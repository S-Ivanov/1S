﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Возможные варианты оплаты
    /// </summary>
    public class PaymentAbilities
    {
        public bool ZP { get; private set; }
        public bool LPP { get; private set; }
        public bool Talon120 { get; private set; } = true;
        public bool Bank { get; private set; } = true;
        public bool Cash { get; private set; } = true;

        public Client Client
        {
            get => client;
            set
            {
                client = value;
                ZP = client.RawClient.HasZP;
                // TODO: добавить ЛПП
            }
        }
        Client client = null;

        public void Refresh()
        {
            // обновить с учетом готовности оборудования
            var cashDesk = CashDeskLib.CashDesk.Instance;
            // TODO: обеспечить возможность оплаты по ЗП и ЛПП без считывателя
            ZP &= (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass;
            LPP &= (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass;
            Talon120 &= (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Talon) == CashDeskLib.DataModel.PaymentMethod.Talon;
            Bank &= (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.BankCard) == CashDeskLib.DataModel.PaymentMethod.BankCard;
            Cash &= (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Cash) == CashDeskLib.DataModel.PaymentMethod.Cash;
        }
    }
}
