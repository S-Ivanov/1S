﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Возможные варианты оплаты - базовый класс
    /// </summary>
    public class PaymentAbilitiesBase
    {
        public bool ZP { get; set; }
        public bool LPP { get; set; }
        public bool Talon120 { get; set; } = true;
        public bool Bank { get; set; } = true;
        public bool Cash { get; set; } = true;
    }

    /// <summary>
    /// Возможные варианты оплаты
    /// </summary>
    public class PaymentAbilities : PaymentAbilitiesBase
    {
        public Client Client
        {
            get => client;
            set
            {
                if (client != value)
                {
                    client = value;
                    if (client == null)
                        ZP = LPP = Talon120 = Bank = Cash = false;
                    else
                    {
                        ZP = client.RawClient.HasZP;
                        // TODO: добавить ЛПП
                        Refresh();
                    }
                }
            }
        }
        Client client = null;

        public void Refresh()
        {
            // обновить с учетом готовности оборудования
            var cashDesk = CashDeskLib.CashDesk.Instance;
            // TODO: обеспечить возможность оплаты по ЗП и ЛПП без считывателя
            ZP = ZP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass;
            LPP = LPP && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Pass) == CashDeskLib.DataModel.PaymentMethod.Pass;
            Talon120 = Talon120 && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Talon) == CashDeskLib.DataModel.PaymentMethod.Talon;
            Bank = Bank && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.BankCard) == CashDeskLib.DataModel.PaymentMethod.BankCard;
            Cash = Cash && (cashDesk.PaymentMethod & CashDeskLib.DataModel.PaymentMethod.Cash) == CashDeskLib.DataModel.PaymentMethod.Cash;
        }
    }
}
