﻿using System.Globalization;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для OrderItemChangeCount.xaml
    /// </summary>
    public partial class OrderItemChangeCount : Window
    {
        const int NUMBER_CHARS_MAX_COUNT = 6;

        public OrderItemChangeCount()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // установить начальные координаты окна так, чтобы не перекрывался список элементов заказа
            Window mainWindow = Application.Current.MainWindow;
            this.Left = mainWindow.Left + mainWindow.ActualWidth / 2;
            this.Top = mainWindow.Top + (mainWindow.ActualHeight - this.ActualHeight) / 2;

            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModel.DataModelEventArgs<string> e)
        {
            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += e.Data;
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text.Length > 0)
                textBox.Text = textBox.Text.Substring(0, textBox.Text.Length - 1);
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = "";
        }

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += "0";
        }

        private void ZeroZeroButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT - 1)
                textBox.Text += "00";
            else if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += "0";
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT && !textBox.Text.Contains(","))
                textBox.Text += ",";
        }

        public decimal Count { get; set; }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(textBox.Text, System.Globalization.NumberStyles.Number, CultureInfo.GetCultureInfo("ru-RU"), out decimal count))
            {
                Count = count;
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void HalfButton_Click(object sender, RoutedEventArgs e)
        {
            Count = 0.5M;
            this.Close();
        }
    }
}
