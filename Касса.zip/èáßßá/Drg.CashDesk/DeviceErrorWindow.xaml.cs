﻿using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для DeviceErrorWindow.xaml
    /// </summary>
    public partial class DeviceErrorWindow : Window
    {
        public DeviceErrorWindow(IDevice device, DeviceError deviceError)
        {
            InitializeComponent();

            Device = device;
            DeviceError = deviceError;

            ErrorDescriptionTextBlock.Text = deviceError.Description;

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent += DeviceErrorWindow_CheckEquipmentEvent;
            }
        }

        public IDevice Device { get; private set; }
        public DeviceError DeviceError { get; private set; }

        private void DeviceErrorWindow_CheckEquipmentEvent(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() => CheckErrors());
        }

        private void CheckErrors()
        {
            var currentDeviceError = Device.LastError;
            if (currentDeviceError != DeviceError.NoError && currentDeviceError.IsUserError)
            {
                if (DeviceError.ErrorCode != currentDeviceError.ErrorCode)
                {
                    DeviceError = currentDeviceError;
                    ErrorDescriptionTextBlock.Text = DeviceError.Description;
                }
            }
            else //if (currentDeviceError == DeviceError.NoError || !currentDeviceError.IsUserError)
            {
                var cashDesk = CashDeskLib.CashDesk.Instance;
                bool hasError = false;
                foreach (var kvp in cashDesk.Devices)
                {
                    if (kvp.Value != Device && kvp.Value.LastError != DeviceError.NoError && kvp.Value.LastError.IsUserError)
                    {
                        // отображаем ошибку по другому устройству
                        Device = kvp.Value;
                        DeviceError = kvp.Value.LastError;
                        ErrorDescriptionTextBlock.Text = DeviceError.Description;
                        hasError = true;
                        break;
                    }
                }

                if (!hasError)
                    Dispatcher.Invoke(() =>
                    {
                        DeviceError = DeviceError.NoError;
                        Close();
                    });
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent -= DeviceErrorWindow_CheckEquipmentEvent;
            }
        }

        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
