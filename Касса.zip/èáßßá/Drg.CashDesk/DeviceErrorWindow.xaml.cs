﻿using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для DeviceErrorWindow.xaml
    /// </summary>
    public partial class DeviceErrorWindow : Window
    {
        public DeviceErrorWindow(IDevice device, DeviceError deviceError)
        {
            InitializeComponent();

            this.device = device;
            this.deviceError = deviceError;

            ErrorDescriptionTextBlock.Text = deviceError.Description;

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent += DeviceErrorWindow_CheckEquipmentEvent;
            }
        }

        private void DeviceErrorWindow_CheckEquipmentEvent(object sender, EventArgs e)
        {
            var currentDeviceError = device.LastError;
            if (currentDeviceError != DeviceError.NoError && currentDeviceError.IsUserError)
            {
                if (deviceError.ErrorCode != currentDeviceError.ErrorCode)
                {
                    deviceError = currentDeviceError;
                    ErrorDescriptionTextBlock.Text = deviceError.Description;
                }
            }
            else //if (currentDeviceError == DeviceError.NoError || !currentDeviceError.IsUserError)
            {
                var cashDesk = CashDeskLib.CashDesk.Instance;
                bool hasError = false;
                foreach (var kvp in cashDesk.Devices)
                {
                    if (kvp.Value.Device != device && kvp.Value.Device.LastError != DeviceError.NoError && kvp.Value.Device.LastError.IsUserError)
                    {
                        // отображаем ошибку по другому устройству
                        device = kvp.Value.Device;
                        deviceError = kvp.Value.Device.LastError;
                        ErrorDescriptionTextBlock.Text = deviceError.Description;
                        hasError = true;
                        break;
                    }
                }

                if (!hasError)
                    Dispatcher.Invoke(() => Close());
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent -= DeviceErrorWindow_CheckEquipmentEvent;
            }
        }

        IDevice device;
        DeviceError deviceError;

        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
