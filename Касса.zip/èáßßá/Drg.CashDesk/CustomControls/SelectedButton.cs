﻿using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.CustomControls
{
    public class SelectedButton : Button
    {
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }

        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register(nameof(IsSelected), typeof(bool), typeof(SelectedButton), new PropertyMetadata(true, IsSelectedChanged));

        private static void IsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as SelectedButton;
            control.BorderThickness = new Thickness(control.IsSelected ?  4 : 2);
        }
    }
}
