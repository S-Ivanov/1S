﻿using Drg.CashDesk.DataModel;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для SelectModeDialog.xaml
    /// </summary>
    public partial class SelectModeDialog : Window
    {
        public SelectModeDialog()
        {
            InitializeComponent();
        }

        public CashDeskMode CashDeskMode { get; private set; }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MenuServiceButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.MenuService);
        }

        private void SetCashDeskMode(CashDeskMode cashDeskMode)
        {
            CashDeskMode = cashDeskMode;
            DialogResult = true;
            Close();
        }

        private void OrderReturnButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.OrderReturn);
        }

        private void TotalMoneyButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.TotalMoney);
        }

        private void TotalProductButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.TotalProduct);
        }
    }
}
