﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для SelectModeDialog.xaml
    /// </summary>
    public partial class SelectModeDialog : Window
    {
        public SelectModeDialog()
        {
            InitializeComponent();
        }

        public CashDeskMode CashDeskMode { get; private set; }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MenuServiceButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.MenuService);
        }

        private void SetCashDeskMode(CashDeskMode cashDeskMode)
        {
            CashDeskMode = cashDeskMode;
            DialogResult = true;
            Close();
        }

        private void OrderReturnButton_Click(object sender, RoutedEventArgs e)
        {
            SetCashDeskMode(CashDeskMode.OrderReturn);
        }
    }
}
