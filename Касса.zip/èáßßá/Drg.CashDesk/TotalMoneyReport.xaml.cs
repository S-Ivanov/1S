﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalMoneyReport : Window
    {
        public TotalMoneyReport(Session session, List<MoneyReportItem> moneyReportItems)
        {
            InitializeComponent();
            Session = session;
            MoneyReportItems = moneyReportItems.Select(_ => new DataModel.MoneyReportItem(_)).ToList();
            MoneyReportItems.Add(new CashDesk.DataModel.MoneyReportItem("Итого:", moneyReportItems.Sum(_ => _.Incoming), moneyReportItems.Sum(_ => _.Refund)));
            DataContext = this;
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public List<CashDesk.DataModel.MoneyReportItem> MoneyReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
