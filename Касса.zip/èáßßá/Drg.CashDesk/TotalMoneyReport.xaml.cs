﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.UserControls;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalMoneyReport : Window, INotifyPropertyChanged
    {
        public TotalMoneyReport(Session session, List<MoneyReportItem> moneyReportItems)
        {
            InitializeComponent();

            Session = session;
            MoneyReportItems = moneyReportItems.Select(_ => new DataModel.MoneyReportItem(_)).ToList();
            if (MoneyReportItems.Any())
            {
                MoneyReportItems.Add(new CashDesk.DataModel.MoneyReportItem("Итого:", moneyReportItems.Sum(_ => _.Incoming), moneyReportItems.Sum(_ => _.Refund)));
            }
            DataContext = this;

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent += TotalMoneyReport_CheckEquipmentEvent;
            }
        }

        private void TotalMoneyReport_CheckEquipmentEvent(object sender, EventArgs e)
        {
            KKMIsReady = CashDeskLib.CashDesk.Instance.IsKKMReadyForNonFiscalPrint();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent -= TotalMoneyReport_CheckEquipmentEvent;
            }
        }

        public bool KKMIsReady
        {
            get => kkmIsReady;
            set
            {
                if (kkmIsReady != value)
                {
                    kkmIsReady = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(KKMIsReady)));
                }
            }
        }
        bool kkmIsReady;

        public event PropertyChangedEventHandler PropertyChanged;

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public List<CashDesk.DataModel.MoneyReportItem> MoneyReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void DoPrint()
        {
            try
            {
                CashDeskLib.CashDesk.Instance.PrintTotalMoneyReport(MoneyReportItems.Where(_ => _.RawItem != null).Select(_ => _.RawItem));
            }
            catch (DeviceException ex)
            {
                MessageBox.Show($"{ex.Message}\n\nКод ошибки: {ex.DeviceError.ErrorCode}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            DoPrint();
            Close();
        }
    }
}
