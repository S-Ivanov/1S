﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.Dialogs;
using Drg.CashDesk.UserControls;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalMoneyReport.xaml
    /// </summary>
    public partial class TotalMoneyReport : Window, INotifyPropertyChanged
    {
        public TotalMoneyReport(Session session, List<MoneyReportItem> moneyReportItems, int orderCount, int orderReturnCount)
        {
            InitializeComponent();

            Session = session;

            OrderCount = orderCount;
            OrderReturnCount = orderReturnCount;

            MoneyReportItems = moneyReportItems.Select(_ => new DataModel.MoneyReportItem(_)).ToList();
            if (MoneyReportItems.Any())
            {
                // добавление отчёта по талонам
                TalonItems = MoneyReportItems
                    .Where(_ => _.Payment == Payment.LPP || _.Payment == Payment.Talon120)
                    .Select(_ =>
                    {
                        decimal nominal =
                            _.Payment == Payment.LPP ?
                            CashDeskLib.CashDesk.Instance.Nominals.LPP :
                            CashDeskLib.CashDesk.Instance.Nominals.Talon120;
                        return new DataModel.MoneyReportItem(
                            _.PaymentName,
                            (int)(_.Incoming / nominal),
                            0,
                            (int)(_.Refund / nominal),
                            0,
                            _.Payment);
                    })
                    .ToList();

                MoneyReportItems.Add(new DataModel.MoneyReportItem("Итого:", moneyReportItems.Sum(_ => _.Incoming), moneyReportItems.Sum(_ => _.IncomingCount), moneyReportItems.Sum(_ => _.Refund), moneyReportItems.Sum(_ => _.RefundCount)));
            }

            DataContext = this;

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent += TotalMoneyReport_CheckEquipmentEvent;
            }
        }

        private void TotalMoneyReport_CheckEquipmentEvent(object sender, EventArgs e)
        {
            KKMIsReady = CashDeskLib.CashDesk.Instance.IsKKMReadyForNonFiscalPrint();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent -= TotalMoneyReport_CheckEquipmentEvent;
            }
        }

        public bool KKMIsReady
        {
            get => kkmIsReady;
            set
            {
                if (kkmIsReady != value)
                {
                    kkmIsReady = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(KKMIsReady)));
                }
            }
        }
        bool kkmIsReady;

        public event PropertyChangedEventHandler PropertyChanged;

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public List<CashDesk.DataModel.MoneyReportItem> MoneyReportItems { get; private set; }
        public List<CashDesk.DataModel.MoneyReportItem> TalonItems { get; private set; }
        public int OrderCount { get; private set; }
        public int OrderReturnCount { get; private set; }
        public int OrderSumCount => OrderCount + OrderReturnCount;


        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void DoPrint()
        {
            (Application.Current as App).CheckEquipmentStop();
            try
            {
                var q1 = MoneyReportItems.Where(_ => _.RawItem != null).Select(_ => _.RawItem);
                var q2 = TalonItems.Where(_ => _.RawItem != null).Select(_ => _.RawItem);
                CashDeskLib.CashDesk.Instance.PrintTotalMoneyReport(MoneyReportItems.Where(_ => _.RawItem != null).Select(_ => _.RawItem), q2);
            }
            catch (DeviceException ex)
            {
                //MessageBox.Show($"{ex.Message}\n\nКод ошибки: {ex.DeviceError.ErrorCode}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                WpfMessageBox.Show("Ошибка", $"{ex.Message}\n\nКод ошибки: {ex.DeviceError.ErrorCode}", MessageBoxButton.OK, Dialogs.MessageBoxImage.Error);
            }
            finally
            {
                (Application.Current as App).CheckEquipmentStart();
            }
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            DoPrint();
            Close();
        }
    }
}
