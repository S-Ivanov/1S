﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderSourceControl : UserControl, INotifyPropertyChanged
    {
        public OrderSourceControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        /// <summary>
        /// Исходный заказ
        /// </summary>
        public OrderSource OrderSource
        {
            get => orderSource;
            set
            {
                if (orderSource != value)
                {
                    orderSource = value;
                    SetZpLppVisibility();
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OrderSource)));
                }
            }
        }
        OrderSource orderSource;

        /// <summary>
        /// Выбранная запись
        /// </summary>
        public OrderSourceItem SelectedOrderItem 
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        OrderSourceItem selectedOrderItem;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void SetZpLppVisibility()
        {
            ZpLabel.Visibility = ZpValue.Visibility = OrderSource.Client.HasZP ? Visibility.Visible : Visibility.Collapsed;
            LppLabel.Visibility = LppValue1.Visibility = LppValue2.Visibility = LppValue3.Visibility = LppValue4.Visibility = OrderSource.Client.HasLPP ? Visibility.Visible : Visibility.Collapsed;
        }

        /// <summary>
        /// Команда возврата всех элементов заказа
        /// </summary>
        public ICommand ReturnAllItemsCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                        foreach (var item in OrderSource.Items)
                        {
                            decimal count = item.Count - GetReturnCount(item.RawOrderItem.MenuItem.IdProduct);
                            if (count != 0)
                            {
                                decimal sum = count * item.RawOrderItem.MenuItem.Price;
                                OrderSource.OrderReturn.AddItem(
                                    new OrderReturnItem(null, item.RawOrderItem)
                                    {
                                        ReturnCount = count,
                                        SourceCount = count,
                                    });
                            }
                        }
                    },
                    _ => 
                        OrderSource != null && 
                        OrderSource.OrderReturn.CanAddReturn &&
                        OrderSource.Items.Any(item => item.Count > GetReturnCount(item.RawOrderItem.MenuItem.IdProduct))
                    );
            }
        }

        /// <summary>
        /// Команда возврата выбранного элемента заказа
        /// </summary>
        public ICommand ReturnItemCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                        decimal count = SelectedOrderItem.Count - GetReturnCount(SelectedOrderItem.RawOrderItem.MenuItem.IdProduct);
                        OrderSource.OrderReturn.AddItem(
                            new OrderReturnItem(null, SelectedOrderItem.RawOrderItem)
                            {
                                ReturnCount = count,
                                SourceCount = count,
                            });
                    },
                    _ =>
                        SelectedOrderItem != null &&
                        OrderSource.OrderReturn.CanAddReturn &&
                        SelectedOrderItem.Count > GetReturnCount(SelectedOrderItem.RawOrderItem.MenuItem.IdProduct)
                    );
            }
        }

        decimal GetReturnCount(Guid productId) => OrderSource.OrderReturn.AllItems.Where(_ => _.RawOrderItem.MenuItem.IdProduct == productId).Sum(_ => _.ReturnCount);
    }
}
