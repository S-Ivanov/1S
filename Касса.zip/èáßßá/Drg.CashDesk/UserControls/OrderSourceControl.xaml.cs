﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderSourceControl : UserControl, INotifyPropertyChanged
    {
        public OrderSourceControl()
        {
            InitializeComponent();
        }

        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    DataContext = order = value;
                    SetZpLppVisibility();
                }
            }
        }
        Order order;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        public void SetOrderClient(Client client)
        {
            Order.Client = client;
            SetZpLppVisibility();
        }

        private void SetZpLppVisibility()
        {
            ZpLabel.Visibility = ZpValue.Visibility = Order.Client.HasZP ? Visibility.Visible : Visibility.Collapsed;
            LppLabel.Visibility = LppValue1.Visibility = LppValue2.Visibility = LppValue3.Visibility = LppValue4.Visibility = Order.Client.HasLPP ? Visibility.Visible : Visibility.Collapsed;
        }

        private void SetButtonsEnabled()
        {
            // TODO: сделать перключение достпности кнопки
            ReturnButton.IsEnabled = Order.SelectedOrderItem != null;
        }

        private void ReturnAllButton_Click(object sender, RoutedEventArgs e)
        {
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
