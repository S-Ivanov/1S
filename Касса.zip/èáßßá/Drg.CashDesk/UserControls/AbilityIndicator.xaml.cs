﻿using Drg.CashDeskLib;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для AbilityIndicator.xaml
    /// </summary>
    public partial class AbilityIndicator : UserControl //, INotifyPropertyChanged
    {
        public AbilityIndicator()
        {
            InitializeComponent();

            if (Application.Current is App)
                CheckEquipment();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: переспросить подтверждение выхода
            Application.Current.Shutdown();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).Tag != null)
                MessageBox.Show((sender as Button).Tag.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // выполняется только в рантайме
            // см. https://stackoverflow.com/questions/834283/is-there-a-way-to-check-if-wpf-is-currently-executing-in-design-mode-or-not
            // ответ 20
            if (Application.Current is App)
            {
                //CheckEquipment();

                timeLabel.Content = DateTime.Now.ToString("HH:mm:ss");

                checkEquipmentTimer = new DispatcherTimer();
                checkEquipmentTimer.Tick += new EventHandler(CheckEquipmentTimer_Tick);
                checkEquipmentTimer.Interval = new TimeSpan(0, 0, 1);
                checkEquipmentTimer.Start();

                timeTimer = new DispatcherTimer();
                timeTimer.Tick += new EventHandler(TimeTimer_Tick);
                timeTimer.Interval = new TimeSpan(0, 0, 1);
                timeTimer.Start();

                // https://social.msdn.microsoft.com/Forums/vstudio/en-US/477e7e74-ccbf-4498-8ab9-ca2f3b836597/how-to-know-when-a-wpf-usercontrol-is-closing?forum=wpf
                Window window = Window.GetWindow(this);
                window.Closing += Window_Closing;
            }
        }

        private void TimeTimer_Tick(object sender, EventArgs e)
        {
            timeLabel.Content = DateTime.Now.ToString("HH:mm:ss");
        }

        private void CheckEquipmentTimer_Tick(object sender, EventArgs e)
        {
            CheckEquipment();
        }

        private void CheckEquipment()
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            cashDesk.CheckEquipment();

            var cardReader = cashDesk.Devices[Device.CardReader].Device as ICardReader;
            var carReaderError = cashDesk.Devices[Device.CardReader].DeviceError;
            HasCardReader = cardReader != null && (carReaderError == null || carReaderError.ErrorCode == DeviceError.NO_ERROR);
            if (HasCardReader)
                cardReader.DataEvent += CardReader_DataEvent;
            else
                cardReader.DataEvent -= CardReader_DataEvent;

            passIndicator.Visibility = (cashDesk.Configuration.PaymentMethods & PaymentMethod.Pass) == PaymentMethod.Pass ? Visibility.Visible : Visibility.Hidden;
            if (passIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
                {
                    passIndicator.Background = Brushes.Green;
                    passIndicator.Tag = null;
                }
                else
                {
                    passIndicator.Background = Brushes.Red;
                    if (cardReader == null)
                        passIndicator.Tag = "Оплата по пропуску невозможна из-за отсутствия считывателя.";
                    else
                    {
                        passIndicator.Tag =
$@"Оплата по пропуску невозможна из-за ошибки считывателя:

Код ошибки: {carReaderError.ErrorCode}
Комментарий: {carReaderError.Description}";
                    }
                }
            }

            var kkm = cashDesk.Devices[Device.KKM].Device as IKKM;
            var kkmError = cashDesk.Devices[Device.KKM].DeviceError;

            bankCardIndicator.Visibility = (cashDesk.Configuration.PaymentMethods & PaymentMethod.BankCard) == PaymentMethod.BankCard ? Visibility.Visible : Visibility.Hidden;
            if (bankCardIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                {
                    bankCardIndicator.Background = Brushes.Green;
                    bankCardIndicator.Tag = null;
                }
                else
                {
                    bankCardIndicator.Background = Brushes.Red;
                    var payTerminal = cashDesk.Devices[Device.PayTerminal].Device;
                    if (kkm == null && payTerminal == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия ККМ и банковского терминала.";
                    else if (payTerminal == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия банковского терминала.";
                    else if (kkm == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия ККМ.";
                    else if (!kkm.Fiscal)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна, так как ККМ не фискализирована.";
                    else
                    {
                        var payTerminalError = cashDesk.Devices[Device.PayTerminal].DeviceError;
                        if (kkmError != null && kkmError.ErrorCode != DeviceError.NO_ERROR && payTerminalError != null && payTerminalError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибок.

ККМ:
Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}

Банковский терминал:
Код ошибки: {payTerminalError.ErrorCode}
Комментарий: {payTerminalError.Description}";
                        else if (kkmError != null && kkmError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
                        else if (payTerminalError != null && payTerminalError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибки банковского терминала:

Код ошибки: {payTerminalError.ErrorCode}
Комментарий: {payTerminalError.Description}";
                    }
                }
            }

            cashIndicator.Visibility = (cashDesk.Configuration.PaymentMethods & PaymentMethod.Cash) == PaymentMethod.Cash ? Visibility.Visible : Visibility.Hidden;
            if (cashIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
                {
                    cashIndicator.Background = Brushes.Green;
                    cashIndicator.Tag = null;
                }
                else
                {
                    cashIndicator.Background = Brushes.Red;
                    if (kkm == null)
                        cashIndicator.Tag = "Оплата наличными невозможна из-за отсутствия ККМ.";
                    else if (!kkm.Fiscal)
                        cashIndicator.Tag = "Оплата наличными невозможна, так как ККМ не фискализирована.";
                    else
                    {
                        cashIndicator.Tag =
$@"Оплата наличными невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
                    }
                }
            }

            if (kkm == null)
            {
                checkIndicator.Background = Brushes.Red;
                checkIndicator.Tag = "Печать чеков невозможна из-за отсутствия ККМ.";
            }
            else if (kkmError != null && kkmError.ErrorCode != DeviceError.NO_ERROR)
            {
                checkIndicator.Background = Brushes.Red;
                checkIndicator.Tag =
$@"Печать чеков невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
            }
            else if (!kkm.Fiscal)
            {
                checkIndicator.Background = Brushes.Yellow;
                checkIndicator.Tag = "Возможна печать только нефискальных чеков.";
            }
            else
            {
                checkIndicator.Background = Brushes.Green;
                checkIndicator.Tag = null;
            }

            EquipmentChecked?.Invoke(this, EventArgs.Empty);
        }

        private void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            CardReaderEvent?.Invoke(this, e);
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            checkEquipmentTimer?.Stop();
            timeTimer?.Stop();

            if (HasCardReader)
            {
                var cashDesk = CashDeskLib.CashDesk.Instance;
                var cardReader = cashDesk.Devices[Device.CardReader].Device as ICardReader;
                if (cardReader != null)
                    cardReader.DataEvent -= CardReader_DataEvent;
            }
        }

        DispatcherTimer checkEquipmentTimer = null;
        DispatcherTimer timeTimer = null;

        public string Title
        {
            get => titleLabel.Content?.ToString();
            set => titleLabel.Content = value;
        }

        public bool HasCardReader { get; private set; }
        //{
        //    get => hasCardReader;
        //    private set
        //    {
        //        if (hasCardReader != value)
        //        {
        //            hasCardReader = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasCardReader)));
        //        }
        //    }
        //}
        //bool hasCardReader; 

        //public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Событие после проверки оборудования
        /// </summary>
        public event EventHandler EquipmentChecked;

        /// <summary>
        /// Событие чтения пропуска
        /// </summary>
        public event EventHandler<CardReaderEventArgs> CardReaderEvent;
    }
}
