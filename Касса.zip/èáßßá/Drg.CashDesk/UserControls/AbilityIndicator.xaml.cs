﻿using Drg.CashDeskLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для AbilityIndicator.xaml
    /// </summary>
    public partial class AbilityIndicator : UserControl
    {
        public AbilityIndicator()
        {
            InitializeComponent();
        }

        private void btnRed_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Строка 1\nСтрока 2");
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).Tag != null)
                MessageBox.Show((sender as Button).Tag.ToString());
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // выполняется только не в design mode
            // см. https://stackoverflow.com/questions/834283/is-there-a-way-to-check-if-wpf-is-currently-executing-in-design-mode-or-not
            // ответ 20
            if (Application.Current is App)
            {
                dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
                dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
                dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
                dispatcherTimer.Start();

                // https://social.msdn.microsoft.com/Forums/vstudio/en-US/477e7e74-ccbf-4498-8ab9-ca2f3b836597/how-to-know-when-a-wpf-usercontrol-is-closing?forum=wpf
                //Window window = Window.GetWindow(this);
                //window.Closing += Window_Closing;

                //MessageBox.Show(grid.Children.Count.ToString());
                //panel.Children.Clear();

                //var allPaymentMethods = Enum.GetValues(typeof(PaymentMethod)).OfType<PaymentMethod>().Where(x => x != PaymentMethod.None);
                //foreach (var paymentMethod in allPaymentMethods)
                //{
                //    int buttonIndex = GetButtonIndex(paymentMethod);
                //}

                //var cashDesk = CashDeskLib.CashDesk.Instance;

                //bool noFirstButton = false;
                //foreach (var paymentMethod in cashDesk.Configuration.PaymentMethods.GetIndividualFlags().Cast<PaymentMethod>())
                //{
                //Button button = new Button();
                //button.Width = button.Height = 32;
                //button.Focusable = false;
                //button.ToolTip = paymentMethod.GetDescription();

                //if (noFirstButton)
                //{
                //    // TODO: добавить отступ
                //    //    button.Margin = ?

                //    noFirstButton = true;
                //}

                // TODO: добавить картинку в button.Content

                //bool paymentMethodEnabled = (cashDesk.PaymentMethod & paymentMethod) == paymentMethod;
                //if (paymentMethodEnabled)
                //{
                //    button.Background = Brushes.Green;
                //}
                //else
                //{
                //    button.Background = paymentMethod == PaymentMethod.Pass ? Brushes.Yellow : Brushes.Red;
                //    button.Click += Button_Click;
                //}

                //panel.Children.Add(button);

                //int buttonIndex = 0;
                //switch (paymentMethod)
                //{
                //    case PaymentMethod.Pass:
                //        button = 
                //}
                //}
            }
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            cashDesk.CheckEquipment();

            passIndicator.Visibility = (cashDesk.Configuration.PaymentMethods & PaymentMethod.Pass) == PaymentMethod.Pass ? Visibility.Visible : Visibility.Hidden;
            if (passIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
                {
                    passIndicator.Background = Brushes.Green;
                    //passIndicator.IsEnabled = false;
                    passIndicator.Tag = null;
                }
                else
                {
                    passIndicator.Background = Brushes.Yellow;
                    //passIndicator.IsEnabled = true;
                    var cardReader = cashDesk.Devices[Equipment.Device.CardReader].Device;
                    if (cardReader == null)
                        passIndicator.Tag = "Оплата по пропускам невозможна из-за отсутствия считывателя";
                    else
                    {
                        var carReaderError = cashDesk.Devices[Equipment.Device.CardReader].DeviceError;
                        passIndicator.Tag =
$@"Оплата по пропускам невозможна из-за ошибки считывателя:

Код ошибки: {carReaderError.ErrorCode}
Комментарий: {carReaderError.Description}";
                    }
                }
            }
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            //dispatcherTimer?.
        }

        //private int GetButtonIndex(PaymentMethod paymentMethod)
        //{
        //    throw new NotImplementedException();
        //}

        DispatcherTimer dispatcherTimer = null;
    }
}
