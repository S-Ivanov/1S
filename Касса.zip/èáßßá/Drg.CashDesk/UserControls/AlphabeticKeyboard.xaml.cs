﻿using Drg.CashDesk.Commands;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для AlphabeticKeyboard.xaml
    /// </summary>
    public partial class AlphabeticKeyboard : UserControl, INotifyPropertyChanged
    {
        public AlphabeticKeyboard()
        {
            InitializeComponent();
        }

        void SetButtonsEnable(string symbols, bool enabled)
        {
            if (string.IsNullOrEmpty(symbols))
                return;

            // https://stackoverflow.com/questions/10279092/how-to-get-children-of-a-wpf-container-by-type
            foreach (var button in pane.Children.OfType<Button>().Where(b => symbols.Contains(b.Content.ToString())))
            {
                button.IsEnabled = enabled;
            }
        }

        /// <summary>
        /// Символы, которые необходимо отключить
        /// </summary>
        public string DisableSymbols
        {
            get => disableSymbols;
            set
            {
                if (disableSymbols != value)
                {
                    SetButtonsEnable(disableSymbols, true);
                    disableSymbols = value;
                    SetButtonsEnable(disableSymbols, false);
                }
            }
        }
        string disableSymbols;

        /// <summary>
        /// Текст, набранный на клавиатуре
        /// </summary>
        public string Text { get; private set; } = "";

        private void SymbolButton_Click(object sender, RoutedEventArgs e)
        {
            Text += (sender as Button).Content.ToString();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        public ICommand BackspaceCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    Text = Text.Substring(0, Text.Length - 1);
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
                },
                o => Text.Length > 0);
            }
        }

        /// <summary>
        /// Событие нажатия кнопки Ok
        /// </summary>
        public event EventHandler OkEvent;

        /// <summary>
        /// Событие нажатия кнопки Cancel
        /// </summary>
        public event EventHandler CancelEvent;

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: сделать кнопку Ok с закруглениями как у обычной кнопки
            OkEvent?.Invoke(this, EventArgs.Empty);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            CancelEvent?.Invoke(this, EventArgs.Empty);
        }
    }
}
