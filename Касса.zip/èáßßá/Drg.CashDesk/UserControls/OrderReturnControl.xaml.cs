﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderReturnControl : UserControl, INotifyPropertyChanged
    {
        public OrderReturnControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        public OrderReturn OrderReturn
        {
            get => orderReturn;
            set
            {
                if (orderReturn != value)
                {
                    if (orderReturn != null && orderReturn.AllItems != null)
                    {
                        orderReturn.AllItems.CollectionChanged -= AllItems_CollectionChanged;
                    }

                    orderReturn = value;

                    if (orderReturn != null && orderReturn.AllItems != null)
                    {
                        orderReturn.AllItems.CollectionChanged += AllItems_CollectionChanged;
                    }

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OrderReturn)));
                }
            }
        }
        OrderReturn orderReturn;

        private void AllItems_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OrderReturn)));
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void OrderItemDeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //if (Order.SelectedOrderItem == null)
            //    return;

            //if (MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            //{
            //    var orderItem = Order.SelectedOrderItem;
            //    var orderItemIndex = Order.Items.IndexOf(orderItem);
            //    Order.Items.Remove(orderItem);

            //    // сделать активной какую-то другую запись
            //    if (orderItemIndex < Order.Items.Count)
            //        Order.SelectedOrderItem = Order.Items[orderItemIndex];
            //    else if (Order.Items.Count == 0)
            //        Order.SelectedOrderItem = null;
            //    else
            //        Order.SelectedOrderItem = Order.Items.Last();

            //    SetButtonsEnabled();

            //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
            //}
        }

        private void OrderItemChangeCountButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(OrderReturn.ReturnOrders.Count(_ => _.IsSelected == true).ToString());

            //if (Order.SelectedOrderItem == null)
            //    return;

            //var orderItem = Order.SelectedOrderItem;

            //ChangeCount changeCount = new ChangeCount(orderItem.Count);

            //Window parentWindow = Window.GetWindow(this);

            //changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
            //changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2;

            //if (changeCount.ShowDialog() == true)
            //{
            //    orderItem.Count = changeCount.Count;
            //}
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            if (ReturnEvent != null && OrderReturn.AllItems.Where(_ => _.Order == null).Any())
            {
                if (MessageBox.Show("Отменить возврат заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    ReturnEvent(this, EventArgs.Empty);
                }
            }
        }

        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            //// свернуть заказ до оплаты
            //OrderCollapse();

            //var paymentAbilities = new PaymentAbilities
            //{
            //    Order = Order,
            //    Client = Order.Client
            //};

            //PaymentInfo paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
            //List<CashDeskLib.DataModel.Payment> noPayments = paymentInfo.Payments.Select(kvp => kvp.Key).ToList();
            //while (true)
            //{
            //    paymentInfo = DoPayment(paymentInfo);
            //    if (paymentInfo == null)
            //    {
            //        // досрочный выход по отмене
            //        break;
            //    }
            //    else
            //    {
            //        // обработать результат оплаты
            //        var cancelPayment = CashDeskLib.CashDesk.Instance.Pay(Order.Client.RawClient, Order.ToRawOrder(), paymentInfo.Payments, out noPayments);
            //        if (cancelPayment == CashDeskLib.DataModel.Payment.None && !noPayments.Any())
            //        {
            //            // успешная оплата
            //            NewOrder();
            //            break;
            //        }
            //        else
            //        {
            //            if (cancelPayment != CashDeskLib.DataModel.Payment.None)
            //            {
            //                paymentInfo.Payments.Remove(cancelPayment);
            //            }

            //            if (noPayments.Any())
            //            {
            //                // не все варианты оплаты удалось выполнить
            //                paymentAbilities.SetPayments(false, noPayments);
            //                paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
            //            }
            //        }
            //    }
            //}
        }

        //PaymentInfo DoPayment(PaymentInfo paymentInfo)
        //{
        //    PayWindow payWindow = new PayWindow();
        //    // TODO: исключить обращение к viewModel
        //    payWindow.viewModel.PaymentInfo = paymentInfo;
        //    return payWindow.ShowDialog() == true ? payWindow.viewModel.PaymentInfo : null;
        //}

        public event EventHandler ReturnEvent;

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            (checkBox.DataContext as OrderReturnListItem).IsSelected = checkBox.IsChecked == true;

            if (OrderReturn.ReturnOrders.All(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = true;
            }
            else if (OrderReturn.ReturnOrders.Any(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = null;
            }
            else
            {
                AllCheckBox.IsChecked = false;
            }
        }

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            OrderReturn.ReturnOrders.ForEach(order => order.IsSelected = (sender as CheckBox).IsChecked == true);
        }
    }
}
