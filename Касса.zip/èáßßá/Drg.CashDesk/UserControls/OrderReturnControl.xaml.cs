﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderReturnControl : UserControl, INotifyPropertyChanged
    {
        public OrderReturnControl()
        {
            InitializeComponent();

            DataContext = this;
        }


        public ICollectionView ItemsView { get; private set; }

        public OrderReturn OrderReturn
        {
            get => orderReturn;
            set
            {
                if (orderReturn != value)
                {
                    orderReturn = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OrderReturn)));

                    if (orderReturn != null)
                    {
                        ItemsView = CollectionViewSource.GetDefaultView(orderReturn.AllItems);
                        ItemsView.Filter = ItemsViewFilter;
                        ItemsView.CollectionChanged += ItemsView_CollectionChanged;
                        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ItemsView)));
                    }

                    FilterGrid.Visibility = (orderReturn == null || orderReturn.ReturnOrders.Count == 1) ? Visibility.Hidden : Visibility.Visible;
                }
            }
        }

        private void ItemsView_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
        }

        OrderReturn orderReturn;

        private bool ItemsViewFilter(object item)
        {
            OrderReturnItem orderReturnItem = item as OrderReturnItem;
            return OrderReturn.ReturnOrders.Where(_ => _.IsSelected && _.RawOrder == orderReturnItem.Order).Any();
        }

        /// <summary>
        /// Сумма возврата
        /// </summary>
        public decimal Total => ItemsView.Cast<OrderReturnItem>().Sum(_ => _.Sum);

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void OrderItemDeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //if (Order.SelectedOrderItem == null)
            //    return;

            //if (MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            //{
            //    var orderItem = Order.SelectedOrderItem;
            //    var orderItemIndex = Order.Items.IndexOf(orderItem);
            //    Order.Items.Remove(orderItem);

            //    // сделать активной какую-то другую запись
            //    if (orderItemIndex < Order.Items.Count)
            //        Order.SelectedOrderItem = Order.Items[orderItemIndex];
            //    else if (Order.Items.Count == 0)
            //        Order.SelectedOrderItem = null;
            //    else
            //        Order.SelectedOrderItem = Order.Items.Last();

            //    SetButtonsEnabled();

            //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
            //}
        }

        private void OrderItemChangeCountButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(OrderReturn.ReturnOrders.Count(_ => _.IsSelected == true).ToString());

            //if (Order.SelectedOrderItem == null)
            //    return;

            //var orderItem = Order.SelectedOrderItem;

            //ChangeCount changeCount = new ChangeCount(orderItem.Count);

            //Window parentWindow = Window.GetWindow(this);

            //changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
            //changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2;

            //if (changeCount.ShowDialog() == true)
            //{
            //    orderItem.Count = changeCount.Count;
            //}
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            if (ReturnEvent != null && OrderReturn.AllItems.Where(_ => _.Order == null).Any())
            {
                if (MessageBox.Show("Отменить возврат заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    ReturnEvent(this, EventArgs.Empty);
                }
            }
        }

        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            //// свернуть заказ до оплаты
            //OrderCollapse();

            //var paymentAbilities = new PaymentAbilities
            //{
            //    Order = Order,
            //    Client = Order.Client
            //};

            //PaymentInfo paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
            //List<CashDeskLib.DataModel.Payment> noPayments = paymentInfo.Payments.Select(kvp => kvp.Key).ToList();
            //while (true)
            //{
            //    paymentInfo = DoPayment(paymentInfo);
            //    if (paymentInfo == null)
            //    {
            //        // досрочный выход по отмене
            //        break;
            //    }
            //    else
            //    {
            //        // обработать результат оплаты
            //        var cancelPayment = CashDeskLib.CashDesk.Instance.Pay(Order.Client.RawClient, Order.ToRawOrder(), paymentInfo.Payments, out noPayments);
            //        if (cancelPayment == CashDeskLib.DataModel.Payment.None && !noPayments.Any())
            //        {
            //            // успешная оплата
            //            NewOrder();
            //            break;
            //        }
            //        else
            //        {
            //            if (cancelPayment != CashDeskLib.DataModel.Payment.None)
            //            {
            //                paymentInfo.Payments.Remove(cancelPayment);
            //            }

            //            if (noPayments.Any())
            //            {
            //                // не все варианты оплаты удалось выполнить
            //                paymentAbilities.SetPayments(false, noPayments);
            //                paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
            //            }
            //        }
            //    }
            //}
        }

        //PaymentInfo DoPayment(PaymentInfo paymentInfo)
        //{
        //    PayWindow payWindow = new PayWindow();
        //    // TODO: исключить обращение к viewModel
        //    payWindow.viewModel.PaymentInfo = paymentInfo;
        //    return payWindow.ShowDialog() == true ? payWindow.viewModel.PaymentInfo : null;
        //}

        public event EventHandler ReturnEvent;

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool allSelect = (sender as CheckBox).IsChecked == true;
            OrderReturn.ReturnOrders.ForEach(order => order.IsSelected = allSelect);
            OrderReturn.CanAddReturn = allSelect;
            ItemsView?.Refresh();
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                FilterDataGrid_ClickRow(row);
            }
        }

        void FilterDataGrid_ClickRow(DataGridRow row)
        {
            (row.Item as OrderReturnListItem).IsSelected = !(row.Item as OrderReturnListItem).IsSelected;

            if (OrderReturn.ReturnOrders.All(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = true;
            }
            else if (OrderReturn.ReturnOrders.Any(_ => _.IsSelected))
            {
                AllCheckBox.IsChecked = null;
            }
            else
            {
                AllCheckBox.IsChecked = false;
            }

            OrderReturn.CanAddReturn = OrderReturn.ReturnOrders.Any(_ => _.IsSelected && _.RawOrder == null);
            ItemsView?.Refresh();
        }

        /// <summary>
        /// Команда удаления выбранного элемента
        /// </summary>
        public ICommand DeleteItemCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                        if (MessageBox.Show("Удалить выделенную строку возврата?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                        {
                            OrderReturn.AllItems.Remove(ItemsView.CurrentItem as OrderReturnItem);
                        }
                    },
                    _ =>
                        ItemsView != null &&
                        ItemsView.CurrentItem != null &&
                        (ItemsView.CurrentItem as OrderReturnItem).Order == null
                    );
            }
        }

        /// <summary>
        /// Команда изменения количества у выбранного элемента
        /// </summary>
        public ICommand ChangeCountCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                    },
                    _ =>
                        ItemsView != null &&
                        ItemsView.CurrentItem != null &&
                        (ItemsView.CurrentItem as OrderReturnItem).Order == null
                    );
            }
        }

        /// <summary>
        /// Команда выполнения возврата
        /// </summary>
        public ICommand ReturnOrderCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                    },
                    _ =>
                        ItemsView != null &&
                        ItemsView.Cast<OrderReturnItem>().Any(order => order.Order == null)
                    );
            }
        }
    }
}
