﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuList : UserControl, INotifyPropertyChanged
    {
        #region Свойство зависимости Menu

        public static readonly DependencyProperty MenuProperty = DependencyProperty.Register("Menu", typeof(DataModel.Menu), typeof(MenuList));

        #endregion Свойство зависимости Menu

        #region Свойство зависимости SelectedMenuItemGroup

        public static readonly DependencyProperty SelectedMenuItemGroupProperty = 
            DependencyProperty.Register("SelectedMenuItemGroup", typeof(MenuItemGroup), typeof(MenuList), new PropertyMetadata(SelectedMenuItemGroupPropertyChanged));

        private static void SelectedMenuItemGroupPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var menuList = d as MenuList;
            menuList.SelectedMenuItemGroup = e.NewValue as DataModel.MenuItemGroup;
        }

        #endregion Свойство зависимости SelectedMenuItemGroup

        #region Свойство зависимости SelectedMenuItem

        public static readonly DependencyProperty SelectedMenuItemProperty = 
            DependencyProperty.Register("SelectedMenuItem", typeof(DataModel.MenuItem), typeof(MenuList), new PropertyMetadata(SelectedMenuItemPropertyChanged));

        private static void SelectedMenuItemPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var menuList = d as MenuList;
            menuList.SelectedMenuItem = e.NewValue as DataModel.MenuItem;
        }

        #endregion Свойство зависимости SelectedMenuItem

        /// <summary>
        /// Конструктор
        /// </summary>
        public MenuList()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            get => (DataModel.Menu)GetValue(MenuProperty);
            set => SetValue(MenuProperty, value);
        }

        /// <summary>
        /// Выбранная группа элементов меню
        /// </summary>
        public MenuItemGroup SelectedMenuItemGroup
        {
            get => (MenuItemGroup)GetValue(SelectedMenuItemGroupProperty);
            set
            {
                SetValue(SelectedMenuItemGroupProperty, value);

                SelectMenuItemCommand.Execute(null);

                if (Menu != null)
                {
                    foreach (var menuGroup in Menu.MenuGroups)
                    {
                        menuGroup.IsSelected = menuGroup == value;
                    }
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItemGroup)));
            }
        }

        /// <summary>
        /// Выбранный элемент меню
        /// </summary>
        public DataModel.MenuItem SelectedMenuItem
        {
            get => (DataModel.MenuItem)GetValue(SelectedMenuItemProperty);
            set
            {
                SetValue(SelectedMenuItemProperty, value);
                if (SelectedMenuItemGroup != null)
                {
                    foreach (var menuItem in SelectedMenuItemGroup.Items)
                    {
                        menuItem.IsSelected = menuItem == value;
                    }
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItem)));
            }
        }

        /// <summary>
        /// Команда выбора группы элементов меню
        /// </summary>
        public ICommand SelectMenuItemGroupCommand
        {
            get
            {
                return new RelayCommand<MenuItemGroup>(menuItemGroup =>
                {
                    SelectedMenuItemGroup = menuItemGroup;
                });
            }
        }

        /// <summary>
        /// Команда выбора элемента меню
        /// </summary>
        public ICommand SelectMenuItemCommand
        {
            get
            {
                return new RelayCommand<DataModel.MenuItem>(menuItem =>
                {
                    if (SelectedMenuItemGroup != null)
                    {
                        foreach (var item in SelectedMenuItemGroup.Items)
                        {
                            item.IsSelected = item == menuItem;
                        }

                        SelectedMenuItem = menuItem;
                    }
                });
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            SelectedMenuItemGroup = Menu?.MenuGroups.FirstOrDefault();
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
