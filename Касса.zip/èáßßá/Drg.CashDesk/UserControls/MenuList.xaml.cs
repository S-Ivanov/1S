﻿using Drg.CashDesk.DataModel;
using System;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuList : UserControl
    {
        public static readonly DependencyProperty MenuProperty =
            //DependencyProperty.Register("Menu", typeof(DataModel.Menu), typeof(UserIdentification), new PropertyMetadata(MenuPropertyChanged));
            DependencyProperty.Register("Menu", typeof(DataModel.Menu), typeof(UserIdentification));
        //DependencyProperty.Register(
        //    "Menu", 
        //    typeof(DataModel.Menu), 
        //    typeof(UserIdentification), 
        //    new FrameworkPropertyMetadata(
        //        null,
        //        FrameworkPropertyMetadataOptions.
        //        (MenuPropertyChanged));

        //private static void MenuPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) => (d as MenuList).viewModel.Menu = e.NewValue as DataModel.Menu;

        public MenuList()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            //get => viewModel.Menu;
            //set => viewModel.Menu = value;
            get => (DataModel.Menu)GetValue(MenuProperty);
            set => SetValue(MenuProperty, value);
        }

        /// <summary>
        /// Событие выбора элемента меню
        /// </summary>
        public event EventHandler<DataModelEventArgs<DataModel.MenuItem>> SelectMenuItem
        {
            add => viewModel.SelectMenuItem += value;
            remove => viewModel.SelectMenuItem -= value;
        }
    }
}
