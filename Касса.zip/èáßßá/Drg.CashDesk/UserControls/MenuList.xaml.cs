﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuList : UserControl, INotifyPropertyChanged
    {
        #region Свойство зависимости Menu

        public static readonly DependencyProperty MenuProperty = DependencyProperty.Register("Menu", typeof(DataModel.Menu), typeof(MenuList), new PropertyMetadata(MenuPropertyChanged));

        private static void MenuPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var menuList = d as MenuList;
            if (e.NewValue is DataModel.Menu menu && menu.MenuGroups.Count > 0)
            {
                menuList.SelectMenuItemGroup(menu.MenuGroups[0]);
            }
        }

        #endregion Свойство зависимости Menu

        #region Свойство зависимости SelectedMenuItemGroup

        public static readonly DependencyProperty SelectedMenuItemGroupProperty = DependencyProperty.Register("SelectedMenuItemGroup", typeof(MenuItemGroup), typeof(MenuList));

        #endregion Свойство зависимости SelectedMenuItemGroup

        #region Свойство зависимости SelectedMenuItem

        public static readonly DependencyProperty SelectedMenuItemProperty = DependencyProperty.Register("SelectedMenuItem", typeof(DataModel.MenuItem), typeof(MenuList));

        #endregion Свойство зависимости SelectedMenuItem

        /// <summary>
        /// Конструктор
        /// </summary>
        public MenuList()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            get => (DataModel.Menu)GetValue(MenuProperty);
            set => SetValue(MenuProperty, value);
        }

        /// <summary>
        /// Выбранная группа элементов меню
        /// </summary>
        public MenuItemGroup SelectedMenuItemGroup
        {
            get => (MenuItemGroup)GetValue(SelectedMenuItemGroupProperty);
            set => SetValue(SelectedMenuItemGroupProperty, value);
        }

        /// <summary>
        /// Выбранный элемент меню
        /// </summary>
        public DataModel.MenuItem SelectedMenuItem
        {
            get => (DataModel.MenuItem)GetValue(SelectedMenuItemProperty);
            set => SetValue(SelectedMenuItemProperty, value);
        }

        /// <summary>
        /// Команда выбора группы элементов меню
        /// </summary>
        public ICommand SelectMenuItemGroupCommand
        {
            get
            {
                return new RelayCommand<MenuItemGroup>(menuItemGroup =>
                {
                    SelectMenuItemGroup(menuItemGroup);
                });
            }
        }

        /// <summary>
        /// Команда выбора элемента меню
        /// </summary>
        public ICommand SelectMenuItemCommand
        {
            get
            {
                return new RelayCommand<DataModel.MenuItem>(menuItem =>
                {
                    if (SelectedMenuItemGroup != null)
                    {
                        foreach (var item in SelectedMenuItemGroup.Items)
                        {
                            item.IsSelected = item == menuItem;
                        }

                        SelectedMenuItem = menuItem;
                    }
                });
            }
        }

        /// <summary>
        /// Выбрать группу элементов меню
        /// </summary>
        /// <param name="menuItemGroup"></param>
        private void SelectMenuItemGroup(MenuItemGroup menuItemGroup)
        {
            SelectMenuItemCommand.Execute(null);

            foreach (var menuGroup in Menu.MenuGroups)
            {
                menuGroup.IsSelected = menuGroup == menuItemGroup;
            }

            SelectedMenuItemGroup = menuItemGroup;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItemGroup)));
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            var firstMenuItemGroup = Menu?.MenuGroups.FirstOrDefault();
            SelectMenuItemGroup(firstMenuItemGroup);
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
