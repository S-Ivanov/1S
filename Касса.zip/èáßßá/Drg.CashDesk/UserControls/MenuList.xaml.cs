﻿using Drg.CashDesk.DataModel;
using System;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuList : UserControl
    {
        public MenuList()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            get => viewModel.Menu;
            set => viewModel.Menu = value;
        }

        /// <summary>
        /// Событие выбора элемента меню
        /// </summary>
        public event EventHandler<DataModelEventArgs<DataModel.MenuItem>> SelectMenuItem
        {
            add => viewModel.SelectMenuItem += value;
            remove => viewModel.SelectMenuItem -= value;
        }
    }
}
