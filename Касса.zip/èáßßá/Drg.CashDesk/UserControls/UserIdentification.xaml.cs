﻿using Drg.CashDeskLib;
using Drg.Equipment.CardReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для UserIdentification.xaml
    /// </summary>
    public partial class UserIdentification : UserControl
    {
        public bool UsePass
        {
            get { return (bool)GetValue(UsePassProperty); }
            set { SetValue(UsePassProperty, value); }
        }

        public static readonly DependencyProperty UsePassProperty =
            DependencyProperty.Register("UsePass", typeof(bool), typeof(UserIdentification), new PropertyMetadata(true, UsePassChanged));

        private static void UsePassChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as UserIdentification;
            bool usePass = control.UsePass;
            control.lblUsePass.Visibility = usePass ? Visibility.Visible : Visibility.Collapsed;

            // выполняется только не в design mode
            // см. https://stackoverflow.com/questions/834283/is-there-a-way-to-check-if-wpf-is-currently-executing-in-design-mode-or-not
            // ответ 20
            if (Application.Current is App)
                control.UsePassChange(usePass);
        }

        void UsePassChange(bool usePass)
        {
            if (CashDeskLib.CashDesk.Instance.Devices.TryGetValue(Equipment.Device.CardReader, out DeviceInfo di) && di.Device is ICardReader cardReader)
            {
                if (usePass)
                    cardReader.DataEvent += CardReader_DataEvent;
                else
                    cardReader.DataEvent -= CardReader_DataEvent;
            }
        }

        private void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            MessageBox.Show(e.CardCode);
        }

        public bool CanExit
        {
            get { return (bool)GetValue(CanExitProperty); }
            set { SetValue(CanExitProperty, value); }
        }

        public static readonly DependencyProperty CanExitProperty =
            DependencyProperty.Register("CanExit", typeof(bool), typeof(UserIdentification), new PropertyMetadata(false, CanExitChanged));

        private static void CanExitChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as UserIdentification;
            control.btnExit.IsEnabled = control.CanExit;
        }

        public bool CanOk
        {
            get { return (bool)GetValue(CanOkProperty); }
            set { SetValue(CanOkProperty, value); }
        }

        public static readonly DependencyProperty CanOkProperty =
            DependencyProperty.Register("CanOk", typeof(bool), typeof(UserIdentification), new PropertyMetadata(false, CanOkChanged));

        private static void CanOkChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as UserIdentification;
            control.btnOk.IsEnabled = control.CanOk;
        }


        public static readonly RoutedEvent OkButtonClickEvent = 
            EventManager.RegisterRoutedEvent("OkButtonClick", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(UserIdentification));

        public event RoutedEventHandler OkButtonClick
        {
            add { AddHandler(OkButtonClickEvent, value); }
            remove { RemoveHandler(OkButtonClickEvent, value); }
        }

        void RaiseOkButtonClickEvent()
        {
            RoutedEventArgs newEventArgs = new RoutedEventArgs(UserIdentification.OkButtonClickEvent);
            RaiseEvent(newEventArgs);
        }

        public UserIdentification()
        {
            InitializeComponent();
        }

        private void DigitButton_Click(object sender, RoutedEventArgs e)
        {
            if (tbPassword.Text.Length < 10)
                tbPassword.Text += (sender as Button).Content.ToString();
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tbPassword.Text))
                tbPassword.Text = tbPassword.Text.Substring(0, tbPassword.Text.Length - 1);
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            tbPassword.Text = "";
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            RaiseOkButtonClickEvent();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            Window window = Window.GetWindow(this);
            if (window != null)
            {
                // подключить событие считывателя
                UsePassChange(UsePass);

                window.Closing += Window_Closing;
            }
        }

        void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            if (cashDesk != null && cashDesk.Devices.TryGetValue(Equipment.Device.CardReader, out DeviceInfo di) && di.Device is ICardReader cardReader)
                cardReader.DataEvent -= CardReader_DataEvent;
        }
    }
}
