﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuControl : UserControl, INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MenuControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        /// <summary>
        /// Управление меню
        /// </summary>
        public MenuManager MenuManager { get; set; }

        /// <summary>
        /// Меню
        /// </summary>
        public MenuExt Menu
        {
            get => menu;
            set
            {
                if (menu != value)
                {
                    menu = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
                }
            }
        }
        MenuExt menu;

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItemExt> Items
        {
            get => items;
            set
            {
                if (items != value)
                {
                    items = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
                }
            }
        }
        public ObservableCollection<MenuItemExt> items;

        public bool IsCurrentMenu
        {
            get => isCurrentMenu;
            set
            {
                if (isCurrentMenu != value)
                {
                    isCurrentMenu = value;
                    if (isCurrentMenu)
                        ServiceButton.Content = "Сервис";
                    else
                    {
                        ServiceButton.Content = "=>";
                        ServiceButton.IsEnabled = false;
                    }
                }
            }
        }
        bool isCurrentMenu = true;

        public bool IsServiceMode
        {
            get => isServiceMode;
            set
            {
                isServiceMode = value;
                if (IsCurrentMenu)
                {
                    ServiceButton.Content = isServiceMode ? "К работе" : "Сервис";
                    CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = isServiceMode ? Visibility.Visible : Visibility.Hidden;
                    if (IsServiceMode)
                    {
                        ClearItemsSelection();
                        ClearRootItemsSelection();
                        Items = null;
                    }
                }
            }
        }
        bool isServiceMode;

        public CashDeskLib.DataModel.MenuItemExt SelectedMenuItem => Items.FirstOrDefault(_ => _.IsSelected)?.RawItem as CashDeskLib.DataModel.MenuItemExt;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void RootItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (!selectedMenuItem.IsSelected)
            {
                ClearItemsSelection();
                ClearRootItemsSelection();
                selectedMenuItem.IsSelected = true;
            }

            Items = selectedMenuItem.Children;

            CopyMenuItemButton.IsEnabled = DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = false;
            if (!IsCurrentMenu)
                ServiceButton.IsEnabled = false;
        }

        private void ClearItemsSelection()
        {
            if (Items != null)
            {
                foreach (var menuItem in Items)
                {
                    menuItem.IsSelected = false;
                }
            }
        }

        private void ClearRootItemsSelection()
        {
            foreach (var menuItem in Menu.Items)
            {
                menuItem.IsSelected = false;
            }
        }

        private void ItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (selectedMenuItem.Children.Any())
                Items = selectedMenuItem.Children;
            else
            {
                foreach (var menuItem in Items)
                {
                    menuItem.IsSelected = false;
                }
                selectedMenuItem.IsSelected = true;

                if (IsServiceMode)
                {
                    if (IsCurrentMenu)
                    {
                        CopyMenuItemButton.IsEnabled = true;
                        DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = (selectedMenuItem.RawItem as CashDeskLib.DataModel.MenuItemExt)?.IsLocal ?? false;
                    }
                    else
                    {
                        ServiceButton.IsEnabled = true;
                    }
                }
                else
                    SelectMenuItemEvent?.Invoke(this, new CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt> { Data = selectedMenuItem });
            }
        }

        /// <summary>
        /// Событие выбора элемента меню
        /// </summary>
        public event EventHandler<CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt>> SelectMenuItemEvent;

        public event EventHandler ServiceEvent;

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceEvent?.Invoke(this, EventArgs.Empty);
        }

        private void CopyMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            // явно вызвать калькулятор для уточнения количества
            CashDeskLib.DataModel.MenuItemExt selectedItem = SelectedMenuItem;
            decimal? newCount = ChangeCount(selectedItem.Count);

            if (newCount != null)
            {
                AddMenuItem(selectedItem, newCount);
            }
        }

        public void AddMenuItem(CashDeskLib.DataModel.MenuItemExt menuItem, decimal? newCount = null)
        {
            CashDeskLib.DataModel.MenuItemExt newRawMenuItem = (CashDeskLib.DataModel.MenuItemExt)menuItem.Clone();
            newRawMenuItem.IdMenuItem = Guid.NewGuid();
            newRawMenuItem.IsLocal = true;
            if (newCount != null)
                newRawMenuItem.Count = newCount.Value;

            // записать копию элемента меню в базу
            CashDeskLib.CashDesk.Instance.AddMenuItemExt(Menu.RawMenu.Id, newRawMenuItem);
            // HACK: чтобы не усложнять код, полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
            ReloadMenu(newRawMenuItem.IdMenuItem);

            // сделать выбранную группу видимой
            MakeVisibleSelectedItem(menuRootControl, Menu.Items);

            // сделать выбранный элемент видимым
            var selectedItem = MakeVisibleSelectedItem(menuItemsItemsControl, Items);
            if (selectedItem != null)
            {
                CopyMenuItemButton.IsEnabled = DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = true;
            }
        }

        /// <summary>
        /// Сделать выбранный элемент видимым
        /// </summary>
        /// <returns>выбранный элемент</returns>
        /// <remarks>https://social.msdn.microsoft.com/Forums/vstudio/en-US/e49d3442-9bdd-425f-824a-fc373886bc66/scroll-to-a-specific-item-in-an-itemscontrol?forum=wpf</remarks>
        MenuItemExt MakeVisibleSelectedItem(ItemsControl itemsControl, ObservableCollection<MenuItemExt> items)
        {
            if (items != null)
            {
                var selectedItem = items.FirstOrDefault(_ => _.IsSelected);
                if (selectedItem != null)
                {
                    int selectedItemIndex = items.IndexOf(selectedItem);
                    ContentPresenter itemcontainer = itemsControl.ItemContainerGenerator.ContainerFromIndex(selectedItemIndex) as ContentPresenter;
                    itemcontainer.BringIntoView();

                    return selectedItem;
                }
            }

            return null;
        }

        decimal? ChangeCount(decimal count)
        {
            ChangeCount changeCount = new ChangeCount(count);

            Window parentWindow = Window.GetWindow(this);

            changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
            changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2 - changeCount.Width;

            return changeCount.ShowDialog() == true ? changeCount.Count : (decimal?)null;
        }

        private void ReloadMenu(Guid idMenuItem)
        {
            Menu = new MenuExt(CashDeskLib.CashDesk.Instance.LoadMenusExt(DateTime.Today, 1).FirstOrDefault());

            // найти список элементов меню, в котором находится idMenuItem
            Items = FindChildItems(Menu.Items, idMenuItem);
            if (Items != null)
            {
                // установить активным необходимый элемент
                var item = Items.FirstOrDefault(_ => _.RawItem is CashDeskLib.DataModel.MenuItemExt && (_.RawItem as CashDeskLib.DataModel.MenuItemExt).IdMenuItem == idMenuItem);
                if (item != null)
                    item.IsSelected = true;

                // установить активной соответствующую корневую группу
                if (Items.Count > 0)
                {
                    var parent = Items[0].RawItem.Parent;
                    while (parent.Parent != null)
                    {
                        parent = parent.Parent;
                    }

                    var selectedRoot = Menu.Items.FirstOrDefault(_ => _.RawItem.IdNomenclature == parent.IdNomenclature);
                    if (selectedRoot != null)
                        selectedRoot.IsSelected = true;
                }
            }
        }

        ObservableCollection<MenuItemExt> FindChildItems(ObservableCollection<MenuItemExt> items, Guid idMenuItem)
        {
            foreach (var item in items)
            {
                if (item.RawItem is CashDeskLib.DataModel.MenuItemExt menuItem && menuItem.IdMenuItem == idMenuItem)
                {
                    return items;
                }
                else
                {
                    var children = FindChildItems(item.Children, idMenuItem);
                    if (children != null)
                        return children;
                }
            }
            return null;
        }

        private void DeleteMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Удалить выделенный элемент меню?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.Yes)
            {
                MenuItemExt selectedItem = Items.First(_ => _.IsSelected);
                CashDeskLib.CashDesk.Instance.DeleteMenuItemExt(selectedItem.RawItem as CashDeskLib.DataModel.MenuItemExt);
                Items.Remove(selectedItem);

                CopyMenuItemButton.IsEnabled = DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = false;
            }
        }

        private void CountMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            // явно вызвать калькулятор для уточнения количества
            CashDeskLib.DataModel.MenuItemExt selectedItem = SelectedMenuItem;
            decimal? newCount = ChangeCount(selectedItem.Count);

            if (newCount != null && newCount.Value != selectedItem.Count)
            {
                CashDeskLib.CashDesk.Instance.ChangeMenuItemCountExt(selectedItem, newCount.Value);

                // HACK: чтобы не усложнять код перемещением записи с новым количеством, 
                // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
                ReloadMenu(selectedItem.IdMenuItem);

                CopyMenuItemButton.IsEnabled = DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = true;
            }
        }
    }
}
