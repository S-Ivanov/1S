﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuControl : UserControl, INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MenuControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        /// <summary>
        /// Управление меню
        /// </summary>
        public MenuManager MenuManager { get; set; }

        /// <summary>
        /// Меню
        /// </summary>
        public MenuExt Menu
        {
            get => menu;
            set
            {
                if (menu != value)
                {
                    menu = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
                }
            }
        }
        MenuExt menu;

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItemExt> Items
        {
            get => items;
            set
            {
                if (items != value)
                {
                    items = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
                }
            }
        }
        public ObservableCollection<MenuItemExt> items;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void RootItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (!selectedMenuItem.IsSelected)
            {
                foreach(var menuItem in Menu.Items)
                {
                    menuItem.IsSelected = false;
                }
                selectedMenuItem.IsSelected = true;
            }

            Items = selectedMenuItem.Children;
        }

        private void ItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (selectedMenuItem.Children.Any())
                Items = selectedMenuItem.Children;
            else
            {
                foreach (var menuItem in Items)
                {
                    menuItem.IsSelected = false;
                }
                selectedMenuItem.IsSelected = true;
                SelectMenuItemEvent?.Invoke(this, new CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt> { Data = selectedMenuItem });
            }
        }

        /// <summary>
        /// Событие выбора элемента меню
        /// </summary>
        public event EventHandler<CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt>> SelectMenuItemEvent;
    }
}
