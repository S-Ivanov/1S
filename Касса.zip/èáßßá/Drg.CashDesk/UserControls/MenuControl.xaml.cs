﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuList.xaml
    /// </summary>
    public partial class MenuControl : UserControl, INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MenuControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        /// <summary>
        /// Управление меню
        /// </summary>
        public MenuManager MenuManager { get; set; }

        /// <summary>
        /// Меню
        /// </summary>
        public MenuExt Menu
        {
            get => menu;
            set
            {
                if (menu != value)
                {
                    menu = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
                }
            }
        }
        MenuExt menu;

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItemExt> Items
        {
            get => items;
            set
            {
                if (items != value)
                {
                    items = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
                }
            }
        }
        public ObservableCollection<MenuItemExt> items;

        public bool IsCurrentMenu
        {
            get => isCurrentMenu;
            set
            {
                if (isCurrentMenu != value)
                {
                    isCurrentMenu = value;
                    if (isCurrentMenu)
                        ServiceButton.Content = "Сервис";
                    else
                    {
                        ServiceButton.Content = "=>";
                        ServiceButton.IsEnabled = false;
                    }
                }
            }
        }
        bool isCurrentMenu = true;

        public bool IsServiceMode
        {
            get => isServiceMode;
            set
            {
                isServiceMode = value;
                if (IsCurrentMenu)
                {
                    ServiceButton.Content = isServiceMode ? "К работе" : "Сервис";
                    CopyMenuItemButton.Visibility = DeleteMenuItemButton.Visibility = CountMenuItemButton.Visibility = isServiceMode ? Visibility.Visible : Visibility.Hidden;
                    if (IsServiceMode)
                    {
                        ClearItemsSelection();
                        ClearRootItemsSelection();
                        Items = null;
                    }
                }
            }
        }
        bool isServiceMode;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void RootItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (!selectedMenuItem.IsSelected)
            {
                ClearItemsSelection();
                ClearRootItemsSelection();
                selectedMenuItem.IsSelected = true;
            }

            Items = selectedMenuItem.Children;

            CopyMenuItemButton.IsEnabled = DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = false;
            if (!IsCurrentMenu)
                ServiceButton.IsEnabled = false;
        }

        private void ClearItemsSelection()
        {
            if (Items != null)
            {
                foreach (var menuItem in Items)
                {
                    menuItem.IsSelected = false;
                }
            }
        }

        private void ClearRootItemsSelection()
        {
            foreach (var menuItem in Menu.Items)
            {
                menuItem.IsSelected = false;
            }
        }

        private void ItemButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var selectedMenuItem = button.DataContext as MenuItemExt;
            if (selectedMenuItem.Children.Any())
                Items = selectedMenuItem.Children;
            else
            {
                foreach (var menuItem in Items)
                {
                    menuItem.IsSelected = false;
                }
                selectedMenuItem.IsSelected = true;

                if (IsServiceMode)
                {
                    if (IsCurrentMenu)
                    {
                        CopyMenuItemButton.IsEnabled = true;
                        DeleteMenuItemButton.IsEnabled = CountMenuItemButton.IsEnabled = (selectedMenuItem.RawItem as CashDeskLib.DataModel.MenuItemExt)?.IsLocal ?? false;
                    }
                    else
                    {
                        ServiceButton.IsEnabled = true;
                    }
                }
                else
                    SelectMenuItemEvent?.Invoke(this, new CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt> { Data = selectedMenuItem });
            }
        }

        /// <summary>
        /// Событие выбора элемента меню
        /// </summary>
        public event EventHandler<CashDeskLib.DataModel.DataModelEventArgs<MenuItemExt>> SelectMenuItemEvent;

        public event EventHandler ServiceEvent;

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceEvent?.Invoke(this, EventArgs.Empty);
        }

        private void CopyMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: явно вызвать калькулятор для уточнения количества
            if (ChangeCountEvent != null)
            {
                MenuItemExt selectedItem = Items.First(_ => _.IsSelected);
                var eventArgs = new ChangeCountEventArgs { Type = typeof(MenuItemExt), Value = (selectedItem.RawItem as CashDeskLib.DataModel.MenuItemExt).Count };
                ChangeCountEvent(this, eventArgs);
                if (!eventArgs.Cancel)
                {
                    CashDeskLib.DataModel.MenuItemExt newRawMenuItem = (CashDeskLib.DataModel.MenuItemExt)(selectedItem.RawItem as CashDeskLib.DataModel.MenuItemExt).Clone();
                    newRawMenuItem.IdMenuItem = Guid.NewGuid();
                    newRawMenuItem.Count = eventArgs.Value;
                    newRawMenuItem.IsLocal = true;

                    // записать копию элемента меню в базу
                    if (CashDeskLib.CashDesk.Instance.AddMenuItemExt(Menu.RawMenu.Id, newRawMenuItem))
                    {
                        MenuItemExt selectedRoot = Menu.Items.First(_ => _.IsSelected);
                        // HACK: чтобы не усложнять код поиском места для записи с новым количеством, 
                        // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
                        ReloadMenu(selectedRoot.RawItem.IdNomenclature, (selectedItem.RawItem as CashDeskLib.DataModel.MenuItemExt).IdMenuItem);
                    }
                }
            }

        }

        private void ReloadMenu(string rootIdNomenclature, Guid idMenuItem)
        {
            Menu = new MenuExt(CashDeskLib.CashDesk.Instance.LoadMenusExt(DateTime.Today, 1).FirstOrDefault());
            var selectedRoot = Menu.Items.FirstOrDefault(_ => _.RawItem.IdNomenclature == rootIdNomenclature);
            if (selectedRoot != null)
                selectedRoot.IsSelected = true;

            // найти список элементов меню, в котором находится idMenuItem
            Items = FindChildItems(Menu.Items, idMenuItem);
            if (Items != null)
            {
                var item = Items.First(_ => _.RawItem is CashDeskLib.DataModel.MenuItemExt && (_.RawItem as CashDeskLib.DataModel.MenuItemExt).IdMenuItem == idMenuItem);
                item.IsSelected = true;
            }
        }

        ObservableCollection<MenuItemExt> FindChildItems(ObservableCollection<MenuItemExt> items, Guid idMenuItem)
        {
            foreach (var item in items)
            {
                if (item.RawItem is CashDeskLib.DataModel.MenuItemExt menuItem && menuItem.IdMenuItem == idMenuItem)
                {
                    return items;
                }
                else
                {
                    var children = FindChildItems(item.Children, idMenuItem);
                    if (children != null)
                        return children;
                }
            }
            return null;
        }

        public event EventHandler<ChangeCountEventArgs> ChangeCountEvent;
    }
}
