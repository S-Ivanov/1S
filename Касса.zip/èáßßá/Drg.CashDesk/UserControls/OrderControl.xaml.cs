﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderControl : UserControl, INotifyPropertyChanged
    {
        public OrderControl()
        {
            InitializeComponent();
        }

        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    DataContext = order = value;
                    SetZpLppVisibility();
                }
            }
        }
        Order order;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        private void Photo_Click(object sender, RoutedEventArgs e)
        {
            SelectClientWindow selectClientWindow = new SelectClientWindow();
            if (selectClientWindow.ShowDialog() == true)
            {
                SetOrderClient(new DataModel.Client(selectClientWindow.viewModel.SelectedClient.RawClient));
            }
        }

        public void SetOrderClient(Client client)
        {
            Order.Client = client;
            SetZpLppVisibility();
        }

        private void SetZpLppVisibility()
        {
            ZpLabel.Visibility = ZpValue.Visibility = Order.Client.HasZP ? Visibility.Visible : Visibility.Collapsed;
            LppLabel.Visibility = LppValue1.Visibility = LppValue2.Visibility = LppValue3.Visibility = LppValue4.Visibility = Order.Client.HasLPP ? Visibility.Visible : Visibility.Collapsed;
        }

        private void NewOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Удалить имеющиеся строки и создать новый заказ?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                NewOrder();
            }
        }

        private void NewOrder()
        {
            Order = new Order();
            SetZpLppVisibility();
            SetButtonsEnabled();
        }

        /// <summary>
        /// Добавление элемента заказа
        /// </summary>
        /// <param name="menuItem"></param>
        public void AddOrderItem(DataModel.MenuItem menuItem)
        {
            if (menuItem == null)
                return;

            var newOrderItem = new DataModel.OrderItem(menuItem, Order.Items.Count + 1);
            Order.Items.Add(newOrderItem);
            Order.SelectedOrderItem = newOrderItem;

            SetButtonsEnabled();

            //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
        }

        private void SetButtonsEnabled()
        {
            PayButton.IsEnabled = Order.Items.Any();
            OrderItemDeleteButton.IsEnabled = OrderItemChangeCountButton.IsEnabled = Order.SelectedOrderItem != null;
            OrderCollapseButton.IsEnabled = Order.SelectedOrderItem != null && Order.Items.GroupBy(orderItem => orderItem.MenuItem.RawMenuItem.ProductId).Any(g => g.Count() > 1);
        }

        private void OrderItemDeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (Order.SelectedOrderItem == null)
                return;

            if (MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                var orderItem = Order.SelectedOrderItem;
                var orderItemIndex = Order.Items.IndexOf(orderItem);
                Order.Items.Remove(orderItem);

                // сделать активной какую-то другую запись
                if (orderItemIndex < Order.Items.Count)
                    Order.SelectedOrderItem = Order.Items[orderItemIndex];
                else if (Order.Items.Count == 0)
                    Order.SelectedOrderItem = null;
                else
                    Order.SelectedOrderItem = Order.Items.Last();

                SetButtonsEnabled();

                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
            }
        }

        private void OrderItemChangeCountButton_Click(object sender, RoutedEventArgs e)
        {
            if (Order.SelectedOrderItem == null)
                return;

            var orderItem = Order.SelectedOrderItem;

            ChangeCount changeCount = new ChangeCount(orderItem.Count);

            Window parentWindow = Window.GetWindow(this);

            changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
            changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2;

            if (changeCount.ShowDialog() == true)
            {
                orderItem.Count = changeCount.Count;
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                Order.RecalcTotal();
            }
        }

        private void OrderCollapseButton_Click(object sender, RoutedEventArgs e)
        {
            OrderCollapse();
        }

        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            // свернуть заказ до оплаты
            OrderCollapse();

            var paymentAbilities = new PaymentAbilities
            {
                Order = Order,
                Client = Order.Client
            };

            PaymentInfo paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
            List<CashDeskLib.DataModel.Payment> noPayments = paymentInfo.Payments.Select(kvp => kvp.Key).ToList();
            while (true)
            {
                paymentInfo = DoPayment(paymentInfo);
                if (paymentInfo == null)
                {
                    // досрочный выход по отмене
                    break;
                }
                else
                {
                    // обработать результат оплаты
                    var cancelPayment = CashDeskLib.CashDesk.Instance.Pay(Order.Client.RawClient, Order.ToRawOrder(), paymentInfo.Payments, out noPayments);
                    if (cancelPayment == CashDeskLib.DataModel.Payment.None && !noPayments.Any())
                    {
                        // успешная оплата
                        NewOrder();
                        break;
                    }
                    else
                    {
                        if (cancelPayment != CashDeskLib.DataModel.Payment.None)
                        {
                            paymentInfo.Payments.Remove(cancelPayment);
                        }

                        if (noPayments.Any())
                        {
                            // не все варианты оплаты удалось выполнить
                            paymentAbilities.SetPayments(false, noPayments);
                            paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);
                        }
                    }
                }
            }
        }

        PaymentInfo DoPayment(PaymentInfo paymentInfo)
        {
            PayWindow payWindow = new PayWindow();
            // TODO: исключить обращение к viewModel
            payWindow.viewModel.PaymentInfo = paymentInfo;
            return payWindow.ShowDialog() == true ? payWindow.viewModel.PaymentInfo : null;
        }

        private void OrderCollapse()
        {
            var productId = Order.SelectedOrderItem.MenuItem.RawMenuItem.ProductId;
            Order.Collapse();
            Order.SelectedOrderItem = Order.Items.First(item => item.MenuItem.RawMenuItem.ProductId == productId);
        }
    }
}
