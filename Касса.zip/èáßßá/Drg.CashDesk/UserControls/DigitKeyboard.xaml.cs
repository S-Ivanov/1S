﻿using Drg.CashDesk.DataModel;
using System;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для DigitKeyboard.xaml
    /// </summary>
    public partial class DigitKeyboard : UserControl
    {
        public DigitKeyboard()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DigitButtonClick?.Invoke(this, new DataModelEventArgs<string> { Data = (sender as Button).Content.ToString() });
        }

        public event EventHandler<DataModelEventArgs<string>> DigitButtonClick;
    }
}
