﻿using Drg.CashDeskLib.DataModel;
using System.Collections.Generic;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для ReturnWholeOrderDialog.xaml
    /// </summary>
    public partial class ReturnWholeOrderDialog : Window
    {
        public ReturnWholeOrderDialog(List<OrderPaymentItem> orderPaymentItems)
        {
            InitializeComponent();

            OrderPaymentItems = orderPaymentItems;
            DataContext = this;
        }

        public List<OrderPaymentItem> OrderPaymentItems { get; private set; }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
    }
}
