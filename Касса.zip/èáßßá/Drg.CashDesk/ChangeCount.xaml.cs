﻿using System.Globalization;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для ChangeCount.xaml
    /// </summary>
    public partial class ChangeCount : Window
    {
        const int NUMBER_CHARS_MAX_COUNT = 6;
        private bool isStarted;

        public ChangeCount(decimal count)
        {
            InitializeComponent();

            Count = count;
            textBox.Text = count.ToString();
            isStarted = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModel.DataModelEventArgs<string> e)
        {
            if (isStarted) Clear();

            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += e.Data;
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (isStarted) Clear();

            if (textBox.Text.Length > 0)
                textBox.Text = textBox.Text.Substring(0, textBox.Text.Length - 1);
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            textBox.Text = "";
            isStarted = false;
        }

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {
            if (isStarted) Clear();

            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += "0";
        }

        private void ZeroZeroButton_Click(object sender, RoutedEventArgs e)
        {
            if (isStarted) Clear();

            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT - 1)
                textBox.Text += "00";
            else if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
                textBox.Text += "0";
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            if (isStarted) Clear();

            if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT && !textBox.Text.Contains(","))
                textBox.Text += ",";
        }

        public decimal Count { get; private set; }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // заблокировать ввод 0
            if (decimal.TryParse(textBox.Text, System.Globalization.NumberStyles.Number, CultureInfo.GetCultureInfo("ru-RU"), out decimal count) && count > 0)
            {
                Count = count;
                DialogResult = true;
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void HalfButton_Click(object sender, RoutedEventArgs e)
        {
            Count = 0.5M;
            DialogResult = true;
            this.Close();
        }
    }
}
