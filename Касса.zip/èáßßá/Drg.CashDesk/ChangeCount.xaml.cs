﻿using Drg.CashDesk.DataModel;
using Drg.CashDesk.Dialogs;
using Drg.CashDeskLib.DataModel;
using System.Globalization;
using System.Linq;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для ChangeCount.xaml
    /// </summary>
    public partial class ChangeCount : Window
    {
        //const int NUMBER_CHARS_MAX_COUNT = 8;
        //private bool isStarted;

        public ChangeCount(decimal count, decimal limit = 0)
        {
            InitializeComponent();

            digitizer = new InputDigitizer(limit: limit);

            //Count = count;
            textBox.Text = count.ToString();
            //isStarted = true;

            this.limit = limit;
            if (limit != 0)
            {
                this.Title = $"Лимит {limit:N3}";
            }

        }

        public decimal Count { get; private set; }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModelEventArgs<string> e)
        {
            //if (isStarted) Clear();

            //if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
            //    textBox.Text += e.Data;

            digitizer.AddSymbols(e.Data);
            Count = digitizer.Value;
            textBox.Text = digitizer.ValueString;
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            //if (isStarted) Clear();

            //if (textBox.Text.Length > 0)
            //    textBox.Text = textBox.Text.Substring(0, textBox.Text.Length - 1);

            digitizer.BackSpace();
            Count = digitizer.Value;
            textBox.Text = digitizer.ValueString;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            //Clear();

            digitizer.Clear();
            Count = digitizer.Value;
            textBox.Text = digitizer.ValueString;
        }

        //private void Clear()
        //{
        //    textBox.Text = "";
        //    isStarted = false;
        //}

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {
            //if (isStarted) Clear();

            //if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
            //    textBox.Text += "0";

            digitizer.AddSymbols("0");
            Count = digitizer.Value;
            textBox.Text = digitizer.ValueString;
        }

        private void ZeroZeroButton_Click(object sender, RoutedEventArgs e)
        {
            //if (isStarted) Clear();

            //if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT - 1)
            //    textBox.Text += "00";
            //else if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT)
            //    textBox.Text += "0";

            digitizer.AddSymbols("00");
            Count = digitizer.Value;
            textBox.Text = digitizer.ValueString;
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            //if (isStarted) Clear();

            //if (textBox.Text.Length < NUMBER_CHARS_MAX_COUNT && !textBox.Text.Contains(","))
            //    textBox.Text += ",";

            digitizer.AddSymbols(".");
            textBox.Text = digitizer.ValueString;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // заблокировать ввод 0
            if (decimal.TryParse(textBox.Text, System.Globalization.NumberStyles.Number, CultureInfo.GetCultureInfo("ru-RU"), out decimal count) && count > 0)
            {
                if (limit != 0 && count > limit)
                {
                    //MessageBox.Show("Превышен заданный лимит количества.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    WpfMessageBox.Show("Предупреждение", "Превышен заданный лимит количества.", MessageBoxButton.OK, Dialogs.MessageBoxImage.Warning);
                }
                else
                {
                    Count = count;
                    DialogResult = true;
                    this.Close();
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void HalfButton_Click(object sender, RoutedEventArgs e)
        {
            Count = 0.5M;
            DialogResult = true;
            this.Close();
        }

        InputDigitizer digitizer;

        decimal limit;
    }
}
