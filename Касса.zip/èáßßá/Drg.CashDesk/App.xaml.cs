﻿using Drg.CashDeskLib;
using Drg.CashDeskLib.Configuration;
using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Timers;
using System.Windows;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        Timer exchangeDataTimer;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var config = (CashDeskConfiguration)ConfigurationManager.GetSection("CashDeskConfiguration");
            CashDeskLib.CashDesk cashDesk = CashDeskLib.CashDesk.Create(config);
            cashDesk.CashPaymentEvent += CashDesk_CashPaymentEvent;

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            checkEquipmentTimer = new DispatcherTimer();
            checkEquipmentTimer.Tick += new EventHandler(CheckEquipmentTimer_Tick);
            checkEquipmentTimer.Interval = new TimeSpan(0, 0, 0, 0, config.EquipmentCheckPeriod);
            checkEquipmentTimer.Start();

            exchangeDataTimer = cashDesk.Configuration.UseFrontService ? new Timer(config.FrontServiceExchangePeriod * 1000) : null;
            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Elapsed += ExchangeDataTimer_Elapsed;
                exchangeDataTimer.AutoReset = true;
                exchangeDataTimer.Start();
            }

            StartupWindow startupWindow = new StartupWindow();
            startupWindow.ShowDialog();

            if (cashDesk.Operator != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
        }

        private void CheckEquipmentTimer_Tick(object sender, EventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            cashDesk.CheckEquipment();
            CheckEquipmentEvent?.Invoke(this, EventArgs.Empty);

            if (!deviceErrorWindowVisible)
            {
                foreach (var kvp in cashDesk.Devices)
                {
                    if (kvp.Value.LastError == DeviceError.NoError)
                    {
                        var confirmedErrors = confirmedDeviceErrors.Where(_ => _.Item1 == kvp.Value);
                        foreach (var error in confirmedErrors)
                        {
                            confirmedDeviceErrors.Remove(error);
                        }
                    }
                    else if (kvp.Value.LastError != DeviceError.NoError && 
                        kvp.Value.LastError.IsUserError && 
                        !confirmedDeviceErrors.Contains(new Tuple<IDevice, int>(kvp.Value, kvp.Value.LastError.ErrorCode)))
                    {
                        deviceErrorWindowVisible = true;

                        // вывести сообщение пользователю об ошибке оборудования
                        DeviceErrorWindow deviceErrorWindow = new DeviceErrorWindow(kvp.Value, kvp.Value.LastError);
                        deviceErrorWindow.ShowDialog();

                        if (deviceErrorWindow.DeviceError != DeviceError.NoError)
                        {
                            confirmedDeviceErrors.Add(new Tuple<IDevice, int>(deviceErrorWindow.Device, deviceErrorWindow.DeviceError.ErrorCode));
                        }

                        deviceErrorWindowVisible = false;
                    }
                }
            }
        }

        bool deviceErrorWindowVisible = false;

        // хэшсет для хранения подтвержденных пользователем ошибок устройств:
        //  - устройство
        //  - код ошибки
        HashSet<Tuple<IDevice, int>> confirmedDeviceErrors = new HashSet<Tuple<IDevice, int>>();


        DispatcherTimer checkEquipmentTimer = null;

        /// <summary>
        /// Событие после проверки оборудования
        /// </summary>
        public event EventHandler CheckEquipmentEvent;

        //private void CashDesk_DeviceErrorEvent(object sender, CashDeskLib.DataModel.DataModelEventArgs<Equipment.DeviceError> e)
        //{
        //    // вывести сообщение пользователю об ошибке оборудования
        //    DeviceErrorWindow deviceErrorWindow = new DeviceErrorWindow(sender as IDevice, e.Data);
        //    deviceErrorWindow.ShowDialog();
        //}

        protected override void OnExit(ExitEventArgs e)
        {
            checkEquipmentTimer?.Stop();

            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Stop();
                exchangeDataTimer.Dispose();
            }

            base.OnExit(e);
        }

        private void ExchangeDataTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.FrontDataExchange();
            CashDeskLib.CashDesk.Instance.LoadClients();
        }

        private void CashDesk_CashPaymentEvent(object sender, CashDeskLib.DataModel.CashPaymentEventArgs e)
        {
            CalcSurrenderWindow calcSurrenderWindow = new CalcSurrenderWindow
            {
                Sum = e.Sum
            };
            e.Cancel = calcSurrenderWindow.ShowDialog() != true;
        }
    }
}
