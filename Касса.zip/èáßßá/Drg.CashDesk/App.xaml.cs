﻿using Drg.CashDeskLib;
using Drg.CashDeskLib.Configuration;
using Drg.Equipment;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Timers;
using System.Windows;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        Timer exchangeDataTimer;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var config = (CashDeskConfiguration)ConfigurationManager.GetSection("CashDeskConfiguration");
            CashDeskLib.CashDesk cashDesk = CashDeskLib.CashDesk.Create(config);
            cashDesk.CashPaymentEvent += CashDesk_CashPaymentEvent;
            // обработать ошибку, требующую участия пользователя
            cashDesk.DeviceErrorEvent += CashDesk_DeviceErrorEvent;

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            checkEquipmentTimer = new DispatcherTimer();
            checkEquipmentTimer.Tick += new EventHandler(CheckEquipmentTimer_Tick);
            checkEquipmentTimer.Interval = new TimeSpan(0, 0, 0, 0, config.EquipmentCheckPeriod);
            checkEquipmentTimer.Start();

            exchangeDataTimer = cashDesk.Configuration.UseFrontService ? new Timer(config.FrontServiceExchangePeriod * 1000) : null;
            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Elapsed += ExchangeDataTimer_Elapsed;
                exchangeDataTimer.AutoReset = true;
                exchangeDataTimer.Start();
            }

            StartupWindow startupWindow = new StartupWindow();
            startupWindow.ShowDialog();

            if (cashDesk.Operator != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
        }

        private void CheckEquipmentTimer_Tick(object sender, EventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            cashDesk.CheckEquipment();
            CheckEquipmentEvent?.Invoke(this, EventArgs.Empty);
        }

        DispatcherTimer checkEquipmentTimer = null;

        public event EventHandler CheckEquipmentEvent;

        private void CashDesk_DeviceErrorEvent(object sender, CashDeskLib.DataModel.DataModelEventArgs<Equipment.DeviceError> e)
        {
            // вывести сообщение пользователю об ошибке оборудования
            DeviceErrorWindow deviceErrorWindow = new DeviceErrorWindow(sender as IDevice, e.Data);
            deviceErrorWindow.ShowDialog();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            checkEquipmentTimer?.Stop();

            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Stop();
                exchangeDataTimer.Dispose();
            }

            base.OnExit(e);
        }

        private void ExchangeDataTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.FrontDataExchange();
            CashDeskLib.CashDesk.Instance.LoadClients();
        }

        private void CashDesk_CashPaymentEvent(object sender, CashDeskLib.DataModel.CashPaymentEventArgs e)
        {
            CalcSurrenderWindow calcSurrenderWindow = new CalcSurrenderWindow
            {
                Sum = e.Sum
            };
            e.Cancel = calcSurrenderWindow.ShowDialog() != true;
        }
    }
}
