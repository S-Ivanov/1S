﻿using Drg.CashDeskLib;
using Drg.CashDeskLib.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Timers;
using System.Windows;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        Timer exchangeDataTimer;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var config = (CashDeskConfiguration)ConfigurationManager.GetSection("CashDeskConfiguration");
            CashDeskLib.CashDesk cashDesk = CashDeskLib.CashDesk.Create(config);
            cashDesk.CashPaymentEvent += CashDesk_CashPaymentEvent;

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            exchangeDataTimer = cashDesk.Configuration.UseFrontService ? new Timer(cashDesk.Configuration.FrontServiceExchangePeriod * 1000) : null;
            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Elapsed += ExchangeDataTimer_Elapsed;
                exchangeDataTimer.AutoReset = true;
                exchangeDataTimer.Start();
            }

            StartupWindow startupWindow = new StartupWindow();
            startupWindow.ShowDialog();

            if (cashDesk.Operator != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Stop();
                exchangeDataTimer.Dispose();
            }

            base.OnExit(e);
        }

        private void ExchangeDataTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.FrontDataExchange();
            CashDeskLib.CashDesk.Instance.LoadClients();
        }

        private void CashDesk_CashPaymentEvent(object sender, CashDeskLib.DataModel.CashPaymentEventArgs e)
        {
            CalcSurrenderWindow calcSurrenderWindow = new CalcSurrenderWindow
            {
                Sum = e.Sum
            };
            e.Cancel = calcSurrenderWindow.ShowDialog() != true;
        }
    }
}
