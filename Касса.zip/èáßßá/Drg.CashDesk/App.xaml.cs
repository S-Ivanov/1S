﻿using Drg.CashDeskLib;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var config = (CashDeskConfiguration)ConfigurationManager.GetSection("CashDeskConfiguration");
            CashDeskLib.CashDesk cashDesk = CashDeskLib.CashDesk.Create(config);

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            StartupWindow startupWindow = new StartupWindow();
            startupWindow.ShowDialog();

            if (cashDesk.Operator != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
        }
    }
}
