﻿Виртуальная клавиатура
----------------------

https://designforge.wordpress.com/2011/01/06/jhvirtualkeyboard/

+++
https://github.com/snmslavk/WPF-Keyboard-Control