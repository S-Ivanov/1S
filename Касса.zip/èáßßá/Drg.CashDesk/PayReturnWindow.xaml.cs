﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для PayReturnWindow.xaml
    /// </summary>
    public partial class PayReturnWindow : Window
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="total">общая сумма возврата</param>
        /// <param name="payments">словарь оплат исходного заказа с учетом предыдущих возвратов</param>
        public PayReturnWindow(decimal total, Dictionary<Payment, decimal> payments)
        {
            InitializeComponent();

            Total = total;
            //this.payments = payments;

            // HACK: количество элементов enum берем по последнему значению
            Limits = new decimal[(int)Payment.Cash + 1];
            foreach (var kvp in payments)
            {
                Limits[(int)kvp.Key] = kvp.Value;
            }

            DataContext = this;
        }

        ///// <summary>
        ///// Словарь оплат исходного заказа с учетом предыдущих возвратов
        ///// </summary>
        //Dictionary<Payment, decimal> payments;

        /// <summary>
        /// Лимиты возврата по отдельным видам оплаты
        /// </summary>
        public decimal[] Limits { get; private set; }

        /// <summary>
        /// Остаток суммы возврата
        /// </summary>
        public decimal Total { get; set; }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // подключить обработчик нажатия кнопок цифровой клавиатуры
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void ViewModel_OkCommandEvent(object sender, EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModelEventArgs<string> e)
        {
        }

        private void DigitButton_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
