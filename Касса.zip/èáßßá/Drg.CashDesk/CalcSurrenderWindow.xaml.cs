﻿using Drg.CashDeskLib.Utils;
using System.Windows;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для CalcSurrenderWindow.xaml
    /// </summary>
    public partial class CalcSurrenderWindow : Window 
    {
        public CalcSurrenderWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModel.DataModelEventArgs<string> e)
        {
            AddInput(e.Data);
        }

        private void AddInput(string s)
        {
            inputText += s;
            inputLabel.Content = inputText;
            SetSurrender();
        }

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {
            AddInput("0");
        }

        private void ZeroZeroButton_Click(object sender, RoutedEventArgs e)
        {
            AddInput("00");
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            if (!inputText.Contains(","))
            {
                inputText += ",";
                if (inputText.TryToDecimal(out decimal x))
                {
                    inputLabel.Content = x.ToString("F2");
                    if (x >= sum)
                        surrenderLabel.Content = (x - sum).ToString("F2");
                }
            }
        }

        void SetSurrender()
        {
            if (inputText.TryToDecimal(out decimal x) && x >= sum)
                surrenderLabel.Content = (x - sum).ToString("F2");
        }

        string inputText = "";

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            inputLabel.Content = surrenderLabel.Content = inputText = "";
        }

        public decimal Sum
        {
            get => sum;
            set
            {
                if (sum != value)
                {
                    sum = value;
                    sumLabel.Content = sum.ToString("F2");
                }
            }
        }
        decimal sum;
    }
}
