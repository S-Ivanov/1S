﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Drg.CashDesk.Dialogs
{
    /// <summary>
    /// Логика взаимодействия для WpfMessageBox.xaml
    /// </summary>
    public partial class WpfMessageBox : Window
    {
        #region Конструкторы

        public WpfMessageBox()
            : this(string.Empty, string.Empty, MessageBoxButton.OK, MessageBoxImage.None)
        {
        }

        public WpfMessageBox(string msg)
            : this(string.Empty, msg, MessageBoxButton.OK, MessageBoxImage.None)
        {
        }

        public WpfMessageBox(string caption, string msg)
            : this(caption, msg, MessageBoxButton.OK, MessageBoxImage.None)
        {
        }

        public WpfMessageBox(string caption, string msg, MessageBoxButton button)
            : this(caption, msg, button, MessageBoxImage.None)
        {
        }

        public WpfMessageBox(string caption, string msg, MessageBoxButton button, MessageBoxImage image)
        {
            InitializeComponent();

            Title = caption;
            txtMsg.Text = msg;

            SetVisibilityOfButtons(button);
            SetImageOfMessageBox(image);
        }

        #endregion Конструкторы

        #region Статические методы

        public static MessageBoxResult Show(string caption, string msg, Dialogs.MessageBoxType type)
        {
            switch (type)
            {
                case MessageBoxType.ConfirmationWithYesNo:
                    return Show(caption, msg, MessageBoxButton.YesNo, MessageBoxImage.Question);
                case MessageBoxType.ConfirmationWithYesNoCancel:
                    return Show(caption, msg, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                case MessageBoxType.Information:
                    return Show(caption, msg, MessageBoxButton.OK, MessageBoxImage.Information);
                case MessageBoxType.Error:
                    return Show(caption, msg, MessageBoxButton.OK, MessageBoxImage.Error);
                case MessageBoxType.Warning:
                    return Show(caption, msg, MessageBoxButton.OK, MessageBoxImage.Warning);
                default:
                    return MessageBoxResult.No;
            }
        }

        public static MessageBoxResult Show(string msg, MessageBoxType type)
        {
            return Show(string.Empty, msg, type);
        }

        public static MessageBoxResult Show(string msg)
        {
            return Show(string.Empty, msg, MessageBoxButton.OK, MessageBoxImage.None);
        }

        public static MessageBoxResult Show(string caption, string text)
        {
            return Show(caption, text, MessageBoxButton.OK, MessageBoxImage.None);
        }

        public static MessageBoxResult Show(string caption, string text, MessageBoxButton button)
        {
            return Show(caption, text, button, MessageBoxImage.None);
        }

        public static MessageBoxResult Show(string caption, string text, MessageBoxButton button, MessageBoxImage image)
        {
            var _messageBox = new WpfMessageBox(caption, text, button, image);
            _messageBox.ShowDialog();
            return _messageBox.Result;
        }

        #endregion Статические методы

        #region Приватные методы

        void SetVisibilityOfButtons(MessageBoxButton button)
        {
            switch (button)
            {
                case MessageBoxButton.OK:
                    btnCancel.Visibility = Visibility.Collapsed;
                    btnNo.Visibility = Visibility.Collapsed;
                    btnYes.Visibility = Visibility.Collapsed;
                    btnOk.Focus();
                    break;
                case MessageBoxButton.OKCancel:
                    btnNo.Visibility = Visibility.Collapsed;
                    btnYes.Visibility = Visibility.Collapsed;
                    btnCancel.Focus();
                    break;
                case MessageBoxButton.YesNo:
                    btnOk.Visibility = Visibility.Collapsed;
                    btnCancel.Visibility = Visibility.Collapsed;
                    btnNo.Focus();
                    break;
                case MessageBoxButton.YesNoCancel:
                    btnOk.Visibility = Visibility.Collapsed;
                    btnCancel.Focus();
                    break;
                default:
                    break;
            }
        }

        void SetImageOfMessageBox(MessageBoxImage image)
        {
            switch (image)
            {
                case MessageBoxImage.Warning:
                    SetImage("warning-filled.png");
                    break;
                case MessageBoxImage.Question:
                    SetImage("question-filled.png");
                    break;
                case MessageBoxImage.Information:
                    SetImage("information-filled.png");
                    break;
                case MessageBoxImage.Error:
                    SetImage("error2-filled.png");
                    break;
                default:
                    img.Visibility = Visibility.Collapsed;
                    break;
            }
        }

        private void SetImage(string imageName)
        {
            string uri = string.Format("/Images/{0}", imageName);
            var uriSource = new Uri(uri, UriKind.RelativeOrAbsolute);
            img.Source = new BitmapImage(uriSource);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender == btnOk)
                Result = MessageBoxResult.OK;
            else if (sender == btnYes)
                Result = MessageBoxResult.Yes;
            else if (sender == btnNo)
                Result = MessageBoxResult.No;
            else if (sender == btnCancel)
                Result = MessageBoxResult.Cancel;
            else
                Result = MessageBoxResult.None;
            Close();
        }

        #endregion Приватные методы

        public MessageBoxResult Result { get; private set; } = MessageBoxResult.Cancel;
    }
}
