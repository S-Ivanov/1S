﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.ViewModels
{
    public class PayWindow
    {
        public PayItem PayItemZP { get; set; } = new PayItem();
    }

    public class PayItem
    {
        public bool IsSelected { get; set; }
        public bool IsEnabled { get; set; }
    }
}
