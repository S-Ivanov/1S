﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.ViewModels
{
    public class PayWindow : INotifyPropertyChanged
    {
        public PaymentInfo PaymentInfo
        {
            get => paymentInfo;
            set
            {
                if (paymentInfo != value)
                {
                    paymentInfo = value;
                    Reset();
                    if (paymentInfo != null)
                    {
                        switch (paymentInfo.InitPayment)
                        {
                            case Payment.ZP:
                                PayItemZP.IsSelected = true;
                                break;
                            case Payment.LPP:
                                PayItemLPP.IsSelected = true;
                                break;
                            case Payment.Talon120:
                                PayItemTalon120.IsSelected = true;
                                break;
                            case Payment.BankCard:
                                PayItemBank.IsSelected = true;
                                break;
                            case Payment.Cash:
                                PayItemCash.IsSelected = true;
                                break;
                        }

                        foreach (var kvp in paymentInfo.Payments)
                        {
                            switch (kvp.Key)
                            {
                                case Payment.ZP:
                                    PayItemZP.Value = kvp.Value;
                                    break;
                                case Payment.LPP:
                                    PayItemLPP.Value = kvp.Value;
                                    break;
                                case Payment.Talon120:
                                    PayItemTalon120.Value = kvp.Value;
                                    break;
                                case Payment.BankCard:
                                    PayItemBank.Value = kvp.Value;
                                    break;
                                case Payment.Cash:
                                    PayItemCash.Value = kvp.Value;
                                    break;
                            }
                        }
                    }
                }
            }
        }
        PaymentInfo paymentInfo;

        private void Reset()
        {
            if (paymentInfo == null)
            {
                PayItemZP.Reset();
                PayItemLPP.Reset();
                PayItemTalon120.Reset();
                PayItemBank.Reset();
                PayItemCash.Reset();
            }
            else
            {
                // устанавить доступность кнопок оплаты в соответствии с возможностями оплаты
                PayItemZP.IsEnabled = paymentInfo.PaymentAbilities.ZP;
                PayItemLPP.IsEnabled = paymentInfo.PaymentAbilities.LPP;
                PayItemTalon120.IsEnabled = paymentInfo.PaymentAbilities.Talon120;
                PayItemBank.IsEnabled = paymentInfo.PaymentAbilities.Bank;
                PayItemCash.IsEnabled = paymentInfo.PaymentAbilities.Cash;
            }
        }

        public PayItem PayItemZP { get; set; } = new PayItem();
        public PayItem PayItemLPP { get; set; } = new PayItem();
        public PayItem PayItemTalon120 { get; set; } = new PayItem();
        public PayItem PayItemBank { get; set; } = new PayItem();
        public PayItem PayItemCash { get; set; } = new PayItem();

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    public class PayItem : INotifyPropertyChanged
    {
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected;

        public bool IsEnabled
        {
            get => isEnabled;
            set
            {
                if (isEnabled != value)
                {
                    isEnabled = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsEnabled)));
                }
            }
        }
        bool isEnabled;

        public decimal Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value)));

                    ValueText = _value > 0 ? _value.ToString() : string.Empty;
                }
            }
        }
        decimal _value;

        public string ValueText
        {
            get => valueText;
            set
            {
                if (valueText != value)
                {
                    valueText = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ValueText)));
                }
            }
        }
        string valueText;

        public void Reset()
        {
            IsEnabled = IsSelected = false;
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
