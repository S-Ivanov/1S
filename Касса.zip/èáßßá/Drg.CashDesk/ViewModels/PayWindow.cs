﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    public class PayWindow : INotifyPropertyChanged
    {
        public PayWindow()
        {
            PayItems = new PayItem[]
            {
                new PayItem(),
                new PayItem(),
                new PayItem(),
                new PayItem(),
                new PayItem()
            };
        }

        public PaymentInfo PaymentInfo
        {
            get => paymentInfo;
            set
            {
                if (paymentInfo != value)
                {
                    paymentInfo = value;
                    Reset();
                    if (paymentInfo != null)
                    {
                        PayItems[(int)paymentInfo.InitPayment].IsSelected = true;

                        foreach (var kvp in paymentInfo.Payments)
                        {
                            PayItems[(int)kvp.Key].Value = kvp.Value;
                        }
                    }
                }
            }
        }
        PaymentInfo paymentInfo;

        public PayItem[] PayItems { get; private set; }

        public decimal Balance
        {
            get => balance;
            set
            {
                if (balance != value)
                {
                    balance = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Balance)));
                }
            }
        }
        decimal balance;

        /// <summary>
        /// Команда выбора варианта оплаты
        /// </summary>
        public ICommand SelectPaymentCommand
        {
            get
            {
                return new RelayCommand<PayItem>(payItem =>
                {
                    var selected = PayItems.FirstOrDefault(x => x.IsSelected);
                    if (selected != null)
                        selected.IsSelected = false;
                    payItem.IsSelected = true;
                });
            }
        }

        private void Reset()
        {
            Array.ForEach<PayItem>(PayItems, payItem => payItem.Reset());

            if (paymentInfo != null)
            {
                // устанавить доступность кнопок оплаты в соответствии с возможностями оплаты
                PayItems[(int)Payment.ZP].IsEnabled = paymentInfo.PaymentAbilities.ZP;
                PayItems[(int)Payment.LPP].IsEnabled = paymentInfo.PaymentAbilities.LPP;
                PayItems[(int)Payment.Talon120].IsEnabled = paymentInfo.PaymentAbilities.Talon120;
                PayItems[(int)Payment.BankCard].IsEnabled = paymentInfo.PaymentAbilities.Bank;
                PayItems[(int)Payment.Cash].IsEnabled = paymentInfo.PaymentAbilities.Cash;
            }
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    public class PayItem : INotifyPropertyChanged
    {
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected;

        public bool IsEnabled
        {
            get => isEnabled;
            set
            {
                if (isEnabled != value)
                {
                    isEnabled = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsEnabled)));
                }
            }
        }
        bool isEnabled;

        public decimal Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value)));

                    ValueText = _value > 0 ? _value.ToString() : string.Empty;
                }
            }
        }
        decimal _value;

        public string ValueText
        {
            get => valueText;
            set
            {
                if (valueText != value)
                {
                    valueText = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ValueText)));
                }
            }
        }
        string valueText;

        public void Reset()
        {
            IsEnabled = IsSelected = false;
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
