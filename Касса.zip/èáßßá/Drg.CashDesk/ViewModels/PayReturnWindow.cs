﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.Utils;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    public class PayReturnWindow : INotifyPropertyChanged
    {
        public PayReturnWindow()
        {
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
