﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для SelectOrderDialog.xaml
    /// </summary>
    public class SelectOrderDialog : INotifyPropertyChanged
    {
        public SelectOrderDialog()
        {
            allOrders = new ObservableCollection<OrderListItem>(
                CashDeskLib.CashDesk.Instance.LocalOrders
                .OrderBy(order => order.DateTime)
                .Select(order => new OrderListItem(order)));
            Orders = new ObservableCollection<OrderListItem>(allOrders);
        }

        /// <summary>
        /// Текст поиска - номер заказа, табельный или ФИО
        /// </summary>
        public string SearchText
        {
            get => searchText;
            set
            {
                if (searchText != value)
                {
                    searchText = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SearchText)));
                    SetOrders();
                }
            }
        }
        string searchText;
        string lastSearchText = "";
        int mode = 0;

        void SetOrders()
        {
            if (string.IsNullOrEmpty(searchText))
                Orders = new ObservableCollection<OrderListItem>(allOrders);
            else if (searchText.Length < lastSearchText.Length)
                Orders = new ObservableCollection<OrderListItem>(allOrders.Where(order => order.MathText(searchText)));
            else
            {
                for (int i = Orders.Count - 1; i >= 0; i--)
                {
                    if (!Orders[i].MathText(searchText))
                        Orders.RemoveAt(i);
                }
            }

            foreach (var order in Orders)
            {
                order.SetBoldText(searchText);
            }

            lastSearchText = searchText ?? "";
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Orders)));
        }

        public void SetMode(int mode)
        {
            if (this.mode != mode)
            {
                this.mode = mode;
                SetOrders();
            }
        }

        /// <summary>
        /// Активный заказ
        /// </summary>
        public OrderListItem SelectedOrder
        {
            get => selectedOrder;
            set
            {
                if (selectedOrder != value)
                {
                    selectedOrder = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrder)));
                }
            }
        }
        OrderListItem selectedOrder;

        public ObservableCollection<OrderListItem> Orders { get; private set; }

        ObservableCollection<OrderListItem> allOrders;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    public class OrderListItem : INotifyPropertyChanged
    {
        public OrderListItem(OrderSource order)
        {
            this.Order = order;
            if (order.Client == null)
            {
                Client = DataModel.Client.Empty;
            }
            else
            {
                Client = new DataModel.Client(order.Client);
                SetTabNum(order.Client.TabNum);
                SetFIO(order.Client.FIO);
            }
            SetNum(order.Number.ToString());
        }

        public bool MathText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return true;

            if (text.Any(ch => char.IsDigit(ch)))
            {
                // поиск по табельному или номеру заказа
                return (Order.Client != null && !string.IsNullOrEmpty(Order.Client.TabNum) && Order.Client.TabNum.IndexOf(text) >= 0) || Order.Number.ToString().IndexOf(text) >= 0;
            }
            else
            {
                // поиск по ФИО
                return Order.Client != null && !string.IsNullOrEmpty(Order.Client.FIO) && Order.Client.FIO.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0;
            }
        }

        public void SetBoldText(string text)
        {
            string orderNumber = Order.Number.ToString();
            if (string.IsNullOrEmpty(text))
            {
                SetNum(orderNumber);
                if (Order.Client != null)
                {
                    SetTabNum(Order.Client.TabNum);
                    SetFIO(Order.Client.FIO);
                }
                return;
            }

            if (text.Any(ch => char.IsDigit(ch)))
            {
                int index;

                // поиск по табельному
                if (Order.Client != null && !string.IsNullOrEmpty(Order.Client.TabNum))
                {
                    index = Order.Client.TabNum.IndexOf(text);
                    if (index < 0)
                        SetTabNum(Order.Client.TabNum);
                    else
                        SetTabNum(
                            Order.Client.TabNum.Substring(0, index),
                            Order.Client.TabNum.Substring(index, text.Length),
                            Order.Client.TabNum.Substring(index + text.Length));
                }

                // поиск по номеру заказа
                index = orderNumber.IndexOf(text);
                if (index < 0)
                    SetNum(orderNumber);
                else
                    SetNum(
                        orderNumber.Substring(0, index),
                        orderNumber.Substring(index, text.Length),
                        orderNumber.Substring(index + text.Length));
            }
            else if (Order.Client != null && !string.IsNullOrEmpty(Order.Client.FIO))
            {
                // поиск по ФИО
                int index = Order.Client.FIO.IndexOf(text, StringComparison.CurrentCultureIgnoreCase);
                if (index < 0)
                    SetFIO(Order.Client.FIO);
                else
                    SetFIO(
                        Order.Client.FIO.Substring(0, index),
                        Order.Client.FIO.Substring(index, text.Length),
                        Order.Client.FIO.Substring(index + text.Length));
            }
        }

        void SetTabNum(string tabNum1, string tabNum2 = null, string tabNum3 = null)
        {
            if (TabNum1 != tabNum1)
            {
                TabNum1 = tabNum1;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum1)));
            }

            if (TabNum2 != tabNum2)
            {
                TabNum2 = tabNum2;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum2)));
            }

            if (TabNum3 != tabNum3)
            {
                TabNum3 = tabNum3;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum3)));
            }
        }

        void SetNum(string num1, string num2 = null, string num3 = null)
        {
            if (Num1 != num1)
            {
                Num1 = num1;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Num1)));
            }

            if (Num2 != num2)
            {
                Num2 = num2;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Num2)));
            }

            if (Num3 != num3)
            {
                Num3 = num3;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Num3)));
            }
        }

        void SetFIO(string fio1, string fio2 = null, string fio3 = null)
        {
            if (FIO1 != fio1)
            {
                FIO1 = fio1;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO1)));
            }

            if (FIO2 != fio2)
            {
                FIO2 = fio2;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO2)));
            }

            if (FIO3 != fio3)
            {
                FIO3 = fio3;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO3)));
            }
        }

        /// <summary>
        /// Заказ
        /// </summary>
        public OrderSource Order { get; private set; }

        /// <summary>
        /// Клиент
        /// </summary>
        public DataModel.Client Client { get; private set; }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum1 { get; private set; }
        public string TabNum2 { get; private set; }
        public string TabNum3 { get; private set; }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public string Num1 { get; private set; }
        public string Num2 { get; private set; }
        public string Num3 { get; private set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO1 { get; private set; }
        public string FIO2 { get; private set; }
        public string FIO3 { get; private set; }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
