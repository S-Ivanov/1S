﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Timers;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// Модель отображения индикаторов готовности вариантов оплаты
    /// </summary>
    public class AbilityIndicator : INotifyPropertyChanged
    {
        public AbilityIndicator()
        {
            //timer = new Timer();
        }

        #region Свойства

        public bool Pass
        {
            get => pass;
            set
            {
                if (pass != value)
                {
                    pass = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Pass"));
                }
            }
        }
        bool pass = false;

        #endregion Свойства

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        //Timer timer = null;
    }
}
