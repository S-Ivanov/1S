﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        public MainWindow()
        {
            menu = new Menu(CashDeskLib.CashDesk.Instance.GetMenu());
            if (menu != null && menu.MenuGroups.Count > 0)
            {
                SelectMenuItemGroup(menu.MenuGroups[0]);
                MenuItems = menu.MenuGroups[0].Items;
            }
        }

        /// <summary>
        /// Список элементов выбранной группы меню или найденных в результате поиска
        /// </summary>
        public ObservableCollection<MenuItem> MenuItems
        {
            get => menuItems;
            set
            {
                if (menuItems != value)
                {
                    menuItems = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MenuItems)));
                }
            }
        }
        ObservableCollection<MenuItem> menuItems = null;

        /// <summary>
        /// Команда выбора группы элементов меню
        /// </summary>
        public ICommand SelectMenuItemGroupCommand
        {
            get
            {
                return new RelayCommand<MenuItemGroup>(menuItemGroup =>
                {
                    SelectMenuItemGroup(menuItemGroup);
                    MenuItems = menuItemGroup.Items;
                });
            }
        }

        /// <summary>
        /// Команда выбора элемента меню
        /// </summary>
        public ICommand SelectMenuItemCommand
        {
            get
            {
                return new RelayCommand<MenuItem>(menuItem =>
                {
                    foreach (var item in MenuItems)
                    {
                        item.IsSelected = item == menuItem;
                    }
                });
            }
        }

        private void SelectMenuItemGroup(MenuItemGroup menuItemGroup)
        {
            foreach (var menuGroup in menu.MenuGroups)
            {
                menuGroup.IsSelected = menuGroup == menuItemGroup;
            }
        }

        /// <summary>
        /// Меню
        /// </summary>
        public Menu Menu => menu;
        Menu menu;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
