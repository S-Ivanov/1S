﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MainWindow()
        {
            Clear();

            menu = new DataModel.Menu(CashDeskLib.CashDesk.Instance.GetMenu());
        }

        /// <summary>
        /// Очистка возможных вариантов оплаты, заказа и клиента
        /// </summary>
        public void Clear()
        {
            PaymentAbilities = new PaymentAbilities();
            Order = new Order();
            SetClient(null);
        }

        /// <summary>
        /// Индикатор того, что находимся в режиме сервиса меню
        /// </summary>
        public bool IsMenuServiceMode
        {
            get => isMenuServiceMode;
            set
            {
                if (isMenuServiceMode != value)
                {
                    isMenuServiceMode = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMenuServiceMode)));

                    // при переходе в режим сервиса меню обнуляем клиента и заказ
                    if (isMenuServiceMode)
                        Clear();
                }
            }
        }
        bool isMenuServiceMode;

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            get
            {
                //if (menu == null)
                //    menu = new DataModel.Menu(CashDeskLib.CashDesk.Instance.GetMenu());
                return menu;
            }
        }
        DataModel.Menu menu = null;

        /// <summary>
        /// Предыдущее меню
        /// </summary>
        public DataModel.Menu OldMenu
        {
            get => oldMenu;
            set
            {
                if (oldMenu != value)
                {
                    oldMenu = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OldMenu)));
                }
            }
        }
        DataModel.Menu oldMenu = null;

        /// <summary>
        /// Даты прошлых меню, отсортированные в обратнои порядке
        /// </summary>
        public List<DateTime> OldMenuDates
        {
            get
            {
                if (oldMenuDates == null)
                {
                    var cashDesk = CashDeskLib.CashDesk.Instance;
                    var dateStart = DateTime.Today.AddDays(-cashDesk.Configuration.OldMenuDays);
                    var dateEnd = DateTime.Today.AddDays(-1);
                    oldMenuDates = cashDesk.GetMenuDates(dateStart, dateEnd).OrderByDescending(d => d).ToList();
                    if (oldMenuDates != null && oldMenuDates.Count > 0)
                        SelectedOldMenuDate = oldMenuDates[0];
                }
                return oldMenuDates;
            }
        }
        List<DateTime> oldMenuDates = null;

        /// <summary>
        /// Дата выбранного прошлого меню
        /// </summary>
        public DateTime SelectedOldMenuDate
        {
            get => selectedOldMenuDate;
            set
            {
                if (selectedOldMenuDate != value)
                {
                    selectedOldMenuDate = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOldMenuDate)));

                    OldMenu = new DataModel.Menu(CashDeskLib.CashDesk.Instance.GetMenu(selectedOldMenuDate));
                }
            }
        }
        DateTime selectedOldMenuDate = DateTime.MinValue;

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilities PaymentAbilities { get; private set; }

        /// <summary>
        /// Клиент
        /// </summary>
        public Client Client { get; private set; }

        /// <summary>
        /// Заказ
        /// </summary>
        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    SelectedOrderItem = null;
                }
            }
        }
        Order order = null;

        /// <summary>
        /// Выбранная позиция заказа
        /// </summary>
        public OrderItem SelectedOrderItem
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        OrderItem selectedOrderItem = null;

        /// <summary>
        /// Выбранная группа элементов меню
        /// </summary>
        public MenuItemGroup SelectedMenuItemGroup { get; set; }

        /// <summary>
        /// Выбранная позиция меню
        /// </summary>
        public MenuItem SelectedMenuItem
        {
            get => selectedMenuItem;
            set
            {
                if (selectedMenuItem != value)
                {
                    selectedMenuItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItem)));

                    if (selectedMenuItem == null)
                        return;

                    if (IsMenuServiceMode)
                    {

                    }
                    else
                    {
                        // добавление элемента заказа
                        AddOrderItem(selectedMenuItem);
                    }
                }
            }
        }
        MenuItem selectedMenuItem = null;

        /// <summary>
        /// Команда копирования выбранного локального элемента меню
        /// </summary>
        public ICommand CopySelectedMenuItemCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (ChangeCount != null)
                    {
                        var eventArgs = new ChangeCountEventArgs { Type = typeof(MenuItem), Value = SelectedMenuItem.Count };
                        ChangeCount(this, eventArgs);
                        if (!eventArgs.Cancel) // && SelectedMenuItem.Count != eventArgs.Value)
                        {
                            // изменить количество и цену
                            decimal count = eventArgs.Value;
                            decimal price = count == SelectedMenuItem.Count ? SelectedMenuItem.Price : Math.Round(count / SelectedMenuItem.Count * SelectedMenuItem.Price, 2, MidpointRounding.AwayFromZero);
                            var newRawMenuItem = SelectedMenuItem.RawMenuItem.Copy(count, price);

                            // TODO: записать копию элемента меню в базу

                            // добавить копию элемента меню в список
                            MenuItem newMenuItem = new MenuItem(newRawMenuItem);
                            int index = 0;
                            var menuItem = SelectedMenuItemGroup.Items.FirstOrDefault(item => item.Name == SelectedMenuItem.Name && item.Count >= count);
                            if (menuItem == null)
                            {
                                menuItem = SelectedMenuItemGroup.Items.Last(item => item.Name == SelectedMenuItem.Name && item.Count < count);
                                index = 1;
                            }
                            index += SelectedMenuItemGroup.Items.IndexOf(menuItem);
                            SelectedMenuItemGroup.Items.Insert(index, newMenuItem);
                        }
                    }
                },
                o => SelectedMenuItem != null);
            }
        }

        /// <summary>
        /// Команда переключения режима сервиса меню
        /// </summary>
        public ICommand ChangeMenuServiceModeCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    IsMenuServiceMode = !IsMenuServiceMode;
                });
            }
        }

        /// <summary>
        /// Команда оплаты
        /// </summary>
        public ICommand PaymentCommand
        {
            get
            {
                return new RelayCommand<Payment>(payment =>
                {
                    if (Payment != null && Order != null && Order.Total > 0)
                    {
                        PaymentInfo paymentInfo = new PaymentInfo(PaymentAbilities, payment, Order.Total);
                        var eventArgs = new DataModelEventArgs<PaymentInfo> { Data = paymentInfo };
                        Payment(this, eventArgs);
                    }
                });
            }
        }

        /// <summary>
        /// Добавление элемента заказа
        /// </summary>
        /// <param name="menuItem"></param>
        void AddOrderItem(MenuItem menuItem)
        {
            if (menuItem == null)
                return;

            var newOrderItem = new OrderItem(menuItem, Order.Items.Count + 1);
            Order.Items.Add(newOrderItem);
            SelectedOrderItem = newOrderItem;

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
        }

        /// <summary>
        /// Установить клиента по коду пропуска
        /// </summary>
        /// <param name="cardCode"></param>
        public void SetClient(uint cardCode)
        {
            // в режиме сервиса меню изменение клиента не отрабатываем
            if (IsMenuServiceMode)
                return;

            if (Client.RawClient == null || Client.RawClient.CardCode != cardCode)
                SetClient(CashDeskLib.CashDesk.Instance.GetClient(cardCode));
        }

        void SetClient(CashDeskLib.DataModel.Client client)
        {
            if (client == null)
                Client = Client.Empty;
            else
            {
                if (!client.IsPhotoLoaded && client.Photo == null)
                    CashDeskLib.CashDesk.Instance.LoadPhoto(client);
                Client = new Client(client);
            }
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Client)));

            PaymentAbilities.Client = Client;
            PaymentAbilitiesRefresh();
        }

        /// <summary>
        /// Обновить возможные варианты оплаты
        /// </summary>
        public void PaymentAbilitiesRefresh()
        {
            // блокировка на случай вызова из другого потока, например, по событию проверки оборудования
            lock (PaymentAbilities)
            {
                PaymentAbilities.Refresh();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PaymentAbilities)));
            }
        }

        /// <summary>
        /// Команда создания нового заказа
        /// </summary>
        public ICommand NewOrderCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить создание нового заказа, если есть элементы в текущем
                    if (Order.Items.Count > 0 && NewOrder != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        NewOrder(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    Clear();
                });
            }
        }

        /// <summary>
        /// Команда изменения количества выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemChangeCountCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    if (ChangeCount != null)
                    {
                        var eventArgs = new ChangeCountEventArgs { Type = typeof(OrderItem), Value = orderItem.Count };
                        ChangeCount(this, eventArgs);
                        if (!eventArgs.Cancel && orderItem.Count != eventArgs.Value)
                        {
                            orderItem.Count = eventArgs.Value;
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                        }
                    }
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда выбора клиента из списка
        /// </summary>
        public ICommand SelectClientCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (SelectClient != null)
                    {
                        var eventArgs = new DataModelEventArgs<CashDeskLib.DataModel.Client>();
                        SelectClient(this, eventArgs);
                        if (eventArgs.Data != null)
                            SetClient(eventArgs.Data);
                    }
                });
            }
        }

        /// <summary>
        /// Команда удаления выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemDeleteCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить удаление выбранного элемента заказа
                    if (OrderItemDelete != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        OrderItemDelete(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    var orderItemIndex = Order.Items.IndexOf(orderItem);
                    Order.Items.Remove(orderItem);

                    // сделать активной какую-то другую запись
                    if (orderItemIndex < Order.Items.Count)
                        SelectedOrderItem = Order.Items[orderItemIndex];
                    else if (Order.Items.Count == 0)
                        SelectedOrderItem = null;
                    else
                        SelectedOrderItem = Order.Items.Last();

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда сворачивания заказа
        /// </summary>
        public ICommand OrderCollapseCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    var selected = SelectedOrderItem?.MenuItem;
                    Order.Collapse();
                    // сделать активной запись, которая была до сворачивания
                    if (selected != null)
                        SelectedOrderItem = Order.Items.First(item => item.MenuItem == selected);
                });
            }
        }

        /// <summary>
        /// Событие оплаты
        /// </summary>
        public event EventHandler<DataModelEventArgs<PaymentInfo>> Payment;

        /// <summary>
        /// Событие для выбора клиента из списка
        /// </summary>
        public event EventHandler<DataModelEventArgs<CashDeskLib.DataModel.Client>> SelectClient;

        /// <summary>
        /// Событие для изменения количества 
        /// </summary>
        public event EventHandler<ChangeCountEventArgs> ChangeCount;

        /// <summary>
        /// Событие для подтверждения удаления элемента заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> OrderItemDelete;

        /// <summary>
        /// Событие для подтверждения создания нового заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> NewOrder;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
