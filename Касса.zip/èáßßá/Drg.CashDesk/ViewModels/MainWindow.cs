﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MainWindow()
        {
            Clear();
        }

        /// <summary>
        /// Очистка возможных вариантов оплаты, заказа и клиента
        /// </summary>
        public void Clear()
        {
            PaymentAbilities = new PaymentAbilities();
            Order = new Order();
            SetClient(null);
        }

        /// <summary>
        /// Индикатор того, что находимся в режиме сервиса меню
        /// </summary>
        public bool IsMenuServiceMode
        {
            get => isMenuServiceMode;
            set
            {
                if (isMenuServiceMode != value)
                {
                    isMenuServiceMode = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMenuServiceMode)));

                    // при переходе в режим сервиса меню обнуляем клиента и заказ
                    if (isMenuServiceMode)
                        Clear();

                    if (!oldMenuPropertiesSet)
                    {
                        oldMenuPropertiesSet = true;
                        if (SetOldMenuProperties != null)
                        {
                            var cashDesk = CashDeskLib.CashDesk.Instance;
                            var dateStart = DateTime.Today.AddDays(-cashDesk.Configuration.OldMenuDays);
                            var dateEnd = DateTime.Today.AddDays(-1);
                            List<DateTime> dates = cashDesk.GetMenuDates(dateStart, dateEnd);
                            OldMenuProperties oldMenuProperties = new OldMenuProperties
                            {
                                DateStart = dateStart,
                                DateEnd = dateEnd,
                                Dates = dates
                            };
                            SetOldMenuProperties(this, new DataModelEventArgs<OldMenuProperties> { Data = oldMenuProperties });
                        }
                    }
                }
            }
        }
        bool isMenuServiceMode;
        bool oldMenuPropertiesSet;

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilities PaymentAbilities { get; private set; }

        /// <summary>
        /// Клиент
        /// </summary>
        public Client Client { get; private set; }

        /// <summary>
        /// Заказ
        /// </summary>
        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    SelectedOrderItem = null;
                }
            }
        }
        Order order = null;

        /// <summary>
        /// Выбранная позиция заказа
        /// </summary>
        public OrderItem SelectedOrderItem
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        OrderItem selectedOrderItem = null;

        /// <summary>
        /// Команда переключения режима сервиса меню
        /// </summary>
        public ICommand ChangeMenuServiceModeCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    IsMenuServiceMode = !IsMenuServiceMode;
                });
            }
        }

        /// <summary>
        /// Команда оплаты
        /// </summary>
        public ICommand PaymentCommand
        {
            get
            {
                return new RelayCommand<Payment>(payment =>
                {
                    if (Payment != null && Order != null && Order.Total > 0)
                    {
                        PaymentInfo paymentInfo = new PaymentInfo(PaymentAbilities, payment, Order.Total);
                        var eventArgs = new DataModelEventArgs<PaymentInfo> { Data = paymentInfo };
                        Payment(this, eventArgs);
                    }
                });
            }
        }

        /// <summary>
        /// Добавление элемента заказа
        /// </summary>
        /// <param name="menuItem"></param>
        public void AddOrderItem(MenuItem menuItem)
        {
            if (menuItem == null)
                throw new ArgumentNullException(nameof(menuItem));

            var newOrderItem = new OrderItem(menuItem, Order.Items.Count + 1);
            Order.Items.Add(newOrderItem);
            SelectedOrderItem = newOrderItem;

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
        }

        /// <summary>
        /// Установить клиента по коду пропуска
        /// </summary>
        /// <param name="cardCode"></param>
        public void SetClient(uint cardCode)
        {
            // в режиме сервиса меню изменение клиента не отрабатываем
            if (IsMenuServiceMode)
                return;

            if (Client.RawClient == null || Client.RawClient.CardCode != cardCode)
                SetClient(CashDeskLib.CashDesk.Instance.GetClient(cardCode));
        }

        void SetClient(CashDeskLib.DataModel.Client client)
        {
            if (client == null)
                Client = Client.Empty;
            else
            {
                if (!client.IsPhotoLoaded && client.Photo == null)
                    CashDeskLib.CashDesk.Instance.LoadPhoto(client);
                Client = new Client(client);
            }
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Client)));

            PaymentAbilities.Client = Client;
            PaymentAbilitiesRefresh();
        }

        /// <summary>
        /// Обновить возможные варианты оплаты
        /// </summary>
        public void PaymentAbilitiesRefresh()
        {
            // блокировка на случай вызова из другого потока, например, по событию проверки оборудования
            lock (PaymentAbilities)
            {
                PaymentAbilities.Refresh();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PaymentAbilities)));
            }
        }

        /// <summary>
        /// Команда создания нового заказа
        /// </summary>
        public ICommand NewOrderCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить создание нового заказа, если есть элементы в текущем
                    if (Order.Items.Count > 0 && NewOrder != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        NewOrder(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    Clear();
                });
            }
        }

        /// <summary>
        /// Команда изменения количества выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemChangeCountCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    if (OrderItemChangeCount != null)
                    {
                        var eventArgs = new DataModelEventArgs<decimal> { Data = orderItem.Count };
                        OrderItemChangeCount(this, eventArgs);
                        orderItem.Count = eventArgs.Data;

                        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    }
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда выбора клиента из списка
        /// </summary>
        public ICommand SelectClientCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (SelectClient != null)
                    {
                        var eventArgs = new DataModelEventArgs<CashDeskLib.DataModel.Client>();
                        SelectClient(this, eventArgs);
                        if (eventArgs.Data != null)
                            SetClient(eventArgs.Data);
                    }
                });
            }
        }

        /// <summary>
        /// Команда удаления выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemDeleteCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить удаление выбранного элемента заказа
                    if (OrderItemDelete != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        OrderItemDelete(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    var orderItemIndex = Order.Items.IndexOf(orderItem);
                    Order.Items.Remove(orderItem);

                    // сделать активной какую-то другую запись
                    if (orderItemIndex < Order.Items.Count)
                        SelectedOrderItem = Order.Items[orderItemIndex];
                    else if (Order.Items.Count == 0)
                        SelectedOrderItem = null;
                    else
                        SelectedOrderItem = Order.Items.Last();

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда сворачивания заказа
        /// </summary>
        public ICommand OrderCollapseCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    var selected = SelectedOrderItem?.MenuItem;
                    Order.Collapse();
                    // сделать активной запись, которая была до сворачивания
                    if (selected != null)
                        SelectedOrderItem = Order.Items.First(item => item.MenuItem == selected);
                });
            }
        }

        /// <summary>
        /// Событие настройки прошедших меню
        /// </summary>
        public event EventHandler<DataModelEventArgs<OldMenuProperties>> SetOldMenuProperties;

        /// <summary>
        /// Событие оплаты
        /// </summary>
        public event EventHandler<DataModelEventArgs<PaymentInfo>> Payment;

        /// <summary>
        /// Событие для выбора клиента из списка
        /// </summary>
        public event EventHandler<DataModelEventArgs<CashDeskLib.DataModel.Client>> SelectClient;

        /// <summary>
        /// Событие для изменения количества в элементе заказа
        /// </summary>
        public event EventHandler<DataModelEventArgs<decimal>> OrderItemChangeCount;

        /// <summary>
        /// Событие для подтверждения удаления элемента заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> OrderItemDelete;

        /// <summary>
        /// Событие для подтверждения создания нового заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> NewOrder;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
