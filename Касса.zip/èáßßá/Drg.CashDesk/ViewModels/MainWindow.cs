﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Timers;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MainWindow()
        {
            //PaymentAbilities = new PaymentAbilities();

            //Clear();

            //// загрузка меню
            //var menus = CashDeskLib.CashDesk.Instance.LoadMenus(DateTime.Today, 2);
            //if (menus.Any())
            //{
            //    var lastMenu = menus.Last();
            //    if (lastMenu.Date == DateTime.Today)
            //        menu = new DataModel.Menu(lastMenu);
            //    else
            //        oldMenu = new DataModel.Menu(lastMenu);

            //    if (oldMenu == null)
            //        oldMenu = new DataModel.Menu(menus[0]);
            //}
        }

        ///// <summary>
        ///// Очистка возможных вариантов оплаты, заказа и клиента
        ///// </summary>
        //public void Clear()
        //{
        //    lastCardCode = 0;

        //    //Client = DataModel.Client.Empty;
        //    //Order = new DataModel.Order();

        //    //PaymentAbilities.Order = Order;
        //    //PaymentAbilities.Client = Client;
        //    //PaymentAbilitiesRefresh();
        //}

        /// <summary>
        /// Режим работы кассы
        /// </summary>
        public CashDeskMode CashDeskMode { get; set; }

        ///// <summary>
        ///// Индикатор того, что находимся в режиме сервиса меню
        ///// </summary>
        //public bool IsMenuServiceMode
        //{
        //    get => isMenuServiceMode;
        //    set
        //    {
        //        if (isMenuServiceMode != value)
        //        {
        //            isMenuServiceMode = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMenuServiceMode)));

        //            // при переходе в режим сервиса меню обнуляем клиента и заказ
        //            if (isMenuServiceMode)
        //            {
        //                Clear();
        //            }
        //        }
        //    }
        //}
        //bool isMenuServiceMode;

        ///// <summary>
        ///// Меню
        ///// </summary>
        //public DataModel.Menu Menu
        //{
        //    get => menu;
        //    set
        //    {
        //        if (menu != value)
        //        {
        //            menu = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
        //        }
        //    }
        //}
        //DataModel.Menu menu = null;

        ///// <summary>
        ///// Предыдущее меню
        ///// </summary>
        //public DataModel.Menu OldMenu => oldMenu;
        //DataModel.Menu oldMenu = null;

        ///// <summary>
        ///// Возможные варианты оплаты
        ///// </summary>
        //public PaymentAbilities PaymentAbilities { get; private set; }

        ///// <summary>
        ///// Выбранная группа элементов прошлого меню
        ///// </summary>
        //public DataModel.MenuItemGroup SelectedOldMenuItemGroup
        //{
        //    get => selectedOldMenuItemGroup;
        //    set
        //    {
        //        if (selectedOldMenuItemGroup != value)
        //        {
        //            selectedOldMenuItemGroup = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOldMenuItemGroup)));
        //        }
        //    }
        //}
        //DataModel.MenuItemGroup selectedOldMenuItemGroup;

        ///// <summary>
        ///// Выбранная группа элементов меню
        ///// </summary>
        //public DataModel.MenuItemGroup SelectedMenuItemGroup
        //{
        //    get => selectedMenuItemGroup;
        //    set
        //    {
        //        if (selectedMenuItemGroup != value)
        //        {
        //            selectedMenuItemGroup = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItemGroup)));
        //        }
        //    }
        //}
        //DataModel.MenuItemGroup selectedMenuItemGroup;

        ///// <summary>
        ///// Выбранная позиция прошлого меню
        ///// </summary>
        //public DataModel.MenuItem SelectedOldMenuItem
        //{
        //    get => selectedOldMenuItem;
        //    set
        //    {
        //        if (selectedOldMenuItem != value)
        //        {
        //            selectedOldMenuItem = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOldMenuItem)));
        //        }
        //    }
        //}
        //DataModel.MenuItem selectedOldMenuItem = null;

        ///// <summary>
        ///// Выбранная позиция меню
        ///// </summary>
        //public DataModel.MenuItem SelectedMenuItem
        //{
        //    get => selectedMenuItem;
        //    set
        //    {
        //        if (selectedMenuItem != value)
        //        {
        //            selectedMenuItem = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItem)));

        //            if (selectedMenuItem == null)
        //                return;
        //        }

        //        if (CashDeskMode == CashDeskMode.Work)
        //        {
        //            // добавление элемента заказа
        //            AddOrderItem(selectedMenuItem);
        //        }
        //    }
        //}
        //DataModel.MenuItem selectedMenuItem = null;

        ///// <summary>
        ///// Команда копирования выбранного элемента меню
        ///// </summary>
        //public ICommand CopySelectedMenuItemCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<object>(o =>
        //        {
        //            if (ChangeCount != null)
        //            {
        //                var eventArgs = new ChangeCountEventArgs { Type = typeof(DataModel.MenuItem), Value = SelectedMenuItem.Count };
        //                ChangeCount(this, eventArgs);
        //                if (!eventArgs.Cancel)
        //                {
        //                    var newRawMenuItem = SelectedMenuItem.RawMenuItem.Copy(eventArgs.Value);

        //                    // записать копию элемента меню в базу
        //                    if (CashDeskLib.CashDesk.Instance.AddMenuItem(newRawMenuItem))
        //                    {
        //                        // HACK: чтобы не усложнять код поиском места для записи с новым количеством, 
        //                        // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
        //                        ReloadMenu(SelectedMenuItemGroup.RawMenuItemGroup.Id, newRawMenuItem.Id);
        //                    }
        //                }
        //            }
        //        },
        //        o => SelectedMenuItem != null);
        //    }
        //}

        ///// <summary>
        ///// Команда копирования выбранного элемента прошлого меню
        ///// </summary>
        //public ICommand CopySelectedOldMenuItemCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<object>(o =>
        //        {
        //            var newRawMenuItem = SelectedOldMenuItem.RawMenuItem.Copy(isLocal: true);
        //            newRawMenuItem.MenuId = Menu.RawMenu.Id;

        //            if (CashDeskLib.CashDesk.Instance.AddMenuItem(newRawMenuItem))
        //            {
        //                // HACK: чтобы не усложнять код проверкой и добавлением при необходимости несуществующих групп элементов меню, 
        //                // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
        //                ReloadMenu(SelectedOldMenuItemGroup.RawMenuItemGroup.Id, newRawMenuItem.Id);
        //            }
        //        },
        //        o => SelectedOldMenuItem != null);
        //    }
        //}

        //void ReloadMenu(string menuItemGroupId, Guid menuItemId)
        //{
        //    Menu = new DataModel.Menu(CashDeskLib.CashDesk.Instance.LoadMenus(DateTime.Today, 1).FirstOrDefault());
        //    var selectedMenuItemGroup = Menu.MenuGroups.FirstOrDefault(g => g.RawMenuItemGroup.Id == menuItemGroupId);
        //    SelectedMenuItemGroup = selectedMenuItemGroup;
        //    if (selectedMenuItemGroup == null)
        //        SelectedMenuItem = null;
        //    else
        //    {
        //        var selectedMenuItem = selectedMenuItemGroup.Items.FirstOrDefault(item => item.RawMenuItem.Id == menuItemId);
        //        SelectedMenuItem = selectedMenuItem;
        //    }
        //}

        ///// <summary>
        ///// Команда удаления выбранного локального элемента меню
        ///// </summary>
        //public ICommand DeleteSelectedMenuItemCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<object>(o =>
        //        {
        //            if (LocalMenuItemDelete != null)
        //            {
        //                var eventArgs = new CancelEventArgs();
        //                LocalMenuItemDelete(this, eventArgs);
        //                if (!eventArgs.Cancel && CashDeskLib.CashDesk.Instance.DeleteMenuItem(SelectedMenuItem.RawMenuItem))
        //                {
        //                    SelectedMenuItemGroup.Items.Remove(SelectedMenuItem);
        //                    SelectedMenuItem = null;
                        
        //                    // при удалении записи группа может оказаться пустой, тогда ее нужно удалить
        //                    if (SelectedMenuItemGroup.Items.Count == 0)
        //                    {
        //                        Menu.MenuGroups.Remove(SelectedMenuItemGroup);
        //                        SelectedMenuItemGroup = Menu.MenuGroups.Count == 0 ? null : Menu.MenuGroups[0];
        //                    }
        //                }
        //            }
        //        },
        //        o => SelectedMenuItem != null && SelectedMenuItem.IsLocal);
        //    }
        //}

        ///// <summary>
        ///// Команда изменения количества для выбранного локального элемента меню
        ///// </summary>
        //public ICommand ChangeCountSelectedMenuItemCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<object>(o =>
        //        {
        //            if (ChangeCount != null)
        //            {
        //                var eventArgs = new ChangeCountEventArgs { Type = typeof(DataModel.MenuItem), Value = SelectedMenuItem.Count };
        //                ChangeCount(this, eventArgs);
        //                if (!eventArgs.Cancel && eventArgs.Value != SelectedMenuItem.Count)
        //                {
        //                    if (CashDeskLib.CashDesk.Instance.ChangeMenuItemCount(SelectedMenuItem.RawMenuItem, eventArgs.Value))
        //                    {
        //                        // HACK: чтобы не усложнять код перемещением записи с новым количеством, 
        //                        // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
        //                        ReloadMenu(SelectedMenuItemGroup.RawMenuItemGroup.Id, SelectedMenuItem.RawMenuItem.Id);
        //                    }
        //                }
        //            }
        //        },
        //        o => SelectedMenuItem != null && SelectedMenuItem.IsLocal);
        //    }
        //}

        ///// <summary>
        ///// Команда переключения режима сервиса меню
        ///// </summary>
        //public ICommand ChangeMenuServiceModeCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<object>(o =>
        //        {
        //            IsMenuServiceMode = !IsMenuServiceMode;
        //        });
        //    }
        //}

        ///// <summary>
        ///// Добавление элемента заказа
        ///// </summary>
        ///// <param name="menuItem"></param>
        //void AddOrderItem(DataModel.MenuItem menuItem)
        //{
        //    if (menuItem == null || menuItemLocked)
        //        return;

        //    menuItemLocked = true;
        //    // задержка для блокировки двойного срабатывания при нажатии
        //    Timer timer = new Timer(100)
        //    {
        //        AutoReset = true
        //    };
        //    timer.Elapsed += Timer_Elapsed;
        //    timer.Start();

        //    AddOrderItemEvent?.Invoke(this, new DataModelEventArgs<DataModel.MenuItem> { Data = menuItem });
        //}

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            menuItemLocked = false;
        }

        bool menuItemLocked = false;

        ///// <summary>
        ///// Установить клиента по коду пропуска
        ///// </summary>
        ///// <param name="cardCode"></param>
        //public void SetClient(uint cardCode)
        //{
        //    // в режиме сервиса меню изменение клиента не отрабатываем
        //    if (CashDeskMode == CashDeskMode.Work && lastCardCode != cardCode)
        //    {
        //        lastCardCode = cardCode;
        //        SetClient(CashDeskLib.CashDesk.Instance.GetClient(cardCode));
        //    }
        //}

        //uint lastCardCode = 0;

        //void SetClient(CashDeskLib.DataModel.Client client)
        //{
        //    if (client == null)
        //        Client = DataModel.Client.NoCard;
        //    else
        //    {
        //        Client = new DataModel.Client(client);
        //    }
        //}

        ///// <summary>
        ///// Обновить возможные варианты оплаты
        ///// </summary>
        //public void PaymentAbilitiesRefresh()
        //{
        //    // блокировка на случай вызова из другого потока, например, по событию проверки оборудования
        //    lock (PaymentAbilities)
        //    {
        //        try
        //        {
        //            PaymentAbilities.Refresh();
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PaymentAbilities)));
        //        }
        //        catch
        //        {
        //        }
        //    }
        //}

        ///// <summary>
        ///// Событие добавления в заказ выбранного элемента меню
        ///// </summary>
        //public event EventHandler<DataModelEventArgs<DataModel.MenuItem>> AddOrderItemEvent;

        //public event EventHandler<DataModelEventArgs<CashDeskMode>> CashDeskModeChangedEvent;

        ///// <summary>
        ///// Событие для изменения количества 
        ///// </summary>
        //public event EventHandler<ChangeCountEventArgs> ChangeCount;

        ///// <summary>
        ///// Событие для подтверждения удаления локального элемента меню
        ///// </summary>
        //public event EventHandler<CancelEventArgs> LocalMenuItemDelete;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
