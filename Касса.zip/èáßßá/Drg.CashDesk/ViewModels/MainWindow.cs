﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Timers;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public MainWindow()
        {
            PaymentAbilities = new PaymentAbilities();

            Clear();

            // загрузка меню
            var menus = CashDeskLib.CashDesk.Instance.LoadMenus(DateTime.Today, 2);
            if (menus.Any())
            {
                var lastMenu = menus.Last();
                if (lastMenu.Date == DateTime.Today)
                    menu = new DataModel.Menu(lastMenu);
                else
                    oldMenu = new DataModel.Menu(lastMenu);

                if (oldMenu == null)
                    oldMenu = new DataModel.Menu(menus[0]);
            }
        }

        /// <summary>
        /// Очистка возможных вариантов оплаты, заказа и клиента
        /// </summary>
        public void Clear()
        {
            lastCardCode = 0;

            Client = DataModel.Client.Empty;
            Order = new DataModel.Order();

            PaymentAbilities.Order = Order;
            PaymentAbilities.Client = Client;
            //PaymentAbilitiesRefresh();
        }

        /// <summary>
        /// Индикатор того, что находимся в режиме сервиса меню
        /// </summary>
        public bool IsMenuServiceMode
        {
            get => isMenuServiceMode;
            set
            {
                if (isMenuServiceMode != value)
                {
                    isMenuServiceMode = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMenuServiceMode)));

                    // при переходе в режим сервиса меню обнуляем клиента и заказ
                    if (isMenuServiceMode)
                    {
                        Clear();
                        //SetOldMenu();
                    }
                }
            }
        }
        bool isMenuServiceMode;

        /// <summary>
        /// Меню
        /// </summary>
        public DataModel.Menu Menu
        {
            get => menu;
            set
            {
                if (menu != value)
                {
                    menu = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
                }
            }
        }
        DataModel.Menu menu = null;

        /// <summary>
        /// Предыдущее меню
        /// </summary>
        public DataModel.Menu OldMenu => oldMenu;
        DataModel.Menu oldMenu = null;

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilities PaymentAbilities { get; private set; }

        /// <summary>
        /// Клиент
        /// </summary>
        public DataModel.Client Client 
        {
            get => client;
            private set
            {
                if (client != value)
                {
                    client = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Client)));

                    PaymentAbilities.Client = Client;
                    //PaymentAbilitiesRefresh();
                }
            }
        }
        DataModel.Client client;

        /// <summary>
        /// Заказ
        /// </summary>
        public DataModel.Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    SelectedOrderItem = null;
                }
            }
        }
        DataModel.Order order = null;

        /// <summary>
        /// Выбранная позиция заказа
        /// </summary>
        public DataModel.OrderItem SelectedOrderItem
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        DataModel.OrderItem selectedOrderItem = null;

        /// <summary>
        /// Выбранная группа элементов прошлого меню
        /// </summary>
        public DataModel.MenuItemGroup SelectedOldMenuItemGroup
        {
            get => selectedOldMenuItemGroup;
            set
            {
                if (selectedOldMenuItemGroup != value)
                {
                    selectedOldMenuItemGroup = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOldMenuItemGroup)));
                }
            }
        }
        DataModel.MenuItemGroup selectedOldMenuItemGroup;

        /// <summary>
        /// Выбранная группа элементов меню
        /// </summary>
        public DataModel.MenuItemGroup SelectedMenuItemGroup
        {
            get => selectedMenuItemGroup;
            set
            {
                if (selectedMenuItemGroup != value)
                {
                    selectedMenuItemGroup = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItemGroup)));
                }
            }
        }
        DataModel.MenuItemGroup selectedMenuItemGroup;

        /// <summary>
        /// Выбранная позиция прошлого меню
        /// </summary>
        public DataModel.MenuItem SelectedOldMenuItem
        {
            get => selectedOldMenuItem;
            set
            {
                if (selectedOldMenuItem != value)
                {
                    selectedOldMenuItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOldMenuItem)));
                }
            }
        }
        DataModel.MenuItem selectedOldMenuItem = null;

        /// <summary>
        /// Выбранная позиция меню
        /// </summary>
        public DataModel.MenuItem SelectedMenuItem
        {
            get => selectedMenuItem;
            set
            {
                if (selectedMenuItem != value)
                {
                    selectedMenuItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuItem)));

                    if (selectedMenuItem == null)
                        return;
                }

                if (!IsMenuServiceMode)
                {
                    // добавление элемента заказа
                    AddOrderItem(selectedMenuItem);
                }
            }
        }
        DataModel.MenuItem selectedMenuItem = null;

        /// <summary>
        /// Команда копирования выбранного элемента меню
        /// </summary>
        public ICommand CopySelectedMenuItemCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (ChangeCount != null)
                    {
                        var eventArgs = new ChangeCountEventArgs { Type = typeof(DataModel.MenuItem), Value = SelectedMenuItem.Count };
                        ChangeCount(this, eventArgs);
                        if (!eventArgs.Cancel)
                        {
                            var newRawMenuItem = SelectedMenuItem.RawMenuItem.Copy(eventArgs.Value);

                            // записать копию элемента меню в базу
                            if (CashDeskLib.CashDesk.Instance.AddMenuItem(newRawMenuItem))
                            {
                                // HACK: чтобы не усложнять код поиском места для записи с новым количеством, 
                                // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
                                ReloadMenu(SelectedMenuItemGroup.RawMenuItemGroup.Id, newRawMenuItem.Id);
                            }
                        }
                    }
                },
                o => SelectedMenuItem != null);
            }
        }

        /// <summary>
        /// Команда копирования выбранного элемента прошлого меню
        /// </summary>
        public ICommand CopySelectedOldMenuItemCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    var newRawMenuItem = SelectedOldMenuItem.RawMenuItem.Copy(isLocal: true);
                    newRawMenuItem.MenuId = Menu.RawMenu.Id;

                    if (CashDeskLib.CashDesk.Instance.AddMenuItem(newRawMenuItem))
                    {
                        // HACK: чтобы не усложнять код проверкой и добавлением при необходимости несуществующих групп элементов меню, 
                        // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
                        ReloadMenu(SelectedOldMenuItemGroup.RawMenuItemGroup.Id, newRawMenuItem.Id);
                    }
                },
                o => SelectedOldMenuItem != null);
            }
        }

        void ReloadMenu(string menuItemGroupId, Guid menuItemId)
        {
            Menu = new DataModel.Menu(CashDeskLib.CashDesk.Instance.LoadMenus(DateTime.Today, 1).FirstOrDefault());
            var selectedMenuItemGroup = Menu.MenuGroups.FirstOrDefault(g => g.RawMenuItemGroup.Id == menuItemGroupId);
            SelectedMenuItemGroup = selectedMenuItemGroup;
            if (selectedMenuItemGroup == null)
                SelectedMenuItem = null;
            else
            {
                var selectedMenuItem = selectedMenuItemGroup.Items.FirstOrDefault(item => item.RawMenuItem.Id == menuItemId);
                SelectedMenuItem = selectedMenuItem;
            }
        }

        /// <summary>
        /// Команда удаления выбранного локального элемента меню
        /// </summary>
        public ICommand DeleteSelectedMenuItemCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (LocalMenuItemDelete != null)
                    {
                        var eventArgs = new CancelEventArgs();
                        LocalMenuItemDelete(this, eventArgs);
                        if (!eventArgs.Cancel && CashDeskLib.CashDesk.Instance.DeleteMenuItem(SelectedMenuItem.RawMenuItem))
                        {
                            SelectedMenuItemGroup.Items.Remove(SelectedMenuItem);
                            SelectedMenuItem = null;
                        
                            // при удалении записи группа может оказаться пустой, тогда ее нужно удалить
                            if (SelectedMenuItemGroup.Items.Count == 0)
                            {
                                Menu.MenuGroups.Remove(SelectedMenuItemGroup);
                                SelectedMenuItemGroup = Menu.MenuGroups.Count == 0 ? null : Menu.MenuGroups[0];
                            }
                        }
                    }
                },
                o => SelectedMenuItem != null && SelectedMenuItem.IsLocal);
            }
        }

        /// <summary>
        /// Команда изменения количества для выбранного локального элемента меню
        /// </summary>
        public ICommand ChangeCountSelectedMenuItemCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (ChangeCount != null)
                    {
                        var eventArgs = new ChangeCountEventArgs { Type = typeof(DataModel.MenuItem), Value = SelectedMenuItem.Count };
                        ChangeCount(this, eventArgs);
                        if (!eventArgs.Cancel && eventArgs.Value != SelectedMenuItem.Count)
                        {
                            if (CashDeskLib.CashDesk.Instance.ChangeMenuItemCount(SelectedMenuItem.RawMenuItem, eventArgs.Value))
                            {
                                // HACK: чтобы не усложнять код перемещением записи с новым количеством, 
                                // полностью перегрузим меню и установим активными группу и элемент, соответствующие исходным
                                ReloadMenu(SelectedMenuItemGroup.RawMenuItemGroup.Id, SelectedMenuItem.RawMenuItem.Id);
                            }
                        }
                    }
                },
                o => SelectedMenuItem != null && SelectedMenuItem.IsLocal);
            }
        }

        /// <summary>
        /// Команда переключения режима сервиса меню
        /// </summary>
        public ICommand ChangeMenuServiceModeCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    IsMenuServiceMode = !IsMenuServiceMode;
                });
            }
        }

        /// <summary>
        /// Команда оплаты
        /// </summary>
        public ICommand PayCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (PaymentEvent != null && Order != null && Order.Total > 0)
                    {
                        // свернуть заказ до оплаты
                        Order.Collapse();

                        PaymentInfo paymentInfo = new PaymentInfo(PaymentAbilities, Payment.None, Order.Total);
                        List<Payment> noPayments = paymentInfo.Payments.Select(kvp => kvp.Key).ToList();
                        Payment cancelPayment = Payment.None;
                        while (noPayments.Any() && cancelPayment != Payment.None)
                        {
                            var eventArgs = new DataModelEventArgs<PaymentInfo> { Data = paymentInfo };
                            PaymentEvent(this, eventArgs);
                            if (eventArgs.Data == null)
                            {
                                // досрочный выход по отмене
                                break;
                            }
                            else
                            {
                                // обработать результат оплаты

                                // TODO: разобраться - как оплачивать картой, когда печатать чек и что делать в случае ошибки
                                // возможно, использовать шаблон проектирования "Цепочка обязанностей" (Chain of Responsibility) 
                                // и только в случе успешого выполнения всех необходимых операций завершать оплату,
                                // в т.ч. записывать в БД

                                // TODO: перед записью оплаты нужно распределить сумму оплаты
                                // при оплате талонами при некратном превышении стоимости талона раскидать оплату по позициям заказа
                                // нужно для формирования отчета ФО, где указывается форма оплата для всех позиций
                                //CashDeskLib.CashDesk.Instance.SaveOrderAndPayment(Client.RawClient, Order.ToRawOrder(), eventArgs.Data.Payments);
                                cancelPayment = CashDeskLib.CashDesk.Instance.Pay(Client.RawClient, Order.ToRawOrder(), eventArgs.Data.Payments, out noPayments);
                                if (cancelPayment == Payment.None && !noPayments.Any())
                                {
                                    // успешная оплата
                                    Clear();
                                }
                                else
                                {
                                    if (cancelPayment != Payment.None)
                                    {
                                        paymentInfo.Payments.Remove(cancelPayment);
                                    }

                                    if (noPayments.Any())
                                    {
                                        // не все варианты оплаты удалось выполнить
                                        PaymentAbilities.SetPayments(false, noPayments);
                                        paymentInfo = new PaymentInfo(PaymentAbilities, Payment.None, Order.Total);
                                    }
                                }
                            }
                        }
                    }
                },
                o => Order.Total > 0);
            }
        }

        /// <summary>
        /// Команда оплаты
        /// </summary>
        //public ICommand PaymentCommand
        //{
        //    get
        //    {
        //        return new RelayCommand<string>(payment =>
        //        {
        //            if (PaymentEvent != null && Order != null && Order.Total > 0)
        //            {
        //                PaymentInfo paymentInfo = new PaymentInfo(PaymentAbilities, (Payment)int.Parse(payment), Order.Total);
        //                var eventArgs = new DataModelEventArgs<PaymentInfo> { Data = paymentInfo };
        //                PaymentEvent(this, eventArgs);
        //                if (eventArgs.Data != null)
        //                {
        //                    // обработать результат оплаты
        //                    Order.Collapse();
        //                    // TODO: перед записью оплаты нужно распределить сумму оплаты
        //                    // при оплате талонами при некратном превышении стоимости талона раскидать оплату по позициям заказа
        //                    // нужно для формирования отчета ФО, где указывается форма оплата для всех позиций
        //                    CashDeskLib.CashDesk.Instance.SaveOrderAndPayment(Client.RawClient, Order.ToRawOrder(), eventArgs.Data.Payments);
        //                    Clear();
        //                }
        //            }
        //        });
        //    }
        //}

        /// <summary>
        /// Добавление элемента заказа
        /// </summary>
        /// <param name="menuItem"></param>
        void AddOrderItem(DataModel.MenuItem menuItem)
        {
            if (menuItem == null || menuItemLocked)
                return;

            menuItemLocked = true;
            // задержка для блокировки двойного срабатывания при нажатии
            Timer timer = new Timer(100)
            {
                AutoReset = true
            };
            timer.Elapsed += Timer_Elapsed;
            timer.Start();

            var newOrderItem = new DataModel.OrderItem(menuItem, Order.Items.Count + 1);
            Order.Items.Add(newOrderItem);
            SelectedOrderItem = newOrderItem;

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));

            //// пересчитать возможности оплаты с учетом суммы заказа
            //PaymentAbilitiesRefresh();
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            menuItemLocked = false;
        }

        bool menuItemLocked = false;

        /// <summary>
        /// Установить клиента по коду пропуска
        /// </summary>
        /// <param name="cardCode"></param>
        public void SetClient(uint cardCode)
        {
            // в режиме сервиса меню изменение клиента не отрабатываем
            if (IsMenuServiceMode)
                return;

            if (lastCardCode != cardCode)
            {
                lastCardCode = cardCode;
                SetClient(CashDeskLib.CashDesk.Instance.GetClient(cardCode));
            }
        }

        uint lastCardCode = 0;

        void SetClient(CashDeskLib.DataModel.Client client)
        {
            if (client == null)
                Client = DataModel.Client.NoCard;
            else
            {
                if (!client.IsPhotoLoaded && client.Photo == null)
                    CashDeskLib.CashDesk.Instance.LoadPhoto(client);
                Client = new DataModel.Client(client);
            }

            PaymentAbilities.Client = Client;
            //PaymentAbilitiesRefresh();
        }

        ///// <summary>
        ///// Обновить возможные варианты оплаты
        ///// </summary>
        //public void PaymentAbilitiesRefresh()
        //{
        //    // блокировка на случай вызова из другого потока, например, по событию проверки оборудования
        //    lock (PaymentAbilities)
        //    {
        //        try
        //        {
        //            PaymentAbilities.Refresh();
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PaymentAbilities)));
        //        }
        //        catch
        //        {
        //        }
        //    }
        //}

        /// <summary>
        /// Команда создания нового заказа
        /// </summary>
        public ICommand NewOrderCommand
        {
            get
            {
                return new RelayCommand<DataModel.OrderItem>(orderItem =>
                {
                    // переспросить создание нового заказа, если есть элементы в текущем
                    if (Order.Items.Count > 0 && NewOrder != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        NewOrder(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    Clear();
                });
            }
        }

        /// <summary>
        /// Команда изменения количества выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemChangeCountCommand
        {
            get
            {
                return new RelayCommand<DataModel.OrderItem>(orderItem =>
                {
                    if (ChangeCount != null)
                    {
                        var eventArgs = new ChangeCountEventArgs { Type = typeof(DataModel.OrderItem), Value = orderItem.Count };
                        ChangeCount(this, eventArgs);
                        if (!eventArgs.Cancel && orderItem.Count != eventArgs.Value)
                        {
                            orderItem.Count = eventArgs.Value;
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                        }
                    }
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда выбора клиента из списка
        /// </summary>
        public ICommand SelectClientCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (SelectClient != null)
                    {
                        var eventArgs = new DataModelEventArgs<CashDeskLib.DataModel.Client>();
                        SelectClient(this, eventArgs);
                        if (eventArgs.Data != null)
                            SetClient(eventArgs.Data);
                    }
                });
            }
        }

        /// <summary>
        /// Команда удаления выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemDeleteCommand
        {
            get
            {
                return new RelayCommand<DataModel.OrderItem>(orderItem =>
                {
                    // переспросить удаление выбранного элемента заказа
                    if (OrderItemDelete != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        OrderItemDelete(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    var orderItemIndex = Order.Items.IndexOf(orderItem);
                    Order.Items.Remove(orderItem);

                    // сделать активной какую-то другую запись
                    if (orderItemIndex < Order.Items.Count)
                        SelectedOrderItem = Order.Items[orderItemIndex];
                    else if (Order.Items.Count == 0)
                        SelectedOrderItem = null;
                    else
                        SelectedOrderItem = Order.Items.Last();

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));

                    //// пересчитать возможности оплаты с учетом суммы заказа
                    //PaymentAbilitiesRefresh();
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда сворачивания заказа
        /// </summary>
        public ICommand OrderCollapseCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    var productId = SelectedOrderItem.MenuItem.RawMenuItem.ProductId;
                    Order.Collapse();
                    SelectedOrderItem = Order.Items.First(item => item.MenuItem.RawMenuItem.ProductId == productId);
                },
                o =>
                {
                    if (SelectedOrderItem == null) return false;

                    var groups = Order.Items.GroupBy(orderItem => orderItem.MenuItem.RawMenuItem.ProductId);
                    return groups.Any(g => g.Count() > 1);
                });
            }
        }

        /// <summary>
        /// Событие оплаты
        /// </summary>
        public event EventHandler<DataModelEventArgs<PaymentInfo>> PaymentEvent;

        /// <summary>
        /// Событие для выбора клиента из списка
        /// </summary>
        public event EventHandler<DataModelEventArgs<CashDeskLib.DataModel.Client>> SelectClient;

        /// <summary>
        /// Событие для изменения количества 
        /// </summary>
        public event EventHandler<ChangeCountEventArgs> ChangeCount;

        /// <summary>
        /// Событие для подтверждения удаления локального элемента меню
        /// </summary>
        public event EventHandler<CancelEventArgs> LocalMenuItemDelete;

        /// <summary>
        /// Событие для подтверждения удаления элемента заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> OrderItemDelete;

        /// <summary>
        /// Событие для подтверждения создания нового заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> NewOrder;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
