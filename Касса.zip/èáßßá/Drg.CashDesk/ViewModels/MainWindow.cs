﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для MainWindow.xaml
    /// </summary>
    public class MainWindow : INotifyPropertyChanged
    {
        public MainWindow()
        {
            menu = new Menu(CashDeskLib.CashDesk.Instance.GetMenu());
            if (menu != null && menu.MenuGroups.Count > 0)
            {
                SelectMenuItemGroup(menu.MenuGroups[0]);
                MenuItems = menu.MenuGroups[0].Items;
            }

            Order = new Order();
            Client = Client.Empty;
            PaymentAbilities = new PaymentAbilities { Client = Client };
            PaymentAbilities.Refresh();
        }

        /// <summary>
        /// Возможные варианты оплаты
        /// </summary>
        public PaymentAbilities PaymentAbilities { get; private set; }

        /// <summary>
        /// Клиент
        /// </summary>
        public Client Client { get; private set; }

        /// <summary>
        /// Заказ
        /// </summary>
        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    SelectedOrderItem = null;
                }
            }
        }
        Order order = null;

        /// <summary>
        /// Выбранная позиция заказа
        /// </summary>
        public OrderItem SelectedOrderItem
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        OrderItem selectedOrderItem = null;


        /// <summary>
        /// Список элементов выбранной группы меню или найденных в результате поиска
        /// </summary>
        public ObservableCollection<MenuItem> MenuItems
        {
            get => menuItems;
            set
            {
                if (menuItems != value)
                {
                    menuItems = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MenuItems)));
                }
            }
        }
        ObservableCollection<MenuItem> menuItems = null;

        /// <summary>
        /// Команда выбора группы элементов меню
        /// </summary>
        public ICommand SelectMenuItemGroupCommand
        {
            get
            {
                return new RelayCommand<MenuItemGroup>(menuItemGroup =>
                {
                    SelectMenuItemGroup(menuItemGroup);
                    MenuItems = menuItemGroup.Items;
                });
            }
        }

        /// <summary>
        /// Команда выбора элемента меню
        /// </summary>
        public ICommand SelectMenuItemCommand
        {
            get
            {
                return new RelayCommand<MenuItem>(menuItem =>
                {
                    foreach (var item in MenuItems)
                    {
                        item.IsSelected = item == menuItem;
                    }

                    var newOrderItem = new OrderItem(menuItem, Order.Items.Count + 1);
                    Order.Items.Add(newOrderItem);
                    SelectedOrderItem = newOrderItem;

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                });
            }
        }

        /// <summary>
        /// Установить клиента по коду пропуска
        /// </summary>
        /// <param name="cardCode"></param>
        public void SetClient(uint cardCode)
        {
            if (Client.RawClient == null || Client.RawClient.CardCode != cardCode)
                SetClient(CashDeskLib.CashDesk.Instance.GetClient(cardCode));
        }

        void SetClient(CashDeskLib.DataModel.Client client)
        {
            Client = client == null ? Client.Empty : new Client(client);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Client)));

            PaymentAbilities.Client = Client;
            PaymentAbilitiesRefresh();
        }

        /// <summary>
        /// Обновить возможные варианты оплаты
        /// </summary>
        public void PaymentAbilitiesRefresh()
        {
            // блокировка на случай вызова из другого потока, например, по событию проверки оборудования
            lock (PaymentAbilities)
            {
                PaymentAbilities.Refresh();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PaymentAbilities)));
            }
        }

        /// <summary>
        /// Команда создания нового заказа
        /// </summary>
        public ICommand NewOrderCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить создание нового заказа, если есть элементы в текущем
                    if (Order.Items.Count > 0 && NewOrder != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        NewOrder(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    Order = new DataModel.Order();
                });
            }
        }

        /// <summary>
        /// Команда изменения количества выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemChangeCountCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    if (OrderItemChangeCount != null)
                    {
                        var eventArgs = new DataModelEventArgs<decimal> { Data = orderItem.Count };
                        OrderItemChangeCount(this, eventArgs);
                        orderItem.Count = eventArgs.Data;

                        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                    }
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда выбора клиента из списка
        /// </summary>
        public ICommand SelectClientCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    if (SelectClient != null)
                    {
                        var eventArgs = new DataModelEventArgs<CashDeskLib.DataModel.Client>();
                        SelectClient(this, eventArgs);
                        if (eventArgs.Data != null)
                            SetClient(eventArgs.Data);
                    }
                });
            }
        }

        /// <summary>
        /// Команда удаления выбранного элемента заказа
        /// </summary>
        public ICommand OrderItemDeleteCommand
        {
            get
            {
                return new RelayCommand<OrderItem>(orderItem =>
                {
                    // переспросить удаление выбранного элемента заказа
                    if (OrderItemDelete != null)
                    {
                        CancelEventArgs cancelEventArgs = new CancelEventArgs();
                        OrderItemDelete(this, cancelEventArgs);
                        if (cancelEventArgs.Cancel)
                            return;
                    }

                    var orderItemIndex = Order.Items.IndexOf(orderItem);
                    Order.Items.Remove(orderItem);

                    // сделать активной какую-то другую запись
                    if (orderItemIndex < Order.Items.Count)
                        SelectedOrderItem = Order.Items[orderItemIndex];
                    else if (Order.Items.Count == 0)
                        SelectedOrderItem = null;
                    else
                        SelectedOrderItem = Order.Items.Last();

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                },
                orderItem => orderItem != null);
            }
        }

        /// <summary>
        /// Команда сворачивания заказа
        /// </summary>
        public ICommand OrderCollapseCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    var selected = SelectedOrderItem?.MenuItem;
                    Order.Collapse();
                    // сделать активной запись, которая была до сворачивания
                    if (selected != null)
                        SelectedOrderItem = Order.Items.First(item => item.MenuItem == selected);
                });
            }
        }

        /// <summary>
        /// Событие для выбора клиента из списка
        /// </summary>
        public event EventHandler<DataModelEventArgs<CashDeskLib.DataModel.Client>> SelectClient;

        /// <summary>
        /// Событие для изменения количества в элементе заказа
        /// </summary>
        public event EventHandler<DataModelEventArgs<decimal>> OrderItemChangeCount;

        /// <summary>
        /// Событие для подтверждения удаления элемента заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> OrderItemDelete;

        /// <summary>
        /// Событие для подтверждения создания нового заказа
        /// </summary>
        public event EventHandler<CancelEventArgs> NewOrder;

        /// <summary>
        /// Выбрать группу элементов меню
        /// </summary>
        /// <param name="menuItemGroup"></param>
        private void SelectMenuItemGroup(MenuItemGroup menuItemGroup)
        {
            foreach (var menuGroup in menu.MenuGroups)
            {
                menuGroup.IsSelected = menuGroup == menuItemGroup;
            }
        }

        /// <summary>
        /// Меню
        /// </summary>
        public Menu Menu => menu;
        Menu menu;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

    }
}
