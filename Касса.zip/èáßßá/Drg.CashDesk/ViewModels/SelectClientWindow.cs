﻿using Drg.CashDesk.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для SelectClientWindow.xaml
    /// </summary>
    public class SelectClientWindow : INotifyPropertyChanged
    {
        public SelectClientWindow()
        {
            allClients = new ObservableCollection<ClientListItem>(CashDeskLib.CashDesk.Instance.GetClients().Select(client => new ClientListItem(client)));
            SetClients();
        }

        public string SearchText
        {
            get => searchText;
            set
            {
                if (searchText != value)
                {
                    searchText = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SearchText)));
                    SetClients();
                }
            }
        }
        string searchText;

        void SetClients()
        {
            bool clientsChanged = true;
            //if (string.IsNullOrEmpty(searchText) || searchText.Length < 3)
            //{
            //    if (Clients == allClients)
            //        clientsChanged = false;
            //    else
            //        Clients = allClients;
            //}
            //else
                Clients = new ObservableCollection<ClientListItem>(allClients.Where(client => client.MathText(searchText)));

            foreach (var client in Clients)
            {
                client.SetBoldText(searchText);
            }

            if (clientsChanged)
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Clients)));
        }

        public ObservableCollection<ClientListItem> Clients { get; private set; }
        //{
        //    get => clients;
        //    set
        //    {
        //        if (clients != value)
        //        {
        //            clients = value;
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Clients)));
        //        }
        //    }
        //}
        //ObservableCollection<ClientListItem> clients = null;

        ObservableCollection<ClientListItem> allClients;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
