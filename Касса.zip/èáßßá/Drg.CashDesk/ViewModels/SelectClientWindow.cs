﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDesk.ViewModels
{
    /// <summary>
    /// View-модель для SelectClientWindow.xaml
    /// </summary>
    public class SelectClientWindow : INotifyPropertyChanged
    {
        // TODO: добавить выключение кнопки Ok при отсутствии выбора в списке
        // TODO: выбранную запись показывать увеличенной и с фоткой
        // TODO: выполнить стресс-тест поиска работника по полному списку людей
        public SelectClientWindow()
        {
            allClients = new ObservableCollection<ClientListItem>(CashDeskLib.CashDesk.Instance.GetClients().Select(client => new ClientListItem(client)));
            Clients = new ObservableCollection<ClientListItem>(allClients);
        }

        /// <summary>
        /// Текст поиска - табельный или ФИО
        /// </summary>
        public string SearchText
        {
            get => searchText;
            set
            {
                if (searchText != value)
                {
                    searchText = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SearchText)));
                    SetClients();
                }
            }
        }
        string searchText;
        string lastSearchText = "";

        void SetClients()
        {
            if (string.IsNullOrEmpty(searchText))
                Clients = new ObservableCollection<ClientListItem>(allClients);
            else if (searchText.Length < lastSearchText.Length)
                Clients = new ObservableCollection<ClientListItem>(allClients.Where(client => client.MathText(searchText)));
            else
            {
                for (int i = Clients.Count - 1; i >= 0; i--)
                {
                    if (!Clients[i].MathText(searchText))
                        Clients.RemoveAt(i);
                }
            }

            foreach (var client in Clients)
            {
                client.SetBoldText(searchText);
            }

            lastSearchText = searchText ?? "";
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Clients)));
        }

        /// <summary>
        /// Активный клиент
        /// </summary>
        public ClientListItem SelectedClient
        {
            get => selectedClient;
            set
            {
                if (selectedClient != value)
                {
                    selectedClient = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedClient)));
                    if (selectedClient != null && !selectedClient.RawClient.IsPhotoLoaded)
                    {
                        CashDeskLib.CashDesk.Instance.LoadPhoto(selectedClient.RawClient);
                        selectedClient.ReloadPhoto();
                    }
                }
            }
        }
        ClientListItem selectedClient;

        /// <summary>
        /// Список клиентов
        /// </summary>
        public ObservableCollection<ClientListItem> Clients { get; private set; }

        ObservableCollection<ClientListItem> allClients;

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    /// <summary>
    /// Отображение клиента в списке для поиска
    /// </summary>
    public class ClientListItem : DataModel.Client, INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="rawClient">объект клиента</param>
        public ClientListItem(CashDeskLib.DataModel.Client rawClient)
            : base(rawClient)
        {
            SetTabNum(RawClient.TabNum);
            SetFIO(RawClient.FIO);
        }

        /// <summary>
        /// Перезагрузить фото
        /// </summary>
        public override void ReloadPhoto()
        {
            base.ReloadPhoto();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Photo)));
        }

        /// <summary>
        /// Проверка на соответствие тексту
        /// </summary>
        /// <param name="text">текст для поиска: только цифры - поиск по табельному, символы - поиск по ФИО</param>
        /// <returns></returns>
        public bool MathText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return true;

            if (text.Any(ch => char.IsDigit(ch)))
            {
                // поиск по табельному
                return RawClient.TabNum.IndexOf(text) >= 0;
            }
            else
            {
                // поиск по ФИО
                return RawClient.FIO.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0;
            }
        }

        /// <summary>
        /// Установить выделенный текст
        /// </summary>
        /// <param name="text">текст для поиска: только цифры - поиск по табельному, символы - поиск по ФИО</param>
        public void SetBoldText(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                SetTabNum(RawClient.TabNum);
                SetFIO(RawClient.FIO);
                return;
            }

            if (text.Any(ch => char.IsDigit(ch)))
            {
                // поиск по табельному
                int index = RawClient.TabNum.IndexOf(text);
                if (index < 0)
                    SetTabNum(RawClient.TabNum);
                else
                    SetTabNum(
                        RawClient.TabNum.Substring(0, index),
                        RawClient.TabNum.Substring(index, text.Length),
                        RawClient.TabNum.Substring(index + text.Length));
            }
            else
            {
                // поиск по ФИО
                int index = RawClient.FIO.IndexOf(text, StringComparison.CurrentCultureIgnoreCase);
                if (index < 0)
                    SetFIO(RawClient.FIO);
                else
                    SetFIO(
                        RawClient.FIO.Substring(0, index),
                        RawClient.FIO.Substring(index, text.Length),
                        RawClient.FIO.Substring(index + text.Length));
            }
        }

        void SetTabNum(string tabNum1, string tabNum2 = null, string tabNum3 = null)
        {
            if (TabNum1 != tabNum1)
            {
                TabNum1 = tabNum1;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum1)));
            }

            if (TabNum2 != tabNum2)
            {
                TabNum2 = tabNum2;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum2)));
            }

            if (TabNum3 != tabNum3)
            {
                TabNum3 = tabNum3;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TabNum3)));
            }
        }

        void SetFIO(string fio1, string fio2 = null, string fio3 = null)
        {
            if (FIO1 != fio1)
            {
                FIO1 = fio1;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO1)));
            }

            if (FIO2 != fio2)
            {
                FIO2 = fio2;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO2)));
            }

            if (FIO3 != fio3)
            {
                FIO3 = fio3;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FIO3)));
            }
        }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum1 { get; private set; }
        public string TabNum2 { get; private set; }
        public string TabNum3 { get; private set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO1 { get; private set; }
        public string FIO2 { get; private set; }
        public string FIO3 { get; private set; }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }
}
