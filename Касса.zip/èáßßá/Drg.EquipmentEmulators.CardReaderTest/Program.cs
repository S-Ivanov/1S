﻿using System;
using System.IO;
using Drg.Equipment.CardReader;

namespace Drg.EquipmentEmulators.CardReaderTest
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Программа проверки работы эмулятора считывателя пропусков.");

            string[] args = System.Environment.GetCommandLineArgs();
            string exeName = args[0];
            string path = Path.GetDirectoryName(exeName);
            string fileName = Path.Combine(path, "CardNumber.txt");

            Console.WriteLine($"Редактируйте в блокноте файл {fileName}.");
            Console.WriteLine("После редактирования сохраните файл (блокнот закрывать необязательно).");

            CardReader cardReader = new CardReader(fileName);
            cardReader.DataEvent += CardReader_DataEvent;
            
            Console.WriteLine("Для выхода из программы нажмите Enter ...");
            Console.ReadLine();
        }

        private static void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            Console.WriteLine(e.CardCode);
        }
    }
}
