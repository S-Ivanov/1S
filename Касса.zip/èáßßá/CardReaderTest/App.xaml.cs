﻿using Drg.AtolWrapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace CardReaderTest
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            port = ConfigurationManager.AppSettings["Port"];
            baudRate = int.Parse(ConfigurationManager.AppSettings["BaudRate"]);

            try
            {
                CreateCardReader();
                ShowState(true);
            }
            catch (DeviceException ex)
            {
                MessageBox.Show($"Ошибка считывателя: {ex.ErrorCode} - {ex.Description}");
            }
            catch (NotSupportedException)
            {
                MessageBox.Show("Ошибка инициализации драйвера Атол при подключении считывателя");
            }

            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }

        private void CreateCardReader()
        {
            cardReader = new CardReader(port, baudRate);
            cardReader.DataEvent += CardReader_DataEvent;
        }

        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (cardReader == null)
            {
                try
                {
                    CreateCardReader();
                    ShowState(true);
                }
                catch
                {
                }
            }
            else
            {
                try
                {
                    cardReader.CheckEnabled();
                    ShowState(true);
                }
                catch
                {
                    cardReader.DataEvent -= CardReader_DataEvent;
                    cardReader.Dispose();
                    cardReader = null;
                    ShowState(false);
                }
            }
        }

        void ShowState(bool enabled)
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.State = enabled ? "подключен" : "отключен";
            }
        }

        private void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.CardCode = e.CardCode;
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (cardReader != null)
                cardReader.Dispose();

            base.OnExit(e);
        }

        string port;
        int baudRate;
        CardReader cardReader = null;
        DispatcherTimer dispatcherTimer = null;
    }
}
