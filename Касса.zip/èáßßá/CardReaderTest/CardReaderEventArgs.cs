﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CardReaderTest
{
    public class CardReaderEventArgs : EventArgs
    {
        public CardReaderEventArgs(string cardCode)
        {
            CardCode = cardCode;
        }

        public string CardCode { get; private set; }
    }
}
