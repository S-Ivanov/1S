﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.CardReaderAtol;
using System;
using System.Configuration;
using System.Windows;

namespace CardReaderTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            port = ConfigurationManager.AppSettings["Port"];
            baudRate = int.Parse(ConfigurationManager.AppSettings["BaudRate"]);

            try
            {
                CreateCardReader();
                ShowState(true);
            }
            catch (DeviceException ex)
            {
                MessageBox.Show($"Ошибка считывателя: {ex.DeviceError.ErrorCode} - {ex.DeviceError.Description}");
            }
            catch (NotSupportedException)
            {
                MessageBox.Show("Ошибка инициализации драйвера Атол при подключении считывателя");
            }

        }

        private void CreateCardReader()
        {
            cardReader = new CardReader(port, baudRate);
            cardReader.DataEvent += CardReader_DataEvent;
        }

        void ShowState(bool enabled)
        {
            State = enabled ? "подключен" : "отключен";
        }

        private void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            CardCode = e.CardCode.ToString();
        }

        public string CardCode
        {
            get { return tbCardCode.Text; }
            set { tbCardCode.Text = value; }
        }

        public string State
        {
            get { return tbState.Text; }
            set { tbState.Text = value; }
        }

        string port;
        int baudRate;
        CardReader cardReader = null;
    }
}
