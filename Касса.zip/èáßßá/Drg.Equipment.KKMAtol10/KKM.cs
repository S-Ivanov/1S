﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment.KKMAtol10
{
    public class KKM : IKKM
    {
        public enum ErrorCode : int
        {
            /// <summary>
            /// Фатальная ошибка
            /// </summary>
            FATAL = 100
        }

        public Dictionary<int, string> Errors = new Dictionary<int, string>
        {
            { (int)libfptr_param.LIBFPTR_PARAM_NO_SERIAL_NUMBER, "Не введен ЗН ККТ" },
            { (int)libfptr_param.LIBFPTR_PARAM_RTC_FAULT, "Ошибка часов реального времени" },
            { (int)libfptr_param.LIBFPTR_PARAM_SETTINGS_FAULT, "Ошибка настроек" },
            { (int)libfptr_param.LIBFPTR_PARAM_COUNTERS_FAULT, "Ошибка счетчиков" },
            { (int)libfptr_param.LIBFPTR_PARAM_USER_MEMORY_FAULT, "Ошибка пользовательской памяти" },
            { (int)libfptr_param.LIBFPTR_PARAM_SERVICE_COUNTERS_FAULT, "Ошибка сервисных регистров" },
            { (int)libfptr_param.LIBFPTR_PARAM_ATTRIBUTES_FAULT, "Ошибка реквизитов" },
            { (int)libfptr_param.LIBFPTR_PARAM_FN_FAULT, "Фатальная ошибка ФН" },
            { (int)libfptr_param.LIBFPTR_PARAM_INVALID_FN, "Установлен ФН из другой ККТ" },
            { (int)libfptr_param.LIBFPTR_PARAM_HARD_FAULT, "Фатальная аппаратная ошибка" },
            { (int)libfptr_param.LIBFPTR_PARAM_MEMORY_MANAGER_FAULT, "Ошибка диспетчера памяти" },
            { (int)libfptr_param.LIBFPTR_PARAM_SCRIPTS_FAULT, "Скрипты повреждены или отсутствуют" },
            { (int)libfptr_param.LIBFPTR_PARAM_WAIT_FOR_REBOOT, "Требуется перезагрузка" },
        };

        public KKM(string dllFileName, string settings)
        {
            // загружаем библиотеку только 1 раз
            if (dllHandle == IntPtr.Zero)
                dllHandle = NativeMethods.LoadLibrary(dllFileName);

            if (dllHandle == IntPtr.Zero)
                throw new DllNotFoundException(dllFileName);

            int result;

            libfptr_create Libfptr_create = (libfptr_create)GetFunction("libfptr_create", typeof(libfptr_create));
            result = Libfptr_create(out driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_create: {result}");

            libfptr_set_settings Libfptr_set_settings = (libfptr_set_settings)GetFunction("libfptr_set_settings", typeof(libfptr_set_settings));
            result = Libfptr_set_settings(driverHandle, settings);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_set_settings: {result}");

            libfptr_open Libfptr_open = (libfptr_open)GetFunction("libfptr_open", typeof(libfptr_open));
            result = Libfptr_open(driverHandle);
            if (result < 0)
                throw new ApplicationException($"Ошибка libfptr_open: {result}");

            // определение точек входа в библиотечные функции
            Libfptr_set_param_int = (libfptr_set_param_int)GetFunction("libfptr_set_param_int", typeof(libfptr_set_param_int));
            Libfptr_query_data = (libfptr_query_data)GetFunction("libfptr_query_data", typeof(libfptr_query_data));
            Libfptr_get_param_bool = (libfptr_get_param_bool)GetFunction("libfptr_get_param_bool", typeof(libfptr_get_param_bool));
        }

        // TODO: сделать возможность возврата нескольких ошибок
        public DeviceError CheckState()
        {
            // запрос фатальных ошибок
            Libfptr_set_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_DATA_TYPE, (uint)libfptr_kkt_data_type.LIBFPTR_DT_FATAL_STATUS);

            int result = Libfptr_query_data(driverHandle);
            if (result < 0)
            {
                return new DeviceError((int)ErrorCode.FATAL, "Фатальная ошибка");
            }
            else
            {
                // проверяем конкретные ошибки
                List<int> errors = new List<int>();
                for (int paramId = (int)libfptr_param.LIBFPTR_PARAM_NO_SERIAL_NUMBER; paramId <= (int)libfptr_param.LIBFPTR_PARAM_WAIT_FOR_REBOOT; paramId++)
                {
                    if (paramId != (int)libfptr_param.LIBFPTR_PARAM_FULL_RESET)
                    {
                        if (Libfptr_get_param_bool(driverHandle, paramId) == 1)
                        {
                            errors.Add(paramId);
                        }
                    }
                }

                // если есть проблема, ошибка
                if (errors.Any())
                {
                    return new KKMDeviceError((int)ErrorCode.FATAL, "Фатальная ошибка")
                    {
                        InnerErrors = errors.Select(errorCode => new DeviceError(errorCode, Errors.TryGetValue(errorCode, out string errorDescription) ? errorDescription : "")).ToList()
                    };
                }
            }

            return DeviceError.NoError;
        }

        Delegate GetFunction(string functionName, Type t)
        {
            IntPtr functionHandle = NativeMethods.GetProcAddress(dllHandle, functionName);
            if (functionHandle == IntPtr.Zero)
                throw new MethodAccessException(functionName);
            return Marshal.GetDelegateForFunctionPointer(functionHandle, t);
        }

        #region Точки входа в библиотечные функции

        libfptr_set_param_int Libfptr_set_param_int;
        libfptr_query_data Libfptr_query_data;
        libfptr_get_param_bool Libfptr_get_param_bool;

        #endregion Точки входа в библиотечные функции

        #region Делегаты, соответствующие функциям dll

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_create(out IntPtr handle);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_close(IntPtr handle);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_destroy(IntPtr handle);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_set_settings(IntPtr handle, string settings);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_open(IntPtr handle);

        //[UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        //private delegate void libfptr_set_param_str(IntPtr handle, libfptr_param param_id, string value);

        //[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        //private delegate int libfptr_print_text(IntPtr handle);

        //[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        //private delegate uint libfptr_get_param_int(IntPtr handle, libfptr_param param_id);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_set_param_int(IntPtr handle, libfptr_param param_id, uint value);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_query_data(IntPtr handle);

        //[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        //private delegate int libfptr_process_json(IntPtr handle);

        //[UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        //private delegate int libfptr_get_param_str(IntPtr handle, libfptr_param param_id, StringBuilder value, int size);

        // 1
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_get_param_bool(IntPtr handle, int param_id);

        #endregion Делегаты, соответствующие функциям dll

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            if (driverHandle != IntPtr.Zero)
            {
                try
                {
                    libfptr_close Libfptr_close = (libfptr_close)GetFunction("libfptr_close", typeof(libfptr_close));
                    Libfptr_close(driverHandle);

                    libfptr_destroy Libfptr_destroy = (libfptr_destroy)GetFunction("libfptr_destroy", typeof(libfptr_destroy));
                    Libfptr_destroy(driverHandle);
                }
                catch
                {
                    // все ошибки игнорируем
                }
            }
        }

        public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            throw new NotImplementedException();
        }

        public void CheckErrors()
        {
            throw new NotImplementedException();
        }

        public void OpenSession(string operatorInfo, string operatorINN)
        {
            throw new NotImplementedException();
        }

        public void CloseSession()
        {
            throw new NotImplementedException();
        }

        public void PrintReceipt(Receipt receipt)
        {
            throw new NotImplementedException();
        }

        public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument)
        {
            throw new NotImplementedException();
        }

        public Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            throw new NotImplementedException();
        }

        public void DoAction<T>(int actionType, T parameters)
        {
            throw new NotImplementedException();
        }

        public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            throw new NotImplementedException();
        }

        #endregion Реализация интерфейса IDisposable

        IntPtr driverHandle = IntPtr.Zero;

        static IntPtr dllHandle = IntPtr.Zero;

        public bool Fiscal => throw new NotImplementedException();

        public uint LineLength => throw new NotImplementedException();

        public SessionState SessionState => throw new NotImplementedException();

        public uint SessionNumber => throw new NotImplementedException();

        public FnInfo FnInfo => throw new NotImplementedException();

        public bool IsBusy => throw new NotImplementedException();

        public DeviceError LastError => throw new NotImplementedException();
    }
}
