﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.Equipment.KKMAtol10
{
    public class KKMDeviceError : DeviceError
    {
        public KKMDeviceError(int errorCode, string description) : base(errorCode, description)
        {
        }

        public List<DeviceError> InnerErrors { get; set; }
    }
}
