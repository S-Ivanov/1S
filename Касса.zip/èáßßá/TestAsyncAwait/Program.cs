﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestAsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId.ToString());

            Task t = DisplayResultAsync();
            t.Wait();
            Console.ReadLine();
        }

        static async Task DisplayResultAsync()
        {
            int num = 5;

            Console.WriteLine("DisplayResultAsync: " + Thread.CurrentThread.ManagedThreadId.ToString());
            int result = await FactorialAsync(num);
            //Thread.Sleep(3000);
            Console.WriteLine("Факториал числа {0} равен {1}", num, result);
        }

        static async Task<int> FactorialAsync(int x)
        {
            int result = 1;

            return await Task.Run(() =>
            {
                Console.WriteLine("FactorialAsync: " + Thread.CurrentThread.ManagedThreadId.ToString());
                Thread.Sleep(3000);

                for (int i = 1; i <= x; i++)
                {
                    result *= i;
                }


                return result;
            });
        }
    }
}
