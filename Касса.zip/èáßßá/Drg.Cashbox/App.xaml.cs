﻿using Drg.CashboxLib;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace Drg.Cashbox
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            try
            {
                bool useRealEquipment = bool.Parse(ConfigurationManager.AppSettings["UseRealEquipment"]);
                string cardReader_Port = ConfigurationManager.AppSettings["CardReader_Port"];
                int cardReader_OpenDelay = int.Parse(ConfigurationManager.AppSettings["CardReader_Port"]);

                Cashbox = new CashboxLib.Cashbox(useRealEquipment, cardReader_Port, cardReader_OpenDelay);

            }
            catch (Exception ex)
            {
                string message = string.IsNullOrEmpty(ex.Message) ? "Неизвестная ошибка" : ex.Message;
                MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                this.Shutdown();
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (Cashbox != null)
                Cashbox.Dispose();

            base.OnExit(e);
        }

        public CashboxLib.Cashbox Cashbox { get; private set; }

        public Cashier Cashier { get; set; }
    }
}
