﻿using Drg.CashboxLib;
using Drg.CashboxLib.CardReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Drg.Cashbox
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            cardReader = (Application.Current as App).Cashbox.Reader;
            cardReader.CardNotify += CardReader_CardNotify;
        }

        private void CardReader_CardNotify(object sender, CardReaderNotifyEventArgs e)
        {
            if (e.Inserted)
            {
                cardReader.CardNotify -= CardReader_CardNotify;
                Cashier = new Cashier(e.CardNum, "post", "inn");
                Application.Current.Dispatcher.Invoke(new Action(() => { this.Close(); }));
            }
        }

        public Cashier Cashier { get; private set; }

        ICardReader cardReader;
    }
}
