﻿using Drg.Equipment.PayTerminal;
using Drg.EquipmentEmulators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace JsonConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //string operatorFIO = "fio", operatorPost = "post", operatorINN = "1234567890";
            //var x = new { type = "openShift", @operator = new { name = $"{operatorFIO} {operatorPost}".TrimEnd(), vatin = operatorINN } };

            //PayResult payResult = new PayResult
            //{
            //    SlipText = "slip text",
            //    ResultInfo = new ResultInfo
            //    {
            //        ResultCode = 0,
            //        ResultDescription = "Нет ошибок"
            //    },
            //    //AuthorizationInfo = new AuthorizationInfo
            //    //{
            //    //}
            //};

            //var serializer = new JavaScriptSerializer();

            //var reading = File.ReadAllText(@"C:\Проекты\Касса\Drg.EquipmentEmulators\KKM.json");
            //var kkmInfo = serializer.Deserialize<KKMInfo>(reading);

            //var s = serializer.Serialize(kkmInfo);
            //Console.WriteLine(s);

            //            var s = 
            //@"{
            //   ""deviceInfo"" : {
            //        ""firmwareVersion"" : ""1245"",
            //        ""model"" : 69,
            //        ""modelName"" : ""АТОЛ 77Ф"",
            //        ""receiptLineLength"" : 48,
            //        ""receiptLineLengthPix"" : 576,
            //        ""serial"" : ""00106900000014""
            //    }
            //}";
            //            //var serializer = new JavaScriptSerializer();
            //            //var x = serializer.Deserialize<KKM10_DeviceInfoWrapper>(s);
            //            //Console.WriteLine(x.deviceInfo.modelName);
            //            //dynamic x = serializer.Deserialize<object>(s);
            //            dynamic x = ProcessJson(s);
            //            Console.WriteLine(x["deviceInfo"]["modelName"]);

            //            string result = 
            //@"{
            //""deviceInfo"" : {
            //    ""firmwareVersion"" : ""1245"",
            //     ""model"" : 69,
            //     ""modelName"" : ""АТОЛ 77Ф"",
            //     ""receiptLineLength"" : 48,
            //     ""receiptLineLengthPix"" : 576,
            //     ""serial"" : ""00106900000014""
            //  }
            //        }";
            //            dynamic dyn = (new JavaScriptSerializer()).Deserialize<object>(result);

            //            Console.WriteLine(dyn["deviceInfo"]["receiptLineLength"].ToString());

            //Dictionary<string, object> dict = new Dictionary<string, object>
            //{
            //    { "type", "nonFiscal" },
            //    {
            //        "items", new List<Dictionary<string, object>>
            //        {
            //            new Dictionary<string, object>
            //            {
            //                { "type", "text" },
            //                {  "text", "ИНН: 7725760410 КПП: 772501001" },
            //                { "alignment", "center" }
            //            },
            //            new Dictionary<string, object>
            //            {
            //                { "type", "text" },
            //                {  "text", "КАССА: 00105700000011 СМЕНА:1" },
            //                { "alignment", "center" }
            //            },
            //        }
            //    }
            //};

            //var serializer = new JavaScriptSerializer();
            //string json = serializer.Serialize(dict);

            /*
{
    "type":"nonFiscal",
    "items":[
        {
            "type":"text",
            "text":"ИНН: 7725760410 КПП: 772501001",
            "alignment":"center"
        },
        {
            "type":"text",
            "text":"КАССА: 00105700000011 СМЕНА:1",
            "alignment":"center"
            }
         ]
         }
             */
            //Console.WriteLine(json);

            CancellationToken token = new CancellationToken();
            Console.WriteLine(token);

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }

        static object ProcessJson(string s)
        {
            var serializer = new JavaScriptSerializer();
            return serializer.Deserialize<object>(s);
        }

#pragma warning disable 0649
        public struct KKM10_DeviceInfoWrapper
        {
            public KKM10_DeviceInfo deviceInfo;
        }

        public struct KKM10_DeviceInfo
        {
            public string firmwareVersion;
            public int model;
            public string modelName;
            public int receiptLineLength;
            public int receiptLineLengthPix;
            public string serial;
        }
#pragma warning restore 0649
    }
}
