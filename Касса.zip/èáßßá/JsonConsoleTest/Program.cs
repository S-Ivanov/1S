﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace JsonConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string operatorFIO = "fio", operatorPost = "post", operatorINN = "1234567890";
            var x = new { type = "openShift", @operator = new { name = $"{operatorFIO} {operatorPost}".TrimEnd(), vatin = operatorINN } };
            var serializer = new JavaScriptSerializer();
            var s = serializer.Serialize(x);
            Console.WriteLine(s);

            //            var s = 
            //@"{
            //   ""deviceInfo"" : {
            //        ""firmwareVersion"" : ""1245"",
            //        ""model"" : 69,
            //        ""modelName"" : ""АТОЛ 77Ф"",
            //        ""receiptLineLength"" : 48,
            //        ""receiptLineLengthPix"" : 576,
            //        ""serial"" : ""00106900000014""
            //    }
            //}";
            //            //var serializer = new JavaScriptSerializer();
            //            //var x = serializer.Deserialize<KKM10_DeviceInfoWrapper>(s);
            //            //Console.WriteLine(x.deviceInfo.modelName);
            //            //dynamic x = serializer.Deserialize<object>(s);
            //            dynamic x = ProcessJson(s);
            //            Console.WriteLine(x["deviceInfo"]["modelName"]);

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }

        static object ProcessJson(string s)
        {
            var serializer = new JavaScriptSerializer();
            return serializer.Deserialize<object>(s);
        }

#pragma warning disable 0649
        public struct KKM10_DeviceInfoWrapper
        {
            public KKM10_DeviceInfo deviceInfo;
        }

        public struct KKM10_DeviceInfo
        {
            public string firmwareVersion;
            public int model;
            public string modelName;
            public int receiptLineLength;
            public int receiptLineLengthPix;
            public string serial;
        }
#pragma warning restore 0649
    }
}
