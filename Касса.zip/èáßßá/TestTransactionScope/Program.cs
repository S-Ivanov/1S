﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace TestTransactionScope
{
    /// <summary>
    /// Тестирование TransactionScope
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            TransactionObject t1 = new TransactionObject(1, false, true);
            TransactionObject t2 = new TransactionObject(2, true, false);

            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    try
                    {
                        t1.Action();
                        t2.Action();

                        ts.Complete();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"TransactionScope Exception: {ex.Message}");
                    }
                }
            }
            catch (TransactionAbortedException ex)
            {
                Console.WriteLine($"TransactionAborted: {ex.Message}");
            }

            Console.WriteLine();
            Console.Write("Press Enter to exit ...");
            Console.ReadLine();
        }
    }

    public class TransactionObject : IEnlistmentNotification
    {
        public TransactionObject(int number, bool throwAction, bool throwRollback)
        {
            this.number = number;
            this.throwAction = throwAction;
            this.throwRollback = throwRollback;
        }

        public void Action()
        {
            Transaction currentTx = Transaction.Current;
            if (currentTx != null)
                currentTx.EnlistVolatile(this, EnlistmentOptions.None);

            Console.WriteLine($"{number}: Action");

            if (throwAction)
                throw new Exception($"{number}: Action Exception");
        }

        #region IEnlistmentNotification

        public void Commit(Enlistment enlistment)
        {
            Console.WriteLine($"{number}: Commit");

            //if (throwException)
            //{
            //    Console.WriteLine($"{number}: Exception");
            //    throw new Exception();
            //}
        }

        public void InDoubt(Enlistment enlistment)
        {
            Console.WriteLine($"{number}: InDoubt");
        }

        public void Prepare(PreparingEnlistment preparingEnlistment)
        {
            // однофазная транзакция - Commit() не вызывается
            preparingEnlistment.Done();

            //preparingEnlistment.Prepared();
        }

        public void Rollback(Enlistment enlistment)
        {
            Console.WriteLine($"{number}: Rollback");

            //if (throwRollback)
            //    throw new Exception($"{number}: Rollback Exception");
        }

        #endregion IEnlistmentNotification

        int number;
        bool throwAction;
        bool throwRollback;
    }
}
