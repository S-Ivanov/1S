﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atol.Drivers10.Fptr;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Threading;

namespace Drg.Equipment.KKMAtol10_3_1
{
    /// <summary>
    /// ККМ
    /// </summary>
    /// <remarks>
    /// http://integration.atol.ru/
    /// </remarks>
    public class KKM : DeviceBase, IKKM
    {
        public KKM(int timeoutMilliseconds)
        {
            this.timeoutMilliseconds = timeoutMilliseconds;

            try
            {
                fptr = new Fptr();

                // настройка драйвера
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_MODEL, Constants.LIBFPTR_MODEL_ATOL_AUTO.ToString());
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_PORT, Constants.LIBFPTR_PORT_USB.ToString());
                fptr.applySingleSettings();

                // открытие драйвера
                fptr.open();

                // TODO: проверить фактическое открытие драйвера
                bool isOpened = fptr.isOpened();

                // чтение настроек
                ReadProperties();
            }
            catch
            {
                LastError = DeviceError.CreateError("Ошибка подключения ККМ");
            }
        }

        private void ReadProperties()
        {
            ReadSessionInfo();

            // Запрос данных о ККМ
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
            fptr.queryData();

            bool isFiscalDevice = fptr.getParamBool(Constants.LIBFPTR_PARAM_FISCAL);
            bool isFiscalFN = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_FISCAL);
            fiscal = isFiscalDevice && isFiscalFN;

            lineLength = fptr.getParamInt(Constants.LIBFPTR_PARAM_RECEIPT_LINE_LENGTH);

            // Запрос данных о ФН
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_REG_INFO);
            fptr.fnQueryData();
            numberFN = fptr.getParamString(1037);
        }

        /// <summary>
        /// Запрос о состоянии смены
        /// </summary>
        private void ReadSessionInfo()
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_SHIFT_STATE);
            fptr.queryData();

            sessionState = (SessionState)fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_STATE);
            sessionNumber = fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_NUMBER);
        }

        public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            DoAction((int)PrintAction.PrintNotFiscal, textInfo);
        }

        void DoPrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            PrintNonFiscalDocument(textInfo, new CancellationToken(), null, null);
        }

        void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            if (textInfo == null || !textInfo.Any())
                return;

            //Dictionary<string, object> dict = new Dictionary<string, object>
            //{
            //    { "type", "nonFiscal" },
            //};
            //dict.Add(
            //    "items",
            //    textInfo
            //    .Select(_ => new Dictionary<string, object>
            //    {
            //        { "type", "text" },
            //        { "text", _.Text },
            //        { "alignment", _.Alignment },
            //        { "font", _.Font },
            //        { "doubleWidth", _.DoubleWidth },
            //        { "doubleHeight", _.DoubleHeight },
            //    })
            //    .ToList()
            //);

            //var serializer = new JavaScriptSerializer();
            //string json = serializer.Serialize(dict);

            //fptr.setParam(Constants.LIBFPTR_PARAM_JSON_DATA, json);
            //fptr.processJson();

            //CheckErrors();

            bool documentOpened = false;

            LastError = DeviceError.NoError;

            try
            {
                DoLowMethod(() => fptr.beginNonfiscalDocument());
                documentOpened = true;

                foreach (var ti in textInfo)
                {
                    if (token.CanBeCanceled && token.IsCancellationRequested)
                    {
                        PrintLine(
                            new TextInfo
                            {
                                Text = "Печать прервана пользователем"
                            });
                        break;
                    }

                    PrintLine(ti);
                    itemCompletedAction?.Invoke();
                }

                finishAction?.Invoke();
            }
            catch (DeviceException ex)
            {
                LastError = ex.DeviceError;
                throw;
            }
            finally
            {
                if (documentOpened)
                    fptr.endNonfiscalDocument();
            }
        }

        private void PrintLine(TextInfo ti)
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT, ti.Text);
            fptr.setParam(Constants.LIBFPTR_PARAM_ALIGNMENT, (int)ti.Alignment);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT, ti.Font);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_WIDTH, ti.DoubleWidth);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT, ti.DoubleHeight);
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT_WRAP, (int)ti.Wrap);
            fptr.setParam(Constants.LIBFPTR_PARAM_LINESPACING, ti.LineSpacing);
            fptr.setParam(Constants.LIBFPTR_PARAM_BRIGHTNESS, ti.Brightness);

            DoLowMethod(() => fptr.printText());
        }

        public Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            return DoActionAsync((int)PrintAction.PrintNotFiscal, textInfo, token, itemCompletedAction, finishAction);
        }

        Task DoPrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            return Task.Run(() =>
            {
                PrintNonFiscalDocument(textInfo, token, itemCompletedAction, finishAction);
            });
        }

        void DoLowMethod(Func<int> func)
        {
            int errorCode = func();
            if (errorCode != 0)
            {
                throw new DeviceException(fptr.errorCode(), fptr.errorDescription());
            }
        }

        /// <summary>
        /// Ширина чековой ленты, символов
        /// </summary>
        public uint LineLength => lineLength;
        uint lineLength;

        public bool Fiscal => fiscal;
        bool fiscal;

        public uint SessionNumber => sessionNumber;
        uint sessionNumber;

        public string FnNumber => numberFN;
        string numberFN;

        public SessionState SessionState => sessionState;
        SessionState sessionState;

        #region Реализация интерфейса IKKM

        protected override void CheckErrorsInternal()
        {
            /*
            LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT Наличие бумаги  bool
LIBFPTR_PARAM_COVER_OPENED  Крышка открыта  bool
LIBFPTR_PARAM_PRINTER_ERROR	Невосстановимая ошибка печатного механизма	bool
LIBFPTR_PARAM_CUT_ERROR	Ошибка отрезчика	bool
LIBFPTR_PARAM_PRINTER_OVERHEAT	Перегрев печатного механизма	bool
LIBFPTR_PARAM_BLOCKED	ККТ заблокирована из-за ошибок	bool

*/
            LastError = DeviceError.NoError;

            var task = new Task(() =>
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
                fptr.queryData();

                bool isCoverOpened = fptr.getParamBool(Constants.LIBFPTR_PARAM_COVER_OPENED);
                if (isCoverOpened)
                {
                    LastError = new DeviceError(Constants.LIBFPTR_PARAM_COVER_OPENED, Errors.TryGetValue(Constants.LIBFPTR_PARAM_COVER_OPENED, out string description) ? description : string.Empty);
                }
            });
            task.Start();

            var result = task.Wait(timeoutMilliseconds);
            if (!result)
            {
                LastError = new DeviceError(Constants.LIBFPTR_ERROR_NO_CONNECTION, Errors.TryGetValue(Constants.LIBFPTR_ERROR_NO_CONNECTION, out string description) ? description : string.Empty);
            }
        }

        protected override void DisposeInternal()
        {
            fptr.close();
        }

        protected override void DoActionInternal<T>(int actionType, T parameters)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        DoPrintNonFiscalDocument(parameters as IEnumerable<TextInfo>);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
                case (int)PrintAction.PrintReceipt:
                    if (parameters is Receipt)
                    {
                        DoPrintReceipt(parameters as Receipt);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }
        }

        public void PrintReceipt(Receipt receipt)
        {
            DoAction((int)Drg.Equipment.KKM.PrintAction.PrintReceipt, receipt);
        }

        private void DoPrintReceipt(Receipt receipt)
        {
            RegisterOperator();

            // открыть чек
            fptr.setParam(Constants.LIBFPTR_PARAM_RECEIPT_TYPE, (int)receipt.ReceiptType);
            fptr.openReceipt();

            // регистрировать товарные позиции чека
            foreach (var item in receipt.Items)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_COMMODITY_NAME, item.Name);
                fptr.setParam(Constants.LIBFPTR_PARAM_PRICE, item.Price);
                fptr.setParam(Constants.LIBFPTR_PARAM_QUANTITY, item.Count);
                if (item.TaxType == TaxType.CUSTOM)
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, Math.Round(item.Price * item.Count * item.VATCoefficient, 2));
                }
                else
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_TYPE, (int)item.TaxType);
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, 0);
                }
                fptr.registration();
            }

            // Зарегистрировать оплату
            foreach (var kvp in receipt.Payments)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_TYPE, (int)kvp.Key);
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_SUM, kvp.Value);
                fptr.payment();
            }

            // Закрытие полностью оплаченного чека
            fptr.closeReceipt();

            // проверить закрытие чека - http://integration.atol.ru/#804811a4ee
            if (fptr.checkDocumentClosed() < 0 || !fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED) || !fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            {
                fptr.cancelReceipt();
                LastError = new DeviceError(fptr.errorCode(), fptr.errorDescription());
                throw new DeviceException(LastError);
            }

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED))
            //{
            //    // Документ не закрылся. Требуется его отменить (если это чек) и сформировать заново
            //    fptr.cancelReceipt();
            //    LastError = new DeviceError(fptr.errorCode(), fptr.errorDescription());
            //    throw new DeviceException(LastError);
            //}

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            //{
            //    fptr.cancelReceipt();
            //    LastError = new DeviceError(fptr.errorCode(), fptr.errorDescription());
            //    throw new DeviceException(LastError);
            //}
        }

        protected override Task DoActionInternalAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        return DoPrintNonFiscalDocumentAsync(parameters as IEnumerable<TextInfo>, token, itemCompletedAction, finishAction);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }

            return null;
        }

        void CheckActionType(int actionType)
        {
            if (!Enum.IsDefined(typeof(PrintAction), actionType))
                throw new ArgumentException(nameof(actionType));
        }

        void RegisterOperator()
        {
            fptr.setParam(1021, operatorInfo);
            fptr.setParam(1203, operatorINN);
            fptr.operatorLogin();
        }

        public void OpenSession(string operatorInfo, string operatorINN)
        {
            if (string.IsNullOrWhiteSpace(operatorInfo))
                throw new ArgumentException(nameof(operatorInfo));
            if (string.IsNullOrWhiteSpace(operatorINN))
                throw new ArgumentException(nameof(operatorINN));

            this.operatorInfo = operatorInfo;
            this.operatorINN = operatorINN;

            RegisterOperator();
            fptr.openShift();
            //fptr.checkDocumentClosed();

            //while (fptr.checkDocumentClosed() < 0)
            //{
            //    // Не удалось проверить состояние документа. Вывести пользователю текст ошибки, попросить устранить неполадку и повторить запрос
            //    Console.WriteLine(fptr.errorDescription());
            //    continue;
            //}

            if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED))
            {
                // Документ не закрылся. Требуется его отменить (если это чек)
                fptr.cancelReceipt();
            }

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            //{
            //    // Можно сразу вызвать метод допечатывания документа, он завершится с ошибкой, если это невозможно
            //    while (fptr.continuePrint() < 0)
            //    {
            //        // Если не удалось допечатать документ - показать пользователю ошибку и попробовать еще раз.
            //        Console.WriteLine(String.Format("Не удалось напечатать документ (Ошибка \"{0}\"). Устраните неполадку и повторите.", fptr.errorDescription()));
            //        continue;
            //    }
            //}

            // Перечитать номер смены
            ReadSessionInfo();
        }

        public void CloseSession()
        {
            RegisterOperator();
            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_CLOSE_SHIFT);
            fptr.report();
        }

        #endregion Реализация интерфейса IKKM

        Dictionary<int, string> Errors = new Dictionary<int, string>
        {
            { Constants.LIBFPTR_ERROR_NO_CONNECTION, "Нет связи с ККМ" },
            { Constants.LIBFPTR_PARAM_COVER_OPENED, "Крышка открыта" },
        };

        IFptr fptr = null;
        int timeoutMilliseconds;
        string operatorInfo, operatorINN;
    }
}
