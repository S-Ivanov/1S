﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atol.Drivers10.Fptr;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Threading;

namespace Drg.Equipment.KKMAtol10_3_1
{
    /// <summary>
    /// ККМ
    /// </summary>
    /// <remarks>
    /// http://integration.atol.ru/
    /// </remarks>
    public class KKM : DeviceBase, IKKM
    {
        public KKM(int timeoutMilliseconds)
        {
            this.timeoutMilliseconds = timeoutMilliseconds;

            fptr = new Fptr();

            // настройка драйвера
            fptr.setSingleSetting(Constants.LIBFPTR_SETTING_MODEL, Constants.LIBFPTR_MODEL_ATOL_AUTO.ToString());
            fptr.setSingleSetting(Constants.LIBFPTR_SETTING_PORT, Constants.LIBFPTR_PORT_USB.ToString());
            fptr.applySingleSettings();

            // открытие драйвера
            fptr.open();

            // TODO: проверить фактическое открытие драйвера
            bool isOpened = fptr.isOpened();

            // чтение настроек
            ReadProperties();
        }

        private void ReadProperties()
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
            fptr.queryData();

            bool isFiscalDevice = fptr.getParamBool(Constants.LIBFPTR_PARAM_FISCAL);
            bool isFiscalFN = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_FISCAL);
            fiscal = isFiscalDevice && isFiscalFN;

            lineLength = fptr.getParamInt(Constants.LIBFPTR_PARAM_RECEIPT_LINE_LENGTH);
        }

        void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            PrintNonFiscalDocument(textInfo, new CancellationToken(), null, null);
        }

        void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            if (textInfo == null || !textInfo.Any())
                return;

            //Dictionary<string, object> dict = new Dictionary<string, object>
            //{
            //    { "type", "nonFiscal" },
            //};
            //dict.Add(
            //    "items",
            //    textInfo
            //    .Select(_ => new Dictionary<string, object>
            //    {
            //        { "type", "text" },
            //        { "text", _.Text },
            //        { "alignment", _.Alignment },
            //        { "font", _.Font },
            //        { "doubleWidth", _.DoubleWidth },
            //        { "doubleHeight", _.DoubleHeight },
            //    })
            //    .ToList()
            //);

            //var serializer = new JavaScriptSerializer();
            //string json = serializer.Serialize(dict);

            //fptr.setParam(Constants.LIBFPTR_PARAM_JSON_DATA, json);
            //// TODO: обработка ошибки
            //fptr.processJson();

            //CheckErrors();

            bool documentOpened = false;

            LastError = DeviceError.NoError;

            try
            {
                DoLowMethod(() => fptr.beginNonfiscalDocument());
                documentOpened = true;

                foreach (var ti in textInfo)
                {
                    if (token.CanBeCanceled && token.IsCancellationRequested)
                    {
                        PrintLine(
                            new TextInfo
                            {
                                Text = "Печать прервана пользователем"
                            });
                        break;
                    }

                    PrintLine(ti);
                    itemCompletedAction?.Invoke();
                }

                finishAction?.Invoke();
            }
            catch (DeviceException ex)
            {
                LastError = ex.DeviceError;
                throw;
            }
            finally
            {
                if (documentOpened)
                    fptr.endNonfiscalDocument();
            }
        }

        private void PrintLine(TextInfo ti)
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT, ti.Text);
            fptr.setParam(Constants.LIBFPTR_PARAM_ALIGNMENT, (int)ti.Alignment);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT, ti.Font);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_WIDTH, ti.DoubleWidth);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT, ti.DoubleHeight);
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT_WRAP, (int)ti.Wrap);
            fptr.setParam(Constants.LIBFPTR_PARAM_LINESPACING, ti.LineSpacing);
            fptr.setParam(Constants.LIBFPTR_PARAM_BRIGHTNESS, ti.Brightness);

            DoLowMethod(() => fptr.printText());
        }

        Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            return Task.Run(() =>
            {
                PrintNonFiscalDocument(textInfo, token, itemCompletedAction, finishAction);
            });
        }

        void DoLowMethod(Func<int> func)
        {
            int errorCode = func();
            if (errorCode != 0)
            {
                throw new DeviceException(fptr.errorCode(), fptr.errorDescription());
            }
        }

        /// <summary>
        /// Ширина чековой ленты, символов
        /// </summary>
        public uint LineLength => lineLength;
        uint lineLength;

        public bool Fiscal => fiscal;

        bool fiscal;

        #region Реализация интерфейса IKKM

        protected override void CheckErrorsInternal()
        {
            /*
            LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT Наличие бумаги  bool
LIBFPTR_PARAM_COVER_OPENED  Крышка открыта  bool
LIBFPTR_PARAM_PRINTER_ERROR	Невосстановимая ошибка печатного механизма	bool
LIBFPTR_PARAM_CUT_ERROR	Ошибка отрезчика	bool
LIBFPTR_PARAM_PRINTER_OVERHEAT	Перегрев печатного механизма	bool
LIBFPTR_PARAM_BLOCKED	ККТ заблокирована из-за ошибок	bool

*/
            LastError = DeviceError.NoError;

            var task = new Task(() =>
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
                fptr.queryData();

                bool isCoverOpened = fptr.getParamBool(Constants.LIBFPTR_PARAM_COVER_OPENED);
                if (isCoverOpened)
                {
                    LastError = new DeviceError(Constants.LIBFPTR_PARAM_COVER_OPENED, Errors.TryGetValue(Constants.LIBFPTR_PARAM_COVER_OPENED, out string description) ? description : string.Empty);
                    throw new DeviceException(LastError);
                }
            });
            task.Start();

            try
            {
                var result = task.Wait(timeoutMilliseconds);
                if (!result)
                {
                    LastError = new DeviceError(Constants.LIBFPTR_ERROR_NO_CONNECTION, Errors.TryGetValue(Constants.LIBFPTR_ERROR_NO_CONNECTION, out string description) ? description : string.Empty);
                    throw new DeviceException(LastError);
                }
            }
            catch (AggregateException ae)
            {
                if (ae.InnerExceptions.Any())
                {
                    throw ae.InnerExceptions.First();
                }
            }
        }

        protected override void DisposeInternal()
        {
            fptr.close();
        }

        protected override void DoActionInternal<T>(int actionType, T parameters)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        PrintNonFiscalDocument(parameters as IEnumerable<TextInfo>);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }
        }

        protected override Task DoActionInternalAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        return PrintNonFiscalDocumentAsync(parameters as IEnumerable<TextInfo>, token, itemCompletedAction, finishAction);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }

            return null;
        }

        void CheckActionType(int actionType)
        {
            if (!Enum.IsDefined(typeof(PrintAction), actionType))
                throw new ArgumentException(nameof(actionType));
        }

        #endregion Реализация интерфейса IKKM

        Dictionary<int, string> Errors = new Dictionary<int, string>
        {
            { Constants.LIBFPTR_ERROR_NO_CONNECTION, "Нет связи с ККМ" },
            { Constants.LIBFPTR_PARAM_COVER_OPENED, "Крышка открыта" },
        };

        IFptr fptr = null;
        int timeoutMilliseconds;
    }
}
