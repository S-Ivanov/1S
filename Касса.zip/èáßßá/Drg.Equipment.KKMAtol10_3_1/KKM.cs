﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atol.Drivers10.Fptr;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Threading;

namespace Drg.Equipment.KKMAtol10_3_1
{
    /// <summary>
    /// ККМ
    /// </summary>
    /// <remarks>
    /// Используется библиотека интеграции с драйвером Атол ККМ 10.х - см. http://integration.atol.ru/
    /// </remarks>
    public class KKM : DeviceBase, IKKM
    {
        public KKM(int timeoutMilliseconds)
        {
            this.timeoutMilliseconds = timeoutMilliseconds;

            try
            {
                fptr = new Fptr();

                // настройка драйвера
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_MODEL, Constants.LIBFPTR_MODEL_ATOL_AUTO.ToString());
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_PORT, Constants.LIBFPTR_PORT_USB.ToString());
                fptr.applySingleSettings();

                // открытие драйвера
                fptr.open();

                // TODO: проверить фактическое открытие драйвера
                bool isOpened = fptr.isOpened();

                // чтение настроек
                ReadProperties();
            }
            catch
            {
                FixLastError(-1, "Ошибка подключения ККМ");
            }
        }

        private void ReadProperties()
        {
            ReadSessionInfo();

            // Запрос данных о ККМ
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
            fptr.queryData();

            bool isFiscalDevice = fptr.getParamBool(Constants.LIBFPTR_PARAM_FISCAL);
            bool isFiscalFN = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_FISCAL);
            Fiscal = isFiscalDevice && isFiscalFN;

            LineLength = fptr.getParamInt(Constants.LIBFPTR_PARAM_RECEIPT_LINE_LENGTH);

            // Запрос данных о ФН
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_REG_INFO);
            fptr.fnQueryData();
            FnNumber = fptr.getParamString(1037);
        }

        /// <summary>
        /// Запрос о состоянии смены
        /// </summary>
        private void ReadSessionInfo()
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_SHIFT_STATE);
            fptr.queryData();

            SessionState = (SessionState)fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_STATE);
            SessionNumber = fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_NUMBER);
        }

        public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            DoAction((int)PrintAction.PrintNotFiscal, textInfo);
        }

        void DoPrintNonFiscalDocument(IEnumerable<TextInfo> textInfo)
        {
            PrintNonFiscalDocument(textInfo, new CancellationToken(), null, null);
        }

        void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            if (textInfo == null || !textInfo.Any())
                return;

            //Dictionary<string, object> dict = new Dictionary<string, object>
            //{
            //    { "type", "nonFiscal" },
            //};
            //dict.Add(
            //    "items",
            //    textInfo
            //    .Select(_ => new Dictionary<string, object>
            //    {
            //        { "type", "text" },
            //        { "text", _.Text },
            //        { "alignment", _.Alignment },
            //        { "font", _.Font },
            //        { "doubleWidth", _.DoubleWidth },
            //        { "doubleHeight", _.DoubleHeight },
            //    })
            //    .ToList()
            //);

            //var serializer = new JavaScriptSerializer();
            //string json = serializer.Serialize(dict);

            //fptr.setParam(Constants.LIBFPTR_PARAM_JSON_DATA, json);
            //fptr.processJson();

            //CheckErrors();

            bool documentOpened = false;

            LastError = DeviceError.NoError;

            try
            {
                DoLowMethod(() => fptr.beginNonfiscalDocument());
                documentOpened = true;

                foreach (var ti in textInfo)
                {
                    if (token.CanBeCanceled && token.IsCancellationRequested)
                    {
                        PrintLine(
                            new TextInfo
                            {
                                Text = "Печать прервана пользователем"
                            });
                        break;
                    }

                    PrintLine(ti);
                    itemCompletedAction?.Invoke();
                }

                finishAction?.Invoke();
            }
            catch (DeviceException ex)
            {
                LastError = ex.DeviceError;
                throw;
            }
            finally
            {
                if (documentOpened)
                    fptr.endNonfiscalDocument();
            }
        }

        private void PrintLine(TextInfo ti)
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT, ti.Text);
            fptr.setParam(Constants.LIBFPTR_PARAM_ALIGNMENT, (int)ti.Alignment);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT, ti.Font);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_WIDTH, ti.DoubleWidth);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT, ti.DoubleHeight);
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT_WRAP, (int)ti.Wrap);
            fptr.setParam(Constants.LIBFPTR_PARAM_LINESPACING, ti.LineSpacing);
            fptr.setParam(Constants.LIBFPTR_PARAM_BRIGHTNESS, ti.Brightness);

            DoLowMethod(() => fptr.printText());
        }

        public Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            return DoActionAsync((int)PrintAction.PrintNotFiscal, textInfo, token, itemCompletedAction, finishAction);
        }

        Task DoPrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            return Task.Run(() =>
            {
                PrintNonFiscalDocument(textInfo, token, itemCompletedAction, finishAction);
            });
        }

        void DoLowMethod(Func<int> func)
        {
            int errorCode = func();
            if (errorCode != 0)
            {
                FixLastError();
                throw new DeviceException(LastError);
            }
        }

        /// <summary>
        /// Ширина чековой ленты, символов
        /// </summary>
        public uint LineLength { get; private set; }

        public bool Fiscal { get; private set; }

        public uint SessionNumber { get; private set; }

        public string FnNumber { get; private set; }

        public SessionState SessionState { get; private set; }

        #region Реализация интерфейса IKKM

        protected override void CheckErrorsInternal()
        {
            LastError = DeviceError.NoError;

            var task = new Task(() =>
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
                fptr.queryData();

                if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_NO_PAPER);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_COVER_OPENED))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_COVER_OPENED);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_CONNECTION_LOST))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_PRINTER_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_ERROR))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_MECHANICAL_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_CUT_ERROR))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_CUTTER_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_OVERHEAT))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_PRINTER_OVERHEAT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_BLOCKED))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_INTERRUPTED_BY_PREVIOUS_ERRORS);
                    return;
                }

                // состояние смены не проверяем

            });
            task.Start();

            var result = task.Wait(timeoutMilliseconds);
            if (!result)
            {
                FixLastError(Constants.LIBFPTR_ERROR_NO_CONNECTION);
            }
        }

        void FixLastError()
        {
            FixLastError(fptr.errorCode(), fptr.errorDescription());
        }

        void FixLastError(int errorCode, string errorDescription = null)
        {
            LastError = new DeviceError { ErrorCode = errorCode, Description = errorDescription };
            if (ErrorInfo.TryGetValue(errorCode, out Tuple<bool, string, string> errorInfo))
            {
                LastError.IsUserError = errorInfo.Item1;
                if (string.IsNullOrEmpty(LastError.Description))
                    LastError.Description = errorInfo.Item2;
                LastError.Recomendation = errorInfo.Item3;
            }
            else
            {
                LastError.IsUserError = false;
                LastError.Recomendation = string.Empty;
            }
        }

        protected override void DisposeInternal()
        {
            fptr.close();
        }

        protected override void DoActionInternal<T>(int actionType, T parameters)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        DoPrintNonFiscalDocument(parameters as IEnumerable<TextInfo>);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
                case (int)PrintAction.PrintReceipt:
                    if (parameters is Receipt)
                    {
                        DoPrintReceipt(parameters as Receipt);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }
        }

        public void PrintReceipt(Receipt receipt)
        {
            DoAction((int)Drg.Equipment.KKM.PrintAction.PrintReceipt, receipt);
        }

        private void DoPrintReceipt(Receipt receipt)
        {
            RegisterOperator();

            // открыть чек
            fptr.setParam(Constants.LIBFPTR_PARAM_RECEIPT_TYPE, (int)receipt.ReceiptType);
            fptr.openReceipt();

            // регистрировать товарные позиции чека
            foreach (var item in receipt.Items)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_COMMODITY_NAME, item.Name);
                fptr.setParam(Constants.LIBFPTR_PARAM_PRICE, item.Price);
                fptr.setParam(Constants.LIBFPTR_PARAM_QUANTITY, item.Count);
                if (item.TaxType == TaxType.CUSTOM)
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, Math.Round(item.Price * item.Count * item.VATCoefficient, 2));
                }
                else
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_TYPE, (int)item.TaxType);
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, 0);
                }
                fptr.registration();
            }

            // Зарегистрировать оплату
            foreach (var kvp in receipt.Payments)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_TYPE, (int)kvp.Key);
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_SUM, kvp.Value);
                fptr.payment();
            }

            // Закрытие полностью оплаченного чека
            fptr.closeReceipt();

            CloseFiscalDocument();
        }

        protected override Task DoActionInternalAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        return DoPrintNonFiscalDocumentAsync(parameters as IEnumerable<TextInfo>, token, itemCompletedAction, finishAction);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }

            return null;
        }

        void CheckActionType(int actionType)
        {
            if (!Enum.IsDefined(typeof(PrintAction), actionType))
                throw new ArgumentException(nameof(actionType));
        }

        void RegisterOperator()
        {
            fptr.setParam(1021, operatorInfo);
            fptr.setParam(1203, operatorINN);
            fptr.operatorLogin();
        }

        public void OpenSession(string operatorInfo, string operatorINN)
        {
            if (string.IsNullOrWhiteSpace(operatorInfo))
                throw new ArgumentException(nameof(operatorInfo));
            if (string.IsNullOrWhiteSpace(operatorINN))
                throw new ArgumentException(nameof(operatorINN));

            this.operatorInfo = operatorInfo;
            this.operatorINN = operatorINN;

            RegisterOperator();
            fptr.openShift();

            CloseFiscalDocument();

            // Перечитать номер смены
            ReadSessionInfo();
        }

        private void CloseFiscalDocument()
        {
            if (fptr.checkDocumentClosed() < 0 || !fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED) || !fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            {
                FixLastError();
                fptr.cancelReceipt();
                throw new DeviceException(LastError);
            }
        }

        public void CloseSession()
        {
            RegisterOperator();
            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_CLOSE_SHIFT);
            fptr.report();
        }

        #endregion Реализация интерфейса IKKM

        readonly Dictionary<int, Tuple<bool, string, string>> ErrorInfo = new Dictionary<int, Tuple<bool, string, string>>
        {
            {
                Constants.LIBFPTR_ERROR_NO_CONNECTION,
                new Tuple<bool, string, string>(true, "Нет связи", "Проверьте питание ККМ, пошевелите провода")
            },
            {
                Constants.LIBFPTR_ERROR_NO_PAPER,
                new Tuple<bool, string, string>(true, "Нет бумаги", "Вставьте бумагу в ККМ")
            },
            {
                Constants.LIBFPTR_ERROR_COVER_OPENED,
                new Tuple<bool, string, string>(true, "Открыта крышка", "Закройте крышку ККМ")
            },
            {
                Constants.LIBFPTR_ERROR_PRINTER_FAULT,
                new Tuple<bool, string, string>(true, "Нет связи с принтером чеков", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_MECHANICAL_FAULT,
                new Tuple<bool, string, string>(false, "Механическая ошибка печатающего устройства", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_CUTTER_FAULT,
                new Tuple<bool, string, string>(false, "Ошибка отрезчика", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_PRINTER_OVERHEAT,
                new Tuple<bool, string, string>(true, "Перегрев головки принтера", "Выключите ККМ, откройте крышку для охлаждения головки принтера")
            },
            {
                Constants.LIBFPTR_ERROR_INTERRUPTED_BY_PREVIOUS_ERRORS,
                new Tuple<bool, string, string>(false, "Выполнение прервано из-за предыдущих ошибок", string.Empty)
            },
        };

        IFptr fptr = null;
        int timeoutMilliseconds;
        string operatorInfo, operatorINN;
    }
}
