﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Resources;

[assembly: AssemblyTitle("Stateless")]
[assembly: AssemblyProduct("Stateless")]
[assembly: AssemblyCopyright("Copyright © Stateless Contributors 2009-2016")]

// This value will remain fixed throughout the 4.x series.
[assembly: AssemblyVersion("4.0.0.0")]

[assembly: InternalsVisibleTo("Stateless.Tests, PublicKey=" +
    "0024000004800000940000000602000000240000525341310004000001000100abebe581d3e209" +
    "862aedf4c60416e3e70329c3f1a962cc7f67460d0b48449f87d19b6c54680e465f9bf6c238c71e" +
    "7bf7e14efff5c348f3f60220ad7c43cc2b9bd18f945963869a23712d61a808f9b3fc6eef26fe60" +
    "1cb5b7ce19cf788ce198362a9a49a2a3c2dd44faffd39870308ecb42d0eb4dd51e16f6accf0d37" +
    "82fbfab1")]

[assembly: NeutralResourcesLanguageAttribute("en")]
[assembly: CLSCompliant(true)]
