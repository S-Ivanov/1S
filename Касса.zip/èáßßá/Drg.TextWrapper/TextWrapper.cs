﻿using NHyphenator;
using NHyphenator.Loaders;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.TextWrapper
{
    /// <summary>
    /// Перенос текста с учетом правил переноса слов
    /// </summary>
    /// <remarks>
    /// Расширение проекта https://github.com/alkozko/NHyphenator
    /// </remarks>
    public class TextWrapper
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="patterns_path">путь к файлу правил переноса</param>
        /// <param name="exceptions_path">путь к файлу исключений переноса</param>
        /// <param name="hyphenateSymbol">символ переноса для внутренней работы алгоритмов переноса, не должен встречаться в обрабатываемых текстах</param>
        /// <param name="minWordLength">минимальная длина слова</param>
        /// <param name="hyphenateLastWord">переносить или нет последнее слово текста</param>
        /// <remarks>
        /// файлы правил и исключений переноса можно взять https://github.com/hyphenation/tex-hyphen/tree/master/hyph-utf8/tex/generic/hyph-utf8/patterns/txt
        /// </remarks>
        public TextWrapper(string patterns_path, string exceptions_path, string hyphenateSymbol = "●", int minWordLength = 3, bool hyphenateLastWord = true)
        {
            this.hyphenateSymbol = hyphenateSymbol;

            var loader = new FilePatternsLoader(patterns_path, exceptions_path);
            this.hyphenator = new Hyphenator(loader, hyphenateSymbol.ToString(), minWordLength: minWordLength, hyphenateLastWord: hyphenateLastWord);
        }

        /// <summary>
        /// Перенести текст
        /// </summary>
        /// <param name="text">исходный текст</param>
        /// <param name="lineLength">длина строк</param>
        /// <returns></returns>
        public IEnumerable<string> WrapText(string text, int lineLength)
        {
            if (lineLength <= 2)
                throw new ArgumentException(nameof(lineLength));

            if (string.IsNullOrEmpty(text))
                return new List<string>();

            if (text.Contains(hyphenateSymbol))
                throw new ArgumentException(nameof(text));

            List<string> result = new List<string>();

            List<string> temp = new List<string>();

            var str = hyphenator.HyphenateText(text);

            string separators = @" .,;:-(){}[]/\'""?!" + hyphenateSymbol;
            int resultLength = lineLength;
            int start = 0;
            bool finished = false;
            for (int i = 0; i < str.Length; i++)
            {
                if (finished)
                {
                    temp.Add(str.Substring(start, i - start));
                    start = i;
                    finished = false;
                }
                if (separators.Contains(str[i]))
                {
                    finished = true;
                }
            }
            temp.Add(str.Substring(start));

            string line = "";
            foreach (var s in temp)
            {
                bool hasHyphen = s.EndsWith(hyphenateSymbol);
                string x = line.TrimEnd(hyphenateSymbol[0]);
                string y = s.TrimEnd(hyphenateSymbol[0]);
                if ((x + y).Length <= (hasHyphen ? lineLength - 1 : lineLength))
                {
                    line = x + s;
                }
                else
                {
                    result.Add(line.Replace(hyphenateSymbol, "-"));
                    line = s;
                }
            }
            result.Add(line);

            return result;

        }

        string hyphenateSymbol;

        Hyphenator hyphenator;
    }
}
