﻿using Drg.Equipment.CardReader;
using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment.CardReaderAtol
{
    public class CardReader : ICardReader
    {
        public CardReader(string port, int baudRate)
        {
            string objectName = "AddIn.Scaner8";
            Type f = Type.GetTypeFromProgID(objectName, true);
            _driver = Activator.CreateInstance(f);

            if (_driver == null)
                throw new NotSupportedException();

            portNumberAtol = GetPortNumberAtol(port);
            baudRateAtol = GetBaudRateAtol(baudRate);

            Initialize();
        }

        void Initialize()
        {
            if (_driver.DeviceCount == 0)
                _driver.AddDevice();

            _driver.CurrentDeviceNumber = 1;
            _driver.PortNumber = portNumberAtol;
            _driver.BaudRate = baudRateAtol;
            _driver.Parity = 0;
            _driver.DataBits = 4;
            _driver.StopBits = 0;
            _driver.Model = 13;
            _driver.DataFormat = 4;

            _driver.OldVersion = false;
            _driver.AutoDisable = false;

            _driver.DeviceEnabled = true;
            if (_driver.ResultCode != 0)
                throw new DeviceException(new DeviceError { ErrorCode = _driver.ResultCode, Description = _driver.ResultDescription });

            if (_driver.DataEvent != null)
            {
                _driver.DataEventEnabled = false;
                _driver.DataEvent -= new Action(Driver_DataEvent);
            }
            _driver.DataEvent += new Action(Driver_DataEvent);
            _driver.DataEventEnabled = true;
        }

        private int GetBaudRateAtol(int baudRate)
        {
            switch (baudRate)
            {
                case 300: return 1;
                case 600: return 2;
                case 1200: return 3;
                case 2400: return 4;
                case 4800: return 5;
                case 9600: return 7;
                case 14400: return 9;
                case 19200: return 10;
                case 38400: return 12;
                case 57600: return 14;
                case 115200: return 18;
                default: throw new ArgumentException("Ошибка параметра", nameof(baudRate));
            }
        }

        int GetPortNumberAtol(string port)
        {
            const string COM = "COM";

            if (string.IsNullOrEmpty(port) || port.Length <= COM.Length)
                throw new ArgumentException("Ошибка параметра", nameof(port));

            int comStart = port.ToUpper().IndexOf(COM);
            if (comStart < 0)
                throw new ArgumentException("Ошибка параметра", nameof(port));

            string portNumberStr = port.Substring(comStart + COM.Length).TrimEnd();
            int portNumber;
            if (!int.TryParse(portNumberStr, out portNumber))
                throw new ArgumentException("Ошибка параметра", nameof(port));
            else
                return portNumber + 1000;
        }

        public event EventHandler<CardReaderEventArgs> DataEvent;

        public DeviceError CheckState()
        {
            return LastError;
        }

        private void Driver_DataEvent()
        {
            string scanData = _driver.ScanData;
            try
            {
                if (DataEvent != null)
                {
                    if (!string.IsNullOrEmpty(scanData))
                    {
                        int cardCodePrefixIndex = scanData.IndexOf(CardCodePrefix);
                        if (cardCodePrefixIndex >= 0)
                        {
                            string cardCode =
                                scanData.Substring(cardCodePrefixIndex + CardCodePrefix.Length + 6, 2) +
                                scanData.Substring(cardCodePrefixIndex + CardCodePrefix.Length + 4, 2) +
                                scanData.Substring(cardCodePrefixIndex + CardCodePrefix.Length + 2, 2) +
                                scanData.Substring(cardCodePrefixIndex + CardCodePrefix.Length, 2);
                            DataEvent(this, new CardReaderEventArgs(Convert.ToUInt32(cardCode, 16)));
                        }
                    }
                }
            }
            finally
            {
                _driver.DeleteEvent();
            }
        }

        #region Реализация интерфейса ICardReader

        public void Dispose()
        {
            if (_driver != null)
            {
                _driver.DataEventEnabled = false;
                _driver.DeviceEnabled = false;
                // освобождение COM-объекта в соответствии с https://www.codeproject.com/Tips/235230/Proper-Way-of-Releasing-COM-Objects-in-NET
                Marshal.ReleaseComObject(_driver);
            }
        }

        public void CheckErrors()
        {
        }

        public void DoAction<T>(int actionType, T parameters)
        {
            throw new NotSupportedException();
        }

        public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            throw new NotSupportedException();
        }

        #endregion Реализация интерфейса ICardReader

        // COM6: Mifare[4E2FE4E8] 228,12110 1K (0004,08)
        const string CardCodePrefix = "Mifare[";


        dynamic _driver = null;

        int portNumberAtol;
        int baudRateAtol;

        public bool IsBusy => false;

        public DeviceError LastError => DeviceError.NoError;
    }
}
