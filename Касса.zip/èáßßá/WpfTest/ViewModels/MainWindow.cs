﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WpfTest.DataModel;

namespace WpfTest.ViewModels
{
    public class MainWindow : INotifyPropertyChanged
    {
        public MainWindow()
        {
            model = new Model();
        }

        public ObservableCollection<MenuSection> MenuSections
        {
            get
            {
                if (menuSections == null)
                {
                    menuSections = new ObservableCollection<MenuSection>(model.Menu.OrderBy(menuSection => menuSection.Name));
                }
                return menuSections;
            }
        }
        ObservableCollection<MenuSection> menuSections = null;

        public MenuSection SelectedMenuSection
        {
            get => selectedMenuSection;
            set
            {
                selectedMenuSection = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("SelectedMenuSection"));
            }
        }
        MenuSection selectedMenuSection = null;

        Model model = null;

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
