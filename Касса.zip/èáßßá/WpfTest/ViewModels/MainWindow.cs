﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WpfTest.DataModel;

namespace WpfTest.ViewModels
{
    public class MainWindow : INotifyPropertyChanged, IDisposable
    {
        public MainWindow()
        {
            model = new Model();
            model.CheckEvent += Model_CheckEvent;
        }

        public void CheckStart()
        {
            model.CheckStart();
        }

        public void CheckStop()
        {
            model.CheckStop();
        }

        private void Model_CheckEvent(object sender, System.Timers.ElapsedEventArgs e)
        {
            Checked = model.CheckResult;
        }

        public bool Checked
        {
            get => @checked;
            private set
            {
                if (@checked != value)
                {
                    @checked = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Checked"));
                }
            }
        }
        bool @checked;

        public event PropertyChangedEventHandler PropertyChanged;

        Model model = null;

        public void Dispose()
        {
            if (model != null)
            {
                model.Dispose();
                model = null;
            }
        }
    }
}
