﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using WpfTest.Commands;
using WpfTest.DataModel;

namespace WpfTest.ViewModels
{
    public class MainWindow : INotifyPropertyChanged
    {
        //public MainWindow()
        //{
        //    model = new Model();
        //}

        public ObservableCollection<MenuSection> MenuSections
        {
            get
            {
                if (menuSections == null)
                {
                    menuSections = new ObservableCollection<MenuSection>(model.Menu.OrderBy(menuSection => menuSection.Name));
                    SelectedMenuSection = menuSections.Count > 0 ? menuSections[0] : null;
                }
                return menuSections;
            }
        }
        ObservableCollection<MenuSection> menuSections = null;

        public MenuSection SelectedMenuSection
        {
            get
            {
                return selectedMenuSection;
            }
            set
            {
                selectedMenuSection = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuSection)));
            }
        }
        MenuSection selectedMenuSection = null;

        // TODO: разобраться - зачем нужно
        public OrderItem SelectedOrderItem
        {
            get
            {
                return selectedOrderItem;
            }
            set
            {
                selectedOrderItem = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
            }
        }
        OrderItem selectedOrderItem = null;

        public ICommand SelectMenuSectionCommand
        {
            get
            {
                return new RelayCommand<MenuSection>(menuSection => SelectedMenuSection = menuSection);
            }
        }

        public ICommand SelectMenuItemCommand
        {
            get
            {
                return new RelayCommand<MenuItem>(
                    menuItem =>
                    {
                        var newOrderItem = new OrderItem { Number = order.Count + 1, MenuItem = menuItem, Count = 1 };
                        order.Add(newOrderItem);
                        SelectedOrderItem = newOrderItem;

                        SelectedMenuSection?.MenuItems.ForEach(item => item.IsSelected = false);
                        menuItem.IsSelected = true;
                    }
                );
            }
        }

        //public OrderItem SelectedOrderItem

        public ObservableCollection<OrderItem> Order => order;
        ObservableCollection<OrderItem> order = new ObservableCollection<OrderItem>();

        Model model = new Model();

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
