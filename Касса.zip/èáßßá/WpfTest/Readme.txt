﻿Inserting button controls into a WPF ListView and handling their click events
http://www.technical-recipes.com/2016/inserting-button-controls-into-a-wpf-listview-and-handling-their-click-events/