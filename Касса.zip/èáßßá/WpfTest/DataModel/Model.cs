﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace WpfTest.DataModel
{
    public class Model 
    {
        public Model()
        {
        }

        public List<MenuSection> Menu
        {
            get => menu;
        }
        List<MenuSection> menu = new List<MenuSection>
        {
            new MenuSection
            {
                Name = "01 Салаты",
                MenuItems = new List<MenuItem>
                {
                    new MenuItem { Name = "Сметана", Price = 42 },
                    new MenuItem { Name = @"Салат ""Морозко""", Price = 27 },
                    new MenuItem { Name = "Винегрет", Price = 23 },
                }
            },
            new MenuSection
            {
                Name = "06 Хлеб и соусы",
                MenuItems = new List<MenuItem>
                {
                    new MenuItem { Name = "Хлеб белый", Price = 4 },
                    new MenuItem { Name = "Хлеб черный", Price = 2 },
                    new MenuItem { Name = @"Хлеб черный ""Бородинский""", Price = 3 },
                }
            }
        };
    }
}
