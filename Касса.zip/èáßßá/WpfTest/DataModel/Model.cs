﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace WpfTest.DataModel
{
    public class Model : IDisposable
    {
        public Model()
        {
            timer = new Timer(1000);
            timer.Elapsed += Timer_Elapsed;
        }

        public void CheckStart()
        {
            timer.Start();
        }

        public void CheckStop()
        {
            timer.Stop();
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (CheckEvent != null)
            {
                CheckEvent(this, e);
                CheckResult = !CheckResult;
            }
        }

        public event EventHandler<ElapsedEventArgs> CheckEvent;

        public void Dispose()
        {
            if (timer != null)
            {
                timer.Elapsed -= Timer_Elapsed;
                timer.Dispose();
                timer = null;
            }
        }

        public bool CheckResult { get; private set; }

        Timer timer = null;
    }
}
