﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTest.DataModel
{
    public class OrderItem
    {
        public int Number { get; set; }
        public MenuItem MenuItem { get; set; }
        public decimal Count { get; set; }
        public decimal Sum => MenuItem.Price * Count;
    }
}
