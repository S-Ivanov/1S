﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTest.DataModel
{
    public class MenuSection
    {
        public string Name { get; set; }
        public List<MenuItem> MenuItems
        {
            get => menuItems;
            set => menuItems = value;
        }
        List<MenuItem> menuItems = new List<DataModel.MenuItem>();
    }
}
