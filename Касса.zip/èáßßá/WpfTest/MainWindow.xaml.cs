﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            var uriSource = new Uri(@"/WpfTest;component/Images/icons8-ок-30.png", UriKind.Relative);
            imgTest.Source = new BitmapImage(uriSource);
            imgTest.Tag = null;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            var uriSource = new Uri(@"/WpfTest;component/Images/icons8-cancel-30.png", UriKind.Relative);
            imgTest.Source = new BitmapImage(uriSource);
            imgTest.Tag = null;
        }

        private void btnError_Click(object sender, RoutedEventArgs e)
        {
            var uriSource = new Uri(@"/WpfTest;component/Images/icons8-warning-30.png", UriKind.Relative);
            imgTest.Source = new BitmapImage(uriSource);
            imgTest.Tag = "Error";
        }

        private void imgTest_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (imgTest.Tag != null)
                MessageBox.Show(imgTest.Tag.ToString());
        }
    }
}
