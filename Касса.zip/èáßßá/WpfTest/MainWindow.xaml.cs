﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WpfTest.DataModel;

namespace WpfTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Ok");
            OnScrollUp(sender, e);
        }

        /// <summary>
        /// Программное скроллирование
        /// </summary>
        /// <param name="o"></param>
        /// <returns></returns>
        /// <remarks>
        /// https://stackoverflow.com/questions/1009036/how-can-i-programmatically-scroll-a-wpf-listview
        /// ответ 27
        /// </remarks>
        public static DependencyObject GetScrollViewer(DependencyObject o)
        {
            // Return the DependencyObject if it is a ScrollViewer
            if (o is ScrollViewer)
            { return o; }

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++)
            {
                var child = VisualTreeHelper.GetChild(o, i);

                var result = GetScrollViewer(child);
                if (result == null)
                {
                    continue;
                }
                else
                {
                    return result;
                }
            }
            return null;
        }

        private void OnScrollUp(object sender, RoutedEventArgs e)
        {
            //var scrollViwer = GetScrollViewer(menuItemsList) as ScrollViewer;

            //if (scrollViwer != null)
            //{
            //    // Logical Scrolling by Item - не работает
            //    //scrollViwer.LineUp();
            //    // Physical Scrolling by Offset
            //    // scrollViwer.ScrollToVerticalOffset(scrollViwer.VerticalOffset + 62);

            //    scrollViwer.PageUp();
            //}
        }

        private void OnScrollDown(object sender, RoutedEventArgs e)
        {
            //var scrollViwer = GetScrollViewer(menuItemsList) as ScrollViewer;

            //if (scrollViwer != null)
            //{
            //    // Logical Scrolling by Item - не работает
            //    //scrollViwer.LineUp();
            //    // Physical Scrolling by Offset
            //    //scrollViwer.ScrollToVerticalOffset(scrollViwer.VerticalOffset - 62);

            //    scrollViwer.PageDown();
            //}
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OnScrollDown(sender, e);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var item = itemsDataGrid.Items[itemsDataGrid.Items.Count - 1];
            itemsDataGrid.SelectedItem = item;
            itemsDataGrid.ScrollIntoView(item);

            var selectedRow = (DataGridRow)itemsDataGrid.ItemContainerGenerator.ContainerFromIndex(itemsDataGrid.SelectedIndex);
            FocusManager.SetIsFocusScope(selectedRow, true);
            FocusManager.SetFocusedElement(selectedRow, selectedRow);
        }

        private void control_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            // If the entire contents fit on the screen, ignore this event
            if (e.ExtentHeight < e.ViewportHeight)
                return;

            // If no items are available to display, ignore this event
            if (itemsDataGrid.Items.Count <= 0)
                return;

            // If the ExtentHeight and ViewportHeight haven't changed, ignore this event
            if (e.ExtentHeightChange == 0.0 && e.ViewportHeightChange == 0.0)
                return;

            // If we were close to the bottom when a new item appeared,
            // scroll the new item into view.  We pick a threshold of 5
            // items since issues were seen when resizing the window with
            // smaller threshold values.
            var oldExtentHeight = e.ExtentHeight - e.ExtentHeightChange;
            var oldVerticalOffset = e.VerticalOffset - e.VerticalChange;
            var oldViewportHeight = e.ViewportHeight - e.ViewportHeightChange;
            if (oldVerticalOffset + oldViewportHeight + 5 >= oldExtentHeight)
            {
                var item = itemsDataGrid.Items[itemsDataGrid.Items.Count - 1];
                itemsDataGrid.SelectedItem = item;
                itemsDataGrid.ScrollIntoView(item);

                var row = (DataGridRow)itemsDataGrid.ItemContainerGenerator.ContainerFromIndex(itemsDataGrid.SelectedIndex);
                row.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            }
        }

        private void itemsDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show((itemsDataGrid.SelectedItem as OrderItem).MenuItem.Name);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Ok");
        }
    }
}
