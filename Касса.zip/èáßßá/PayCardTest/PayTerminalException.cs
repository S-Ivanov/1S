﻿using System;

namespace PayCardTest
{
    public class PayTerminalException : ApplicationException
    {
        public PayTerminalException()
        {
        }

        public PayTerminalException(string message) : base(message)
        {
        }
    }
}
