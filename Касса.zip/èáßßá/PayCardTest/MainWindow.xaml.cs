﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PayCardTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DoPayOperation(0);
        }

        private void DoPayOperation(int operationType)
        {
            try
            {
                PayResult payResult;
                using (PayTerminal payTerminal = new PayTerminal(40, ConfigurationManager.AppSettings["pathAC"], ConfigurationManager.AppSettings["pathDB"], int.Parse(ConfigurationManager.AppSettings["protocol"])))
                {
                    payResult = payTerminal.DoPayOperation(operationType, int.Parse(tbSession.Text), int.Parse(tbCheckNumber.Text), decimal.Parse(tbSum.Text));
                }
                if (payResult == null)
                {
                    MessageBox.Show("Отмена авторизации");
                }
                else
                {
                    SaveToFile($"Слип - {operationType}.txt", (new JavaScriptSerializer()).Serialize(payResult));
                    MessageBox.Show("Операция выполнена");
                }
            }
            catch (PayException ex)
            {
                SaveToFile("Ошибка.txt", (new JavaScriptSerializer()).Serialize(ex.ResultInfo));
                MessageBox.Show("Ошибка выполнения операции");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        void SaveToFile(string fileName, string text)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(fileName))
            {
                file.Write(text);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //String exePath = System.Reflection.Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName;
            //string fileName = System.IO.Path.ChangeExtension(exePath, ".txt");
            //try
            //{
            //    using (PayTerminal payTerminal = new PayTerminal(40))
            //    {
            //        using (System.IO.StreamWriter file = new System.IO.StreamWriter(fileName))
            //        {
            //            WriteLine(file, "DialogFontName", payTerminal.DialogFontName);
            //            WriteLine(file, "DialogFontSize", payTerminal.DialogFontSize);
            //            WriteLine(file, "DialogFontStyle", payTerminal.DialogFontStyle);
            //            WriteLine(file, "ResultCode", payTerminal.ResultCode);
            //            WriteLine(file, "ResultDescription", payTerminal.ResultDescription);
            //            WriteLine(file, "ResultPrompt", payTerminal.ResultPrompt);
            //            WriteLine(file, "Version", payTerminal.Version);
            //            WriteLine(file, "IsDemo", payTerminal.IsDemo);
            //            WriteLine(file, "ProtocolsList", payTerminal.ProtocolsList);
            //            WriteLine(file, "UseSoftCheque", payTerminal.UseSoftCheque);
            //            WriteLine(file, "IsSoftCheque", payTerminal.IsSoftCheque);
            //            WriteLine(file, "CurrentDeviceIndex", payTerminal.CurrentDeviceIndex);
            //            WriteLine(file, "CurrentDeviceNumber", payTerminal.CurrentDeviceNumber);
            //            WriteLine(file, "PathAC", payTerminal.PathAC);
            //            WriteLine(file, "PathDB", payTerminal.PathDB);
            //            WriteLine(file, "DataTracksFormat", payTerminal.DataTracksFormat);
            //            WriteLine(file, "ResponseTimeout", payTerminal.ResponseTimeout);
            //            WriteLine(file, "Protocol", payTerminal.Protocol);
            //            WriteLine(file, "EnablePINIdentif", payTerminal.EnablePINIdentif);
            //            WriteLine(file, "EnableSignIdentif", payTerminal.EnableSignIdentif);
            //            WriteLine(file, "EnableKeyboardCardEntry", payTerminal.EnableKeyboardCardEntry);
            //            WriteLine(file, "SlipHeader", payTerminal.SlipHeader);
            //            WriteLine(file, "SlipFooter", payTerminal.SlipFooter);
            //            WriteLine(file, "DevicesSettings", payTerminal.DevicesSettings);
            //            WriteLine(file, "DeviceSettings", payTerminal.DeviceSettings);
            //            WriteLine(file, "DeviceCount", payTerminal.DeviceCount);
            //            WriteLine(file, "CurrentDeviceName", payTerminal.CurrentDeviceName);
            //            WriteLine(file, "CharLineLength", payTerminal.CharLineLength);
            //            WriteLine(file, "TextCount", payTerminal.TextCount);
            //            WriteLine(file, "TextIndex", payTerminal.TextIndex);
            //            WriteLine(file, "Text", payTerminal.Text);
            //            WriteLine(file, "TextStr", payTerminal.TextStr);
            //            WriteLine(file, "NeedReferenceNumber", payTerminal.NeedReferenceNumber);
            //            WriteLine(file, "NeedReaderEntryDataTracks", payTerminal.NeedReaderEntryDataTracks);
            //            WriteLine(file, "NeedKeyboardEntryDataTracks", payTerminal.NeedKeyboardEntryDataTracks);
            //            WriteLine(file, "NeedSumm", payTerminal.NeedSumm);
            //            WriteLine(file, "TerminalNumber", payTerminal.TerminalNumber);
            //            WriteLine(file, "OperationType", payTerminal.OperationType);
            //            WriteLine(file, "AuthorizationType", payTerminal.AuthorizationType);
            //            WriteLine(file, "Sum", payTerminal.Sum);
            //            WriteLine(file, "CardNumber", payTerminal.CardNumber);
            //            WriteLine(file, "CardExpDate", payTerminal.CardExpDate);
            //            WriteLine(file, "DataTrack2", payTerminal.DataTrack2);
            //            WriteLine(file, "DataTracks", payTerminal.DataTracks);
            //            WriteLine(file, "ReferenceNumber", payTerminal.ReferenceNumber);
            //            WriteLine(file, "ECRSessionNumber", payTerminal.ECRSessionNumber);
            //            WriteLine(file, "ECRReceiptNumber", payTerminal.ECRReceiptNumber);
            //            WriteLine(file, "Currency", payTerminal.Currency);
            //            WriteLine(file, "ResponseCode", payTerminal.ResponseCode);
            //            WriteLine(file, "TransType", payTerminal.TransType);
            //            WriteLine(file, "TransDate", payTerminal.TransDate);
            //            WriteLine(file, "TransTime", payTerminal.TransTime);
            //            WriteLine(file, "TransID", payTerminal.TransID);
            //            WriteLine(file, "AuthCode", payTerminal.AuthCode);
            //            WriteLine(file, "CardType", payTerminal.CardType);
            //            WriteLine(file, "TerminalID", payTerminal.TerminalID);
            //            WriteLine(file, "MsgNumber", payTerminal.MsgNumber);
            //            WriteLine(file, "MessageType", payTerminal.MessageType);
            //            WriteLine(file, "MerchNumber", payTerminal.MerchNumber);
            //            WriteLine(file, "MerchCategoryCode", payTerminal.MerchCategoryCode);
            //            WriteLine(file, "MerchEngName", payTerminal.MerchEngName);
            //            WriteLine(file, "SlipNumber", payTerminal.SlipNumber);
            //            WriteLine(file, "Discount", payTerminal.Discount);
            //            WriteLine(file, "Bonus", payTerminal.Bonus);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            DoPayOperation(1);
        }

        private void WriteLine(StreamWriter file, string propertyName, object value)
        {
            try
            {
                file.WriteLine($"{propertyName}: {value}");
            }
            catch (Exception ex)
            {
                file.WriteLine($"{propertyName}: Error - {ex.Message}");
            }
            finally
            {
                file.WriteLine();
            }
        }
    }
}
