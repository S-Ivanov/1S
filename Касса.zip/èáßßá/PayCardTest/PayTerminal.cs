﻿using System;
using System.Configuration;
using System.Runtime.InteropServices;

namespace PayCardTest
{
    /// <summary>
    /// Платежный (эквайринговый) терминал
    /// </summary>
    /// <remarks>
    /// Описание общего алгоритма взаимодействия с ККМ:
    /// http://v8.1c.ru/libraries/cel/a_terminal.htm
    /// </remarks>
    public class PayTerminal : IDisposable
    {
        #region Константы

        #region Коды ошибок драйвера Атол

        /// <summary>
        /// Ошибок нет
        /// </summary>
        public const int Result_Success = 0;

        /// <summary>
        /// Работа драйвера прервана пользователем
        /// </summary>
        const int Result_UserBreak = -5;

        /// <summary>
        /// Ошибка АС
        /// </summary>
        const int Result_ACError = -10000;

        /// <summary>
        /// Предел кодов ошибок АС
        /// </summary>
        const int Result_ACErrorLimit = -11000;

        #endregion Коды ошибок драйвера Атол

        #endregion Константы

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="charLineLength">ширина ленты ККМ в символах - для печати слипов</param>
        /// <param name="pathAC">каталог обмена с АС</param>
        /// <param name="pathDB">каталог драйвера</param>
        /// <param name="protocol">протокол обмена с платежной системой (3 - Сбербанк, см. документацию драйвера Атол)</param>
        public PayTerminal(int charLineLength, string pathAC, string pathDB, int protocol)
        {
            Type f = Type.GetTypeFromProgID("AddIn.PayCARD8", true);
            _driver = Activator.CreateInstance(f);

            if (_driver == null)
                throw new NotSupportedException("Ошибка подключения драйвера");

            #region Заимствовано из 1С:Трактир - обработка Обслуживание_ПС_АТОЛ, модуль объекта

            if (_driver.DeviceCount == 0)
                _driver.AddDevice();

            if (_driver.DeviceCount == 0)
                throw new NotSupportedException("Ошибка подключения устройства");

            _driver.CurrentDeviceNumber = 1;

            // мы будем поддерживать только авторизацию по карте через ридер, без всяких ручных вводов
            _driver.EnableKeyboardCardEntry = false;

            #endregion Заимствовано из 1С:Трактир - обработка Обслуживание_ПС_АТОЛ, модуль объекта

            _driver.CharLineLength = charLineLength;
            _driver.PathAC = pathAC;
            _driver.PathDB = pathDB;
            _driver.Protocol = protocol;

            /*

            Процедура ПодготовкаАвторизации(ПараметрыДействия)

                DRV.TerminalNumber = ПараметрыДействия.НомерТерминала;
                DRV.CardNumber = ПараметрыДействия.НомерКарты;
                DRV.DataTracks = ПараметрыДействия.ДанныеКарты;
                DRV.Sum = ПараметрыДействия.Сумма;
                DRV.Currency = Строка(Константы.ОсновнаяВалюта.Получить().Код);
                DRV.ReferenceNumber = ПараметрыДействия.СсылочныйНомер;
                DRV.CharLineLength = Число(ПараметрыДействия.ШиринаЛенты);
                DRV.ECRSessionNumber = Число(ПараметрыДействия.НомерСмены);
                DRV.ECRReceiptNumber = Число(ПараметрыДействия.НомерЧека);
                DRV.OperationType = 0/1/2/3/-1;
                DRV.PrepareOnLineAuthorization();
                Результат.Вставить("НуженВводКарты",			DRV.NeedReaderEntryDataTracks);
                Результат.Вставить("НеобходимСсылочныйНомер",	DRV.NeedReferenceNumber);

            Функция Ошибка()

                Если DRV.ResultCode = 0 Тогда
                Результат.Подробно = СокрЛП(DRV.ResultDescription);

            Процедура ВыполнитьОперацию(ПараметрыДействия)

                DRV.TerminalNumber		= ПараметрыДействия.НомерТерминала;
                DRV.CardNumber			= ПараметрыДействия.НомерКарты;
                DRV.DataTracks			= ПараметрыДействия.ДанныеКарты;
                DRV.Sum					= ПараметрыДействия.Сумма;
                DRV.ReferenceNumber		= ПараметрыДействия.СсылочныйНомер;
                DRV.CharLineLength		= Число(ПараметрыДействия.ШиринаЛенты);
                DRV.ECRSessionNumber	= Число(ПараметрыДействия.НомерСмены);
                DRV.ECRReceiptNumber	= Число(ПараметрыДействия.НомерЧека);

                DRV.OnLineAuthorization();

                Если DRV.ResultCode = 0 ИЛИ ( DRV.ResultCode <= -10000 И DRV.ResultCode > -11000) тогда

                    Док.ДатаТранзакции		= DRV.TransDate;
                    Док.ВремяТранзакции		= DRV.TransTime;
                    Док.НомерКарты			= DRV.CardNumber;
                    Док.СрокДействияКарты	= DRV.CardExpDate;
                    Док.ТипАвторизации		= DRV.AuthorizationType;
                    Док.ТипОперации			= DRV.OperationType;
                    Док.КодАвторизации		= DRV.AuthCode;
                    Док.Сумма				= DRV.Sum;
                    Док.ТипТранзакции		= DRV.TransType;
                    Док.ИДТерминала			= DRV.TerminalID;
                    Док.КодОтвета			= DRV.ResponseCode;
                    Док.НомерСлипа			= DRV.SlipNumber;
                    Док.НомерСообщения		= DRV.MsgNumber;
                    Док.СсылочныйНомер		= DRV.ReferenceNumber;

                    Результат.Вставить("ДанныеКарты"	,DRV.DataTracks);
                    Результат.Вставить("СсылочныйНомер"	,DRV.ReferenceNumber);
                    Результат.Вставить("ТекстСлипа"		,DRV.TextStr);
                    Результат.Вставить("НомерКарты"		,DRV.CardNumber);

        Процедура СнятьОтчет(ПараметрыДействия)

            DRV.TerminalNumber	= ПараметрыДействия.НомерТерминала;
            DRV.CharLineLength	= Число(ПараметрыДействия.ШиринаЛенты);

            DRV.ReportType=0/1/2/-1;


            DRV.BeginReport();
            Если Ошибка() Тогда
                DRV.ResetState();
                Возврат;
            КонецЕсли;

            Пока Выборка.Следующий() Цикл

                DRV.RepTerminalID		= Выборка.ИДТерминала;
                DRV.RepTransDate		= Выборка.ДатаТранзакции;
                DRV.RepTransTime		= Выборка.ВремяТранзакции;
                DRV.RepCardNumber		= Выборка.НомерКарты;
                DRV.RepCardExpDate		= Выборка.СрокДействияКарты;
                DRV.RepOperationType	= Выборка.ТипОперации;
                DRV.RepAuthCode			= Выборка.КодАвторизации;
                DRV.RepSum				= Выборка.Сумма;
                DRV.RepTransType		= Выборка.ТипТранзакции;
                DRV.RepResponseCode		= Выборка.КодОтвета;
                DRV.RepSlipNumber		= Выборка.НомерСлипа;
                DRV.RepMsgNumber		= Выборка.НомерСообщения;
                DRV.RepReferenceNumber	= Выборка.СсылочныйНомер;

                DRV.AddToReport();
                Если Ошибка() Тогда
                    DRV.ResetState();
                    Возврат;
                КонецЕсли;

            КонецЦикла;

            DRV.EndReport();
            Если Ошибка() Тогда
                DRV.ResetState();
                Возврат;
            КонецЕсли;

            Результат.Вставить("ТекстСлипа", DRV.TextStr);


            */
        }

        #region Низкоуровневые свойства и методы

        #region Низкоуровневые свойства

        /// <summary>
        /// Имя шрифта диалогов
        /// </summary>
        public string DialogFontName
        {
            get => _driver.DialogFontName;
            set => _driver.DialogFontName = value;
        }

        /// <summary>
        /// Имя шрифта диалогов
        /// </summary>
        public int DialogFontSize
        {
            get => _driver.DialogFontSize;
            set => _driver.DialogFontSize = value;
        }

        /// <summary>
        /// Стиль шрифта диалогов
        /// </summary>
        public int DialogFontStyle
        {
            get => _driver.DialogFontStyle;
            set => _driver.DialogFontStyle = value;
        }

        /// <summary>
        /// Код результата
        /// </summary>
        public int ResultCode
        {
            get => _driver.ResultCode;
        }

        /// <summary>
        /// Описание результата
        /// </summary>
        public string ResultDescription
        {
            get => _driver.ResultDescription;
        }

        /// <summary>
        /// Рекомендация к результату
        /// </summary>
        public string ResultPrompt
        {
            get => _driver.ResultPrompt;
        }

        /// <summary>
        /// Версия драйвера
        /// </summary>
        public string Version
        {
            get => _driver.Version;
        }

        /// <summary>
        /// Включен бесплатный режим драйвера
        /// </summary>
        public bool IsDemo
        {
            get => _driver.IsDemo;
        }

        /// <summary>
        /// Список платежных систем
        /// </summary>
        /// <remarks>
        /// Данные в свойстве хранятся в виде текста, разделенного на строки символами #13 и #10, где каждая строка – отдельный тип платежной системы
        /// </remarks>
        public string ProtocolsList
        {
            get => _driver.ProtocolsList;
        }

        /// <summary>
        /// Бонусная система использует мягкий чек
        /// </summary>
        public bool UseSoftCheque
        {
            get => _driver.UseSoftCheque;
        }

        /// <summary>
        /// Мягкий чек
        /// </summary>
        /// <remarks>
        /// Данное свойство показывает, для какого вида чека выполняется операция бонусной системы. Используется в случае, если свойство UseSoftCheque = TRUE.
        /// Если свойство IsSoftCheque = TRUE, операция выполняется для мягкого чека, иначе – для фискального.
        /// </remarks>
        public bool IsSoftCheque
        {
            get => _driver.IsSoftCheque;
        }

        /// <summary>
        /// Индекс текущего устройства
        /// </summary>
        public int CurrentDeviceIndex
        {
            get => _driver.CurrentDeviceIndex;
            set => _driver.CurrentDeviceIndex = value;
        }

        /// <summary>
        /// Номер текущего устройства
        /// </summary>
        public int CurrentDeviceNumber
        {
            get => _driver.CurrentDeviceNumber;
            set => _driver.CurrentDeviceNumber = value;
        }

        /// <summary>
        /// Каталог обмена с АС
        /// </summary>
        public string PathAC
        {
            get => _driver.PathAC;
            set => _driver.PathAC = value;
        }

        /// <summary>
        /// Каталог драйвера
        /// </summary>
        public string PathDB
        {
            get => _driver.PathDB;
            set => _driver.PathDB = value;
        }

        /// <summary>
        /// Формат магнитной полосы
        /// </summary>
        public string DataTracksFormat
        {
            get => _driver.DataTracksFormat;
            set => _driver.DataTracksFormat = value;
        }

        /// <summary>
        /// Таймаут ответа от АС, сек
        /// </summary>
        public int ResponseTimeout
        {
            get => _driver.ResponseTimeout;
            set => _driver.ResponseTimeout = value;
        }

        /// <summary>
        /// Таймаут ответа от АС, сек
        /// </summary>
        public int Protocol
        {
            get => _driver.Protocol;
            set => _driver.Protocol = value;
        }

        /// <summary>
        /// Разрешить идентификацию по PIN-коду
        /// </summary>
        public bool EnablePINIdentif
        {
            get => _driver.EnablePINIdentif;
            set => _driver.EnablePINIdentif = value;
        }

        /// <summary>
        /// Разрешить идентификацию по подписи
        /// </summary>
        public bool EnableSignIdentif
        {
            get => _driver.EnableSignIdentif;
            set => _driver.EnableSignIdentif = value;
        }

        /// <summary>
        /// Разрешить клавиатурный ввод карты
        /// </summary>
        public bool EnableKeyboardCardEntry
        {
            get => _driver.EnableKeyboardCardEntry;
            set => _driver.EnableKeyboardCardEntry = value;
        }

        /// <summary>
        /// Заголовок слипа
        /// </summary>
        /// <remarks>
        /// Многострочный текст, печатаемый в начале слипа. Строки отделены символом «возврат каретки» (#13).
        /// </remarks>
        public string SlipHeader
        {
            get => _driver.SlipHeader;
            set => _driver.SlipHeader = value;
        }

        /// <summary>
        /// Подвал слипа
        /// </summary>
        /// <remarks>
        /// Многострочный текст, печатаемый в начале слипа. Строки отделены символом «возврат каретки» (#13).
        /// </remarks>
        public string SlipFooter
        {
            get => _driver.SlipFooter;
            set => _driver.SlipFooter = value;
        }

        /// <summary>
        /// Параметры логических устройств в виде строки
        /// </summary>
        public string DevicesSettings
        {
            get => _driver.DevicesSettings;
            set => _driver.DevicesSettings = value;
        }

        /// <summary>
        /// Параметры логического устройства в виде строки
        /// </summary>
        public string DeviceSettings
        {
            get => _driver.DeviceSettings;
            set => _driver.DeviceSettings = value;
        }

        /// <summary>
        /// Число логических систем, существующих на данный момент
        /// </summary>
        public int DeviceCount
        {
            get => _driver.DeviceCount;
        }

        /// <summary>
        /// Наименование текущего устройства
        /// </summary>
        public string CurrentDeviceName
        {
            get => _driver.CurrentDeviceName;
            set => _driver.CurrentDeviceName = value;
        }

        /// <summary>
        /// Ширина ленты ККМ в символах
        /// </summary>
        public int CharLineLength
        {
            get => _driver.CharLineLength;
            set => _driver.CharLineLength = value;
        }

        /// <summary>
        /// Количество строк текста слипа
        /// </summary>
        public int TextCount
        {
            get => _driver.TextCount;
        }

        /// <summary>
        /// Номер текущей строки слипа
        /// </summary>
        public int TextIndex
        {
            get => _driver.TextIndex;
            set => _driver.TextIndex = value;
        }

        /// <summary>
        /// Текущая строка слипа
        /// </summary>
        /// <remarks>
        /// Длина до CharLineLength символов
        /// </remarks>
        public string Text
        {
            get => _driver.Text;
        }

        /// <summary>
        /// Текст слипа
        /// </summary>
        /// <remarks>
        /// Строки слипа разделенные парой символов #13 (возврат каретки) и #10 (перевод строки).
        /// </remarks>
        public string TextStr
        {
            get => _driver.TextStr;
        }

        /// <summary>
        /// Необходим ссылочный номер
        /// </summary>
        public bool NeedReferenceNumber
        {
            get => _driver.NeedReferenceNumber;
        }

        /// <summary>
        /// Необходимо считать карту ридером магнитных карт
        /// </summary>
        public bool NeedReaderEntryDataTracks
        {
            get => _driver.NeedReaderEntryDataTracks;
        }

        /// <summary>
        /// Необходимо ввести номер карты с клавиатуры
        /// </summary>
        public bool NeedKeyboardEntryDataTracks
        {
            get => _driver.NeedKeyboardEntryDataTracks;
        }

        /// <summary>
        /// Необходимо ввести сумму операции
        /// </summary>
        public bool NeedSumm
        {
            get => _driver.NeedSumm;
        }

        /// <summary>
        /// Номер точки оплаты
        /// </summary>
        /// <remarks>
        /// Является идентификатором точки оплаты и в пределах ЛВС представляет собой уникальное значение
        /// </remarks>
        public int TerminalNumber
        {
            get => _driver.TerminalNumber;
            set => _driver.TerminalNumber = value;
        }

        /// <summary>
        /// Тип операции
        /// </summary>
        public int OperationType
        {
            get => _driver.OperationType;
            set => _driver.OperationType = value;
        }

        /// <summary>
        /// Тип (способ) авторизации
        /// </summary>
        public int AuthorizationType
        {
            get => _driver.AuthorizationType;
            set => _driver.AuthorizationType = value;
        }

        /// <summary>
        /// Сумма операции
        /// </summary>
        public double Sum
        {
            get => _driver.Sum;
            set => _driver.Sum = value;
        }

        /// <summary>
        /// Номер карты: до 19 буквенно-цифровых символов
        /// </summary>
        /// <remarks>
        /// Данное свойство используется только при AuthorizationType, соответствующем ручному вводу номера карты и только в паре со свойством с CardExpDate
        /// </remarks>
        public string CardNumber
        {
            get => _driver.CardNumber;
            set => _driver.CardNumber = value;
        }

        /// <summary>
        /// Срок действия карты
        /// </summary>
        /// <remarks>
        /// Данное свойство используется только при AuthorizationType, соответствующем ручному вводу номера карты и только в паре со свойством с CardNumber
        /// </remarks>
        public string CardExpDate
        {
            get => _driver.CardExpDate;
            set => _driver.CardExpDate = value;
        }

        /// <summary>
        /// Вторая дорожка магнитной полосы карты
        /// </summary>
        /// <remarks>
        /// Используется только при AuthorizationType, соответствующем вводу карты ридером магнитных карт
        /// </remarks>
        public string DataTrack2
        {
            get => _driver.DataTrack2;
            set => _driver.DataTrack2 = value;
        }

        /// <summary>
        /// Дорожки магнитной полосы карты
        /// </summary>
        /// <remarks>
        /// Предназначено для разбора данных, полученных от ридера магнитных карт. Результатом является автоматическое заполнение свойства DataTrack2
        /// </remarks>
        public string DataTracks
        {
            get => _driver.DataTracks;
            set => _driver.DataTracks = value;
        }

        /// <summary>
        /// Ссылочный номер
        /// </summary>
        public string ReferenceNumber
        {
            get => _driver.ReferenceNumber;
            set => _driver.ReferenceNumber = value;
        }

        /// <summary>
        /// Номер смены ККМ
        /// </summary>
        public int ECRSessionNumber
        {
            get => _driver.ECRSessionNumber;
            set => _driver.ECRSessionNumber = value;
        }

        /// <summary>
        /// Номер чека ККМ
        /// </summary>
        public int ECRReceiptNumber
        {
            get => _driver.ECRReceiptNumber;
            set => _driver.ECRReceiptNumber = value;
        }

        /// <summary>
        /// Код валюты: Трехзначное число с лидирующими нулями
        /// </summary>
        /// <remarks>
        /// TODO: Переделать на число ?
        /// </remarks>
        public string Currency
        {
            get => _driver.Currency;
            set => _driver.Currency = value;
        }

        /// <summary>
        /// Код ответа от АС: строка до 10 символов
        /// </summary>
        public string ResponseCode
        {
            get => _driver.ResponseCode;
        }

        /// <summary>
        /// Тип банковской транзакции
        /// </summary>
        public int TransType
        {
            get => _driver.TransType;
        }

        /// <summary>
        /// Дата транзакции по часам ПЦ
        /// </summary>
        public string TransDate
        {
            get => _driver.TransDate;
        }

        /// <summary>
        /// Время транзакции по часам ПЦ
        /// </summary>
        public string TransTime
        {
            get => _driver.TransTime;
        }

        /// <summary>
        /// ID транзакции
        /// </summary>
        public long TransID
        {
            get => _driver.TransID;
        }

        /// <summary>
        /// Код авторизации: строка до 9 символов
        /// </summary>
        public string AuthCode
        {
            get => _driver.AuthCode;
        }

        /// <summary>
        /// Тип карты: строка до 10 символов
        /// </summary>
        /// <remarks>
        /// Международная аббревиатура карты
        /// </remarks>
        public string CardType
        {
            get => _driver.CardType;
        }

        /// <summary>
        /// ID терминала: строка до 8 символов
        /// </summary>
        public string TerminalID
        {
            get => _driver.TerminalID;
        }

        /// <summary>
        /// Номер сообщения
        /// </summary>
        public int MsgNumber
        {
            get => _driver.MsgNumber;
        }

        /// <summary>
        /// Тип сообщения
        /// </summary>
        public string MessageType
        {
            get => _driver.MessageType;
        }

        /// <summary>
        /// Номер точки обслуживания
        /// </summary>
        public string MerchNumber
        {
            get => _driver.MerchNumber;
        }

        /// <summary>
        /// Категория точки обслуживания
        /// </summary>
        public string MerchCategoryCode
        {
            get => _driver.MerchCategoryCode;
        }

        /// <summary>
        /// Английское наименование точки обслуживания
        /// </summary>
        public string MerchEngName
        {
            get => _driver.MerchEngName;
        }

        /// <summary>
        /// Номер слипа
        /// </summary>
        public int SlipNumber
        {
            get => _driver.SlipNumber;
            set => _driver.SlipNumber = value;
        }

        /// <summary>
        /// Сумма скидки
        /// </summary>
        public double Discount
        {
            get => _driver.Discount;
        }

        /// <summary>
        /// Сумма начисленных бонусов
        /// </summary>
        public double Bonus
        {
            get => _driver.Bonus;
        }

        /// <summary>
        /// Тип отчета
        /// </summary>
        /// <remarks>
        /// TODO: Переделать на перечисление ?
        /// </remarks>
        public int ReportType
        {
            get => _driver.ReportType;
            set => _driver.ReportType = value;
        }

        /// <summary>
        /// Код авторизации: строка до 9 символов
        /// </summary>
        public string RepAuthCode
        {
            get => _driver.RepAuthCode;
            set => _driver.RepAuthCode = value;
        }

        /// <summary>
        /// Краткое название валюты
        /// </summary>
        public string RepCurAbbrev
        {
            get => _driver.RepCurAbbrev;
            set => _driver.RepCurAbbrev = value;
        }

        /// <summary>
        /// Тип операции
        /// </summary>
        public int RepOperationType
        {
            get => _driver.RepOperationType;
            set => _driver.RepOperationType = value;
        }

        /// <summary>
        /// Тип транзакции
        /// </summary>
        public int RepTransType
        {
            get => _driver.RepTransType;
            set => _driver.RepTransType = value;
        }

        /// <summary>
        /// Сумма операции
        /// </summary>
        public double RepSum
        {
            get => _driver.RepSum;
            set => _driver.RepSum = value;
        }

        /// <summary>
        /// Номер карты: до 19 буквенно-цифровых символов
        /// </summary>
        public string RepCardNumber
        {
            get => _driver.RepCardNumber;
            set => _driver.RepCardNumber = value;
        }

        /// <summary>
        /// Номер слипа
        /// </summary>
        public int RepSlipNumber
        {
            get => _driver.RepSlipNumber;
            set => _driver.RepSlipNumber = value;
        }

        /// <summary>
        /// Дата транзакции
        /// </summary>
        public string RepTransDate
        {
            get => _driver.RepTransDate;
            set => _driver.RepTransDate = value;
        }

        /// <summary>
        /// Время транзакции
        /// </summary>
        public string RepTransTime
        {
            get => _driver.RepTransTime;
            set => _driver.RepTransTime = value;
        }

        /// <summary>
        /// Номер сообщения
        /// </summary>
        public int RepMsgNumber
        {
            get => _driver.RepMsgNumber;
            set => _driver.RepMsgNumber = value;
        }

        /// <summary>
        /// ID терминала: строка до 8 символов
        /// </summary>
        public string RepTerminalID
        {
            get => _driver.RepTerminalID;
            set => _driver.RepTerminalID = value;
        }

        /// <summary>
        /// Ссылочный номер: строка до 50 символов
        /// </summary>
        public string RepReferenceNumber
        {
            get => _driver.RepReferenceNumber;
            set => _driver.RepReferenceNumber = value;
        }

        /// <summary>
        /// Код ответа от АС: строка до 10 символов
        /// </summary>
        public string RepResponseCode
        {
            get => _driver.RepResponseCode;
            set => _driver.RepResponseCode = value;
        }

        #endregion Низкоуровневые свойства

        #region Низкоуровневые методы

        /// <summary>
        /// Метод создает новую логическую систему и устанавливает ее текущей
        /// </summary>
        public void AddDevice()
        {
            _driver.AddDevice();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Метод производит удаление текущей логической системы
        /// </summary>
        public void DeleteDevice()
        {
            _driver.DeleteDevice();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Метод выводит на экран визуальную страницу свойств
        /// </summary>
        public void ShowProperties()
        {
            _driver.ShowProperties();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Метод выводит на экран визуальную страницу свойств выбранного протокола
        /// </summary>
        public void ShowPropertiesProtocol()
        {
            _driver.ShowPropertiesProtocol();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Метод выводит сервисное меню платежной системы
        /// </summary>
        public void ServiceMenu()
        {
            _driver.ServiceMenu();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Подготовка к online авторизации
        /// </summary>
        public void PrepareOnLineAuthorization()
        {
            _driver.PrepareOnLineAuthorization();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Online авторизация
        /// </summary>
        public void OnLineAuthorization()
        {
            _driver.OnLineAuthorization();
            if (_driver.ResultCode < 0)
                throw new PayTerminalException(_driver.ResultDescription);
        }

        /// <summary>
        /// Начать отчет
        /// </summary>
        public void BeginReport()
        {
            _driver.BeginReport();
            if (_driver.ResultCode < 0)
            {
                _driver.ResetState();
                throw new PayTerminalException(_driver.ResultDescription);
            }
        }

        /// <summary>
        /// Добавить данные в отчет
        /// </summary>
        public void AddToReport()
        {
            _driver.AddToReport();
            if (_driver.ResultCode < 0)
            {
                _driver.ResetState();
                throw new PayTerminalException(_driver.ResultDescription);
            }
        }

        /// <summary>
        /// Завершить отчет и сформировать результат
        /// </summary>
        public void EndReport()
        {
            _driver.EndReport();
            if (_driver.ResultCode < 0)
            {
                _driver.ResetState();
                throw new PayTerminalException(_driver.ResultDescription);
            }
        }

        /// <summary>
        /// Сброс состояния драйвера
        /// </summary>
        public void ResetState()
        {
            _driver.ResetState();
        }

        #endregion Низкоуровневые методы

        #endregion Низкоуровневые свойства и методы

        /// <summary>
        /// Оплата
        /// </summary>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если оплата выполнена (возможно, с ошибкой процессингового центра), null - если клиент отказался от оплаты (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult Pay(int sessionNumber, int checkNumber, decimal sum)
        {
            return DoPayOperation(0, sessionNumber, checkNumber, sum);
        }

        /// <summary>
        /// Возврат оплаты
        /// </summary>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если возврат оплаты выполнен (возможно, с ошибкой процессингового центра), null - если клиент отказался от возврата оплаты (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult PayReturn(int sessionNumber, int checkNumber, decimal sum)
        {
            return DoPayOperation(1, sessionNumber, checkNumber, sum);
        }

        /// <summary>
        /// Оплата или возврат оплаты
        /// </summary>
        /// <param name="operationType">код операции: 0 - оплата, 1 - возврат</param>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если операция выполнена (возможно, с ошибкой процессингового центра), null - если клиент отказался от операции (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult DoPayOperation(int operationType, int sessionNumber, int checkNumber, decimal sum)
        {
            _driver.ECRSessionNumber = sessionNumber;
            _driver.ECRReceiptNumber = checkNumber;
            _driver.OperationType = operationType;
            _driver.Sum = (double)sum;

            _driver.PrepareOnLineAuthorization();

            if (_driver.ResultCode == Result_UserBreak)
                return null;
            else if (_driver.ResultCode != Result_Success)
                throw new PayException
                {
                    ResultInfo = new ResultInfo
                    {
                        ResultCode = _driver.ResultCode,
                        ResultDescription = _driver.ResultDescription,
                        ResultPrompt = _driver.ResultPrompt
                    }
                };

            // TODO: зафиксировать состояния флагов
            //SaveFlags();
            //if (_driver.NeedReaderEntryDataTracks || _driver.NeedKeyboardEntryDataTracks || _driver.NeedReferenceNumber)
            //    throw new NotSupportedException();

            _driver.OnLineAuthorization();

            var resultInfo = new ResultInfo
            {
                ResultCode = _driver.ResultCode,
                ResultDescription = _driver.ResultDescription,
                ResultPrompt = _driver.ResultPrompt
            };

            // Следует сохранять авторизации с ResultCode >= 0 и ResultCode = -10000 ... -11000, т.е. те, на которые получен ответ АС, пусть даже отрицательный
            if (_driver.ResultCode >= Result_Success || IsACError(_driver.ResultCode))
            {
                return new PayResult
                {
                    SlipText = _driver.TextStr,
                    ResultInfo = resultInfo,
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        AuthCode = _driver.AuthCode,
                        TransType = _driver.TransType,
                        OperationType = _driver.OperationType,
                        Sum = (decimal)_driver.Sum,
                        CardNumber = _driver.CardNumber,
                        SlipNumber = _driver.SlipNumber,
                        TransDate = _driver.TransDate,
                        TransTime = _driver.TransTime,
                        MsgNumber = _driver.MsgNumber,
                        TerminalID = _driver.TerminalID,
                        ReferenceNumber = _driver.ReferenceNumber,
                        ResponseCode = _driver.ResponseCode
                    }
                };
            }
            else
                throw new PayException { ResultInfo = resultInfo };
        }

        private void SaveFlags()
        {
            bool needReaderEntryDataTracks = ConfigurationManager.AppSettings["needReaderEntryDataTracks"] == "true";
            bool needKeyboardEntryDataTracks = ConfigurationManager.AppSettings["needKeyboardEntryDataTracks"] == "true";
            bool needReferenceNumber = ConfigurationManager.AppSettings["needReferenceNumber"] == "true";
            if (needReaderEntryDataTracks || needKeyboardEntryDataTracks || needReferenceNumber)
            {
                string fileName = "Флаги.txt";
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(fileName))
                {
                    if (needReaderEntryDataTracks)
                        file.WriteLine($"NeedReaderEntryDataTracks: {_driver.NeedReaderEntryDataTracks}");
                    if (needKeyboardEntryDataTracks)
                        file.WriteLine($"NeedKeyboardEntryDataTracks: {_driver.NeedKeyboardEntryDataTracks}");
                    if (needReferenceNumber)
                        file.WriteLine($"NeedReferenceNumber: {_driver.NeedReferenceNumber}");
                }
            }
        }

        static bool IsACError(int code)
        {
            return Result_ACErrorLimit <= code && code <= Result_ACError;
        }

        public void Dispose()
        {
            // освобождение COM-объекта в соответствии с https://www.codeproject.com/Tips/235230/Proper-Way-of-Releasing-COM-Objects-in-NET
            Marshal.ReleaseComObject(_driver);
        }

        dynamic _driver = null;
    }
}
