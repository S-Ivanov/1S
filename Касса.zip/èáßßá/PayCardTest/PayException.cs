﻿using System;

namespace PayCardTest
{
    /// <summary>
    /// Ошибка оплаты
    /// </summary>
    public class PayException : ApplicationException
    {
        /// <summary>
        /// Результат выполнения операции
        /// </summary>
        public ResultInfo ResultInfo { get; set; }
    }
}
