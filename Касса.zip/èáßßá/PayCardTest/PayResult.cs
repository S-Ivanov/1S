﻿namespace PayCardTest
{
    /// <summary>
    /// Результат оплаты
    /// </summary>
    public class PayResult
    {
        /// <summary>
        /// Строки слипа разделенные парой символов #13 (возврат каретки) и #10 (перевод строки).
        /// </summary>
        public string SlipText { get; set; }

        /// <summary>
        /// Результат выполнения операции
        /// </summary>
        public ResultInfo ResultInfo { get; set; }
        
        /// <summary>
        /// Информация, которую нужно сохранять в базе после выполнения авторизации на терминале (метод PayTerminal.OnLineAuthorization())
        /// </summary>
        public AuthorizationInfo AuthorizationInfo { get; set; }
    }
}
