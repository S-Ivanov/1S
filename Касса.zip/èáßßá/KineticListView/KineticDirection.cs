﻿using System;

namespace KineticListView
{
    [Flags]
    public enum KineticDirection
    {
        Both = 3,
        Vertical = 1,
        Horizontal = 2,
    }
}