﻿using System.Collections.Generic;

namespace Drg.PaymentInitInterface
{
    public interface IPaymentInit
    {
        /// <summary>
        /// Cформировать автоматическую разноску суммы заказа по видам оплат
        /// </summary>
        /// <param name="paymentTypes">варианты оплаты + стоимость единицы оплаты</param>
        /// <param name="limits">варианты оплаты + лимит использования в единицах оплаты</param>
        /// <param name="startPaymentType">инициируемый вариант оплаты</param>
        /// <param name="sum">сумма</param>
        /// <returns>варианты оплаты + количество единиц оплаты</returns>
        /// <remarks>
        /// Например, сумма заказа = 250, оплата талоном ЛПП
        /// Предлагаемая разноска: 1 талон ЛПП + 2 руб. в счет з/п
        /// Возврат:
        /// - (код ЛПП) = 1
        /// - (код з/п) = 2
        /// </remarks>
        bool TryInit(IDictionary<int, decimal> paymentTypes, IDictionary<int, decimal> limits, int startPaymentType, decimal sum, out IDictionary<int, decimal> result);
    }
}
