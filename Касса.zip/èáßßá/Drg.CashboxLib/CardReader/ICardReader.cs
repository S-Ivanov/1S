﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashboxLib.CardReader
{
    /// <summary>
    /// Считыватель карт
    /// </summary>
    public interface ICardReader : IDisposable
    {
        /// <summary>
        /// Запуск
        /// </summary>
        void Start();

        /// <summary>
        /// Событие карта поднесена/убрана
        /// </summary>
        event EventHandler<CardReaderNotifyEventArgs> CardNotify;
    }
}
