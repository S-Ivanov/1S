﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashboxLib
{
    /// <summary>
    /// Кассир
    /// </summary>
    public class Cashier
    {
        public Cashier(string fio, string post, string inn)
        {
            if (string.IsNullOrWhiteSpace(fio))
                throw new ArgumentNullException(nameof(fio));
            if (string.IsNullOrWhiteSpace(post))
                throw new ArgumentNullException(nameof(post));
            if (string.IsNullOrWhiteSpace(inn))
                throw new ArgumentNullException(nameof(inn));

            FIO = fio;
            Post = post;
            INN = inn;
        }

        public string FIO { get; private set; }
        public string Post { get; private set; }
        public string INN { get; private set; }
    }
}
