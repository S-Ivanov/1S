﻿using Drg.CashboxLib.CardReader;
using System;

namespace Drg.CashboxLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class Cashbox : IDisposable
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="useRealEquipment">индикатор использования реального железа</param>
        /// <param name="cardReader_Port">имя порта считывателя, например COM3</param>
        /// <param name="cardReader_OpenDelay">задержка открытия порта считывателя, мсек</param>
        public Cashbox(bool useRealEquipment, string cardReader_Port, int cardReader_OpenDelay = 0)
        {
            if (useRealEquipment)
                Reader = new CardReaderZ2(cardReader_Port, cardReader_OpenDelay);
            else
                Reader = new CardReader_Mock("123", 2000);

            Reader.Start();
        }

        public Cashier FindCashier(string cardNum)
        {
            
            throw new NotImplementedException();
        }

        #region Реализация IDisposable

        public void Dispose()
        {
            if (Reader != null)
                Reader.Dispose();
        }

        #endregion Реализация IDisposable

        public ICardReader Reader { get; private set; }
    }
}
