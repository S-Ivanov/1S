﻿using System;
using System.Collections.Generic;

namespace Drg.PlanMenuReader
{
    /// <summary>
    /// План-меню
    /// </summary>
    public class Menu
    {
        /// <summary>
        /// Дата + время
        /// </summary>
        /// <remarks>
        /// В работе использовать только дату
        /// </remarks>
        public DateTime DateTime { get; set; }

        /// <summary>
        /// Номер меню
        /// </summary>
        public string Number { get; set; }

        /// <summary>
        /// Элементы меню
        /// </summary>
        public List<MenuItem> Items
        {
            get { return items; }
        }
        List<MenuItem> items = new List<MenuItem>();
    }
}
