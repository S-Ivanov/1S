﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.PlanMenuReader
{
    public class Menu
    {
        public List<Nomenclature> Nomenclatures
        {
            get { return nomenclatures; }
        }
        List<Nomenclature> nomenclatures = new List<Nomenclature>();
    }
}
