﻿using System.Collections.Generic;

namespace Drg.PlanMenuReader
{
    /// <summary>
    /// Номенклатура / группа
    /// </summary>
    public class Nomenclature : IdNameObject
    {
        /// <summary>
        /// Идентификатор родительской номенклатуры (группы)
        /// </summary>
        public string IdParent { get; set; }

        /// <summary>
        /// Дочерние номенклатуры
        /// </summary>
        public List<Nomenclature> Childs { get; set; }
    }
}
