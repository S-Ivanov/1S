﻿using System.Collections.Generic;

namespace Drg.PlanMenuReader
{
    public class Menus
    {
        /// <summary>
        /// Все меню, включенные в файл обмена 1С
        /// </summary>
        public List<Menu> AllMenus
        {
            get { return allMenus; }
        }
        List<Menu> allMenus = new List<Menu>();

        /// <summary>
        /// Справочник номенклатуры
        /// </summary>
        public List<Nomenclature> Nomenclatures
        {
            get { return nomenclatures; }
        }
        List<Nomenclature> nomenclatures = new List<Nomenclature>();

        /// <summary>
        /// Справочник единиц измерения
        /// </summary>
        public List<Unit> Units
        {
            get { return units; }
        }
        List<Unit> units = new List<Unit>();

        // TODO: МестаРеализации - проверять с идентификацией кассы ?

    }
}
