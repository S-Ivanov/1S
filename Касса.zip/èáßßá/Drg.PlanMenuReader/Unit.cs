﻿namespace Drg.PlanMenuReader
{
    /// <summary>
    /// Единица измерения
    /// </summary>
    public class Unit : IdNameObject
    {
    }
}
