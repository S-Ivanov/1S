﻿using System;

namespace Drg.PlanMenuReader
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Идентификатор номенклатуры
        /// </summary>
        public string NomenclatureId { get; set; }

        /// <summary>
        /// Код единицы измерения
        /// </summary>
        public string UnitId { get; set; }
        
        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }
    }
}
