﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace Drg.PlanMenuReader
{
    public static class MenuReader
    {
        public static Menu Read(string fileName)
        {
            XDocument xDocument = XDocument.Load(fileName);

            Menu menu = new Menu();
            Dictionary<string, List<Nomenclature>> notParentedNomenclatures = new Dictionary<string, List<Nomenclature>>();

            foreach (var element in xDocument.Element("ФайлОбмена").Elements("Объект"))
            {
                var type = (string)element.Attribute("Тип");
                if (type == "СправочникСсылка.Номенклатура")
                {
                    ProceedNomenclature(element, menu, notParentedNomenclatures);
                }
            }

            // стр. 10177 - первое план-меню

            return menu;
        }

        private static void ProceedNomenclature(XElement element, Menu menu, Dictionary<string, List<Nomenclature>> notParentedNomenclatures)
        {
            string id = 
                (string)element
                .Element("Ссылка")
                .Elements("Свойство")
                .First(el => (string)el.Attribute("Имя") == "Код")
                .Element("Значение");

            string name = 
                (string)element
                .Elements("Свойство")
                .First(el => (string)el.Attribute("Имя") == "Наименование")
                .Element("Значение");

            bool isGroup = 
                (string)element
                .Element("Ссылка")
                .Elements("Свойство")
                .First(el => (string)el.Attribute("Имя") == "ЭтоГруппа")
                .Element("Значение") 
                == "true";

            if (isGroup)
            {
                var parentNomenclature = new Nomenclature { Id = id, Name = name, Childs = new List<Nomenclature>() };
                if (notParentedNomenclatures.TryGetValue(id, out List<Nomenclature> childNomenclatures))
                {
                    parentNomenclature.Childs.AddRange(childNomenclatures);
                    notParentedNomenclatures.Remove(id);
                }
                menu.Nomenclatures.Add(parentNomenclature);
            }
            else
            {
                // добавить в меню дочернюю номенклатуру
                string parentId =
                    (string)element
                    .Elements("Свойство").First(el => (string)el.Attribute("Имя") == "Родитель")
                    .Element("Ссылка")
                    .Elements("Свойство")
                    .First(el => (string)el.Attribute("Имя") == "Код")
                    .Element("Значение");

                List<Nomenclature> childNomenclatures = null;
                var parentNomenclature = menu.Nomenclatures.FirstOrDefault(n => n.Id == parentId);
                if (parentNomenclature == null)
                {
                    // если родитель не найден, поместить номенклатуру во временный буфер
                    if (!notParentedNomenclatures.TryGetValue(parentId, out childNomenclatures))
                    {
                        childNomenclatures = new List<Nomenclature>();
                        notParentedNomenclatures.Add(parentId, childNomenclatures);
                    }
                }
                else
                    childNomenclatures = parentNomenclature.Childs;

                childNomenclatures.Add(new Nomenclature { Id = id, Name = name });
            }
        }
    }
}
