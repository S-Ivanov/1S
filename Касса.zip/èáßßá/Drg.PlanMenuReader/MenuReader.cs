﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace Drg.PlanMenuReader
{
    /// <summary>
    /// Разбор файла обмена 1С
    /// </summary>
    public static class MenuReader
    {
        /// <summary>
        /// Разбор файла
        /// </summary>
        /// <param name="fileName">полное имя файла</param>
        /// <returns></returns>
        public static Menus Read(string fileName)
        {
            XDocument xDocument = XDocument.Load(fileName);

            Menus menus = new Menus();
            // буфер не привязанных к группе номенклатур
            Dictionary<string, List<Nomenclature>> notParentedNomenclatures = new Dictionary<string, List<Nomenclature>>();

            foreach (var element in xDocument.Element("ФайлОбмена").Elements("Объект"))
            {
                var type = (string)element.Attribute("Тип");
                switch (type)
                {
                    case "СправочникСсылка.Номенклатура":
                        ProceedNomenclature(element, menus, notParentedNomenclatures);
                        break;
                    case "ДокументСсылка.ПланМеню":
                        ProceedMenu(element, menus);
                        break;
                    case "СправочникСсылка.КлассификаторЕдиницИзмерения":
                        ProceedUnit(element, menus);
                        break;
                }
            }

            return menus;
        }

        /// <summary>
        /// Обработать единицу измерения
        /// </summary>
        /// <param name="element"></param>
        /// <param name="menus"></param>
        private static void ProceedUnit(XElement element, Menus menus)
        {
            menus.Units.Add(
                new Unit
                {
                    Id = GetRefPropValue(element, "Код").TrimEnd(),
                    Name = GetPropValue(element, "Наименование")
                });
        }

        /// <summary>
        /// Обработать меню
        /// </summary>
        /// <param name="element"></param>
        /// <param name="menus"></param>
        private static void ProceedMenu(XElement element, Menus menus)
        {
            var menu = new Menu
            {
                DateTime = DateTime.Parse(GetRefPropValue(element, "Дата")),
                Number = GetRefPropValue(element, "Номер")
            };
            foreach (var record in element.Elements("ТабличнаяЧасть").First(el => (string)el.Attribute("Имя") == "Товары").Elements("Запись"))
            {
                var product = new Product
                {
                    Id = Guid.Parse(GetPropValue(record, "ИдентификаторТовара")),
                    UnitId = GetPropRefPropValue(record, "ЕдиницаИзмерения", "Код").TrimEnd(),
                    NomenclatureId = GetPropRefPropValue(record, "Номенклатура", "Код"),
                    Price = decimal.Parse(GetPropValue(record, "Цена"), NumberFormatInfo.InvariantInfo),
                    Count = decimal.Parse(GetPropValue(record, "Количество"), NumberFormatInfo.InvariantInfo)
                };
                if (!menus.Products.ContainsKey(product.Id))
                    menus.Products.Add(product.Id, product);
                menu.Items.Add(product);
            }
            menus.AllMenus.Add(menu);
        }

        /// <summary>
        /// Обработать номенклатуру
        /// </summary>
        /// <param name="element"></param>
        /// <param name="menus"></param>
        /// <param name="notParentedNomenclatures">буфер не привязанных к группе номенклатур</param>
        private static void ProceedNomenclature(XElement element, Menus menus, Dictionary<string, List<Nomenclature>> notParentedNomenclatures)
        {
            string id = GetRefPropValue(element, "Код");
            string name = GetPropValue(element, "Наименование");

            if (bool.Parse(GetRefPropValue(element, "ЭтоГруппа")))
            {
                var parentNomenclature = new Nomenclature { Id = id, Name = name, Childs = new List<Nomenclature>() };
                if (notParentedNomenclatures.TryGetValue(id, out List<Nomenclature> childNomenclatures))
                {
                    parentNomenclature.Childs.AddRange(childNomenclatures);
                    notParentedNomenclatures.Remove(id);
                }
                menus.Nomenclatures.Add(parentNomenclature);
            }
            else
            {
                // добавить в меню дочернюю номенклатуру
                string idParent = GetPropRefPropValue(element, "Родитель", "Код");

                List<Nomenclature> childNomenclatures = null;
                var parentNomenclature = menus.Nomenclatures.FirstOrDefault(n => n.Id == idParent);
                if (parentNomenclature == null)
                {
                    // если родитель не найден, поместить номенклатуру во временный буфер
                    if (!notParentedNomenclatures.TryGetValue(idParent, out childNomenclatures))
                    {
                        childNomenclatures = new List<Nomenclature>();
                        notParentedNomenclatures.Add(idParent, childNomenclatures);
                    }
                }
                else
                    childNomenclatures = parentNomenclature.Childs;

                childNomenclatures.Add(new Nomenclature { Id = id, Name = name, IdParent = idParent });
            }
        }

        /// <summary>
        /// Получить значение xml-узла по цепочке "element.Свойство[Имя = propName1].Ссылка.Свойство[Имя = propName2].Значение"
        /// </summary>
        /// <param name="element"></param>
        /// <param name="propName1"></param>
        /// <param name="propName2"></param>
        /// <returns></returns>
        static string GetPropRefPropValue(XElement element, string propName1, string propName2)
        {
            return GetRefPropValue(element.Elements("Свойство").First(el => (string)el.Attribute("Имя") == propName1), propName2);
        }

        /// <summary>
        /// Получить значение xml-узла по цепочке "element.Ссылка.Свойство[Имя = propName].Значение"
        /// </summary>
        /// <param name="element"></param>
        /// <param name="propName"></param>
        /// <returns></returns>
        static string GetRefPropValue(XElement element, string propName)
        {
            return GetPropValue(element.Element("Ссылка"), propName);
        }

        /// <summary>
        /// Получить значение xml-узла по цепочке "element.Свойство[Имя = propName].Значение"
        /// </summary>
        /// <param name="element"></param>
        /// <param name="propName"></param>
        /// <returns></returns>
        static string GetPropValue(XElement element, string propName)
        {
            return
                (string)element
                .Elements("Свойство")
                .First(el => (string)el.Attribute("Имя") == propName)
                .Element("Значение");
        }
    }
}
