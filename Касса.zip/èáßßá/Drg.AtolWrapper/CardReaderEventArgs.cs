﻿using System;

namespace Drg.AtolWrapper
{
    public class CardReaderEventArgs : EventArgs
    {
        public CardReaderEventArgs(string cardCode)
        {
            CardCode = cardCode;
        }

        public string CardCode { get; private set; }
    }
}
