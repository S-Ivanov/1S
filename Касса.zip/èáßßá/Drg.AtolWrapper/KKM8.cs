﻿using System;
using System.Runtime.InteropServices;

namespace Drg.AtolWrapper
{
    /// <summary>
    /// ККМ - версия 8.12.0.0
    /// </summary>
    public class KKM8 : IKKM, IDisposable
    {
        public KKM8()
        {
            Type f = Type.GetTypeFromProgID("AddIn.FprnM45", true);
            _driver = Activator.CreateInstance(f);
            if (_driver == null)
                throw new NotSupportedException();

            _driver.DeviceEnabled = true;
            _driver.ResetMode();
        }

        #region Реализация интерфейса IKKM

        public int SlipCharLineLength
        {
            get
            {
                _driver.RegisterNumber = 24;
                _driver.GetRegister();
                return _driver.RcpCharLineLength;
            }
        }

        public int Session
        {
            get
            {
                _driver.RegisterNumber = 21;
                _driver.GetRegister();
                return _driver.Session;
            }
        }

        public SessionState SessionState
        {
            get
            {
                _driver.RegisterNumber = 18;
                _driver.GetRegister();
                if (_driver.SessionOpened)
                    return SessionState.Opened;
                else if (_driver.SessionExceedLimit)
                    return SessionState.Expired;
                else
                    return SessionState.Closed;
            }
        }

        public int CheckNumber
        {
            get
            {
                ReadRegister19();
                return _driver.CheckNumber;
            }
        }

        public CheckState CheckState
        {
            get
            {
                ReadRegister19();
                switch ((int)_driver.CheckState)
                {
                    case 0:
                        return CheckState.Closed;
                    case 1:
                        return CheckState.Sell;
                    case 2:
                        return CheckState.SellReturn;
                    case 3:
                        return CheckState.SellCancel;
                    case 4:
                        return CheckState.Buy;
                    case 5:
                        return CheckState.BuyReturn;
                    default:
                        return CheckState.Closed;
                }
            }
        }

        public bool NotPrinted => notPrinted;

        public void OpenSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            // метод SetMode
            // DefaultPassword
            // Password
            // Caption
            _driver.Mode = 1;
            _driver.SetMode();
            try
            {
                _driver.OpenSession();
                if (_driver.ResultCode != 0)
                    throw new DeviceException(_driver.ResultCode, _driver.ResultDescription);
            }
            finally
            {
                _driver.ResetMode();
            }
        }

        public void CloseSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            // ?
        }

        public void PrintString(string s)
        {
            _driver.Caption = s;
            _driver.PrintString();
        }

        #endregion Реализация интерфейса IKKM

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            _driver.ResetMode();
            // освобождение COM-объекта в соответствии с https://www.codeproject.com/Tips/235230/Proper-Way-of-Releasing-COM-Objects-in-NET
            Marshal.ReleaseComObject(_driver);
        }

        #endregion Реализация интерфейса IDisposable

        void ReadRegister19()
        {
            if (!readRegister19Complete)
            {
                _driver.RegisterNumber = 19;
                _driver.GetRegister();

                readRegister19Complete = true;
            }
        }

        //void GetStatus()
        //{
        //    if (!statusRead)
        //    {
        //        _driver.GetStatus();
        //        statusRead = true;
        //    }
        //}

        //bool statusRead = false;

        /// <summary>
        /// Документ закрыт, но не допечатан
        /// </summary>
        bool notPrinted = false;

        bool readRegister19Complete = false;

        dynamic _driver = null;
    }
}
