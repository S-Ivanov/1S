﻿namespace Drg.AtolWrapper
{
    /// <summary>
    /// Информация, которую нужно сохранять в базе после выполнения авторизации на терминале (метод PayTerminal.OnLineAuthorization())
    /// </summary>
    public class AuthorizationInfo
    {
        public string AuthCode { get; set; }
        public int TransType { get; set; }
        public int OperationType { get; set; }
        public decimal Sum { get; set; }
        public string CardNumber { get; set; }
        public int SlipNumber { get; set; }
        // TODO: разобраться с датой
        //public DateTime TransDate { get; set; }
        public string TransDate { get; set; }
        // TODO: разобраться с временем
        //public TimeSpan TransTime { get; set; }
        public string TransTime { get; set; }
        public int MsgNumber { get; set; }
        public string TerminalID { get; set; }
        public string ReferenceNumber { get; set; }
        public string ResponseCode { get; set; }
    }
}
