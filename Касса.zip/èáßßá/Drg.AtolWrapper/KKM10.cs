﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;

namespace Drg.AtolWrapper
{
    public class KKM10 : IKKM, IDisposable
    {
        #region Конструктор

        public KKM10(string dllFileName, string settings)
        {
            // загружаем библиотеку только 1 раз
            if (dllHandle == IntPtr.Zero)
                dllHandle = NativeMethods.LoadLibrary(dllFileName);

            if (dllHandle == IntPtr.Zero)
                throw new DllNotFoundException(dllFileName);

            CheckError(_libfptr_create(out driverHandle));
            CheckError(_libfptr_set_settings(driverHandle, settings));
            CheckError(_libfptr_open(driverHandle));

            ReadShiftStatus();
        }

        #endregion Конструктор

        #region Реализация интерфейса IKKM

        public int SlipCharLineLength
        {
            get
            {
                ReadDeviceInfo();
                return charLineLength;
            }
        }

        public int Session
        {
            get
            {
                //ReadShiftStatus();
                return session;
            }
        }

        public int CheckNumber
        {
            get
            {
                ReadStatus();
                return (int)_libfptr_get_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_RECEIPT_NUMBER);
            }
        }

        public CheckState CheckState
        {
            get
            {
                ReadStatus();

                var receiptType = _libfptr_get_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_RECEIPT_TYPE);
                switch (receiptType)
                {
                    case 0:
                        return CheckState.Closed;
                    case 1:
                        return CheckState.Sell;
                    case 2:
                        return CheckState.SellReturn;
                    case 4:
                        return CheckState.Buy;
                    case 5:
                    case 9:
                        return CheckState.BuyReturn;
                    case 7:
                        return CheckState.SellCancel;
                    default:
                        return CheckState.Closed;
                }
            }
        }

        public SessionState SessionState
        {
            get
            {
                //ReadShiftStatus();
                return sessionState;
            }
        }

        public bool NotPrinted => notPrinted;

        public void OpenSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            if (sessionState != SessionState.Opened)
            {
                dynamic x1 = ProcessJson(new { type = "openShift", @operator = new { name = $"{operatorFIO} {operatorPost}".TrimEnd(), vatin = operatorINN } }, 1024);
                session = x1["fiscalParams"]["shiftNumber"];
                notPrinted = x1["warnings"]["notPrinted"];

                dynamic x2 = ProcessJson(new { type = "getShiftStatus" }, 1024);
                sessionState = SessionStatusFromString(x2["shiftStatus"]["state"]);
            }
        }

        public void CloseSession(string operatorFIO, string operatorPost, string operatorINN)
        {
            if (sessionState == SessionState.Opened)
            {
                dynamic x1 = ProcessJson(new { type = "closeShift", @operator = new { name = $"{operatorFIO} {operatorPost}".TrimEnd(), vatin = operatorINN } }, 1024);
                session = x1["fiscalParams"]["shiftNumber"];
                // TODO: разобраться с флагом notPrinted
                notPrinted = x1["warnings"]["notPrinted"];
                sessionState = SessionState.Closed;
            }
        }

        public void PrintString(string s)
        {
            _libfptr_set_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_TEXT, s);
            CheckError(_libfptr_print_text(driverHandle));
        }

        #endregion Реализация интерфейса IKKM

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            if (driverHandle != IntPtr.Zero)
            {
                try
                {
                    _libfptr_close(driverHandle);
                    _libfptr_destroy(driverHandle);
                }
                catch
                {
                    // все ошибки игнорируем
                }
            }
        }

        #endregion Реализация интерфейса IDisposable

        #region Делегаты, соответствующие функциям dll

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_create(out IntPtr handle);
        libfptr_create __libfptr_create = null;
        libfptr_create _libfptr_create
        {
            get
            {
                if (__libfptr_create == null)
                    __libfptr_create = GetFunction<libfptr_create>();
                return __libfptr_create;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_close(IntPtr handle);
        libfptr_close __libfptr_close = null;
        libfptr_close _libfptr_close
        {
            get
            {
                if (__libfptr_close == null)
                    __libfptr_close = GetFunction<libfptr_close>();
                return __libfptr_close;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_destroy(IntPtr handle);
        libfptr_destroy __libfptr_destroy = null;
        libfptr_destroy _libfptr_destroy
        {
            get
            {
                if (__libfptr_destroy == null)
                    __libfptr_destroy = GetFunction<libfptr_destroy>();
                return __libfptr_destroy;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_set_settings(IntPtr handle, string settings);
        libfptr_set_settings __libfptr_set_settings = null;
        libfptr_set_settings _libfptr_set_settings
        {
            get
            {
                if (__libfptr_set_settings == null)
                    __libfptr_set_settings = GetFunction<libfptr_set_settings>();
                return __libfptr_set_settings;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_open(IntPtr handle);
        libfptr_open __libfptr_open = null;
        libfptr_open _libfptr_open
        {
            get
            {
                if (__libfptr_open == null)
                    __libfptr_open = GetFunction<libfptr_open>();
                return __libfptr_open;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate void libfptr_set_param_str(IntPtr handle, libfptr_param param_id, string value);
        libfptr_set_param_str __libfptr_set_param_str = null;
        libfptr_set_param_str _libfptr_set_param_str
        {
            get
            {
                if (__libfptr_set_param_str == null)
                    __libfptr_set_param_str = GetFunction<libfptr_set_param_str>();
                return __libfptr_set_param_str;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_print_text(IntPtr handle);
        libfptr_print_text __libfptr_print_text = null;
        libfptr_print_text _libfptr_print_text
        {
            get
            {
                if (__libfptr_print_text == null)
                    __libfptr_print_text = GetFunction<libfptr_print_text>();
                return __libfptr_print_text;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate uint libfptr_get_param_int(IntPtr handle, libfptr_param param_id);
        libfptr_get_param_int __libfptr_get_param_int = null;
        libfptr_get_param_int _libfptr_get_param_int
        {
            get
            {
                if (__libfptr_get_param_int == null)
                    __libfptr_get_param_int = GetFunction<libfptr_get_param_int>();
                return __libfptr_get_param_int;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void libfptr_set_param_int(IntPtr handle, libfptr_param param_id, uint value);
        libfptr_set_param_int __libfptr_set_param_int = null;
        libfptr_set_param_int _libfptr_set_param_int
        {
            get
            {
                if (__libfptr_set_param_int == null)
                    __libfptr_set_param_int = GetFunction<libfptr_set_param_int>();
                return __libfptr_set_param_int;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_query_data(IntPtr handle);
        libfptr_query_data __libfptr_query_data = null;
        libfptr_query_data _libfptr_query_data
        {
            get
            {
                if (__libfptr_query_data == null)
                    __libfptr_query_data = GetFunction<libfptr_query_data>();
                return __libfptr_query_data;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_process_json(IntPtr handle);
        libfptr_process_json __libfptr_process_json = null;
        libfptr_process_json _libfptr_process_json
        {
            get
            {
                if (__libfptr_process_json == null)
                    __libfptr_process_json = GetFunction<libfptr_process_json>();
                return __libfptr_process_json;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_get_param_str(IntPtr handle, libfptr_param param_id, StringBuilder value, int size);
        libfptr_get_param_str __libfptr_get_param_str = null;
        libfptr_get_param_str _libfptr_get_param_str
        {
            get
            {
                if (__libfptr_get_param_str == null)
                    __libfptr_get_param_str = GetFunction<libfptr_get_param_str>();
                return __libfptr_get_param_str;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int libfptr_error_code(IntPtr handle);
        libfptr_error_code __libfptr_error_code = null;
        libfptr_error_code _libfptr_error_code
        {
            get
            {
                if (__libfptr_error_code == null)
                    __libfptr_error_code = GetFunction<libfptr_error_code>();
                return __libfptr_error_code;
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private delegate int libfptr_error_description(IntPtr handle, StringBuilder value, int size);
        libfptr_error_description __libfptr_error_description = null;
        libfptr_error_description _libfptr_error_description
        {
            get
            {
                if (__libfptr_error_description == null)
                    __libfptr_error_description = GetFunction<libfptr_error_description>();
                return __libfptr_error_description;
            }
        }

        #endregion Делегаты, соответствующие функциям dll

        #region Private methods

        T GetFunction<T>() where T: class
        {
            Type t = typeof(T);
            IntPtr functionHandle = NativeMethods.GetProcAddress(dllHandle, t.Name);
            if (functionHandle == IntPtr.Zero)
                throw new MethodAccessException(t.Name);
            return Marshal.GetDelegateForFunctionPointer(functionHandle, t) as T;
        }

        void ReadStatus()
        {
            if (!readStatusComplete)
            {
                _libfptr_set_param_int(driverHandle, libfptr_param.LIBFPTR_PARAM_DATA_TYPE, (uint)libfptr_kkt_data_type.LIBFPTR_DT_STATUS);
                CheckError(_libfptr_query_data(driverHandle));
                readStatusComplete = true;
            }
        }

        private void ReadDeviceInfo()
        {
            if (!readDeviceInfoComplete)
            {
                dynamic x = ProcessJson(new { type = "getDeviceInfo" }, 1024);
                charLineLength = x["deviceInfo"]["receiptLineLength"];
                readDeviceInfoComplete = true;
            }
        }

        private void ReadShiftStatus()
        {
            if (session < 0)
            {
                dynamic x = ProcessJson(new { type = "getShiftStatus" }, 1024);
                session = x["shiftStatus"]["number"];
                sessionState = SessionStatusFromString(x["shiftStatus"]["state"]);
            }
        }

        private static SessionState SessionStatusFromString(string sessionStateStr)
        {
            if (sessionStateStr == "opened")
                return SessionState.Opened;
            else if (sessionStateStr == "expired")
                return SessionState.Expired;
            else // if (sessionStateStr == "closed")
                return SessionState.Closed;
        }

        void ProcessJson(object jsonParams, JavaScriptSerializer serializer = null)
        {
            _libfptr_set_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_JSON_DATA, (serializer ?? new JavaScriptSerializer()).Serialize(jsonParams));
            CheckError(_libfptr_process_json(driverHandle));
        }

        void CheckError(int result)
        {
            if (result < 0)
            {
                int errorCode = GetFunction<libfptr_error_code>()(driverHandle);
                StringBuilder sb = new StringBuilder(1024);
                _libfptr_error_description(driverHandle, sb, 1024);
                throw new DeviceException(errorCode, sb.ToString());
            }
        }

        /// <summary>
        /// Выполнить на ККМ команду JSON с возвратом результата в виде словаря Dictionary<string, object>
        /// </summary>
        /// <param name="jsonParams"></param>
        /// <param name="bufferSize"></param>
        /// <returns></returns>
        object ProcessJson(object jsonParams, int bufferSize)
        {
            var serializer = new JavaScriptSerializer();
            return serializer.Deserialize<object>(ProcessJsonResult(jsonParams, bufferSize, serializer));
        }

        /// <summary>
        /// Выполнить на ККМ команду JSON с возвратом результата в виде строки
        /// </summary>
        /// <param name="jsonParams"></param>
        /// <param name="bufferSize"></param>
        /// <returns></returns>
        string ProcessJsonResult(object jsonParams, int bufferSize, JavaScriptSerializer serializer = null)
        {
            ProcessJson(jsonParams, serializer);

            StringBuilder sb = new StringBuilder(bufferSize);
            CheckError(_libfptr_get_param_str(driverHandle, libfptr_param.LIBFPTR_PARAM_JSON_DATA, sb, bufferSize));
            return sb.ToString();
        }

        T ProcessJson<T>(object jsonParams, int bufferSize)
        {
            var serializer = new JavaScriptSerializer();
            return serializer.Deserialize<T>(ProcessJsonResult(jsonParams, bufferSize, serializer));
        }

        #endregion Private methods

        #region Private fields

        /// <summary>
        /// Указатель на драйвер
        /// </summary>
        IntPtr driverHandle = IntPtr.Zero;

        /// <summary>
        /// Указатель на dll
        /// </summary>
        static IntPtr dllHandle = IntPtr.Zero;

        /// <summary>
        /// Ширина ленты ККМ в символах
        /// </summary>
        int charLineLength = -1;

        /// <summary>
        /// Номер смены
        /// </summary>
        int session = -1;

        /// <summary>
        /// Состояние смены
        /// </summary>
        SessionState sessionState;

        /// <summary>
        /// Документ закрыт, но не допечатан
        /// </summary>
        bool notPrinted = false;


        bool readStatusComplete = false;

        bool readDeviceInfoComplete = false;

        #endregion Private fields

        #region Private types

        enum libfptr_param : int
        {
            LIBFPTR_PARAM_FIRST = 65536,
            LIBFPTR_PARAM_TEXT = LIBFPTR_PARAM_FIRST,
            LIBFPTR_PARAM_TEXT_WRAP,
            LIBFPTR_PARAM_ALIGNMENT,

            LIBFPTR_PARAM_FONT,
            LIBFPTR_PARAM_FONT_DOUBLE_WIDTH,
            LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT,
            LIBFPTR_PARAM_LINESPACING,
            LIBFPTR_PARAM_BRIGHTNESS,

            LIBFPTR_PARAM_MODEL,
            LIBFPTR_PARAM_RECEIPT_TYPE,
            LIBFPTR_PARAM_REPORT_TYPE,
            LIBFPTR_PARAM_MODE,
            LIBFPTR_PARAM_EXTERNAL_DEVICE_TYPE,
            LIBFPTR_PARAM_EXTERNAL_DEVICE_DATA,
            LIBFPTR_PARAM_FREQUENCY,
            LIBFPTR_PARAM_DURATION,
            LIBFPTR_PARAM_CUT_TYPE,
            LIBFPTR_PARAM_DRAWER_ON_TIMEOUT,
            LIBFPTR_PARAM_DRAWER_OFF_TIMEOUT,
            LIBFPTR_PARAM_DRAWER_ON_QUANTITY,
            LIBFPTR_PARAM_TIMEOUT_ENQ,
            LIBFPTR_PARAM_COMMAND_BUFFER,
            LIBFPTR_PARAM_ANSWER_BUFFER,
            LIBFPTR_PARAM_SERIAL_NUMBER,
            LIBFPTR_PARAM_MANUFACTURER_CODE,
            LIBFPTR_PARAM_NO_NEED_ANSWER,
            LIBFPTR_PARAM_INFO_DISCOUNT_SUM,
            LIBFPTR_PARAM_USE_ONLY_TAX_TYPE,
            LIBFPTR_PARAM_PAYMENT_TYPE,
            LIBFPTR_PARAM_PAYMENT_SUM,
            LIBFPTR_PARAM_REMAINDER,
            LIBFPTR_PARAM_CHANGE,
            LIBFPTR_PARAM_DEPARTMENT,
            LIBFPTR_PARAM_TAX_TYPE,
            LIBFPTR_PARAM_TAX_SUM,
            LIBFPTR_PARAM_TAX_MODE,
            LIBFPTR_PARAM_RECEIPT_ELECTRONICALLY,
            LIBFPTR_PARAM_USER_PASSWORD,
            LIBFPTR_PARAM_SCALE,
            LIBFPTR_PARAM_LEFT_MARGIN,
            LIBFPTR_PARAM_BARCODE,
            LIBFPTR_PARAM_BARCODE_TYPE,
            LIBFPTR_PARAM_BARCODE_PRINT_TEXT,
            LIBFPTR_PARAM_BARCODE_VERSION,
            LIBFPTR_PARAM_BARCODE_CORRECTION,
            LIBFPTR_PARAM_BARCODE_COLUMNS,
            LIBFPTR_PARAM_BARCODE_INVERT,
            LIBFPTR_PARAM_HEIGHT,
            LIBFPTR_PARAM_WIDTH,
            LIBFPTR_PARAM_FILENAME,
            LIBFPTR_PARAM_PICTURE_NUMBER,
            LIBFPTR_PARAM_DATA_TYPE,
            LIBFPTR_PARAM_OPERATOR_ID,
            LIBFPTR_PARAM_LOGICAL_NUMBER,
            LIBFPTR_PARAM_DATE_TIME,
            LIBFPTR_PARAM_FISCAL,
            LIBFPTR_PARAM_SHIFT_STATE,
            LIBFPTR_PARAM_CASHDRAWER_OPENED,
            LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT,
            LIBFPTR_PARAM_COVER_OPENED,
            LIBFPTR_PARAM_SUBMODE,
            LIBFPTR_PARAM_RECEIPT_NUMBER,
            LIBFPTR_PARAM_DOCUMENT_NUMBER,
            LIBFPTR_PARAM_SHIFT_NUMBER,
            LIBFPTR_PARAM_RECEIPT_SUM,
            LIBFPTR_PARAM_RECEIPT_LINE_LENGTH,
            LIBFPTR_PARAM_RECEIPT_LINE_LENGTH_PIX,
            LIBFPTR_PARAM_MODEL_NAME,
            LIBFPTR_PARAM_UNIT_VERSION,
            LIBFPTR_PARAM_PRINTER_CONNECTION_LOST,
            LIBFPTR_PARAM_PRINTER_ERROR,
            LIBFPTR_PARAM_CUT_ERROR,
            LIBFPTR_PARAM_PRINTER_OVERHEAT,
            LIBFPTR_PARAM_UNIT_TYPE,
            LIBFPTR_PARAM_LICENSE_NUMBER,
            LIBFPTR_PARAM_LICENSE_ENTERED,
            LIBFPTR_PARAM_LICENSE,
            LIBFPTR_PARAM_SUM,
            LIBFPTR_PARAM_COUNT,
            LIBFPTR_PARAM_COUNTER_TYPE,
            LIBFPTR_PARAM_STEP_COUNTER_TYPE,
            LIBFPTR_PARAM_ERROR_TAG_NUMBER,
            LIBFPTR_PARAM_TABLE,
            LIBFPTR_PARAM_ROW,
            LIBFPTR_PARAM_FIELD,
            LIBFPTR_PARAM_FIELD_VALUE,
            LIBFPTR_PARAM_FN_DATA_TYPE,
            LIBFPTR_PARAM_TAG_NUMBER,
            LIBFPTR_PARAM_TAG_VALUE,
            LIBFPTR_PARAM_DOCUMENTS_COUNT,
            LIBFPTR_PARAM_FISCAL_SIGN,
            LIBFPTR_PARAM_DEVICE_FFD_VERSION,
            LIBFPTR_PARAM_FN_FFD_VERSION,
            LIBFPTR_PARAM_FFD_VERSION,
            LIBFPTR_PARAM_CHECK_SUM,
            LIBFPTR_PARAM_COMMODITY_NAME,
            LIBFPTR_PARAM_PRICE,
            LIBFPTR_PARAM_QUANTITY,
            LIBFPTR_PARAM_POSITION_SUM,
            LIBFPTR_PARAM_FN_TYPE,
            LIBFPTR_PARAM_FN_VERSION,
            LIBFPTR_PARAM_REGISTRATIONS_REMAIN,
            LIBFPTR_PARAM_REGISTRATIONS_COUNT,
            LIBFPTR_PARAM_NO_ERROR_IF_NOT_SUPPORTED,
            LIBFPTR_PARAM_OFD_EXCHANGE_STATUS,
            LIBFPTR_PARAM_FN_ERROR_DATA,
            LIBFPTR_PARAM_FN_ERROR_CODE,
            LIBFPTR_PARAM_ENVD_MODE,
            LIBFPTR_PARAM_DOCUMENT_CLOSED,
            LIBFPTR_PARAM_JSON_DATA,
            LIBFPTR_PARAM_COMMAND_SUBSYSTEM,
            LIBFPTR_PARAM_FN_OPERATION_TYPE,
            LIBFPTR_PARAM_FN_STATE,
            LIBFPTR_PARAM_ENVD_MODE_ENABLED,
            LIBFPTR_PARAM_SETTING_ID,
            LIBFPTR_PARAM_SETTING_VALUE,
            LIBFPTR_PARAM_MAPPING_KEY,
            LIBFPTR_PARAM_MAPPING_VALUE,
            LIBFPTR_PARAM_COMMODITY_PIECE,
            LIBFPTR_PARAM_POWER_SOURCE_TYPE,
            LIBFPTR_PARAM_BATTERY_CHARGE,
            LIBFPTR_PARAM_VOLTAGE,
            LIBFPTR_PARAM_USE_BATTERY,
            LIBFPTR_PARAM_BATTERY_CHARGING,
            LIBFPTR_PARAM_CAN_PRINT_WHILE_ON_BATTERY,
            LIBFPTR_PARAM_MAC_ADDRESS,
            LIBFPTR_PARAM_FN_FISCAL,
            LIBFPTR_PARAM_NETWORK_ERROR,
            LIBFPTR_PARAM_OFD_ERROR,
            LIBFPTR_PARAM_FN_ERROR,
            LIBFPTR_PARAM_COMMAND_CODE,
            LIBFPTR_PARAM_PRINTER_TEMPERATURE,
            LIBFPTR_PARAM_RECORDS_TYPE,
            LIBFPTR_PARAM_OFD_FISCAL_SIGN,
            LIBFPTR_PARAM_HAS_OFD_TICKET,
            LIBFPTR_PARAM_NO_SERIAL_NUMBER,
            LIBFPTR_PARAM_RTC_FAULT,
            LIBFPTR_PARAM_SETTINGS_FAULT,
            LIBFPTR_PARAM_COUNTERS_FAULT,
            LIBFPTR_PARAM_USER_MEMORY_FAULT,
            LIBFPTR_PARAM_SERVICE_COUNTERS_FAULT,
            LIBFPTR_PARAM_ATTRIBUTES_FAULT,
            LIBFPTR_PARAM_FN_FAULT,
            LIBFPTR_PARAM_INVALID_FN,
            LIBFPTR_PARAM_HARD_FAULT,
            LIBFPTR_PARAM_MEMORY_MANAGER_FAULT,
            LIBFPTR_PARAM_SCRIPTS_FAULT,
            LIBFPTR_PARAM_FULL_RESET,
            LIBFPTR_PARAM_WAIT_FOR_REBOOT,
            LIBFPTR_PARAM_SCALE_PERCENT,
            LIBFPTR_PARAM_FN_NEED_REPLACEMENT,
            LIBFPTR_PARAM_FN_RESOURCE_EXHAUSTED,
            LIBFPTR_PARAM_FN_MEMORY_OVERFLOW,
            LIBFPTR_PARAM_FN_OFD_TIMEOUT,
            LIBFPTR_PARAM_FN_CRITICAL_ERROR,
            LIBFPTR_PARAM_OFD_MESSAGE_READ,
            LIBFPTR_PARAM_DEVICE_MIN_FFD_VERSION,
            LIBFPTR_PARAM_DEVICE_MAX_FFD_VERSION,
            LIBFPTR_PARAM_DEVICE_UPTIME,
            LIBFPTR_PARAM_NOMENCLATURE_TYPE,
            LIBFPTR_PARAM_GTIN,
            LIBFPTR_PARAM_FN_DOCUMENT_TYPE,
            LIBFPTR_PARAM_NETWORK_ERROR_TEXT,
            LIBFPTR_PARAM_FN_ERROR_TEXT,
            LIBFPTR_PARAM_OFD_ERROR_TEXT,
            LIBFPTR_PARAM_USER_SCRIPT_ID,
            LIBFPTR_PARAM_USER_SCRIPT_PARAMETER,
            LIBFPTR_PARAM_USER_MEMORY_OPERATION,
            LIBFPTR_PARAM_USER_MEMORY_DATA,
            LIBFPTR_PARAM_USER_MEMORY_STRING,
            LIBFPTR_PARAM_USER_MEMORY_ADDRESS,
            LIBFPTR_PARAM_FN_PRESENT,
            LIBFPTR_PARAM_BLOCKED,
            LIBFPTR_PARAM_DOCUMENT_PRINTED,
            LIBFPTR_PARAM_DISCOUNT_SUM,
            LIBFPTR_PARAM_SURCHARGE_SUM,
            LIBFPTR_PARAM_LK_USER_CODE,
            LIBFPTR_PARAM_LICENSE_COUNT,

            LIBFPTR_PARAM_LAST
        };

        enum libfptr_kkt_data_type : uint
        {
            LIBFPTR_DT_STATUS = 0,
            LIBFPTR_DT_CASH_SUM,
            LIBFPTR_DT_UNIT_VERSION,
            LIBFPTR_DT_PICTURE_INFO,
            LIBFPTR_DT_LICENSE_ACTIVATED,
            LIBFPTR_DT_REGISTRATIONS_SUM,
            LIBFPTR_DT_REGISTRATIONS_COUNT,
            LIBFPTR_DT_PAYMENT_SUM,
            LIBFPTR_DT_CASHIN_SUM,
            LIBFPTR_DT_CASHIN_COUNT,
            LIBFPTR_DT_CASHOUT_SUM,
            LIBFPTR_DT_CASHOUT_COUNT,
            LIBFPTR_DT_REVENUE,
            LIBFPTR_DT_DATE_TIME,
            LIBFPTR_DT_SHIFT_STATE,
            LIBFPTR_DT_RECEIPT_STATE,
            LIBFPTR_DT_SERIAL_NUMBER,
            LIBFPTR_DT_MODEL_INFO,
            LIBFPTR_DT_RECEIPT_LINE_LENGTH,
            LIBFPTR_DT_CUTTER_RESOURCE,
            LIBFPTR_DT_STEP_RESOURCE,
            LIBFPTR_DT_TERMAL_RESOURCE,
            LIBFPTR_DT_ENVD_MODE,
            LIBFPTR_DT_SHIFT_TAX_SUM,
            LIBFPTR_DT_RECEIPT_TAX_SUM,
            LIBFPTR_DT_NON_NULLABLE_SUM,
            LIBFPTR_DT_RECEIPT_COUNT,
            LIBFPTR_DT_CANCELLATION_COUNT_ALL,
            LIBFPTR_DT_CANCELLATION_SUM,
            LIBFPTR_DT_CANCELLATION_SUM_ALL,
            LIBFPTR_DT_POWER_SOURCE_STATE,
            LIBFPTR_DT_CANCELLATION_COUNT,
            LIBFPTR_DT_NON_NULLABLE_SUM_BY_PAYMENTS,
            LIBFPTR_DT_PRINTER_TEMPERATURE,
            LIBFPTR_DT_FATAL_STATUS,
            LIBFPTR_DT_MAC_ADDRESS,
            LIBFPTR_DT_DEVICE_UPTIME,
            LIBFPTR_DT_RECEIPT_BYTE_COUNT,
            LIBFPTR_DT_DISCOUNT_AND_SURCHARGE_SUM
        };

        //enum libfptr_error
        //{
        //    LIBFPTR_OK = 0,
        //    LIBFPTR_ERROR_CONNECTION_DISABLED,
        //    LIBFPTR_ERROR_NO_CONNECTION,
        //    LIBFPTR_ERROR_PORT_BUSY,
        //    LIBFPTR_ERROR_PORT_NOT_AVAILABLE,
        //    LIBFPTR_ERROR_INCORRECT_DATA,
        //    LIBFPTR_ERROR_INTERNAL,
        //    LIBFPTR_ERROR_UNSUPPORTED_CAST,
        //    LIBFPTR_ERROR_NO_REQUIRED_PARAM,
        //    LIBFPTR_ERROR_INVALID_SETTINGS,
        //    LIBFPTR_ERROR_NOT_CONFIGURED,
        //    LIBFPTR_ERROR_NOT_SUPPORTED,
        //    LIBFPTR_ERROR_INVALID_MODE,
        //    LIBFPTR_ERROR_INVALID_PARAM,
        //    LIBFPTR_ERROR_NOT_LOADED,
        //    LIBFPTR_ERROR_UNKNOWN,
        //    LIBFPTR_ERROR_INVALID_SUM,
        //    LIBFPTR_ERROR_INVALID_QUANTITY,
        //    LIBFPTR_ERROR_CASH_COUNTER_OVERFLOW,
        //    LIBFPTR_ERROR_LAST_OPERATION_STORNO_DENIED,
        //    LIBFPTR_ERROR_STORNO_BY_CODE_DENIED,
        //    LIBFPTR_ERROR_LAST_OPERATION_NOT_REPEATABLE,
        //    LIBFPTR_ERROR_DISCOUNT_NOT_REPEATABLE,
        //    LIBFPTR_ERROR_DISCOUNT_DENIED,
        //    LIBFPTR_ERROR_INVALID_COMMODITY_CODE,
        //    LIBFPTR_ERROR_INVALID_COMMODITY_BARCODE,
        //    LIBFPTR_ERROR_INVALID_COMMAND_FORMAT,
        //    LIBFPTR_ERROR_INVALID_COMMAND_LENGTH,
        //    LIBFPTR_ERROR_BLOCKED_IN_DATE_INPUT_MODE,
        //    LIBFPTR_ERROR_NEED_DATE_ACCEPT,
        //    LIBFPTR_ERROR_NO_MORE_DATA,
        //    LIBFPTR_ERROR_NO_ACCEPT_OR_CANCEL,
        //    LIBFPTR_ERROR_BLOCKED_BY_REPORT_INTERRUPTION,
        //    LIBFPTR_ERROR_DISABLE_CASH_CONTROL_DENIED,
        //    LIBFPTR_ERROR_MODE_BLOCKED,
        //    LIBFPTR_ERROR_CHECK_DATE_TIME,
        //    LIBFPTR_ERROR_DATE_TIME_LESS_THAN_FS,
        //    LIBFPTR_ERROR_CLOSE_ARCHIVE_DENIED,
        //    LIBFPTR_ERROR_COMMODITY_NOT_FOUND,
        //    LIBFPTR_ERROR_WEIGHT_BARCODE_WITH_INVALID_QUANTITY,
        //    LIBFPTR_ERROR_RECEIPT_BUFFER_OVERFLOW,
        //    LIBFPTR_ERROR_QUANTITY_TOO_FEW,
        //    LIBFPTR_ERROR_STORNO_TOO_MUCH,
        //    LIBFPTR_ERROR_BLOCKED_COMMODITY_NOT_FOUND,
        //    LIBFPTR_ERROR_NO_PAPER,
        //    LIBFPTR_ERROR_COVER_OPENED,
        //    LIBFPTR_ERROR_PRINTER_FAULT,
        //    LIBFPTR_ERROR_MECHANICAL_FAULT,
        //    LIBFPTR_ERROR_INVALID_RECEIPT_TYPE,
        //    LIBFPTR_ERROR_INVALID_UNIT_TYPE,
        //    LIBFPTR_ERROR_NO_MEMORY,
        //    LIBFPTR_ERROR_PICTURE_NOT_FOUND,
        //    LIBFPTR_ERROR_NONCACH_PAYMENTS_TOO_MUCH,
        //    LIBFPTR_ERROR_RETURN_DENIED,
        //    LIBFPTR_ERROR_PAYMENTS_OVERFLOW,
        //    LIBFPTR_ERROR_BUSY,
        //    LIBFPTR_ERROR_GSM,
        //    LIBFPTR_ERROR_INVALID_DISCOUNT,
        //    LIBFPTR_ERROR_OPERATION_AFTER_DISCOUNT_DENIED,
        //    LIBFPTR_ERROR_INVALID_DEPARTMENT,
        //    LIBFPTR_ERROR_INVALID_PAYMENT_TYPE,
        //    LIBFPTR_ERROR_MULTIPLICATION_OVERFLOW,
        //    LIBFPTR_ERROR_DENIED_BY_SETTINGS,
        //    LIBFPTR_ERROR_TOTAL_OVERFLOW,
        //    LIBFPTR_ERROR_DENIED_IN_ANNULATION_RECEIPT,
        //    LIBFPTR_ERROR_JOURNAL_OVERFLOW,
        //    LIBFPTR_ERROR_NOT_FULLY_PAID,
        //    LIBFPTR_ERROR_DENIED_IN_RETURN_RECEIPT,
        //    LIBFPTR_ERROR_SHIFT_EXPIRED,
        //    LIBFPTR_ERROR_DENIED_IN_SELL_RECEIPT,
        //    LIBFPTR_ERROR_FISCAL_MEMORY_OVERFLOW,
        //    LIBFPTR_ERROR_INVALID_PASSWORD,
        //    LIBFPTR_ERROR_JOURNAL_BUSY,
        //    LIBFPTR_ERROR_DENIED_IN_CLOSED_SHIFT,
        //    LIBFPTR_ERROR_INVALID_TABLE_NUMBER,
        //    LIBFPTR_ERROR_INVALID_ROW_NUMBER,
        //    LIBFPTR_ERROR_INVALID_FIELD_NUMBER,
        //    LIBFPTR_ERROR_INVALID_DATE_TIME,
        //    LIBFPTR_ERROR_INVALID_STORNO_SUM,
        //    LIBFPTR_ERROR_CHANGE_CALCULATION,
        //    LIBFPTR_ERROR_NO_CASH,
        //    LIBFPTR_ERROR_DENIED_IN_CLOSED_RECEIPT,
        //    LIBFPTR_ERROR_DENIED_IN_OPENED_RECEIPT,
        //    LIBFPTR_ERROR_DENIED_IN_OPENED_SHIFT,
        //    LIBFPTR_ERROR_SERIAL_NUMBER_ALREADY_ENTERED,
        //    LIBFPTR_ERROR_TOO_MUCH_REREGISTRATIONS,
        //    LIBFPTR_ERROR_INVALID_SHIFT_NUMBER,
        //    LIBFPTR_ERROR_INVALID_SERIAL_NUMBER,
        //    LIBFPTR_ERROR_INVALID_RNM_VATIN,
        //    LIBFPTR_ERROR_FISCAL_PRINTER_NOT_ACTIVATED,
        //    LIBFPTR_ERROR_SERIAL_NUMBER_NOT_ENTERED,
        //    LIBFPTR_ERROR_NO_MORE_REPORTS,
        //    LIBFPTR_ERROR_MODE_NOT_ACTIVATED,
        //    LIBFPTR_ERROR_RECORD_NOT_FOUND_IN_JOURNAL,
        //    LIBFPTR_ERROR_INVALID_LICENSE,
        //    LIBFPTR_ERROR_NEED_FULL_RESET,
        //    LIBFPTR_ERROR_DENIED_BY_LICENSE,
        //    LIBFPTR_ERROR_DISCOUNT_CANCELLATION_DENIED,
        //    LIBFPTR_ERROR_CLOSE_RECEIPT_DENIED,
        //    LIBFPTR_ERROR_INVALID_ROUTE_NUMBER,
        //    LIBFPTR_ERROR_INVALID_START_ZONE_NUMBER,
        //    LIBFPTR_ERROR_INVALID_END_ZONE_NUMBER,
        //    LIBFPTR_ERROR_INVALID_RATE_TYPE,
        //    LIBFPTR_ERROR_INVALID_RATE,
        //    LIBFPTR_ERROR_FISCAL_MODULE_EXCHANGE,
        //    LIBFPTR_ERROR_NEED_TECHNICAL_SUPPORT,
        //    LIBFPTR_ERROR_SHIFT_NUMBERS_DID_NOT_MATCH,
        //    LIBFPTR_ERROR_DEVICE_NOT_FOUND,
        //    LIBFPTR_ERROR_EXTERNAL_DEVICE_CONNECTION,
        //    LIBFPTR_ERROR_DISPENSER_INVALID_STATE,
        //    LIBFPTR_ERROR_INVALID_POSITIONS_COUNT,
        //    LIBFPTR_ERROR_DISPENSER_INVALID_NUMBER,
        //    LIBFPTR_ERROR_INVALID_DIVIDER,
        //    LIBFPTR_ERROR_FN_ACTIVATION_DENIED,
        //    LIBFPTR_ERROR_PRINTER_OVERHEAT,
        //    LIBFPTR_ERROR_FN_EXCHANGE,
        //    LIBFPTR_ERROR_FN_INVALID_FORMAT,
        //    LIBFPTR_ERROR_FN_INVALID_STATE,
        //    LIBFPTR_ERROR_FN_FAULT,
        //    LIBFPTR_ERROR_FN_CRYPTO_FAULT,
        //    LIBFPTR_ERROR_FN_EXPIRED,
        //    LIBFPTR_ERROR_FN_OVERFLOW,
        //    LIBFPTR_ERROR_FN_INVALID_DATE_TIME,
        //    LIBFPTR_ERROR_FN_NO_MORE_DATA,
        //    LIBFPTR_ERROR_FN_TOTAL_OVERFLOW,
        //    LIBFPTR_ERROR_BUFFER_OVERFLOW,
        //    LIBFPTR_ERROR_PRINT_SECOND_COPY_DENIED,
        //    LIBFPTR_ERROR_NEED_RESET_JOURNAL,
        //    LIBFPTR_ERROR_TAX_SUM_TOO_MUCH,
        //    LIBFPTR_ERROR_TAX_ON_LAST_OPERATION_DENIED,
        //    LIBFPTR_ERROR_INVALID_FN_NUMBER,
        //    LIBFPTR_ERROR_TAX_CANCEL_DENIED,
        //    LIBFPTR_ERROR_LOW_BATTERY,
        //    LIBFPTR_ERROR_FN_INVALID_COMMAND,
        //    LIBFPTR_ERROR_FN_COMMAND_OVERFLOW,
        //    LIBFPTR_ERROR_FN_NO_TRANSPORT_CONNECTION,
        //    LIBFPTR_ERROR_FN_CRYPTO_HAS_EXPIRED,
        //    LIBFPTR_ERROR_FN_RESOURCE_HAS_EXPIRED,
        //    LIBFPTR_ERROR_INVALID_MESSAGE_FROM_OFD,
        //    LIBFPTR_ERROR_FN_HAS_NOT_SEND_DOCUMENTS,
        //    LIBFPTR_ERROR_FN_TIMEOUT,
        //    LIBFPTR_ERROR_FN_SHIFT_EXPIRED,
        //    LIBFPTR_ERROR_FN_INVALID_TIME_DIFFERENCE,
        //    LIBFPTR_ERROR_INVALID_TAXATION_TYPE,
        //    LIBFPTR_ERROR_INVALID_TAX_TYPE,
        //    LIBFPTR_ERROR_INVALID_COMMODITY_PAYMENT_TYPE,
        //    LIBFPTR_ERROR_INVALID_COMMODITY_CODE_TYPE,
        //    LIBFPTR_ERROR_EXCISABLE_COMMODITY_DENIED,
        //    LIBFPTR_ERROR_FISCAL_PROPERTY_WRITE,
        //    LIBFPTR_ERROR_INVALID_COUNTER_TYPE,
        //    LIBFPTR_ERROR_CUTTER_FAULT,
        //    LIBFPTR_ERROR_REPORT_INTERRUPTED,
        //    LIBFPTR_ERROR_INVALID_LEFT_MARGIN,
        //    LIBFPTR_ERROR_INVALID_ALIGNMENT,
        //    LIBFPTR_ERROR_INVALID_TAX_MODE,
        //    LIBFPTR_ERROR_FILE_NOT_FOUND,
        //    LIBFPTR_ERROR_PICTURE_TOO_BIG,
        //    LIBFPTR_ERROR_INVALID_BARCODE_PARAMS,
        //    LIBFPTR_ERROR_FISCAL_PROPERTY_DENIED,
        //    LIBFPTR_ERROR_FN_INTERFACE,
        //    LIBFPTR_ERROR_DATA_DUPLICATE,
        //    LIBFPTR_ERROR_NO_REQUIRED_FISCAL_PROPERTY,
        //    LIBFPTR_ERROR_FN_READ_DOCUMENT,
        //    LIBFPTR_ERROR_FLOAT_OVERFLOW,
        //    LIBFPTR_ERROR_INVALID_SETTING_VALUE,
        //    LIBFPTR_ERROR_HARD_FAULT,
        //    LIBFPTR_ERROR_FN_NOT_FOUND,
        //    LIBFPTR_ERROR_INVALID_AGENT_FISCAL_PROPERTY,
        //    LIBFPTR_ERROR_INVALID_FISCAL_PROPERTY_VALUE_1002_1056,
        //    LIBFPTR_ERROR_INVALID_FISCAL_PROPERTY_VALUE_1002_1017,
        //    LIBFPTR_ERROR_SCRIPT,
        //    LIBFPTR_ERROR_INVALID_USER_MEMORY_INDEX,
        //    LIBFPTR_ERROR_NO_ACTIVE_OPERATOR,
        //    LIBFPTR_ERROR_REGISTRATION_REPORT_INTERRUPTED,
        //    LIBFPTR_ERROR_CLOSE_FN_REPORT_INTERRUPTED,
        //    LIBFPTR_ERROR_OPEN_SHIFT_REPORT_INTERRUPTED,
        //    LIBFPTR_ERROR_OFD_EXCHANGE_REPORT_INTERRUPTED,
        //    LIBFPTR_ERROR_CLOSE_RECEIPT_INTERRUPTED,
        //    LIBFPTR_ERROR_FN_QUERY_INTERRUPTED,
        //    LIBFPTR_ERROR_RTC_FAULT,
        //    LIBFPTR_ERROR_MEMORY_FAULT,
        //    LIBFPTR_ERROR_CHIP_FAULT,
        //    LIBFPTR_ERROR_TEMPLATES_CORRUPTED,
        //    LIBFPTR_ERROR_INVALID_MAC_ADDRESS,
        //    LIBFPTR_ERROR_INVALID_SCRIPT_NUMBER,
        //    LIBFPTR_ERROR_SCRIPTS_FAULT,
        //    LIBFPTR_ERROR_INVALID_SCRIPTS_VERSION,
        //    LIBFPTR_ERROR_INVALID_CLICHE_FORMAT,
        //    LIBFPTR_ERROR_WAIT_FOR_REBOOT,
        //    LIBFPTR_ERROR_NO_LICENSE,
        //    LIBFPTR_ERROR_INVALID_FFD_VERSION,
        //    LIBFPTR_ERROR_CHANGE_SETTING_DENIED,
        //    LIBFPTR_ERROR_INVALID_NOMENCLATURE_TYPE,
        //    LIBFPTR_ERROR_INVALID_GTIN,
        //    LIBFPTR_ERROR_NEGATIVE_MATH_RESULT,
        //    LIBFPTR_ERROR_FISCAL_PROPERTIES_COMBINATION,
        //    LIBFPTR_ERROR_BASE_WEB = 500,
        //    LIBFPTR_ERROR_RECEIPT_PARSE_ERROR,
        //};

        #endregion Private types

        #region Public types

        public static class NativeMethods
        {
            [DllImport("kernel32.dll")]
            public static extern IntPtr LoadLibrary(string dllToLoad);

            [DllImport("kernel32.dll")]
            public static extern IntPtr GetProcAddress(IntPtr hModule, string procedureName);
        }

#pragma warning disable 0649

        ///// <summary>
        ///// Обертка вокруг DeviceInfo для десериализации из JSON
        ///// </summary>
        //public class DeviceInfoWrapper
        //{
        //    public DeviceInfo deviceInfo;
        //}

        ///// <summary>
        ///// Информация о ККМ
        ///// </summary>
        //public class DeviceInfo
        //{
        //    /// <summary>
        //    /// Версия прошивки
        //    /// </summary>
        //    public string firmwareVersion;

        //    /// <summary>
        //    /// Код модели
        //    /// </summary>
        //    public int model;

        //    /// <summary>
        //    /// Наименование модели
        //    /// </summary>
        //    public string modelName;

        //    /// <summary>
        //    /// Ширина чековой ленты в символах
        //    /// </summary>
        //    public int receiptLineLength;

        //    /// <summary>
        //    /// Ширина чековой ленты в пикселях
        //    /// </summary>
        //    public int receiptLineLengthPix;

        //    /// <summary>
        //    /// Заводской номер ККТ
        //    /// </summary>
        //    public string serial;
        //}

#pragma warning restore 0649

        #endregion Public types

    }
}
