﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.AtolWrapper
{
    /// <summary>
    /// Интерфейс ККМ
    /// </summary>
    public interface IKKM : IDisposable
    {
        #region Свойства

        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        int SlipCharLineLength { get; }

        /// <summary>
        /// Номер смены
        /// </summary>
        int Session { get; }

        /// <summary>
        /// Номер текущего чека
        /// </summary>
        int CheckNumber { get; }

        /// <summary>
        /// Состояние текущего чека
        /// </summary>
        CheckState CheckState { get; }

        /// <summary>
        /// Состояние смены
        /// </summary>
        SessionState SessionState { get; }

        /// <summary>
        /// Документ закрыт, но не допечатан
        /// </summary>
        /// <remarks>
        /// Рекомендуется вывести пользователю сообщение о сбое печати и попросить устранить неисправность (самый стандартный случай - закончилась бумага). 
        /// После устранения неисправности требуется продолжить печать (Продолжение печати документа)
        /// </remarks>
        bool NotPrinted { get; }

        #endregion Свойства

        #region Методы

        ///// <summary>
        ///// Открыть смену
        ///// </summary>
        void OpenSession(string operatorFIO, string operatorPost, string operatorINN);

        ///// <summary>
        ///// Закрыть смену
        ///// </summary>
        void CloseSession(string operatorFIO, string operatorPost, string operatorINN);

        /// <summary>
        /// Печать строки
        /// </summary>
        /// <param name="s"></param>
        void PrintString(string s);

        #endregion Методы
    }

    /// <summary>
    /// Состояние смены
    /// </summary>
    public enum SessionState
    {
        Closed,
        Opened,
        Expired
    }

    /// <summary>
    /// Состояние чека
    /// </summary>
    public enum CheckState
    {
        /// <summary>
        /// Чек закрыт
        /// </summary>
        Closed,

        /// <summary>
        /// Открыт чек продажи
        /// </summary>
        Sell,

        /// <summary>
        /// Открыт чек возврата продажи
        /// </summary>
        SellReturn,

        /// <summary>
        /// Открыт чек аннулирования продажи
        /// </summary>
        SellCancel,

        /// <summary>
        /// Открыт чек покупки
        /// </summary>
        Buy,

        /// <summary>
        /// Открыт чек возврата покупки
        /// </summary>
        BuyReturn
    }
}
