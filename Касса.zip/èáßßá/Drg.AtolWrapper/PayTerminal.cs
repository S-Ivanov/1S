﻿using System;
using System.Runtime.InteropServices;

namespace Drg.AtolWrapper
{
    /// <summary>
    /// Платежный (эквайринговый) терминал
    /// </summary>
    /// <remarks>
    /// Описание общего алгоритма взаимодействия с ККМ:
    /// http://v8.1c.ru/libraries/cel/a_terminal.htm
    /// </remarks>
    public class PayTerminal : IDisposable
    {
        #region Константы

        #region Коды ошибок драйвера Атол

        /// <summary>
        /// Ошибок нет
        /// </summary>
        public const int Result_Success = 0;

        /// <summary>
        /// Работа драйвера прервана пользователем
        /// </summary>
        const int Result_UserBreak = -5;

        /// <summary>
        /// Ошибка АС
        /// </summary>
        const int Result_ACError = -10000;

        /// <summary>
        /// Предел кодов ошибок АС
        /// </summary>
        const int Result_ACErrorLimit = -11000;

        #endregion Коды ошибок драйвера Атол

        #endregion Константы

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="charLineLength">ширина ленты ККМ в символах - для печати слипов</param>
        /// <param name="pathAC">каталог обмена с АС</param>
        /// <param name="pathDB">каталог драйвера</param>
        /// <param name="protocol">протокол обмена с платежной системой (3 - Сбербанк, см. документацию драйвера Атол)</param>
        public PayTerminal(int charLineLength, string pathAC, string pathDB, int protocol)
        {
            Type f = Type.GetTypeFromProgID("AddIn.PayCARD8", true);
            _driver = Activator.CreateInstance(f);

            if (_driver == null)
                throw new NotSupportedException("Ошибка подключения драйвера");

            #region Заимствовано из 1С:Трактир - обработка Обслуживание_ПС_АТОЛ, модуль объекта

            if (_driver.DeviceCount == 0)
                _driver.AddDevice();

            if (_driver.DeviceCount == 0)
                throw new NotSupportedException("Ошибка подключения устройства");

            _driver.CurrentDeviceNumber = 1;

            // мы будем поддерживать только авторизацию по карте через ридер, без всяких ручных вводов
            _driver.EnableKeyboardCardEntry = false;

            #endregion Заимствовано из 1С:Трактир - обработка Обслуживание_ПС_АТОЛ, модуль объекта

            _driver.CharLineLength = charLineLength;
            _driver.PathAC = pathAC;
            _driver.PathDB = pathDB;
            _driver.Protocol = protocol;
        }

        /// <summary>
        /// Оплата
        /// </summary>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если оплата выполнена (возможно, с ошибкой процессингового центра), null - если клиент отказался от оплаты (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult Pay(int sessionNumber, int checkNumber, decimal sum)
        {
            return DoPayOperation(0, sessionNumber, checkNumber, sum);
        }

        /// <summary>
        /// Возврат оплаты
        /// </summary>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если возврат оплаты выполнен (возможно, с ошибкой процессингового центра), null - если клиент отказался от возврата оплаты (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult PayReturn(int sessionNumber, int checkNumber, decimal sum)
        {
            return DoPayOperation(1, sessionNumber, checkNumber, sum);
        }

        /// <summary>
        /// Оплата или возврат оплаты
        /// </summary>
        /// <param name="operationType">код операции: 0 - оплата, 1 - возврат</param>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если операция выполнена (возможно, с ошибкой процессингового центра), null - если клиент отказался от операции (в процессе авторизации)</returns>
        /// <exception cref="PayException">ошибка оплаты</exception>
        /// <exception cref="NotSupportedException">
        /// в результате подготовки операции (метод PrepareOnLineAuthorization) установлен один из флагов: NeedReaderEntryDataTracks, NeedKeyboardEntryDataTracks, NeedReferenceNumber или NeedSumm
        /// </exception>
        public PayResult DoPayOperation(int operationType, int sessionNumber, int checkNumber, decimal sum)
        {
            _driver.ECRSessionNumber = sessionNumber;
            _driver.ECRReceiptNumber = checkNumber;
            _driver.OperationType = operationType;
            _driver.Sum = (double)sum;

            _driver.PrepareOnLineAuthorization();

            if (_driver.ResultCode == Result_UserBreak)
                return null;
            else if (_driver.ResultCode != Result_Success)
                throw new PayException
                {
                    ResultInfo = new ResultInfo
                    {
                        ResultCode = _driver.ResultCode,
                        ResultDescription = _driver.ResultDescription,
                        ResultPrompt = _driver.ResultPrompt
                    }
                };

            _driver.OnLineAuthorization();

            var resultInfo = new ResultInfo
            {
                ResultCode = _driver.ResultCode,
                ResultDescription = _driver.ResultDescription,
                ResultPrompt = _driver.ResultPrompt
            };

            // Следует сохранять авторизации с ResultCode >= 0 и ResultCode = -10000 ... -11000, т.е. те, на которые получен ответ АС, пусть даже отрицательный
            if (_driver.ResultCode >= Result_Success || IsACError(_driver.ResultCode))
            {
                return new PayResult
                {
                    SlipText = _driver.TextStr,
                    ResultInfo = resultInfo,
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        AuthCode = _driver.AuthCode,
                        TransType = _driver.TransType,
                        OperationType = _driver.OperationType,
                        Sum = (decimal)_driver.Sum,
                        CardNumber = _driver.CardNumber,
                        SlipNumber = _driver.SlipNumber,
                        TransDate = _driver.TransDate,
                        TransTime = _driver.TransTime,
                        MsgNumber = _driver.MsgNumber,
                        TerminalID = _driver.TerminalID,
                        ReferenceNumber = _driver.ReferenceNumber,
                        ResponseCode = _driver.ResponseCode
                    }
                };
            }
            else
                throw new PayException { ResultInfo = resultInfo };
        }

        static bool IsACError(int code)
        {
            return Result_ACErrorLimit <= code && code <= Result_ACError;
        }

        public void Dispose()
        {
            // освобождение COM-объекта в соответствии с https://www.codeproject.com/Tips/235230/Proper-Way-of-Releasing-COM-Objects-in-NET
            Marshal.ReleaseComObject(_driver);
        }

        dynamic _driver = null;
    }
}
