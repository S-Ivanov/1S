﻿using System;

namespace Drg.AtolWrapper
{
    /// <summary>
    /// Ошибка оплаты
    /// </summary>
    public class PayException : ApplicationException
    {
        /// <summary>
        /// Результат выполнения операции
        /// </summary>
        public ResultInfo ResultInfo { get; set; }
    }
}
