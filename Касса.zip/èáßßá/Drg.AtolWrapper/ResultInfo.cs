﻿namespace Drg.AtolWrapper
{
    /// <summary>
    /// Результат выполнения операции
    /// </summary>
    public class ResultInfo
    {
        /// <summary>
        /// Код результата
        /// </summary>
        public int ResultCode { get; set; }

        /// <summary>
        /// Описание результата
        /// </summary>
        public string ResultDescription { get; set; }

        /// <summary>
        /// Рекомендация к результату
        /// </summary>
        public string ResultPrompt { get; set; }
    }
}
