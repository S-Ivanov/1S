﻿using Drg.Equipment.KKM;
using Drg.Equipment.KKMAtol10_3_1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.Equipment.KKMAtol10_Test
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //kkm = new KKMAtol10.KKM(@"C:\Program Files (x86)\ATOL\Drivers10\KKT\bin\fptr10.dll", "{ \"Model\":63, \"Port\":1 }");
            //kkm = new KKM(@"C:\Program Files (x86)\ATOL\Drivers10\KKT\bin\fptr10.dll", @"{ ""Model"":63, ""Port"":1 }");
            kkm = new KKMAtol10_3_1.KKM(1000);

            FiscalCheckBox.IsChecked = kkm.Fiscal;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                kkm.CheckErrors();

                ErrorCodeTextBlock.Text = "Нет ошибок";
                ErrorDescriptionTextBlock.Text = "";
            }
            catch (DeviceException ex)
            {
                ErrorCodeTextBlock.Text = ex.DeviceError.ErrorCode.ToString();
                ErrorDescriptionTextBlock.Text = ex.Message;
            }
            catch (Exception ex)
            {
                ErrorCodeTextBlock.Text = ex.ToString();
                ErrorDescriptionTextBlock.Text = ex.Message;
            }


            //ReceiptLineLengthTextBlock.Text = kkm.ReceiptLineLength.ToString();

            //InnerErrorsTextBlock.Text = "";
            //if (deviceError is KKMDeviceError kkmDeviceError)
            //{
            //    foreach (var error in kkmDeviceError.InnerErrors)
            //    {
            //        InnerErrorsTextBlock.Text += $"{error.ErrorCode} - {error.Description}" + Environment.NewLine;
            //    }
            //}
        }

        KKMAtol10_3_1.KKM kkm;

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            List<TextInfo> textInfo = new List<TextInfo>();
            for (int i = 0; i < 100; i++)
            {
                textInfo.Add(new TextInfo()
                {
                    Text = "adsewffvsvs",
                    Alignment = KKM.TextAlignment.Left,
                    //Font = 0,
                    //DoubleHeight = true,
                    //DoubleWidth = false
                });
            }

            try
            {
                //kkm.PrintNonFiscalDocument(textInfo);

                //kkm.PrintNonFiscalDocumentAsync(textInfo, cancelTokenSource.Token);
                //task.Wait();
            }
            catch (DeviceException ex)
            {
                ErrorCodeTextBlock.Text = ex.DeviceError.ErrorCode.ToString();
                ErrorDescriptionTextBlock.Text = ex.Message;
            }
            catch (Exception ex)
            {
                ErrorCodeTextBlock.Text = ex.ToString();
                ErrorDescriptionTextBlock.Text = ex.Message;
            }

        }

        CancellationTokenSource cancelTokenSource = new CancellationTokenSource();

        private void CancelPrintButton_Click(object sender, RoutedEventArgs e)
        {
            cancelTokenSource.Cancel();
        }
    }
}
