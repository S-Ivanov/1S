﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DB
{
    public partial class LocalDB
    {
        /// <summary>
        /// Загрузить отчет ФО
        /// </summary>
        /// <param name="sessionIds">идентификаторы смен</param>
        /// <returns></returns>
        /// <remarks>
        /// Формируются отчеты с момента формирования последнего отчета ФО
        /// </remarks>
        public ReportFO.ReportFO LoadReportFO(params Guid[] sessionIds)
        {
            ReportFO.ReportFO reportFO = new ReportFO.ReportFO();

            List<Session> sessions = new List<Session>();
            List<ReportFO.ReportFOReportRecord> reportRecords = new List<ReportFO.ReportFOReportRecord>();
            List<ReportFO.Item> units = new List<ReportFO.Item>();
            List<ReportFO.Item> payments = new List<ReportFO.Item>();
            List<ReportFO.Item> nomenclature = new List<ReportFO.Item>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // прочитать информацию о сменах
                string sessionIdsForSessions = string.Join(",", sessionIds.Select(_ => $"'{_}'"));
                using (SqlCommand command = new SqlCommand())
                {

                    command.Connection = connection;
                    command.CommandText = $"select Id, Номер, Начало, Конец from Смены where Конец is not null and Id in ({sessionIdsForSessions}) and (ОтчетФОПередан is null or ОтчетФОПередан = 0)";
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            sessions.Add(
                                new Session
                                {
                                    Id = reader.GetGuid(0),
                                    Number = reader.GetInt32(1),
                                    Begin = reader.GetDateTime(2).ToLocalTime(),
                                    End = reader.GetDateTime(3).ToLocalTime()
                                });
                        }
                    }
                }

                if (sessions.Any())
                {
                    // выбрать записи отчета
                    string sessionIdsForRecords = string.Join(",", sessions.Select(session => $"'{session.Id}'"));
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText =
$@"select 
    Номенклатура.Id, 
    Товары.IdЕдиницыИзмерения, 
    ОплатаЗаказов.Цена, 
    sum(ОплатаЗаказов.Количество), 
    sum(ОплатаЗаказов.Сумма), 
    ВидыОплат.КодТрактира, 
    Смены.Номер, 
    Смены.Начало, 
    Смены.Конец
from 
    ОплатаЗаказов inner join 
    Товары on Товары.Id = ОплатаЗаказов.IdТовара inner join
    Номенклатура on Номенклатура.Id = Товары.IdНоменклатуры inner join 
    ВидыОплат on ВидыОплат.Id = ОплатаЗаказов.IdВидаОплаты inner join
    Заказы on Заказы.Id = ОплатаЗаказов.IdЗаказа inner join
    Смены on Смены.Id = Заказы.IdСмены
where
    Смены.Id in ({sessionIdsForRecords})
group by 
    Номенклатура.Id, Товары.IdЕдиницыИзмерения, ОплатаЗаказов.Цена, ВидыОплат.КодТрактира, Смены.Номер, Смены.Начало, Смены.Конец";

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reportRecords.Add(
                                    new ReportFO.ReportFOReportRecord
                                    {
                                        ID = Guid.NewGuid().ToString(),
                                        Nomenclature = reader.GetString(0),
                                        Unit = reader.GetString(1),
                                        Price = reader.GetDecimal(2),
                                        Count = reader.GetDecimal(3),
                                        Sum = reader.GetDecimal(4),
                                        Payment = reader.GetString(5),
                                        SessionNumber = reader.GetInt32(6),
                                        SessionBegin = reader.GetDateTime(7).ToLocalTime(),
                                        SessionEnd = reader.GetDateTime(8).ToLocalTime(),
                                    });
                            }
                        }
                    }

                    if (reportRecords.Any())
                    {
                        // выбрать единицы измерения
                        var unitIds = string.Join(",", reportRecords.Select(reportRecord => reportRecord.Unit).Distinct().Select(code => $"'{code}'"));
                        units = LoadReportFOItems(connection, $"select Id, Наименование from ЕдиницыИзмерения where Id in ({unitIds})");

                        // выбрать виды оплат
                        var paymentIds = string.Join(",", reportRecords.Select(reportRecord => reportRecord.Payment).Distinct().Select(code => $"'{code}'"));
                        payments = LoadReportFOItems(connection, $"select КодТрактира, Наименование from ВидыОплат where КодТрактира in ({paymentIds})");

                        // выбрать номенклатуру
                        var nomenclatureIds = string.Join(",", reportRecords.Select(reportRecord => reportRecord.Nomenclature).Distinct().Select(code => $"'{code}'"));
                        nomenclature = LoadReportFOItems(connection, $"select Id, Наименование from Номенклатура where Id in ({nomenclatureIds})");
                    }
                }

                // заполнение результата
                if (reportRecords.Any())
                {
                    reportFO.PeriodBegin = reportRecords.Min(_ => _.SessionBegin);
                    reportFO.PeriodEnd = reportRecords.Max(_ => _.SessionEnd);
                    reportFO.Reports =
                        reportRecords
                        .GroupBy(_ => _.SessionNumber)
                        .Select(_ => new ReportFO.ReportFOReport
                        {
                            Date = _.First().SessionEnd,
                            Number = _.Key.ToString(),
                            Record = _.ToArray()
                        })
                        .ToArray();
                    reportFO.Units = units.ToArray();
                    reportFO.Payments = payments.ToArray();
                    reportFO.Nomenclature = nomenclature.ToArray();
                }
            }

            return reportFO;
        }

        static List<ReportFO.Item> LoadReportFOItems(SqlConnection connection, string selectCommand)
        {
            List<ReportFO.Item> items = new List<ReportFO.Item>();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText = selectCommand;
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        items.Add(
                            new ReportFO.Item
                            {
                                Code = reader.GetString(0),
                                Value = reader.GetString(1)
                            });
                    }
                }
            }

            return items;
        }

        public DateTime? GetMenuTimeStamp()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select top 1 DateTime
from МеткаМеню",
                    connection);
                var result = command.ExecuteScalar();
                return result == DBNull.Value || result == null ? (DateTime?)null : (DateTime?)result;
            }
        }

        public void SaveMenuTimeStamp(DateTime timeStampServer)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"delete from МеткаМеню;
insert МеткаМеню (DateTime)
values (@DateTime)",
                connection);

                command.Parameters.AddWithValue("@DateTime", timeStampServer);
                command.ExecuteNonQuery();
            }
        }

        public IEnumerable<Session> LoadSessionsForReportFO()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select Id, Номер, Начало
from Смены
where ОтчетФОПередан is null or ОтчетФОПередан = 0",
                connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        yield return new Session
                        {
                            Id = reader.GetGuid(0),
                            Number = reader.GetInt32(1),
                            Begin = reader.GetDateTime(2).ToLocalTime()
                        };
                    }
                }
            }
        }

        public void SaveSessionReportFOFlag(IEnumerable<Guid> sessionIds)
        {
            if (sessionIds == null || !sessionIds.Any())
                return;

            string ids = string.Join(",", sessionIds.Select(_ => $"'{_}'"));
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
$@"update Смены
set ОтчетФОПередан = 1
where Id in ({ids})",
                connection);
                command.ExecuteNonQuery();
            }
        }
    }
}
