﻿using System;

namespace Drg.CashDeskLib.DB
{
    /// <summary>
    /// Интерфейс БД для работы со сменами
    /// </summary>
    public interface IDbSession2
    {
        #region Методы
        
        /// <summary>
        /// Закрыть смену
        /// </summary>
        /// <param name="sessionId">идентификатор смены в БД</param>
        void CloseSession(Guid sessionId);

        /// <summary>
        /// Загрузить информацию о последней смене
        /// </summary>
        /// <returns></returns>
        DataModel.Session LoadLastSession();

        /// <summary>
        /// Переоткрыть смену = закрыть + открыть
        /// </summary>
        /// <param name="sessionId">идентификатор закрываемой смены в БД</param>
        /// <param name="operatorId">идентификатор кассира</param>
        /// <param name="fnNumber">номер фискального накопителя</param>
        /// <returns>информация о смене</returns>
        /// <remarks>
        /// Закрытие смены не выполняется, если sessionId == Guid.Empty
        /// </remarks>
        DataModel.Session ReopenSession(Guid sessionId, Guid operatorId, string fnNumber);

        /// <summary>
        /// Переписать на смене идентификатор кассира
        /// </summary>
        /// <param name="sessionId">идентификатор смены в БД</param>
        /// <param name="operatorId">идентификатор кассира</param>
        void UpdateSessionOperator(Guid sessionId, Guid operatorId);
    
        #endregion Методы
    }
}
