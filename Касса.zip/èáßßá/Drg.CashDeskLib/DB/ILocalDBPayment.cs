﻿using Drg.CashDeskLib.DataModel;
using Drg.Equipment.PayTerminal;
using System;

namespace Drg.CashDeskLib.DB
{
    public interface ILocalDBPayment
    {
        void SaveAuthorizationInfo(Guid authorizationInfoId, AuthorizationInfo authorizationInfo);

        void SavePayment(Guid sessionId, string tabNum, DataModel.Receipt receipt, bool isTestMode);

        void SavePayTerminalReturnError(Guid authorizationInfoId, int sessionNumber, int checkNumber);
    }
}
