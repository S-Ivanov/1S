﻿using System;
using System.Data.SqlClient;

namespace Drg.CashDeskLib.DB
{
    /// <summary>
    /// Работа с базой данных Парсек
    /// </summary>
    public class ParsecDB
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="connectionString">строка соединения</param>
        public ParsecDB(string connectionString)
        {
            this.connectionString = connectionString;
        }

        /// <summary>
        /// Получить фотографию рабюотника
        /// </summary>
        /// <param name="tabNum">табельный номер</param>
        /// <returns></returns>
        public byte[] GetPhoto(string tabNum)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("select PHOTO from PERSON where TAB_NUM = @TAB_NUM", connection);
                command.Parameters.AddWithValue("@TAB_NUM", tabNum);
                object data = command.ExecuteScalar();
                return (data == null || data == DBNull.Value) ? null : (byte[])data;
            }
        }

        private string connectionString;
    }
}
