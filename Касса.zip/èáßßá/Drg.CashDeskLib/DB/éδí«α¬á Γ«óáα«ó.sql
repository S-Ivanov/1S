﻿select n.Наименование --, mi.IdТовара
from
	Меню m inner join
	ЭлементыМеню mi on mi.IdМеню = m.Id inner join
	Товары t on t.Id = mi.IdТовара inner join
	Номенклатура n on n.Id = t.IdНоменклатуры
where
	m.Дата = '20181002' 
	--and n.Id = '00-00002752'
	--and mi.IdТовара = 'a94a1415-b5de-422b-b14a-0c083a8826ed'
	--and mi.IdТовара = '{07F788c3-0C80-4D3A-9791-424E3B7385D2}'
order by 1