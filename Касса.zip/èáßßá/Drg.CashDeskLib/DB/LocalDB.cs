﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.FrontServiceReference;
using Drg.CashDeskLib.MenuReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;

namespace Drg.CashDeskLib.DB
{
    /// <summary>
    /// Работа с локальной базой данных
    /// </summary>
    public partial class LocalDB
    {
        /// <summary>
        /// Работа с локальной базой данных
        /// </summary>
        /// <param name="connectionString">строка соединения с локальной базой данных</param>
        public LocalDB(string connectionString)
        {
            this.connectionString = connectionString;
        }

        //        /// <summary>
        //        /// Прочитать информацию о клиенте по коду пропуска
        //        /// </summary>
        //        /// <param name="cardCode">код пропуска</param>
        //        /// <returns></returns>
        //        public DataModel.Client GetClient(uint cardCode)
        //        {
        //            DataModel.Client client = null;
        //            using (SqlConnection connection = new SqlConnection(connectionString))
        //            {
        //                connection.Open();
        //                using (SqlCommand command = new SqlCommand())
        //                {
        //                    command.Connection = connection;
        //                    command.CommandText =
        //@"declare @date datetime
        //set @date = GETDATE();
        //with ОплатаЗаказовЗП (ТабельныйНомер, Сумма)
        //as
        //(
        //	select o.ТабельныйНомер, SUM(op.Сумма)
        //	from Заказы o
        //		inner join ОплатаЗаказов op on op.IdЗаказа = o.Id
        //	where op.IdВидаОплаты = 0 and o.Год = YEAR(@date) and MONTH(o.Дата) = MONTH(@date)
        //	group by o.ТабельныйНомер
        //)
        //select k.ТабельныйНомер, k.ФИО, k.Фотография, k.ЛимитПоЗП, k.ОстатокЛПП, COALESCE(oz.Сумма, 0) AS Сумма
        //from Клиенты k
        //	left join ОплатаЗаказовЗП oz on oz.ТабельныйНомер = k.ТабельныйНомер
        //where k.КодПропуска = @КодПропуска";
        //                    command.Parameters.AddWithValue("@КодПропуска", (long)cardCode);
        //                    using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow))
        //                    {
        //                        if (reader.Read())
        //                        {
        //                            var limitZP = reader.GetDecimal(3);
        //                            var lpp = reader.GetInt32(4);
        //                            client = new DataModel.Client
        //                            {
        //                                CardCode = cardCode,
        //                                TabNum = reader.GetString(0),
        //                                FIO = reader.GetString(1),
        //                                Photo = reader.IsDBNull(2) ? null : (byte[])reader.GetValue(2),
        //                                MonthLimitZP = limitZP > 0 ? limitZP : 0,
        //                                LPP = lpp > 0 ? lpp : 0,
        //                                UsedZP = reader.GetDecimal(5)
        //                            };
        //                        }
        //                    }
        //                }
        //            }
        //            return client;
        //        }

        /// <summary>
        /// Загрузить информацию о последней смене
        /// </summary>
        public Session LoadLastSession()
        {
            Session session = new Session();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select top 1 Id, Номер, Начало, Конец, IdКассира
from Смены
order by Начало desc",
                    connection);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    session.Id = reader.GetGuid(0);
                    session.Number = reader.GetInt32(1);
                    session.Begin = reader.GetDateTime(2).ToLocalTime();
                    if (!reader.IsDBNull(3))
                        session.End = reader.GetDateTime(3).ToLocalTime();
                    session.OperatorId = reader.GetGuid(4);
                }
            }
            return session;
        }

        ///// <summary>
        ///// Прочитать фотографию клиента
        ///// </summary>
        ///// <param name="clientId">Id клиента</param>
        ///// <returns></returns>
        //public byte[] GetClientPhoto(string tabNum)
        //{
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        using (SqlCommand command = new SqlCommand())
        //        {
        //            command.Connection = connection;
        //            command.CommandText = "select Фотография from Клиенты where ТабельныйНомер = @TabNum";
        //            command.Parameters.AddWithValue("@TabNum", tabNum);
        //            object data = command.ExecuteScalar();
        //            return data == null || data == DBNull.Value ? null : (byte[])data;
        //        }
        //    }
        //}

        public List<OrderSource> LoadOrderSources(bool isTestMode)
        {
            DateTime to = DateTime.Now;
            DateTime from = to.Date;
            return LoadOrderSources(from, to, isTestMode);
        }

        public List<OrderSource> LoadOrderSources(DateTime from, DateTime to, bool isTestMode)
        {
            List<OrderSource> orders = new List<OrderSource>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
@"select z.Id, z.Дата, z.Номер, z.ТабельныйНомер, count(z2.IdИсходногоЗаказа)
from 
	Заказы z left join
	Заказы z2 on z2.IdИсходногоЗаказа = z.Id
where
    z.IdСмены is not null and
	z.IdИсходногоЗаказа is null and
    z.Дата >= @from and
    z.Дата <= @to and
    z.Тест = @Тест
group by z.Id, z.Дата, z.Номер, z.ТабельныйНомер";
                    command.Parameters.AddWithValue("@from", from.ToUniversalTime());
                    command.Parameters.AddWithValue("@to", to.ToUniversalTime());
                    command.Parameters.AddWithValue("@Тест", isTestMode);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            OrderSource orderSource = new OrderSource
                            {
                                Id = reader.GetGuid(0),
                                DateTime = reader.GetDateTime(1).ToLocalTime(),
                                Number = reader.GetInt32(2),
                                HasReturns = reader.GetInt32(4) > 0,
                            };
                            if (!reader.IsDBNull(3))
                            {
                                orderSource.Client = new DataModel.Client { TabNum = reader.GetString(3) };
                            }
                            orders.Add(orderSource);
                        }
                    }
                }

                if (orders.Any())
                {
                    // загрузить клиентов
                    var ordersWithClient = orders.Where(order => order.Client != null).ToArray();
                    var tabNums = ordersWithClient.Select(order => order.Client.TabNum).Distinct().ToArray();
                    if (tabNums.Any())
                    {
                        var clients = GetClients(connection, tabNums);
                        if (clients.Any())
                        {
                            foreach (var order in ordersWithClient)
                            {
                                if (clients.TryGetValue(order.Client.TabNum, out DataModel.Client client))
                                {
                                    order.Client = client;
                                }
                            }
                        }
                    }
                }
            }

            return orders;
        }

        public List<DataModel.Order> LoadReturns(Guid orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                List<Guid> orderIds = new List<Guid>();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "select Id from Заказы where IdИсходногоЗаказа = @IdИсходногоЗаказа";
                    command.Parameters.AddWithValue("@IdИсходногоЗаказа", orderId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            orderIds.Add(reader.GetGuid(0));
                        }
                    }
                }

                return LoadOrders(connection, orderIds).Select(orderInfo => orderInfo.Item2).ToList();
            }
        }

        public Tuple<string, DataModel.Order> LoadOrder(Guid orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                List<Tuple<string, DataModel.Order>> orderInfo = LoadOrders(connection, new Guid[] { orderId });
                return orderInfo.Any() ? orderInfo[0] : null;
            }
        }

        List<Tuple<string, DataModel.Order>> LoadOrders(SqlConnection connection, IEnumerable<Guid> orderIds)
        {
            List<Tuple<string, DataModel.Order>> result = new List<Tuple<string, DataModel.Order>>();
            string orderIdsStr = string.Join(",", orderIds.Select(orderId => $"'{orderId}'"));
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText =
$@"select 
    z.Id,
	z.Дата, 
	z.Номер, 
	z.ТабельныйНомер, 
	oz.IdТовара, 
	n.Наименование as Номенклатура, 
	m.Наименование as ЕдиницаИзмерения,
	t.Цена, 
	oz.Цена, 
	oz.Количество, 
	oz.Сумма, 
	oz.IdВидаОплаты
from
    Заказы z inner join
    ОплатаЗаказов oz on oz.IdЗаказа = z.Id inner join
	Товары t on t.Id = oz.IdТовара inner join
	Номенклатура n on n.Id = t.IdНоменклатуры inner join
	ЕдиницыИзмерения m on m.Id = t.IdЕдиницыИзмерения inner join
	Номенклатура n2 on n2.Id = n.IdРодителя
where z.Id in ({orderIdsStr})
order by z.Id, n2.Наименование, n.Наименование, oz.Количество desc";
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    Guid lastOrderId = Guid.Empty;
                    DataModel.Order lastOrder = null;
                    while (reader.Read())
                    {
                        var orderId = reader.GetGuid(0);
                        if (orderId != lastOrderId)
                        {
                            lastOrderId = orderId;
                            lastOrder = new DataModel.Order
                            {
                                Id = orderId,
                                DateTime = reader.GetDateTime(1),
                                Number = reader.GetInt32(2),
                                Items = new List<OrderItem>()
                            };
                            string tabNum = reader.IsDBNull(3) ? null : reader.GetString(3);
                            result.Add(new Tuple<string, DataModel.Order>(tabNum, lastOrder));
                        }

                        lastOrder.Items.Add(
                            new OrderItem
                            {
                                MenuItem = new MenuItem
                                {
                                    ProductId = reader.GetGuid(4),
                                    Name = reader.GetString(5),
                                    Unit = reader.GetString(6),
                                    Price = reader.GetDecimal(7)
                                },
                                Price = reader.GetDecimal(8),
                                Count = reader.GetDecimal(9),
                                Sum = reader.GetDecimal(10),
                                Payment = (Payment)reader.GetInt32(11)
                            });
                    }
                }
            }

            return result;
        }

        public List<OrderPaymentItem> LoadOrderPaymentItems(Guid orderId)
        {
            List<OrderPaymentItem> orderPaymentItems = new List<OrderPaymentItem>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "select t.IdВидаОплаты, t.Сумма from ОплатаЗаказов t where t.IdЗаказа = @orderId order by t.IdВидаОплаты";
                    command.Parameters.AddWithValue("@orderId", orderId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            orderPaymentItems.Add(
                                new OrderPaymentItem
                                {
                                    Payment = (Payment)reader.GetInt32(0),
                                    Sum = reader.GetDecimal(1)
                                });
                        }
                    }
                }
            }
            return orderPaymentItems;
        }

        Dictionary<string, DataModel.Client> GetClients(SqlConnection connection, string[] tabNums)
        {
            Dictionary<string, DataModel.Client> clients = new Dictionary<string, DataModel.Client>();
            string tabNumsStr = string.Join(",", tabNums.Select(tabNum => $"'{tabNum}'"));
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText =
$@"select k.ТабельныйНомер, k.ФИО, k.Фотография
from Клиенты k
where k.ТабельныйНомер in ({tabNumsStr})";
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var tabNum = reader.GetString(0);
                        clients.Add(
                            tabNum, 
                            new DataModel.Client
                            {
                                TabNum = tabNum,
                                FIO = reader.GetString(1),
                                Photo = reader.IsDBNull(2) ? null : (byte[])reader.GetValue(2)
                            });
                    }
                }
            }
            return clients;
        }

        /// <summary>
        /// Прочитать полный список клиентов
        /// </summary>
        /// <returns></returns>
        public List<DataModel.Client> LoadClients()
        {
            List<DataModel.Client> clients = new List<DataModel.Client>();
            DateTime dateTimeNow = DateTime.Now;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
@"select k.ТабельныйНомер, k.ФИО, k.КодПропуска, k.РазрешеноПитаниеЗП, k.ЛимитПоЗП, COALESCE(lpp.ОстатокЛПП, 0) as ОстатокЛПП, k.Фотография
from Клиенты k
	left join ЛПП lpp on lpp.ТабельныйНомер = k.ТабельныйНомер
where 
	k.РазрешеноПитаниеЗП = 1 or 
	(k.РазрешеноПитаниеЗП <> 1 and lpp.ОстатокЛПП is not null and lpp.Год = YEAR(@date) and lpp.Месяц = MONTH(@date))";
                    command.Parameters.AddWithValue("@date", dateTimeNow);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            clients.Add(new DataModel.Client
                            {
                                TabNum = reader.GetString(0),
                                FIO = reader.GetString(1),
                                CardCode = reader.GetString(2),
                                HasZP = reader.GetBoolean(3),
                                MonthLimitZP = reader.GetDecimal(4),
                                MonthLimitLPP = reader.GetInt32(5),
                                Photo = reader.IsDBNull(6) ? null : (byte[])reader.GetValue(6)
                            });
                        }
                    }
                }

                if (clients.Any())
                {
                    string tabNums = string.Join(",", clients.Select(client => $"'{client.TabNum}'"));
                    // посчитаем расход по з/п
                    LoadUsedSums(connection, clients, dateTimeNow, tabNums, 0, (client, sum) => { client.UsedZP = sum; });
                    // посчитаем расход по ЛПП
                    LoadUsedSums(connection, clients, dateTimeNow, tabNums, 1, (client, sum) => { client.UsedLPP = sum; });
                }
            }
            return clients;
        }

        public DateTime? GetCashDeskTimeStamp()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select top 1 DateTime
from МеткаКассы",
                    connection);
                var result = command.ExecuteScalar();
                return result == DBNull.Value || result == null ? (DateTime?)null : (DateTime?)result;
            }
        }

        void LoadUsedSums(SqlConnection connection, List<DataModel.Client> clients, DateTime dateTimeNow, string tabNums, int paymentType, Action<DataModel.Client, decimal> action)
        {
            List<Tuple<string, decimal>> sums = new List<Tuple<string, decimal>>();
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText =
$@"select o.ТабельныйНомер, SUM(op.Сумма)
from Заказы o
	inner join ОплатаЗаказов op on op.IdЗаказа = o.Id
where o.ТабельныйНомер in ({tabNums}) and op.IdВидаОплаты = @IdВидаОплаты and o.Год = YEAR(@date) and MONTH(o.Дата) = MONTH(@date)
group by o.ТабельныйНомер";
                command.Parameters.AddWithValue("@IdВидаОплаты", paymentType);
                command.Parameters.AddWithValue("@date", dateTimeNow.ToUniversalTime());
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        sums.Add(new Tuple<string, decimal>(reader.GetString(0), reader.GetDecimal(1)));
                    }
                }
            }

            foreach (var sum in sums)
            {
                var client = clients.FirstOrDefault(_ => _.TabNum == sum.Item1);
                if (client != null)
                {
                    action(client, sum.Item2);
                }
            }
        }

        /// <summary>
        /// Записать клиентскую метку времени
        /// </summary>
        /// <param name="newClientTimeStamp">дата + время UTC</param>
        public void SaveClientTimeStamp(DateTime newClientTimeStamp)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"delete from МеткаКассы;
insert МеткаКассы (DateTime)
values (@DateTime)",
                connection);

                command.Parameters.AddWithValue("@DateTime", newClientTimeStamp);
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Загрузить информацию о транзакциях
        /// </summary>
        /// <param name="lastExchangeDateTime"></param>
        /// <returns></returns>
        public Transaction[] LoadTransactionDocument(DateTime? clientTimeStamp, DateTime newClientTimeStamp, bool isTestMode)
        {
            List<Transaction> orderPayments = new List<Transaction>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
@"select z.Id, z.Номер, z.Дата, z.ТабельныйНомер, oz.Сумма, oz.IdВидаОплаты, z.IdИсходногоЗаказа
from 
	Заказы z inner join
	ОплатаЗаказов oz on oz.IdЗаказа = z.Id
where 
	z.IdСмены is not null and
	z.ТабельныйНомер is not null and
	(oz.IdВидаОплаты = 0 or oz.IdВидаОплаты = 1) and
	z.Дата >= @Дата1 and z.Дата < @Дата2";
                    command.Parameters.AddWithValue("@Дата1", PrepareFromDate(clientTimeStamp));
                    command.Parameters.AddWithValue("@Дата2", newClientTimeStamp);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Transaction transaction = new Transaction
                            {
                                Id = reader.GetGuid(0).ToString(), 
                                CheckNum = reader.GetInt32(1), 
                                DateTime = reader.GetDateTime(2).ToLocalTime(), 
                                TabNum = reader.GetString(3), 
                            };
                            int k = reader.IsDBNull(6) ? 1 : -1;
                            decimal sum = reader.GetDecimal(4);
                            if (reader.GetInt32(5) == 0)
                            {
                                transaction.SumZP = k * sum;
                            }
                            else // if (reader.GetInt32(5) == 1)
                            {
                                transaction.SumLPP = k * sum;
                            }
                            orderPayments.Add(transaction);
                        }
                    }
                }
            }

            return orderPayments
                .GroupBy(transaction => transaction.Id)
                .Select(g =>
                {
                    var sumZP = g.Sum(t => t.SumZP);
                    var sumLPP = g.Sum(t => t.SumLPP);
                    var transaction = g.First();
                    return new Transaction
                    {
                        Id = transaction.Id,
                        CheckNum = transaction.CheckNum,
                        DateTime = transaction.DateTime,
                        TabNum = transaction.TabNum,
                        SumZP = sumZP,
                        SumZPSpecified = sumZP != 0,
                        SumLPP = sumLPP,
                        SumLPPSpecified = sumLPP != 0
                    };
                })
                .ToArray();
        }

        /// <summary>
        /// Загрузить информацию о заказах
        /// </summary>
        /// <param name="clientTimeStamp"></param>
        /// <returns></returns>
        public OrderDocument LoadOrderDocument(DateTime? clientTimeStamp, DateTime newClientTimeStamp, bool isTestMode)
        {
            OrderDocument result = new OrderDocument();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                result.OrderReturns = LoadOrderReturns(connection, clientTimeStamp, newClientTimeStamp, isTestMode);
                result.Orders = LoadOrders(connection, clientTimeStamp, newClientTimeStamp, result.OrderReturns, isTestMode);
                result.Products = LoadNomenclature(connection, result.Orders, result.OrderReturns);
                result.Measures = LoadMeasures(connection, result.Orders, result.OrderReturns);
            }
            return result.Orders != null || result.OrderReturns != null ? result : null;
        }

        private FrontServiceReference.Order[] LoadOrders(SqlConnection connection, DateTime? clientTimeStamp, DateTime newClientTimeStamp, FrontServiceReference.OrderReturn[] orderReturns, bool isTestMode)
        {
            Dictionary<Guid, FrontServiceReference.Order> orders = new Dictionary<Guid, FrontServiceReference.Order>();
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText =
@"select Id, Дата, Номер, ТабельныйНомер
from Заказы 
where (IdСмены is not null and ТабельныйНомер is not null and IdИсходногоЗаказа is null and Дата >= @Дата1 and Дата < @Дата2 and Тест = @Тест)";
                if (orderReturns != null && orderReturns.Any())
                {
                    string orderReturnIds = string.Join(",", orderReturns.Select(order => $"'{order.OriginalOrderGUID}'"));
                    command.CommandText += $" or Id in ({orderReturnIds})";
                }
                command.Parameters.AddWithValue("@Дата1", PrepareFromDate(clientTimeStamp));
                command.Parameters.AddWithValue("@Дата2", newClientTimeStamp);
                command.Parameters.AddWithValue("@Тест", isTestMode);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Guid id = reader.GetGuid(0);
                        orders.Add(id,
                            new FrontServiceReference.Order
                            {
                                Id = id.ToString(),
                                BuyDateTime = reader.GetDateTime(1).ToLocalTime(),
                                CheckNum = reader.GetInt32(2),
                                TabNum = reader.GetString(3),
                            });
                    }
                }
            }

            if (!orders.Any())
                return null;

            Dictionary<Guid, List<OrderPay>> orderPays = LoadOrdersPayments(connection, orders.Keys);

            foreach (var kvp in orders)
            {
                if (orderPays.TryGetValue(kvp.Key, out List<OrderPay> payments))
                {
                    kvp.Value.OrderPays = payments.ToArray();
                }
            }

            return orders.Where(kvp => kvp.Value.OrderPays != null).Select(kvp => kvp.Value).ToArray();
        }

        private CodeName[] LoadMeasures(SqlConnection connection, FrontServiceReference.Order[] orders, FrontServiceReference.OrderReturn[] orderReturns)
        {
            if (orders == null && orderReturns == null)
                return null;

            List<CodeName> result = new List<CodeName>();
            string measureIdStr = PrepareInStatement(orders, orderReturns, orderPay => orderPay.IdMeasure);
            using (SqlCommand command = new SqlCommand($"select Id, Наименование from ЕдиницыИзмерения where Id in ({measureIdStr})", connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new CodeName { Id = reader.GetString(0), Name = reader.GetString(1) });
                    }
                }
            }
            return result.ToArray();
        }

        string PrepareInStatement(FrontServiceReference.Order[] orders, FrontServiceReference.OrderReturn[] orderReturns, Func<OrderPay, string> getIdFunc)
        {
            List<string> ids = new List<string>();
            if (orders != null)
            {
                ids.AddRange(orders.SelectMany(order => order.OrderPays.Select(orderPay => getIdFunc(orderPay))));
            }
            if (orderReturns != null)
            {
                ids.AddRange(orderReturns.SelectMany(order => order.OrderPays.Select(orderPay => getIdFunc(orderPay))));
            }

            return string.Join(",", ids.Distinct().Select(id => $"'{id}'"));
        }

        private FrontServiceReference.Product[] LoadNomenclature(SqlConnection connection, FrontServiceReference.Order[] orders, FrontServiceReference.OrderReturn[] orderReturns)
        {
            if (orders == null && orderReturns == null)
                return null;

            List<FrontServiceReference.Product> result = new List<FrontServiceReference.Product>();

            // грузим используемую номенклатуру
            string productIdStr = PrepareInStatement(orders, orderReturns, orderPay => orderPay.IdProduct);
            using (SqlCommand command = new SqlCommand($"select Id, Наименование, IdРодителя from Номенклатура where Id in ({productIdStr})", connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new FrontServiceReference.Product { Id = reader.GetString(0), Name = reader.GetString(1), IdProductGroup = reader.GetString(2) });
                    }
                }
            }

            // грузим родительские элементы
            string productParentIdStr = string.Join(",", result.Select(product => $"'{product.IdProductGroup}'").Distinct());
            using (SqlCommand command = new SqlCommand($"select Id, Наименование from Номенклатура where Id in ({productParentIdStr})", connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new FrontServiceReference.Product { Id = reader.GetString(0), Name = reader.GetString(1) });
                    }
                }
            }

            return result.ToArray();
        }

        private FrontServiceReference.OrderReturn[] LoadOrderReturns(SqlConnection connection, DateTime? clientTimeStamp, DateTime newClientTimeStamp, bool isTestMode)
        {
            Dictionary<Guid, FrontServiceReference.OrderReturn> orders = new Dictionary<Guid, FrontServiceReference.OrderReturn>();
            using (SqlCommand command = new SqlCommand(
@"select Id, Дата, Номер, ТабельныйНомер, IdИсходногоЗаказа
from Заказы 
where IdСмены is not null and ТабельныйНомер is not null and IdИсходногоЗаказа is not null and Дата >= @Дата1 and Дата < @Дата2 and Тест = @Тест",
                connection))
            {

                command.Parameters.AddWithValue("@Дата1", PrepareFromDate(clientTimeStamp));
                command.Parameters.AddWithValue("@Дата2", newClientTimeStamp);
                command.Parameters.AddWithValue("@Тест", isTestMode);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Guid id = reader.GetGuid(0);
                        orders.Add(id,
                            new FrontServiceReference.OrderReturn
                            {
                                Id = id.ToString(),
                                BuyDateTime = reader.GetDateTime(1).ToLocalTime(),
                                CheckNum = reader.GetInt32(2),
                                TabNum = reader.GetString(3),
                                OriginalOrderGUID = reader.GetGuid(4).ToString()
                            });
                    }
                }
            }

            if (!orders.Any())
                return null;

            Dictionary<Guid, List<OrderPay>> orderPays = LoadOrdersPayments(connection, orders.Keys);

            foreach (var kvp in orders)
            {
                if (orderPays.TryGetValue(kvp.Key, out List<OrderPay> payments))
                {
                    kvp.Value.OrderPays = payments.ToArray();
                }
            }

            return orders.Where(kvp => kvp.Value.OrderPays != null).Select(kvp => kvp.Value).ToArray();
        }

        private static Dictionary<Guid, List<OrderPay>> LoadOrdersPayments(SqlConnection connection, IEnumerable<Guid> orderIds)
        {
            string orderIdStr = string.Join(",", orderIds.Select(orderId => $"'{orderId}'"));
            Dictionary<Guid, List<OrderPay>> orderPays = new Dictionary<Guid, List<OrderPay>>();
            using (SqlCommand command = new SqlCommand(
$@"select oz.IdЗаказа, t.IdНоменклатуры, t.IdЕдиницыИзмерения, oz.Цена, oz.Количество, oz.Сумма, vo.КодТрактира
from 
	ОплатаЗаказов oz inner join
	ВидыОплат vo on vo.Id = oz.IdВидаОплаты inner join
	Товары t on t.Id = oz.IdТовара
where 
	oz.IdЗаказа in ({orderIdStr})",
                connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Guid orderId = reader.GetGuid(0);
                        if (!orderPays.TryGetValue(orderId, out List<OrderPay> payments))
                        {
                            payments = new List<OrderPay>();
                            orderPays.Add(orderId, payments);
                        }
                        payments.Add(
                            new OrderPay
                            {
                                IdProduct = reader.GetString(1),
                                IdMeasure = reader.GetString(2),
                                Price = reader.GetDecimal(3),
                                Count = reader.GetDecimal(4),
                                Sum = reader.GetDecimal(5),
                                IdPayOption = reader.GetString(6)
                            });
                    }
                }
            }

            return orderPays;
        }

        /// <summary>
        /// Получить дату; если не указано, то начало месяца
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        DateTime PrepareFromDate(DateTime? dateTime)
        {
            if (dateTime != null)
                return dateTime.Value;
            else
            {
                DateTime now = DateTime.Now;
                return (new DateTime(now.Year, now.Month, 1)).ToUniversalTime();
            }
        }

        /// <summary>
        /// Записать фотографию клиента
        /// </summary>
        /// <param name="client"></param>
        public void SavePhoto(DataModel.Client client)
        {
            if (client == null)
                throw new ArgumentNullException(nameof(client));

            if (client.Photo != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = "update Клиенты set Фотография = @Фотография where ТабельныйНомер = @ТабельныйНомер";
                        command.Parameters.AddWithValue("@ТабельныйНомер", client.TabNum);
                        SqlParameter param = command.Parameters.Add("@Фотография", SqlDbType.VarBinary);
                        param.Value = client.Photo;
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        /// <summary>
        /// Получить список кассиров
        /// </summary>
        /// <returns></returns>
        public List<Operator> GetOperators()
        {
            List<Operator> list = new List<Operator>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select Id, КодПропуска, ФИО, Должность, ИНН, Пароль
from Кассиры
where Блокировка = 0
order by ФИО",
                    connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Operator
                    {
                        Id = reader.GetGuid(0),
                        CardID = reader.GetInt64(1),
                        FIO = reader.GetString(2),
                        Post = reader.IsDBNull(3) ? null : reader.GetString(3),
                        INN = reader.GetString(4),
                        Password = reader.GetString(5)
                    });
                }
            }
            return list;
        }

        /// <summary>
        /// Прочитать номер нового заказа
        /// </summary>
        /// <returns></returns>
        public int GetNewOrderNumber()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select MAX(Номер)
from Заказы
where Год = @Год",
                    connection);
                command.Parameters.AddWithValue("@Год", DateTime.Today.Year);
                var result = command.ExecuteScalar();
                return result == DBNull.Value || result == null ? 1 : (int)result + 1;
            }
        }

        public DateTime? GetServerTimeStamp()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select top 1 DateTime
from МеткаСервера",
                    connection);
                var result = command.ExecuteScalar();
                return result == DBNull.Value || result == null ? (DateTime?)null : (DateTime?)result;
            }
        }

        /// <summary>
        /// Добавить локальный элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool AddMenuItem(MenuItem menuItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"insert into ЭлементыМеню (Id, IdМеню, IdТовара, Количество, ЛокальныйЭлемент)
values (@Id, @IdМеню, @IdТовара, @Количество, @ЛокальныйЭлемент)",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                command.Parameters.AddWithValue("@IdМеню", menuItem.MenuId);
                command.Parameters.AddWithValue("@IdТовара", menuItem.ProductId);
                command.Parameters.AddWithValue("@Количество", menuItem.Count);
                command.Parameters.AddWithValue("@ЛокальныйЭлемент", menuItem.IsLocal);
                return command.ExecuteNonQuery() > 0;
            }
        }

        public void SaveExchangeData(ResultData resultData, string idCashDesk, decimal talonLppNominal, bool isTestMode)
        {
            if (!resultData.TimeStampSpecified)
                return;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    // записать информацию о клиентах
                    SaveExchangeDataClients(connection, transaction, resultData.ClientDocument);

                    // записать ЛПП
                    SaveExchangeDataLPP(connection, transaction, resultData.LPPDocument, talonLppNominal);

                    // записать фотографии
                    SaveExchangeDataPhoto(connection, transaction, resultData.PhotoDocument);

                    // записать транзакции
                    SaveExchangeDataTransactions(connection, transaction, resultData.TransactionDocument, isTestMode);

                    // записать заказы и возвраты
                    SaveExchangeDataOrderDocument(connection, transaction, idCashDesk, resultData.OrderDocument, isTestMode);

                    // записать дату/время сеанса обмена данными
                    SaveServerTimeStamp(connection, transaction, resultData.TimeStamp);

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        private void SaveExchangeDataOrderDocument(SqlConnection connection, SqlTransaction transaction, string idCashDesk, OrderDocument orderDocument, bool isTestMode)
        {
            // единицы измерения
            if (orderDocument.Measures != null && orderDocument.Measures.Length > 0)
            {
                List<Unit> units = orderDocument.Measures.Select(measure => new Unit { Id = measure.Id, Name = measure.Name }).ToList();
                SaveUnits(units, connection, transaction);
            }

            // номенклатура
            SaveExchangeDataNomenclature(connection, transaction, orderDocument.Products);

            if ((orderDocument.Orders != null && orderDocument.Orders.Any()) || (orderDocument.OrderReturns != null && orderDocument.OrderReturns.Any()))
            {
                // сформировать словарь вариантов оплаты
                Dictionary<string, int> payOptions = LoadPayOptions(connection, transaction);

                // сформировать словарь товаров:
                // - ключ: код номенклатуры Трактир + код единицы измерения + цена
                // - значение: внутренний код товара
                Dictionary<Tuple<string, string, decimal>, Guid> products = LoadProducts(connection, transaction, orderDocument.Orders, orderDocument.OrderReturns);

                // заказы
                SaveExchangeDataOrders(connection, transaction, idCashDesk, payOptions, products, orderDocument.Orders, isTestMode);

                // возвраты
                SaveExchangeDataOrderReturns(connection, transaction, idCashDesk, payOptions, products, orderDocument.OrderReturns, isTestMode);
            }
        }

        private void SaveExchangeDataOrderReturns(
            SqlConnection connection, 
            SqlTransaction transaction, 
            string idCashDesk, 
            Dictionary<string, int> payOptions, 
            Dictionary<Tuple<string, string, decimal>, Guid> products,
            FrontServiceReference.OrderReturn[] orderReturns, 
            bool isTestMode)
        {
            SaveExchangeDataOrders(connection, transaction, idCashDesk, payOptions, products, orderReturns, true, isTestMode);
        }

        private Dictionary<Tuple<string, string, decimal>, Guid> LoadProducts(SqlConnection connection, SqlTransaction transaction, FrontServiceReference.Order[] orders, FrontServiceReference.OrderReturn[] orderReturns)
        {
            Dictionary<Tuple<string, string, decimal>, Guid> result = new Dictionary<Tuple<string, string, decimal>, Guid>();

            List<Tuple<string, string, decimal>> productKeys = new List<Tuple<string, string, decimal>>();
            if (orders != null && orders.Length > 0)
            {
                productKeys.AddRange(orders.SelectMany(order => order.OrderPays.Select(orderPay => new Tuple<string, string, decimal>(orderPay.IdProduct, orderPay.IdMeasure, orderPay.Price))));
            }
            if (orderReturns != null && orderReturns.Length > 0)
            {
                productKeys.AddRange(orderReturns.SelectMany(order => order.OrderPays.Select(orderPay => new Tuple<string, string, decimal>(orderPay.IdProduct, orderPay.IdMeasure, orderPay.Price))));
            }
            HashSet<Tuple<string, string, decimal>> productKeysDistinct = new HashSet<Tuple<string, string, decimal>>(productKeys.Distinct());

            string nomenclatureIds = string.Join(",", productKeysDistinct.Select(productKey => $"'{productKey.Item1}'").Distinct());
            string measureIds = string.Join(",", productKeysDistinct.Select(productKey => $"'{productKey.Item2}'").Distinct());
            string prices = string.Join(",", productKeysDistinct.Select(productKey => productKey.Item3.ToString("F2", NumberFormatInfo.InvariantInfo)).Distinct());
            using (SqlCommand command = new SqlCommand(
$@"select Id, IdНоменклатуры, IdЕдиницыИзмерения, Цена 
from Товары
where IdНоменклатуры in ({nomenclatureIds}) and IdЕдиницыИзмерения in ({measureIds}) and Цена in ({prices})", 
                connection, transaction))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Guid id = reader.GetGuid(0);
                        Tuple<string, string, decimal> productKey = new Tuple<string, string, decimal>(reader.GetString(1), reader.GetString(2), reader.GetDecimal(3));
                        if (productKeysDistinct.Contains(productKey) && !result.ContainsKey(productKey))
                        {
                            result.Add(productKey, id);
                        }
                    }
                }
            }
            return result;
        }

        private Dictionary<string, int> LoadPayOptions(SqlConnection connection, SqlTransaction transaction)
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            using (SqlCommand command = new SqlCommand("select Id, КодТрактира from ВидыОплат", connection, transaction))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(reader.GetString(1), reader.GetInt32(0));
                    }
                }
            }
            return result;
        }

        private void SaveExchangeDataOrders(
            SqlConnection connection, 
            SqlTransaction transaction, 
            string idCashDesk, 
            Dictionary<string, int> payOptions, 
            Dictionary<Tuple<string, string, decimal>, Guid> products, 
            FrontServiceReference.Order[] orders, 
            bool isTestMode)
        {
            SaveExchangeDataOrders(connection, transaction, idCashDesk, payOptions, products, orders, false, isTestMode);
        }

        private void SaveExchangeDataOrders(
            SqlConnection connection, 
            SqlTransaction transaction, 
            string idCashDesk, 
            Dictionary<string, int> payOptions, 
            Dictionary<Tuple<string, string, decimal>, Guid> products, 
            IEnumerable<FrontServiceReference.Order> orders, 
            bool isReturns, 
            bool isTestMode)
        {
            if (orders == null || !orders.Any())
                return;

            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Заказы where Id = @Id)
begin
    update Заказы
    set Дата = @Дата, Номер = @Номер, ТабельныйНомер = @ТабельныйНомер, IdИсходногоЗаказа = @IdИсходногоЗаказа, Тест = @Тест
    where Id = @Id;
    delete from ОплатаЗаказов
    where IdЗаказа = @Id;
end
else
    insert Заказы (Id, Дата, Номер, ТабельныйНомер, IdИсходногоЗаказа, Тест)
    values (@Id, @Дата, @Номер, @ТабельныйНомер, @IdИсходногоЗаказа, @Тест)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command.Parameters.Add("@Дата", SqlDbType.DateTime);
            command.Parameters.Add("@Номер", SqlDbType.Int);
            command.Parameters.Add("@ТабельныйНомер", SqlDbType.VarChar, 10);
            command.Parameters.Add("@IdИсходногоЗаказа", SqlDbType.UniqueIdentifier);
            command.Parameters.AddWithValue("@Тест", isTestMode);

            SqlCommand command2 = new SqlCommand(
@"insert ОплатаЗаказов (Id, IdЗаказа, IdТовара, Цена, Количество, Сумма, IdВидаОплаты)
values (NEWID(), @IdЗаказа, @IdТовара, @Цена, @Количество, @Сумма, @IdВидаОплаты)",
                connection, transaction);
            command2.Parameters.Add("@IdЗаказа", SqlDbType.UniqueIdentifier);
            command2.Parameters.Add("@IdТовара", SqlDbType.UniqueIdentifier);
            command2.Parameters.Add(new SqlParameter { ParameterName = "@Цена", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            command2.Parameters.Add(new SqlParameter { ParameterName = "@Количество", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 3 });
            command2.Parameters.Add(new SqlParameter { ParameterName = "@Сумма", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            command2.Parameters.Add("@IdВидаОплаты", SqlDbType.Int);

            SqlCommand command3 = new SqlCommand(
@"insert Товары (Id, IdНоменклатуры, IdЕдиницыИзмерения, Цена)
values (@Id, @IdНоменклатуры, @IdЕдиницыИзмерения, @Цена)",
                connection, transaction);
            command3.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command3.Parameters.Add("@IdНоменклатуры", SqlDbType.VarChar, 15);
            command3.Parameters.Add("@IdЕдиницыИзмерения", SqlDbType.VarChar, 4);
            command3.Parameters.Add(new SqlParameter { ParameterName = "@Цена", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });

            foreach (var order in orders.Where(_ => _.IdCashDesk != idCashDesk))
            {
                Guid orderId = new Guid(order.Id);
                command.Parameters["@Id"].Value = orderId;
                command.Parameters["@Дата"].Value = order.BuyDateTime.ToUniversalTime();
                command.Parameters["@Номер"].Value = order.CheckNum;
                if (string.IsNullOrEmpty(order.TabNum))
                {
                    command.Parameters["@ТабельныйНомер"].Value = DBNull.Value;
                }
                else
                {
                    command.Parameters["@ТабельныйНомер"].Value = order.TabNum;
                }
                if (isReturns)
                {
                    command.Parameters["@IdИсходногоЗаказа"].Value = new Guid((order as FrontServiceReference.OrderReturn).OriginalOrderGUID);
                }
                else
                {
                    command.Parameters["@IdИсходногоЗаказа"].Value = DBNull.Value;
                }
                command.ExecuteNonQuery();

                foreach (var orderPay in order.OrderPays)
                {
                    command2.Parameters["@IdЗаказа"].Value = orderId;
                    command2.Parameters["@Цена"].Value = orderPay.Price; 
                    command2.Parameters["@Количество"].Value = orderPay.Count; 
                    command2.Parameters["@Сумма"].Value = orderPay.Sum;

                    // использовать словарь товаров для преобразования кода товара Трактира во внутренний код кассы
                    var productKey = new Tuple<string, string, decimal>(orderPay.IdProduct, orderPay.IdMeasure, orderPay.Price);
                    if (products.TryGetValue(productKey, out Guid productId))
                    {
                        command2.Parameters["@IdТовара"].Value = productId;
                    }
                    else
                    {
                        // не найден товар
                        productId = Guid.NewGuid();
                        command3.Parameters["@Id"].Value = productId;
                        command3.Parameters["@IdНоменклатуры"].Value = orderPay.IdProduct;
                        command3.Parameters["@IdЕдиницыИзмерения"].Value = orderPay.IdMeasure;
                        command3.Parameters["@Цена"].Value = orderPay.Price;
                        command3.ExecuteNonQuery();

                        products.Add(productKey, productId);

                        command2.Parameters["@IdТовара"].Value = productId;
                    }

                    // использовать словарь вариантов оплаты для преобразования кода Трактира во внутренний код кассы
                    if (payOptions.TryGetValue(orderPay.IdPayOption, out int payOption))
                    {
                        command2.Parameters["@IdВидаОплаты"].Value = payOption;
                    }
                    else
                    {
                        // не найден вид оплаты
                        //throw 
                        continue;
                    }
                    command2.ExecuteNonQuery();
                }
            }
        }

        private void SaveExchangeDataNomenclature(SqlConnection connection, SqlTransaction transaction, FrontServiceReference.Product[] products)
        {
            if (products == null || products.Length == 0)
                return;

            using (SqlCommand command = new SqlCommand(
@"if exists(select 1 from Номенклатура where Id = @Id)
    update Номенклатура
    set Наименование = @Наименование, IdРодителя = @IdРодителя
    where Id = @Id
else
    insert Номенклатура (Id, Наименование, IdРодителя)
    values (@Id, @Наименование, @IdРодителя)",
                connection, transaction))
            {
                command.Parameters.Add("@Id", SqlDbType.VarChar, 15);
                command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
                command.Parameters.Add("@IdРодителя", SqlDbType.VarChar, 15);

                command.Parameters["@IdРодителя"].Value = DBNull.Value;
                foreach (var product in products.Where(_ => string.IsNullOrEmpty(_.IdProductGroup)))
                {
                    command.Parameters["@Id"].Value = product.Id;
                    command.Parameters["@Наименование"].Value = product.Name;
                    command.ExecuteNonQuery();
                }

                foreach (var product in products.Where(_ => !string.IsNullOrEmpty(_.IdProductGroup)))
                {
                    command.Parameters["@Id"].Value = product.Id;
                    command.Parameters["@Наименование"].Value = product.Name;
                    command.Parameters["@IdРодителя"].Value = product.IdProductGroup;
                    command.ExecuteNonQuery();
                }
            }
        }

        private void SaveExchangeDataTransactions(SqlConnection connection, SqlTransaction transaction, Transaction[] transactions, bool isTestMode)
        {
            if (transactions == null || transactions.Length == 0)
                return;

            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Транзакции where Id = @Id)
    update Транзакции
    set ТабельныйНомер = @ТабельныйНомер, ДатаВремя = @ДатаВремя, НомерЗаказа = @НомерЗаказа, СуммаЗП = @СуммаЗП, СуммаЛПП = @СуммаЛПП
    where Id = @Id
else
    insert into Транзакции (Id, ТабельныйНомер, ДатаВремя, НомерЗаказа, СуммаЗП, СуммаЛПП, Тест)
    values (@Id, @ТабельныйНомер, @ДатаВремя, @НомерЗаказа, @СуммаЗП, @СуммаЛПП, @Тест)",
                connection, transaction);

            command.Parameters.Add(new SqlParameter { ParameterName = "@Id", SqlDbType = SqlDbType.UniqueIdentifier });
            command.Parameters.Add(new SqlParameter { ParameterName = "@ТабельныйНомер", SqlDbType = SqlDbType.VarChar, Size = 10 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@ДатаВремя", SqlDbType = SqlDbType.DateTime });
            command.Parameters.Add(new SqlParameter { ParameterName = "@НомерЗаказа", SqlDbType = SqlDbType.Int });
            command.Parameters.Add(new SqlParameter { ParameterName = "@СуммаЗП", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@СуммаЛПП", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            command.Parameters.AddWithValue("@Тест", isTestMode);

            foreach (var tran in transactions)
            {
                command.Parameters["@Id"].Value = new Guid(tran.Id); 
                command.Parameters["@ТабельныйНомер"].Value = tran.TabNum; 
                command.Parameters["@ДатаВремя"].Value = tran.DateTime;
                command.Parameters["@НомерЗаказа"].Value = tran.CheckNum;
                if (tran.SumZPSpecified)
                {
                    command.Parameters["@СуммаЗП"].Value = tran.SumZP;
                }
                else
                {
                    command.Parameters["@СуммаЗП"].Value = DBNull.Value;
                }
                if (tran.SumLPPSpecified)
                {
                    command.Parameters["@СуммаЛПП"].Value = tran.SumLPP; // decimal
                }
                else
                {
                    command.Parameters["@СуммаЛПП"].Value = DBNull.Value; // decimal
                }

                command.ExecuteNonQuery();
            }
        }

        private void SaveServerTimeStamp(SqlConnection connection, SqlTransaction transaction, DateTime dateTime)
        {
            if (dateTime == DateTime.MinValue)
                return;

            SqlCommand command = new SqlCommand(
@"delete from МеткаСервера;
insert МеткаСервера (DateTime)
values (@DateTime)",
                connection, transaction);

            command.Parameters.AddWithValue("@DateTime", dateTime);
            command.ExecuteNonQuery();
        }

        private void SaveExchangeDataPhoto(SqlConnection connection, SqlTransaction transaction, Photo[] photos)
        {
            if (photos == null || photos.Length == 0)
                return;

            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Клиенты where ТабельныйНомер = @ТабельныйНомер)
    update Клиенты
    set Фотография = @Фотография
    where ТабельныйНомер = @ТабельныйНомер",
                connection, transaction);

            command.Parameters.Add(new SqlParameter { ParameterName = "@ТабельныйНомер", SqlDbType = SqlDbType.VarChar, Size = 10 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@Фотография", SqlDbType = SqlDbType.VarBinary });

            foreach (var photo in photos.Where(_ => !string.IsNullOrEmpty(_.Data)))
            {
                command.Parameters["@ТабельныйНомер"].Value = photo.TabNum;
                command.Parameters["@Фотография"].Value = Convert.FromBase64String(photo.Data);
                command.ExecuteNonQuery();
            }
        }

        private void SaveExchangeDataLPP(SqlConnection connection, SqlTransaction transaction, LPP[] lppData, decimal talonLppNominal)
        {
            if (lppData == null || lppData.Length == 0)
                return;

            SqlCommand command = new SqlCommand(
@"declare @Id UNIQUEIDENTIFIER
select @Id = Max(Id)
from ЛПП where ТабельныйНомер = @ТабельныйНомер and Год = @Год and Месяц = @Месяц
if @Id is null
    insert ЛПП (Id, ТабельныйНомер, Год, Месяц, ОстатокЛПП)
    values (NEWID(), @ТабельныйНомер, @Год, @Месяц, @ОстатокЛПП)
else
    update ЛПП
    set ОстатокЛПП = @ОстатокЛПП
    where Id = @Id",
                connection, transaction);

            command.Parameters.Add(new SqlParameter { ParameterName = "@ТабельныйНомер", SqlDbType = SqlDbType.VarChar, Size = 10 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@Год", SqlDbType = SqlDbType.Int });
            command.Parameters.Add(new SqlParameter { ParameterName = "@Месяц", SqlDbType = SqlDbType.Int });
            command.Parameters.Add(new SqlParameter { ParameterName = "@ОстатокЛПП", SqlDbType = SqlDbType.Int });

            foreach (var lpp in lppData)
            {
                command.Parameters["@ТабельныйНомер"].Value = lpp.TabNum;
                command.Parameters["@Год"].Value = lpp.MonthLPP.Year;
                command.Parameters["@Месяц"].Value = lpp.MonthLPP.Month;
                command.Parameters["@ОстатокЛПП"].Value = lpp.SumLPP / talonLppNominal;
                command.ExecuteNonQuery();
            }
        }

        private void SaveExchangeDataClients(SqlConnection connection, SqlTransaction transaction, FrontServiceReference.Client[] clients)
        {
            if (clients == null || clients.Length == 0)
                return;

            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Клиенты where ТабельныйНомер = @ТабельныйНомер)
    update Клиенты
    set ФИО = @ФИО, КодПропуска = @КодПропуска, РазрешеноПитаниеЗП = @РазрешеноПитаниеЗП, ЛимитПоЗП = @ЛимитПоЗП
    where ТабельныйНомер = @ТабельныйНомер
else
    insert Клиенты (ТабельныйНомер, ФИО, КодПропуска, РазрешеноПитаниеЗП, ЛимитПоЗП)
    values (@ТабельныйНомер, @ФИО, @КодПропуска, @РазрешеноПитаниеЗП, @ЛимитПоЗП)",
                connection, transaction);

            command.Parameters.Add(new SqlParameter { ParameterName = "@ТабельныйНомер", SqlDbType = SqlDbType.VarChar, Size = 10 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@ФИО", SqlDbType = SqlDbType.NVarChar, Size = 50 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@КодПропуска", SqlDbType = SqlDbType.VarChar, Size = 12 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@РазрешеноПитаниеЗП", SqlDbType = SqlDbType.Bit });
            command.Parameters.Add(new SqlParameter { ParameterName = "@ЛимитПоЗП", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });

            foreach (var client in clients)
            {
                command.Parameters["@ТабельныйНомер"].Value = client.TabNum;
                command.Parameters["@ФИО"].Value = client.FIO.Replace('Ё', 'Е').Replace('ё', 'е');
                command.Parameters["@КодПропуска"].Value = client.CardCode;
                command.Parameters["@РазрешеноПитаниеЗП"].Value = client.IsZP;
                command.Parameters["@ЛимитПоЗП"].Value = client.LimitZP;
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <param name="operator">идентификатор кассира</param>
        /// <returns></returns>
        public Session OpenSession(Operator @operator)
        {
            Session session = new Session();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    SqlCommand command1 = new SqlCommand(
@"select top 1 Номер
from Смены
order by Начало desc", 
                        connection, transaction);
                    object numberObj = command1.ExecuteScalar();
                    int number = numberObj == DBNull.Value || numberObj == null ? 1 : (int)numberObj + 1;
                    Guid id = Guid.NewGuid();
                    DateTime begin = DateTime.Now;

                    SqlCommand command2 = new SqlCommand(
@"insert into Смены (Id, Номер, Начало, IdКассира)
values (@Id, @Номер, @Начало, @IdКассира)",
                        connection, transaction);
                    command2.Parameters.AddWithValue("@Id", id);
                    command2.Parameters.AddWithValue("@Номер", number);
                    // UTC
                    command2.Parameters.AddWithValue("@Начало", begin.ToUniversalTime());
                    command2.Parameters.AddWithValue("@IdКассира", @operator.Id);
                    if (command2.ExecuteNonQuery() > 0)
                    {
                        session.Id = id;
                        session.Number = number;
                        // local
                        session.Begin = begin;
                        session.OperatorId = @operator.Id;
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
            return session;
        }

        /// <summary>
        /// Закрыть смену
        /// </summary>
        public void CloseSession(Guid sessionId, DateTime dateTime)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"update Смены 
set Конец = @dateTime
where Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", sessionId);
                command.Parameters.AddWithValue("@dateTime", dateTime.ToUniversalTime());
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Загрузить последние меню, дата которых меньше или равна указанной
        /// </summary>
        /// <param name="date"></param>
        /// <param name="menuCount">количество меню для загрузки</param>
        /// <returns></returns>
        public List<DataModel.Menu> LoadMenus(DateTime date, int menuCount)
        {
            Dictionary<Guid, DataModel.Menu> menus = new Dictionary<Guid, DataModel.Menu>();
            Dictionary<string, MenuItemGroup> menuItemGroups = new Dictionary<string, MenuItemGroup>();
            List<Tuple<string, MenuItem>> menuItems = new List<Tuple<string, MenuItem>>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
$@"select top {menuCount} Id, Номер, Дата 
from Меню 
where CONVERT(date, Дата) <= @Дата
order by Дата desc";
                    command.Parameters.AddWithValue("@Дата", date.Date);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var id = reader.GetGuid(0);
                            menus.Add(id, new DataModel.Menu
                                {
                                    Id = id,
                                    Number = reader.GetString(1).TrimEnd(),
                                    Date = reader.GetDateTime(2).Date
                            });
                        }
                    }
                }

                if (menus.Count == 0)
                    return new List<DataModel.Menu>();

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
$@"select 
    n.IdРодителя,
    i.Id,
    n.Наименование,
    m.Наименование,
    t.Цена,
    i.Количество,
    i.ЛокальныйЭлемент,
    i.IdМеню,
    i.IdТовара
from 
    ЭлементыМеню i inner join 
    Товары t on i.IdТовара = t.Id inner join 
    Номенклатура n on t.IdНоменклатуры = n.Id inner join 
    ЕдиницыИзмерения m on t.IdЕдиницыИзмерения = m.Id
where 
    i.IdМеню in ({string.Join(",", menus.Keys.Select(id => $"'{id}'"))})";
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            menuItems.Add(new Tuple<string, MenuItem>(
                                reader.GetString(0),
                                new MenuItem
                                {
                                    Id = reader.GetGuid(1),
                                    Name = reader.GetString(2),
                                    Unit = reader.GetString(3),
                                    Price = reader.GetDecimal(4), 
                                    Count = reader.GetDecimal(5),
                                    IsLocal = reader.IsDBNull(6) ? false : reader.GetBoolean(6),
                                    MenuId = reader.GetGuid(7),
                                    ProductId = reader.GetGuid(8)
                                }));
                        }
                    }
                }

                if (menuItems.Count > 0)
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = 
$@"select Id, Наименование 
from Номенклатура 
where Id in ({string.Join(",", menuItems.Select(t => $"'{t.Item1}'").Distinct())})";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var id = reader.GetString(0);
                                menuItemGroups.Add(id, new MenuItemGroup
                                {
                                    Id = id,
                                    Name = reader.GetString(1)
                                });
                            }
                        }
                    }
                }
            }

            // сгруппировать элементы меню по группам элементов, группы могут дублироваться для разных меню
            //  - Guid - идентификатор меню
            //  - Dictionary<string, MenuItemGroup> - группы элементов меню
            //      - string - идентификатор группы элементов меню
            //      - MenuItemGroup - группа элементов меню
            Dictionary<Guid, Dictionary<string, MenuItemGroup>> menuGroupsItems = new Dictionary<Guid, Dictionary<string, MenuItemGroup>>();
            foreach (var t in menuItems)
            {
                var idGroup = t.Item1;
                var menuItem = t.Item2;
                var idMenu = menuItem.MenuId;
                if (menus.ContainsKey(idMenu))
                {
                    if (!menuGroupsItems.TryGetValue(idMenu, out Dictionary<string, MenuItemGroup> menuGroups))
                    {
                        menuGroups = new Dictionary<string, MenuItemGroup>();
                        menuGroupsItems.Add(idMenu, menuGroups);
                    }

                    if (menuItemGroups.TryGetValue(idGroup, out MenuItemGroup sourceItemGroup))
                    {
                        if (!menuGroups.TryGetValue(idGroup, out MenuItemGroup itemGroup))
                        {
                            itemGroup = new MenuItemGroup
                            {
                                Id = idGroup,
                                Name = sourceItemGroup.Name
                            };
                            menuGroups.Add(idGroup, itemGroup);
                        }

                        itemGroup.Items.Add(menuItem);
                    }
                }
            }

            // отсортировать элементы меню во всех группах всех меню
            foreach (var kvpMenu in menuGroupsItems)
            {
                foreach (var kvpGroup in kvpMenu.Value)
                {
                    kvpGroup.Value.Items.Sort(
                        (item1, item2) =>
                        {
                            int compare = string.Compare(item1.Name, item2.Name, true, CultureInfo.GetCultureInfo("ru-RU"));
                            if (compare == 0)
                                compare = decimal.Compare(item1.Price, item2.Price);
                            if (compare == 0)
                                compare = decimal.Compare(item1.Count, item2.Count);
                            return compare;
                        });
                }
            }

            // полученные группы элементов привязать к меню
            foreach (var kvpMenu in menus)
            {
                if (menuGroupsItems.TryGetValue(kvpMenu.Key, out Dictionary<string, MenuItemGroup> menuGroups))
                {
                    kvpMenu.Value.Items = menuGroups.Values.OrderBy(g => g.Name).ToList();
                }
            }

            // возврат списка меню, отсортированного по дате
            return menus.Values.OrderBy(menu => menu.Date).ToList();
        }

        /// <summary>
        /// Записать заказ и оплату
        /// </summary>
        /// <param name="session">смена</param>
        /// <param name="client">клиент</param>
        /// <param name="order">заказ</param>
        /// <param name="orderItems">оплата</param>
        public void SaveOrderAndPayment(Session session, DataModel.Client client, DataModel.Order order, IDictionary<Payment, List<OrderItem>> orderItems, bool isTestMode)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    SqlCommand command1 = new SqlCommand(
@"declare @MaxOrderNumber int
select @MaxOrderNumber = COALESCE(MAX(Номер), 0)
from Заказы 
where Год = YEAR(@Дата) 

if @Номер <= @MaxOrderNumber
	set @Номер = @MaxOrderNumber + 1

insert into Заказы (Id, IdСмены, Дата, Номер, ТабельныйНомер, Тест)
values (@Id, @IdСмены, @Дата, @Номер, @ТабельныйНомер, @Тест)",
                        connection, transaction);
                    command1.Parameters.AddWithValue("@Id", order.Id);
                    command1.Parameters.AddWithValue("@IdСмены", session.Id);
                    command1.Parameters.AddWithValue("@Дата", order.DateTime.ToUniversalTime());
                    command1.Parameters.AddWithValue("@Номер", order.Number);
                    command1.Parameters.AddWithValue("@Тест", isTestMode);
                    if (string.IsNullOrEmpty(client.TabNum))
                        command1.Parameters.AddWithValue("@ТабельныйНомер", DBNull.Value);
                    else
                        command1.Parameters.AddWithValue("@ТабельныйНомер", client.TabNum);
                    command1.ExecuteNonQuery();

                    SqlCommand command2 = new SqlCommand(
@"insert into ОплатаЗаказов (Id, IdЗаказа, IdТовара, Цена, Количество, Сумма, IdВидаОплаты)
values (NEWID(), @IdЗаказа, @IdТовара, @Цена, @Количество, @Сумма, @IdВидаОплаты)",
                        connection, transaction);
                    command2.Parameters.AddWithValue("@IdЗаказа", order.Id);
                    command2.Parameters.Add("@IdТовара", SqlDbType.UniqueIdentifier);
                    command2.Parameters.Add(new SqlParameter { ParameterName = "@Цена", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
                    command2.Parameters.Add(new SqlParameter { ParameterName = "@Количество", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 3 });
                    command2.Parameters.Add(new SqlParameter { ParameterName = "@Сумма", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });

                    command2.Parameters.Add("@IdВидаОплаты", SqlDbType.Int);
                    foreach (var kvp in orderItems)
                    {
                        foreach (var orderItem in kvp.Value)
                        {
                            command2.Parameters["@IdТовара"].Value = orderItem.MenuItem.ProductId;
                            command2.Parameters["@Цена"].Value = orderItem.MenuItem.Price;
                            command2.Parameters["@Количество"].Value = orderItem.Count;
                            command2.Parameters["@Сумма"].Value = orderItem.Sum;
                            command2.Parameters["@IdВидаОплаты"].Value = (int)kvp.Key;
                            command2.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        /// <summary>
        /// Изменить количество в элементе меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <param name="newCount"></param>
        /// <returns></returns>
        public bool ChangeMenuItemCount(MenuItem menuItem, decimal newCount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"update ЭлементыМеню 
set Количество = @Количество
where Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                command.Parameters.AddWithValue("@Количество", newCount);
                return command.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Удалить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool DeleteMenuItem(MenuItem menuItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"delete from ЭлементыМеню 
where Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                return command.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Записать планы-меню
        /// </summary>
        /// <param name="menus"></param>
        public void SaveMenus(Menus menus)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // все операции записи выполняются в рамках одной транзакции
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // запись единиц измерения
                    SaveUnits(menus, connection, transaction);

                    // запись номенклатуры
                    SaveNomenclature(menus, connection, transaction);

                    // запись товаров
                    SaveProducts(menus, connection, transaction);

                    // запись меню
                    SaveMenu(menus, connection, transaction);

                    // подтверждение транзакции
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            }
        }

        private void SaveUnits(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SaveUnits(menus.Units, connection, transaction);
        }

        private void SaveUnits(List<Unit> units, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from ЕдиницыИзмерения where Id = @Id)
    update ЕдиницыИзмерения
    set Наименование = @Наименование
    where Id = @Id
else
    insert ЕдиницыИзмерения (Id, Наименование)
    values (@Id, @Наименование)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.VarChar, 4);
            command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 25);
            foreach (var unit in units)
            {
                command.Parameters["@Id"].Value = unit.Id;
                command.Parameters["@Наименование"].Value = unit.Name;
                command.ExecuteNonQuery();
            }
        }

        private void SaveProducts(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Товары where Id = @Id)
    update Товары
    set IdНоменклатуры = @IdНоменклатуры, IdЕдиницыИзмерения = @IdЕдиницыИзмерения, Цена = @Цена
    where Id = @Id
else
    insert Товары (Id, IdНоменклатуры, IdЕдиницыИзмерения, Цена)
    values (@Id, @IdНоменклатуры, @IdЕдиницыИзмерения, @Цена)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command.Parameters.Add("@IdНоменклатуры", SqlDbType.VarChar, 15);
            command.Parameters.Add("@IdЕдиницыИзмерения", SqlDbType.VarChar, 4);
            command.Parameters.Add(new SqlParameter { ParameterName = "@Цена", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            foreach (var product in menus.Products)
            {
                command.Parameters["@Id"].Value = product.Id;
                command.Parameters["@IdНоменклатуры"].Value = product.NomenclatureId;
                command.Parameters["@IdЕдиницыИзмерения"].Value = product.UnitId;
                command.Parameters["@Цена"].Value = product.Price;
                command.ExecuteNonQuery();
            }
        }

        private static void SaveMenu(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command1 = new SqlCommand("select Id from Меню where Номер = @Номер and Дата = @Дата", connection, transaction);
            command1.Parameters.Add("@Номер", SqlDbType.NChar, 15);
            command1.Parameters.Add("@Дата", SqlDbType.DateTime);

            SqlCommand command2 = new SqlCommand("insert Меню (Id, Номер, Дата) values (@Id, @Номер, @Дата)", connection, transaction);
            command2.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command2.Parameters.Add("@Номер", SqlDbType.NChar, 15);
            command2.Parameters.Add("@Дата", SqlDbType.DateTime);

            SqlCommand command3 = new SqlCommand("delete from ЭлементыМеню where IdМеню = @IdМеню", connection, transaction);
            command3.Parameters.Add("@IdМеню", SqlDbType.UniqueIdentifier);

            SqlCommand command4 = new SqlCommand(
@"insert ЭлементыМеню (Id, IdМеню, IdТовара, Количество) 
values (@Id, @IdМеню, @IdТовара, @Количество)",
                connection, transaction);
            command4.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command4.Parameters.Add("@IdМеню", SqlDbType.UniqueIdentifier);
            command4.Parameters.Add("@IdТовара", SqlDbType.UniqueIdentifier);
            command4.Parameters.Add(new SqlParameter { ParameterName = "@Количество", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });

            foreach (var menu in menus.AllMenus)
            {
                command1.Parameters["@Номер"].Value = menu.Number;
                command1.Parameters["@Дата"].Value = menu.DateTime.Date;
                object idMenuObject = command1.ExecuteScalar();
                Guid idMenu = idMenuObject == null || idMenuObject == DBNull.Value ? Guid.Empty : (Guid)idMenuObject;
                if (idMenu == Guid.Empty)
                {
                    // добавление меню
                    idMenu = Guid.NewGuid();
                    command2.Parameters["@Id"].Value = idMenu;
                    command2.Parameters["@Номер"].Value = menu.Number;
                    command2.Parameters["@Дата"].Value = menu.DateTime.Date;
                    command2.ExecuteNonQuery();
                }
                else
                {
                    // удаление элементов меню
                    command3.Parameters["@IdМеню"].Value = idMenu;
                    command3.ExecuteNonQuery();
                }

                // добавление элементов меню
                foreach (var menuItem in menu.Items)
                {
                    command4.Parameters["@Id"].Value = Guid.NewGuid();
                    command4.Parameters["@IdМеню"].Value = idMenu;
                    command4.Parameters["@IdТовара"].Value = menuItem.Id;
                    command4.Parameters["@Количество"].Value = menuItem.Count;
                    command4.ExecuteNonQuery();
                }
            }
        }

        private static void SaveNomenclature(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Номенклатура where Id = @Id)
    update Номенклатура
    set Наименование = @Наименование, IdРодителя = @IdРодителя
    where Id = @Id
else
    insert Номенклатура (Id, Наименование, IdРодителя)
    values (@Id, @Наименование, @IdРодителя)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.VarChar, 15);
            command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
            command.Parameters.Add("@IdРодителя", SqlDbType.VarChar, 15);
            foreach (var parent in menus.Nomenclatures.Where(nm => string.IsNullOrEmpty(nm.IdParent)))
            {
                command.Parameters["@Id"].Value = parent.Id;
                command.Parameters["@Наименование"].Value = parent.Name;
                command.Parameters["@IdРодителя"].Value = DBNull.Value;
                command.ExecuteNonQuery();
                foreach (var nomenclature in parent.Childs)
                {
                    command.Parameters["@Id"].Value = nomenclature.Id;
                    command.Parameters["@Наименование"].Value = nomenclature.Name;
                    command.Parameters["@IdРодителя"].Value = nomenclature.IdParent;
                    command.ExecuteNonQuery();
                }
            }
        }

        string connectionString;
    }
}
