﻿/*******
* Метка кассы
*******/
CREATE TABLE [dbo].[МеткаКассы] (
    [DateTime] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([DateTime] ASC)
);

/*******
* Метка меню
*******/
CREATE TABLE [dbo].[МеткаМеню] (
    [DateTime] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([DateTime] ASC)
);

/*******
* Метка сервера
*******/
CREATE TABLE [dbo].[МеткаСервера] (
    [DateTime] DATETIME NOT NULL,
    PRIMARY KEY CLUSTERED ([DateTime] ASC)
);

/*******
* Номиналы талонов и дотаций
*******/
CREATE TABLE [dbo].[Номиналы] (
    [Id]        UNIQUEIDENTIFIER            NOT NULL,
    [С]         DATETIME       NOT NULL,
    [По]        DATETIME       NULL,
    [ЛПП]       DECIMAL (8, 2) NOT NULL,
    [Талон120]  DECIMAL (8, 2) NOT NULL,
    [Дотация8]  DECIMAL (8, 2) NOT NULL,
    [Дотация12] DECIMAL (8, 2) NOT NULL,
    [Дотация24] DECIMAL (8, 2) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

/*******
* Транзакции банковских карт
*******/
CREATE TABLE [dbo].[ТранзакцииБанковскихКарт] (
    [Id]              UNIQUEIDENTIFIER NOT NULL,
	IdЗаказа	UNIQUEIDENTIFIER NULL,
    [AuthCode]        NVARCHAR (9)     NULL,
    [TransType]       INT              NULL,
    [OperationType]   INT              NULL,
    [Sum]             DECIMAL (10, 2)  NULL,
    [CardNumber]      NVARCHAR (19)    NULL,
    [SlipNumber]      INT              NULL,
    [TransDateTime]   DATETIME         NULL,
    [MsgNumber]       INT              NULL,
    [TerminalID]      NVARCHAR (8)     NULL,
    [ReferenceNumber] NVARCHAR (50)    NULL,
    [ResponseCode]    NVARCHAR (10)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [FK_ТранзакцииБанковскихКарт_Заказы] FOREIGN KEY (IdЗаказа) REFERENCES [Заказы](Id)
);

/*******
* Ошибки возврата банковских карт
*******/

CREATE TABLE [dbo].[ОшибкиВозвратаБанковскихКарт]
(
	[Id] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [IdТранзакцииБанковскихКарт] UNIQUEIDENTIFIER NOT NULL, 
    [НомерСмены] INT NOT NULL, 
    [НомерЧека] INT NOT NULL, 
    CONSTRAINT [FK_ОшибкиВозвратаБанковскихКарт_ТранзакцииБанковскихКарт] FOREIGN KEY ([IdТранзакцииБанковскихКарт]) REFERENCES [ТранзакцииБанковскихКарт]([Id])
);

/*******
* Кассиры
*******/
CREATE TABLE [dbo].[Кассиры] (
    [Id]          UNIQUEIDENTIFIER NOT NULL,
    [КодПропуска] VARCHAR (12)     NOT NULL,
    [ФИО]         NVARCHAR (50)    NOT NULL,
    [Должность]   NVARCHAR (50)    NULL,
    [ИНН]         CHAR (12)        NOT NULL,
    [Пароль]      VARCHAR (10)     NOT NULL,
    [Блокировка]  BIT              NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

INSERT INTO [dbo].[Кассиры] ([Id], [КодПропуска], [ФИО], [ИНН], [Пароль], [Блокировка])
VALUES ('{EED7A48A-6645-4A58-8979-494A9D29B990}', '00005DEE27CE', N'Белышев Иван Алексеевич', '234567890123', '123', 0);
INSERT INTO [dbo].[Кассиры] ([Id], [КодПропуска], [ФИО], [ИНН], [Пароль], [Блокировка])
VALUES ('{53DB67B4-801F-483E-9E75-00064EA822AA}', '0000DBDC8E5D', N'Иванов Сергей Владимирович', '123456789012', '123', 0);

/*******
* Смены
*******/
CREATE TABLE [dbo].[Смены] (
    [Id]             UNIQUEIDENTIFIER NOT NULL,
    [Номер]          INT              NOT NULL,
	[НомерФН]        VARCHAR (25)     NULL,
    [Начало]         DATETIME         NOT NULL,
    [Конец]          DATETIME         NULL,
    [IdКассира]      UNIQUEIDENTIFIER NOT NULL,
    [ОтчетФОПередан] BIT              NULL,
    [Год]            AS               (datepart(year,[Начало])),
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Смены_Кассиры] FOREIGN KEY ([IdКассира]) REFERENCES [dbo].[Кассиры] ([Id])
);

/*******
* Ставки НДС
*******/
CREATE TABLE [dbo].[СтавкиНДС]
(
	-- Код ставки НДС, соответствующий перечислению LIBFPTR_PARAM_TAX_TYPE в драйвере Атол 
	[Код] INT NOT NULL PRIMARY KEY, 
	-- Код ставки НДС, соответствующий перечислению СтавкиНДС в конфигурации Бухгалтерия 
    [Код1С] NVARCHAR(25) NOT NULL, 
	-- Формула расчета для ставок НДС, отсутствующих в драйвере Атол (Код < 0)
    [Формула]	VARCHAR(25)	NULL,
	[Комментарий] NVARCHAR(50) NOT NULL
);

CREATE UNIQUE NONCLUSTERED INDEX [UI_СтавкиНДС_Код1С]
    ON [dbo].[СтавкиНДС]([Код1С] ASC);

INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (0, N'-- нет кода --', N'НДС, привязанный к секции товара');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (1, N'НДС18', N'НДС 18%');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (2, N'НДС10', N'НДС 10%');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (3, N'НДС18_118', N'НДС расчитанный 18/118');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (4, N'НДС10_110', N'НДС расчитанный 10/110');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (5, N'НДС0', N'НДС 0%');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Комментарий])
VALUES (6, N'БезНДС', N'не облагается');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Формула], [Комментарий])
VALUES (-1, N'НДС20', '20/100', N'НДС 20%');
INSERT INTO [dbo].[СтавкиНДС] ([Код], [Код1С], [Формула], [Комментарий])
VALUES (-2, N'НДС20_120', '20/120', N'НДС расчитанный 20/120');

/*******
* Номенклатура
*******/
CREATE TABLE [dbo].[Номенклатура] (
    [Id]           VARCHAR (15)   NOT NULL,
    [Наименование] NVARCHAR (100) NOT NULL,
    [IdРодителя]   VARCHAR (15)   NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Номенклатура_Номенклатура] FOREIGN KEY ([IdРодителя]) REFERENCES [dbo].[Номенклатура] ([Id])
);

/*******
* Виды оплат
*******/
CREATE TABLE [dbo].[ВидыОплат] (
    [Id]           INT           NOT NULL,
    [Наименование] NVARCHAR (50) NOT NULL,
    [КодТрактира]  NVARCHAR (8)  NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE UNIQUE NONCLUSTERED INDEX [UI_ВидыОплат_КодТрактира]
    ON [dbo].[ВидыОплат]([КодТрактира] ASC);

INSERT INTO [dbo].[ВидыОплат] ([Id], [Наименование], [КодТрактира])
VALUES (0, N'В счёт ЗП', '00000006');
INSERT INTO [dbo].[ВидыОплат] ([Id], [Наименование], [КодТрактира])
VALUES (1, N'ТАЛОН 248', '00000002');
INSERT INTO [dbo].[ВидыОплат] ([Id], [Наименование], [КодТрактира])
VALUES (2, N'ТАЛОН 120', '00000003');
INSERT INTO [dbo].[ВидыОплат] ([Id], [Наименование], [КодТрактира])
VALUES (3, N'Банк. карта', '00000005');
INSERT INTO [dbo].[ВидыОплат] ([Id], [Наименование], [КодТрактира])
VALUES (4, N'Наличные', '00000001');

/*******
* Единицы измерения
*******/
CREATE TABLE [dbo].[ЕдиницыИзмерения] (
    [Id]           VARCHAR (4)   NOT NULL,
    [Наименование] NVARCHAR (25) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

/*******
* Товары
*******/
CREATE TABLE [dbo].[Товары] (
    [Id]                 UNIQUEIDENTIFIER NOT NULL,
    [IdНоменклатуры]     VARCHAR (15)     NOT NULL,
    [IdЕдиницыИзмерения] VARCHAR (4)      NOT NULL,
    [Цена]               DECIMAL (8, 2)   NOT NULL,
    [КодСтавкиНДС]		INT NOT NULL, 
    [КоэффициентНДС] DECIMAL(8, 6) NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Товары_ЕдиницыИзмерения] FOREIGN KEY ([IdЕдиницыИзмерения]) REFERENCES [dbo].[ЕдиницыИзмерения] ([Id]),
    CONSTRAINT [FK_Товары_Номенклатура] FOREIGN KEY ([IdНоменклатуры]) REFERENCES [dbo].[Номенклатура] ([Id]),
    CONSTRAINT [FK_Товары_СтавкиНДС] FOREIGN KEY ([КодСтавкиНДС]) REFERENCES [dbo].[СтавкиНДС] ([Код])
);

/*******
* Меню
*******/
CREATE TABLE [dbo].[Меню] (
    [Id]    UNIQUEIDENTIFIER NOT NULL,
    [Номер] NCHAR (15)       NOT NULL,
    [Дата]  DATETIME         NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE UNIQUE NONCLUSTERED INDEX [UIX_Меню_Номер]
    ON [dbo].[Меню]([Номер] ASC);

CREATE UNIQUE NONCLUSTERED INDEX [UIX_Меню_Дата]
    ON [dbo].[Меню]([Дата] ASC);

/*******
* Элементы меню
*******/
CREATE TABLE [dbo].[ЭлементыМеню] (
    [Id]               UNIQUEIDENTIFIER NOT NULL,
    [IdМеню]           UNIQUEIDENTIFIER NOT NULL,
    [IdТовара]         UNIQUEIDENTIFIER NOT NULL,
    [Количество]       DECIMAL (8, 2)   NOT NULL,
    [ЛокальныйЭлемент] BIT              NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ЭлементыМеню_Меню] FOREIGN KEY ([IdМеню]) REFERENCES [dbo].[Меню] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_ЭлементыМеню_Товары] FOREIGN KEY ([IdТовара]) REFERENCES [dbo].[Товары] ([Id]) ON DELETE CASCADE
);

/*******
* Клиенты
*******/
CREATE TABLE [dbo].[Клиенты] (
    [ТабельныйНомер]     VARCHAR (10)    NOT NULL,
    [ФИО]                NVARCHAR (50)   NOT NULL,
    [КодПропуска]        VARCHAR (12)    NOT NULL,
    [РазрешеноПитаниеЗП] BIT             NOT NULL,
    [ЛимитПоЗП]          DECIMAL (8, 2)  DEFAULT ((0)) NOT NULL,
    [Фотография]         VARBINARY (MAX) NULL,
    PRIMARY KEY CLUSTERED ([ТабельныйНомер] ASC)
);

/*******
* ЛПП
*******/
CREATE TABLE [dbo].[ЛПП] (
    [Id]             UNIQUEIDENTIFIER NOT NULL,
    [ТабельныйНомер] VARCHAR (10)     NOT NULL,
    [Год]            INT              NOT NULL,
    [Месяц]          INT              NOT NULL,
    [ОстатокЛПП]     INT              NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ЛПП_Клиенты] FOREIGN KEY ([ТабельныйНомер]) REFERENCES [dbo].[Клиенты] ([ТабельныйНомер]) ON DELETE CASCADE
);

CREATE UNIQUE NONCLUSTERED INDEX [UI_ЛПП_ТабельныйНомерГодМесяц]
    ON [dbo].[ЛПП]([ТабельныйНомер] ASC, [Год] ASC, [Месяц] ASC);

/*******
* Транзакции
*******/
CREATE TABLE [dbo].[Транзакции] (
    [Id]             UNIQUEIDENTIFIER NOT NULL,
    [ТабельныйНомер] VARCHAR (10)     NOT NULL,
    [ДатаВремя]      DATETIME         NOT NULL,
    [НомерЗаказа]    INT              NOT NULL,
    [СуммаЗП]        DECIMAL (8, 2)   NULL,
    [СуммаЛПП]       DECIMAL (8, 2)   NULL,
    [Тест]           BIT              NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Транзакции_Клиенты] FOREIGN KEY ([ТабельныйНомер]) REFERENCES [dbo].[Клиенты] ([ТабельныйНомер]) ON DELETE CASCADE
);

/*******
* Заказы
*******/
CREATE TABLE [dbo].[Заказы] (
    [Id]                UNIQUEIDENTIFIER NOT NULL,
    [IdСмены]           UNIQUEIDENTIFIER NULL,
    [Дата]              DATETIME         NOT NULL,
    [Номер]             INT              NOT NULL,
    [ТабельныйНомер]    VARCHAR (10)     NULL,
    [IdИсходногоЗаказа] UNIQUEIDENTIFIER NULL,
    [Тест]              BIT              NOT NULL,
    [Год]               AS               (datepart(year,[Дата])),
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Заказы_Клиенты] FOREIGN KEY ([ТабельныйНомер]) REFERENCES [dbo].[Клиенты] ([ТабельныйНомер]) ON DELETE CASCADE,
    CONSTRAINT [FK_Заказы_Смены] FOREIGN KEY ([IdСмены]) REFERENCES [dbo].[Смены] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_Заказы_Заказы] FOREIGN KEY ([IdИсходногоЗаказа]) REFERENCES [dbo].[Заказы] ([Id])
);

/*******
* Оплата заказов
*******/
CREATE TABLE [dbo].[ОплатаЗаказов] (
    [Id]           UNIQUEIDENTIFIER NOT NULL,
    [IdЗаказа]     UNIQUEIDENTIFIER NOT NULL,
    [IdТовара]     UNIQUEIDENTIFIER NOT NULL,
    [Цена]         DECIMAL (8, 2)   NOT NULL,
    [Количество]   DECIMAL (8, 3)   NOT NULL,
    [Сумма]        DECIMAL (8, 2)   NOT NULL,
    [IdВидаОплаты] INT              NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ОплатаЗаказов_ВидыОплат] FOREIGN KEY ([IdВидаОплаты]) REFERENCES [dbo].[ВидыОплат] ([Id]),
    CONSTRAINT [FK_ОплатаЗаказов_Заказы] FOREIGN KEY ([IdЗаказа]) REFERENCES [dbo].[Заказы] ([Id]) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT [FK_ОплатаЗаказов_Товары] FOREIGN KEY ([IdТовара]) REFERENCES [dbo].[Товары] ([Id]) ON DELETE CASCADE
);

CREATE UNIQUE NONCLUSTERED INDEX [UI_ОплатаЗаказов_ЗаказТоварВидОплаты]
    ON [dbo].[ОплатаЗаказов]([IdЗаказа] ASC, [IdТовара] ASC, [IdВидаОплаты] ASC);

