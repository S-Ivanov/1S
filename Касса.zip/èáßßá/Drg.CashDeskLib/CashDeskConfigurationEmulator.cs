﻿namespace Drg.CashDeskLib
{
    public class CashDeskConfigurationEmulator : CashDeskConfiguration
    {
        #region Настройки считывателя пропусков

        /// <summary>
        /// Полное имя файла управления эмулятором считывателя пропусков
        /// </summary>
        public string CardReaderEmulatorFileName { get; set; }

        #endregion Настройки считывателя пропусков

        /// <summary>
        /// Полное имя файла управления эмулятором ККМ
        /// </summary>
        public string KkmEmulatorFileName { get; set; }

        /// <summary>
        /// Полное имя файла управления эмулятором банковского терминала
        /// </summary>
        public string PayTerminalEmulatorFileName { get; set; }
    }
}
