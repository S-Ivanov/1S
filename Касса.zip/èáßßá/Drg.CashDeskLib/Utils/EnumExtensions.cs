﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDeskLib.Utils
{
    /// <summary>
    /// Методы расширения для Enum + Flags
    /// </summary>
    /// <remarks>
    /// см. https://stackoverflow.com/questions/4171140/iterate-over-values-in-flags-enum
    /// ответ 37
    /// </remarks>
    public static class EnumExtensions
    {
        public static IEnumerable<Enum> GetFlags(this Enum value)
        {
            return GetFlags(value, Enum.GetValues(value.GetType()).Cast<Enum>().ToArray());
        }

        public static IEnumerable<Enum> GetIndividualFlags(this Enum value)
        {
            return GetFlags(value, GetFlagValues(value.GetType()).ToArray());
        }

        private static IEnumerable<Enum> GetFlags(Enum value, Enum[] values)
        {
            ulong bits = Convert.ToUInt64(value);
            List<Enum> results = new List<Enum>();
            for (int i = values.Length - 1; i >= 0; i--)
            {
                ulong mask = Convert.ToUInt64(values[i]);
                if (i == 0 && mask == 0L)
                    break;
                if ((bits & mask) == mask)
                {
                    results.Add(values[i]);
                    bits -= mask;
                }
            }
            if (bits != 0L)
                return Enumerable.Empty<Enum>();
            if (Convert.ToUInt64(value) != 0L)
                return results.Reverse<Enum>();
            if (bits == Convert.ToUInt64(value) && values.Length > 0 && Convert.ToUInt64(values[0]) == 0L)
                return values.Take(1);
            return Enumerable.Empty<Enum>();
        }

        private static IEnumerable<Enum> GetFlagValues(Type enumType)
        {
            ulong flag = 0x1;
            foreach (var value in Enum.GetValues(enumType).Cast<Enum>())
            {
                ulong bits = Convert.ToUInt64(value);
                if (bits == 0L)
                    //yield return value;
                    continue; // skip the zero value
                while (flag < bits) flag <<= 1;
                if (flag == bits)
                    yield return value;
            }
        }

        /// <summary>
        /// Получить текст дескриптора для элемента перечисления
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        /// <remarks>
        /// см. https://stackoverflow.com/questions/28152903/how-do-you-add-a-description-to-you-enum-values-in-c-sharp-to-use-with-a-dropdow
        /// ответ 3 - адаптированный вариант
        /// </remarks>
        public static string GetDescription(this Enum value)
        {
            #region Исходный вариант

            //// ошибка value.GetName()
            //var fieldInfo = value.GetType().GetField(value.GetName());
            //var descriptionAttribute = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false).FirstOrDefault() as DescriptionAttribute;
            //return descriptionAttribute == null ? value.GetName() : descriptionAttribute.Description;

            #endregion Исходный вариант

            #region Адаптированный вариант

            string valueName = Enum.GetName(value.GetType(), value);
            var fieldInfo = value.GetType().GetField(valueName);
            var descriptionAttribute = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false).FirstOrDefault() as DescriptionAttribute;
            return descriptionAttribute == null ? valueName : descriptionAttribute.Description;

            #endregion Адаптированный вариант
        }
    }
}
