﻿namespace Drg.CashDeskLib.Utils
{
    public static class PaymentUtils
    {
        public static string GetPaymentName(DataModel.Payment payment, bool isShortName = false)
        {
            switch (payment)
            {
                case DataModel.Payment.BankCard: return isShortName ? "Банк. карта" : "По банковской карте";
                case DataModel.Payment.Cash: return "Наличные";
                case DataModel.Payment.LPP: return "Талоны ЛПП";
                case DataModel.Payment.Talon120: return "Талоны 120";
                case DataModel.Payment.ZP: return isShortName ? "В счёт ЗП" : "В счёт зарплаты";
                default: return "";
            }
        }
    }
}
