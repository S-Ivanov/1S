﻿using Drg.CashDeskLib.DataModel;

namespace Drg.CashDeskLib.Utils
{
    public static class PaymentUtils
    {
        public static string GetPaymentName(Payment payment, bool isShortName = false)
        {
            switch (payment)
            {
                case Payment.BankCard: return isShortName ? "Банк. карта" : "По банковской карте";
                case Payment.Cash: return "Наличные";
                case Payment.LPP: return "Талоны ЛПП";
                case Payment.Talon120: return "Талоны 120";
                case Payment.ZP: return isShortName ? "В счёт ЗП" : "В счёт зарплаты";
                default: return "";
            }
        }
    }
}
