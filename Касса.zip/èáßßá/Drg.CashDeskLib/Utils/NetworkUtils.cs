﻿using System.Net.NetworkInformation;
using System.Text;

namespace Drg.CashDeskLib.Utils
{
    public static class NetworkUtils
    {
        /// <summary>
        /// Пинг хоста
        /// </summary>
        /// <param name="host"></param>
        /// <returns></returns>
        /// <remarks>
        /// https://docs.microsoft.com/en-us/dotnet/api/system.net.networkinformation.ping?redirectedfrom=MSDN&view=netframework-4.5
        /// </remarks>
        public static bool HasPing(string host)
        {
            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();
            options.DontFragment = true;
            string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            int timeout = 120;
            PingReply reply = pingSender.Send(host, timeout, buffer, options);
            return reply.Status == IPStatus.Success;
        }
    }
}
