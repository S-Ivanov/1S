﻿namespace Drg.CashDeskLib.Utils
{
    /// <summary>
    /// Утилиты для работы со строками
    /// </summary>
    public static class StringUtils
    {
        public static string FIO2FInitials(string fio)
        {
            if (string.IsNullOrWhiteSpace(fio))
                return string.Empty;

            string[] items = fio.Split(' ');
            if (items.Length == 1)
                return items[0];
            else if (items.Length == 2)
                return $"{items[0]} {items[1][0]}.";
            else
                return $"{items[0]} {items[1][0]}.{items[2][0]}.";
        }
    }
}
