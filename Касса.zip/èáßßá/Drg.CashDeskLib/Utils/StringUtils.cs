﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.Utils
{
    /// <summary>
    /// Утилиты для работы со строками
    /// </summary>
    public static class StringUtils
    {
        /// <summary>
        /// Преобразовать ФИО в фамилию и инициалы
        /// </summary>
        /// <param name="fio"></param>
        /// <returns></returns>
        public static string FIO2FInitials(this string fio)
        {
            if (string.IsNullOrWhiteSpace(fio))
                return string.Empty;

            string[] items = fio.Split(' ');
            if (items.Length == 1)
                return items[0];
            else if (items.Length == 2)
                return $"{items[0]} {items[1][0]}.";
            else
                return $"{items[0]} {items[1][0]}.{items[2][0]}.";
        }

        /// <summary>
        /// Разбить строку на цифры и символы
        /// </summary>
        /// <param name="text">входная строка</param>
        /// <returns>
        /// Tuple:
        ///     - Item1 = цифры
        ///     - Item2 = остальные символы
        /// </returns>
        public static Tuple<string, string> ToDigitsAndChars(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return new Tuple<string, string>("", "");

            string digits = string.Concat(text.Where(ch => char.IsDigit(ch)));
            string chars = string.Concat(text.Where(ch => !char.IsDigit(ch)));
            return new Tuple<string, string>(digits, chars);
        }

        /// <summary>
        /// Поиск всех вхождений подстроки в строку
        /// </summary>
        /// <param name="str">проверяемая строка</param>
        /// <param name="substr">строка для поиска</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns>индексы вхождений</returns>
        /// <remarks>
        /// https://stackoverflow.com/questions/2641326/finding-all-positions-of-substring-in-a-larger-string-in-c-sharp
        /// ответ 4
        /// </remarks>
        public static List<int> AllIndexesOf(this string str, string substr, bool ignoreCase = true)
        {
            if (string.IsNullOrWhiteSpace(str) ||
                string.IsNullOrWhiteSpace(substr))
            {
                throw new ArgumentException("String or substring is not specified.");
            }

            var indexes = new List<int>();
            int index = 0;

            while ((index = str.IndexOf(substr, index, ignoreCase ? StringComparison.CurrentCultureIgnoreCase : StringComparison.CurrentCulture)) != -1)
            {
                indexes.Add(index++);
            }

            return indexes;
        }

        /// <summary>
        /// Обрамить вхождения подстроки строками frameBegin и frameEnd
        /// </summary>
        /// <param name="str">исходная строка</param>
        /// <param name="substr">искомая подстрока</param>
        /// <param name="frameBegin">обрамляющая строка слева</param>
        /// <param name="frameEnd">обрамляющая строка справа</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns></returns>
        public static string FrameSubstringAll(this string str, string substr, string frameBegin, string frameEnd, bool ignoreCase = true)
        {
            var allIndexes = AllIndexesOf(str, substr, ignoreCase);
            if (allIndexes.Count == 0)
                return str;

            int substrLength = substr.Length;

            int previousIndex = allIndexes[0];
            var indexes = allIndexes.Where(
                index =>
                {
                    if (index == previousIndex)
                        return true;
                    else if (index - previousIndex >= substrLength)
                    {
                        previousIndex = index;
                        return true;
                    }
                    else
                        return false;
                });

            StringBuilder sb = new StringBuilder();
            int startIndex = 0;
            foreach (var index in indexes)
            {
                sb.Append(str.Substring(startIndex, index - startIndex));
                sb.Append(frameBegin);
                sb.Append(str.Substring(index, substrLength));
                sb.Append(frameEnd);
                startIndex = index + substrLength;
            }

            if (startIndex < str.Length)
                sb.Append(str.Substring(startIndex));

            return sb.ToString();

        }

        /// <summary>
        /// Обрамить первое вхождение подстроки строками frameBegin и frameEnd
        /// </summary>
        /// <param name="str">исходная строка</param>
        /// <param name="substr">искомая подстрока</param>
        /// <param name="frameBegin">обрамляющая строка слева</param>
        /// <param name="frameEnd">обрамляющая строка справа</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns></returns>
        public static string FrameSubstring(this string str, string substr, string frameBegin, string frameEnd, bool ignoreCase = true)
        {
            if (string.IsNullOrEmpty(frameBegin) || string.IsNullOrEmpty(frameEnd))
                throw new ArgumentException();

            if (string.IsNullOrEmpty(str) || string.IsNullOrEmpty(substr))
                return str;

            int index = str.IndexOf(substr, ignoreCase ? StringComparison.CurrentCultureIgnoreCase : StringComparison.CurrentCulture);
            if (index >= 0)
                return str.Substring(0, index) + frameBegin + str.Substring(index, substr.Length) + frameEnd + str.Substring(index + substr.Length);
            else
                return str;
        }

        /// <summary>
        /// Обрамить вхождения подстроки открывающим и закрывающим тэгами
        /// </summary>
        /// <param name="str">исходная строка</param>
        /// <param name="substr">искомая подстрока</param>
        /// <param name="tag">имя тэга без угловых скобок</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns></returns>
        public static string InsertTagsAll(this string str, string substr, string tag, bool ignoreCase = true)
        {
            return FrameSubstringAll(str, substr, $"<{tag}>", $"</{tag}>", ignoreCase);
        }

        /// <summary>
        /// Обрамить первое вхождение подстроки открывающим и закрывающим тэгами
        /// </summary>
        /// <param name="str">исходная строка</param>
        /// <param name="substr">искомая подстрока</param>
        /// <param name="tag">имя тэга без угловых скобок</param>
        /// <param name="ignoreCase">игнорировать зависимость от регистра</param>
        /// <returns></returns>
        public static string InsertTags(this string str, string substr, string tag, bool ignoreCase = true)
        {
            return FrameSubstring(str, substr, $"<{tag}>", $"</{tag}>", ignoreCase);
        }

        /// <summary>
        /// Попытка преобразовать строку к decimal 
        /// </summary>
        /// <param name="str">входная строка</param>
        /// <param name="value">значение decimal</param>
        /// <returns>true - если преобразование успешно</returns>
        /// <remarks>
        /// см. примеры использования в UnitTests.StringUtils_Tests.StringUtils_TryToDecimal_Test()
        /// </remarks>
        public static bool TryToDecimal(this string str, out decimal value)
        {
            value = 0;
            if (string.IsNullOrEmpty(str))
                return true;

            if (str.First() == ',' || str.First() == '.')
                str = "0" + str;
            if (str.Last() == ',' || str.Last() == '.')
                str += "0";

            return decimal.TryParse(str.Replace(',', '.'), NumberStyles.Number, NumberFormatInfo.InvariantInfo, out value);
        }
    }
}
