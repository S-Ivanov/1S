﻿using System;

namespace Drg.CashDeskLib.Utils
{
    /// <summary>
    /// Контракт
    /// </summary>
    /// <remarks>
    /// Используется для контрактного программирования
    /// </remarks>
    public static class Contract
    {
        /// <summary>
        /// Определяет контракт предусловия и генерирует исключение, если условие для контракта не выполняется
        /// </summary>
        /// <typeparam name="T">тип исключения</typeparam>
        /// <param name="condition">условие</param>
        public static void Requires<T>(bool condition) where T : Exception, new()
        {
            if (!condition)
                throw new T();
        }

        /// <summary>
        /// Определяет контракт предусловия и генерирует исключение с сообщением, если условие для контракта не выполняется
        /// </summary>
        /// <typeparam name="T">тип исключения</typeparam>
        /// <param name="condition">условие</param>
        /// <param name="exceptionMessage">сообщение исключения (первый параметр конструктора исключения)</param>
        public static void Requires<T>(bool condition, string exceptionMessage) where T : Exception
        {
            if (!condition)
                throw (T)Activator.CreateInstance(typeof(T), exceptionMessage);
        }
    }
}
