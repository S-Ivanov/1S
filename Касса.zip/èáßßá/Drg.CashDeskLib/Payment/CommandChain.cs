﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.Payment
{
    public class CommandChain<T>
    {
        public static CommandChain<T> Create() => new CommandChain<T>();

        private CommandChain()
        {
        }

        public CommandChain<T> Add(Command<T> command)
        {
            commands.Add(command);
            return this;
        }

        public void Execute(T data)
        {
            int commandIndex = 0;
            try
            {
                // последовательное выполнение команд
                for (; commandIndex < commands.Count; commandIndex++)
                {
                    commands[commandIndex].Execute(data);
                }
            }
            catch (Exception ex)
            {
                // в случае ошибки в какой-либо команде откат команд в обратном порядке
                for (; commandIndex >= 0; commandIndex--)
                {
                    try
                    {
                        commands[commandIndex].Undo(data);
                    }
                    catch (Exception undoException)
                    {
                        // в случае ошибки отката команды запомним ее для последующего использования
                        undoExceptions.Add(undoException);
                    }
                }

                throw ex;
            }
        }

        public IEnumerable<Exception> UndoExceptions => undoExceptions;
        List<Exception> undoExceptions = new List<Exception>();

        List<Command<T>> commands = new List<Command<T>>();
    }
}
