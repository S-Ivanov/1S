﻿using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib.Payment
{
    public class PaymentInfo
    {
        #region Данные для обработки

        public DataModel.Session Session { get; set; }

        public DataModel.Receipt Receipt { get; set; }

        #endregion Данные для обработки

        #region Результаты оплаты по банковскому терминалу

        /// <summary>
        /// Индикатор отмены операции
        /// </summary>
        public bool PayTerminalCanceled { get; set; }

        ///// <summary>
        ///// Информация, которую нужно сохранять в базе после выполнения авторизации на терминале (метод PayTerminal.OnLineAuthorization())
        ///// </summary>
        //public AuthorizationInfo AuthorizationInfo { get; set; }

        /// <summary>
        /// Строки слипа разделенные парой символов #13 (возврат каретки) и #10 (перевод строки).
        /// </summary>
        public string SlipText { get; set; }

        #endregion Результаты оплаты по банковскому терминалу
    }
}
