﻿using Drg.CashDeskLib.Utils;
using System;

namespace Drg.CashDeskLib.Payment
{
    public class Command<T>
    {
        public Command(Func<T, bool> executeCondition, Action<T> executeAction, Action<T> undoAction = null)
        {
            Contract.Requires<ArgumentNullException>(executeCondition != null, nameof(executeCondition));
            Contract.Requires<ArgumentNullException>(executeAction != null, nameof(executeAction));

            this.executeCondition = executeCondition;
            this.executeAction = executeAction;
            this.undoAction = undoAction;
        }

        public void Execute(T data)
        {
            if (executeCondition(data))
                executeAction(data);
        }

        public void Undo(T data)
        {
            if (undoAction != null && executeCondition(data))
                undoAction(data);
        }

        Func<T, bool> executeCondition;
        Action<T> executeAction, undoAction;
    }
}
