﻿namespace Drg.CashDeskLib.MenuReader
{
    /// <summary>
    /// Базовый класс "Идентификатор + Наименование"
    /// </summary>
    public class IdNameObject
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }
    }
}
