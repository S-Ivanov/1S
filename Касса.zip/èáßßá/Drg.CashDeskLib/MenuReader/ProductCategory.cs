﻿namespace Drg.CashDeskLib.MenuReader
{
    /// <summary>
    /// Категория товара
    /// </summary>
    public class ProductCategory : IdNameObject
    {
        /// <summary>
        /// Ставка НДС
        /// </summary>
        public string VAT { get; set; }
    }
}
