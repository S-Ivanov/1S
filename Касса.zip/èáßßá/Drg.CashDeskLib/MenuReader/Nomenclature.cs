﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.MenuReader
{
    /// <summary>
    /// Номенклатура / группа
    /// </summary>
    public class Nomenclature : IdNameObject
    {
        /// <summary>
        /// Идентификатор родительской номенклатуры (группы)
        /// </summary>
        public string IdParent { get; set; }

        /// <summary>
        /// Дочерние номенклатуры
        /// </summary>
        public List<Nomenclature> Childs { get; set; } = new List<Nomenclature>();

        /// <summary>
        /// Код категории товара
        /// </summary>
        public int ProductCategoryId { get; set; }
    }
}
