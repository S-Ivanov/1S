﻿namespace Drg.CashDeskLib.MenuReader
{
    /// <summary>
    /// Единица измерения
    /// </summary>
    public class Unit : IdNameObject
    {
    }
}
