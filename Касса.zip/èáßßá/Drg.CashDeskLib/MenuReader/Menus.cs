﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.MenuReader
{
    public class Menus
    {
        /// <summary>
        /// Все меню, включенные в файл обмена 1С
        /// </summary>
        public List<Menu> AllMenus { get; } = new List<Menu>();

        /// <summary>
        /// Справочник номенклатуры
        /// </summary>
        public List<Nomenclature> Nomenclature { get; } = new List<Nomenclature>();

        /// <summary>
        /// Справочник категорий товаров
        /// </summary>
        public List<ProductCategory> ProductCategories { get; } = new List<ProductCategory>();

        /// <summary>
        /// Справочник товаров
        /// </summary>
        public List<Product> Products { get; } = new List<Product>();

        /// <summary>
        /// Справочник единиц измерения
        /// </summary>
        public List<Unit> Units { get; } = new List<Unit>();

        // TODO: МестаРеализации - проверять с идентификацией кассы ?

    }
}
