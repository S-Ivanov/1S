﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.MenuReader
{
    public class Menus
    {
        /// <summary>
        /// Все меню, включенные в файл обмена 1С
        /// </summary>
        public List<Menu> AllMenus 
        {
            get => allMenus;
        }
        List<Menu> allMenus = new List<Menu>();

        /// <summary>
        /// Справочник номенклатуры
        /// </summary>
        public List<Nomenclature> Nomenclature
        {
            get => nomenclatures;
        }
        List<Nomenclature> nomenclatures = new List<Nomenclature>();

        /// <summary>
        /// Справочник товаров
        /// </summary>
        public List<Product> Products
        {
            get => products; 
        }
        List<Product> products = new List<Product>();

        /// <summary>
        /// Справочник единиц измерения
        /// </summary>
        public List<Unit> Units
        {
            get => units;
        }
        List<Unit> units = new List<Unit>();

        // TODO: МестаРеализации - проверять с идентификацией кассы ?

    }
}
