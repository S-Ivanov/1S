﻿using System;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;

namespace Drg.CashDeskLib.Configuration
{
    /// <summary>
    /// Загрузка секций конфигурационного файла
    /// </summary>
    /// <see cref="http://www.codecutout.com/blog/xml-deserialization-from-app-config/"/>
    public abstract class XmlDeserializeConfigSectionHandler : IConfigurationSectionHandler
    {
        #region IConfigurationSectionHandler Members

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            Type t = this.GetType();
            XmlSerializer ser = new XmlSerializer(t);
            XmlNodeReader xNodeReader = new XmlNodeReader(section);
            return ser.Deserialize(xNodeReader);
        }

        #endregion
    }
}