﻿using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using System;
using System.Xml.Serialization;

namespace Drg.CashDeskLib.Configuration
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration : XmlDeserializeConfigSectionHandler
    {
        #region Общие настройки

        /// <summary>
        /// Строка соединения с локальной базой данных
        /// </summary>
        public string DBConnectionString { get; set; }

        /// <summary>
        /// Строка соединения с базой данных Парсек
        /// </summary>
        public string ParsecDBConnectionString { get; set; }

        /// <summary>
        /// Идентификатор кассы
        /// </summary>
        public Guid CashDeskID { get; set; }

        /// <summary>
        /// Наименование кассы
        /// </summary>
        public string CashDeskName { get; set; }

        /// <summary>
        /// Использовать эмуляторы оборудования
        /// </summary>
        public bool UseEmulators { get; set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethods { get; set; }

        public string PaymentMethodSet
        {
            get { return PaymentMethods.ToString(); }
            set { PaymentMethods = ParseEnum<PaymentMethod>(value); }
        }

        /// <summary>
        /// Подключаемое оборудование
        /// </summary>
        [XmlIgnore]
        public Device Devices { get; set; }

        public string DeviceSet
        {
            get { return Devices.ToString(); }
            set { Devices = ParseEnum<Device>(value); }
        }

        /// <summary>
        /// Номинал ЛПП
        /// </summary>
        public decimal LPPNominal { get; set; }

        /// <summary>
        /// Номинал талона 120
        /// </summary>
        public decimal Talon120Nominal { get; set; }

        /// <summary>
        /// Количество прошедших дней, не считая сегодняшнего, для загрузки старых меню
        /// </summary>
        public int OldMenuDays { get; set; }

        #endregion Общие настройки

        #region Настройки считывателя пропусков

        #region Настройки эмулятора считывателя пропусков

        /// <summary>
        /// Полное имя файла управления эмулятором считывателя пропусков
        /// </summary>
        public string CardReaderEmulatorFileName { get; set; }

        #endregion Настройки эмулятора считывателя пропусков

        #region Настройки боевого считывателя пропусков

        /// <summary>
        /// Номер COM-порта 
        /// </summary>
        public int CardReaderPort { get; set; }

        /// <summary>
        /// Скорость обмена, бод
        /// </summary>
        public int CardReaderBaudRate { get; set; }

        #endregion Настройки боевого считывателя пропусков

        #endregion Настройки считывателя пропусков

        #region Настройки ККМ

        #region Настройки эмулятора ККМ

        /// <summary>
        /// Полное имя файла управления эмулятором ККМ
        /// </summary>
        public string KkmEmulatorFileName { get; set; }

        #endregion Настройки эмулятора ККМ

        #endregion Настройки ККМ

        #region Настройки банковского терминала

        #region Настройки эмулятора банковского терминала

        /// <summary>
        /// Полное имя файла управления эмулятором банковского терминала
        /// </summary>
        public string PayTerminalEmulatorFileName { get; set; }

        #endregion Настройки эмулятора банковского терминала

        #endregion Настройки банковского терминала

        /// <summary>
        /// Вспомогательный метод для десериализации строкового представления Enum+Flags из XML
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="str"></param>
        /// <returns></returns>
        /// <remarks>
        /// см. https://stackoverflow.com/questions/41292279/how-to-represent-composite-flagged-enum-values-in-xml-config-file
        /// ответ 1
        /// </remarks>
        private T ParseEnum<T>(string str) where T : struct, IConvertible
        {
            var result = 0;
            foreach (var s in str.Split(','))
            {
                string name = s.Trim();
                if (name.StartsWith("~"))
                {
                    result &= ~(int)(Enum.Parse(typeof(T), name.Substring(1), true));
                }
                else
                {
                    result |= (int)(Enum.Parse(typeof(T), name, true));
                }
            }

            return (T)(object)result;
        }
    }
}
