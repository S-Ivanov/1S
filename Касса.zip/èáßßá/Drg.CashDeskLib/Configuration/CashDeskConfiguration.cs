﻿using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using System;
using System.Xml.Serialization;

namespace Drg.CashDeskLib.Configuration
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration : XmlDeserializeConfigSectionHandler
    {
        #region Общие настройки

        /// <summary>
        /// Все кассы новые
        /// </summary>
        public bool AllNew { get; set; }

        ///// <summary>
        ///// Строка соединения с локальной базой данных
        ///// </summary>
        //public string DBConnectionString { get; set; }

        /// <summary>
        /// Идентификатор записи справочнка обмена данными XML (из BackOffice)
        /// </summary>
        public string ExchangeBuhID { get; set; }

        /// <summary>
        /// Идентификатор столовой (из BackOffice - склад)
        /// </summary>
        public string EateryID { get; set; }

        /// <summary>
        /// Наименование столовой (из BackOffice - склад)
        /// </summary>
        public string EateryName { get; set; }

        /// <summary>
        /// Идентификатор кассы (из Сервер - кассовый узел)
        /// </summary>
        public string CashDeskID { get; set; }

        /// <summary>
        /// Наименование кассы (из Сервер - кассовый узел)
        /// </summary>
        public string CashDeskName { get; set; }

        /// <summary>
        /// Номер кассы для отчета ФО, например 082 = столовая №8 касса №2
        /// </summary>
        public string CashDeskNumber { get; set; }

        /// <summary>
        /// Количество копий чеков возврата
        /// </summary>
        public int ReturnCopies { get; set; }

        /// <summary>
        /// Тестовый режим работы кассы
        /// </summary>
        public bool IsTestMode { get; set; }

        /// <summary>
        /// Скрывать курсор мыши
        /// </summary>
        public bool HideMouseCursor { get; set; }

        /// <summary>
        /// Использовать эмуляторы оборудования
        /// </summary>
        public bool UseEmulators { get; set; }

        /// <summary>
        /// Интервал опроса оборудования, мсек
        /// </summary>
        public int EquipmentCheckPeriod { get; set; }

        /// <summary>
        /// Использовать сервис обмена данными с сервером 1С - меню
        /// </summary>
        public bool UseMenuService { get; set; }

        /// <summary>
        /// Интервал обмена данными с сервером 1С, сек - меню
        /// </summary>
        public int MenuServiceExchangePeriod { get; set; }

        /// <summary>
        /// Использовать сервис обмена данными с сервером 1С - обмен заказами
        /// </summary>
        public bool UseFrontService { get; set; }

        /// <summary>
        /// Интервал обмена данными с сервером 1С, сек - обмен заказами
        /// </summary>
        public int FrontServiceExchangePeriod { get; set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethods { get; set; }

        public string PaymentMethodSet
        {
            get { return PaymentMethods.ToString(); }
            set { PaymentMethods = ParseEnum<PaymentMethod>(value); }
        }

        /// <summary>
        /// Подключаемое оборудование
        /// </summary>
        [XmlIgnore]
        public Device Devices { get; set; }

        public string DeviceSet
        {
            get { return Devices.ToString(); }
            set { Devices = ParseEnum<Device>(value); }
        }

        /// <summary>
        /// Номинал ЛПП
        /// </summary>
        public decimal LPPNominal { get; set; }

        ///// <summary>
        ///// Лимит использования талонов ЛПП за одну покупку
        ///// </summary>
        //public int LPPLimit { get; set; }

        /// <summary>
        /// Номинал талона 120
        /// </summary>
        public decimal Talon120Nominal { get; set; }

        /// <summary>
        /// Размер дотации на питание 1 (57,47)
        /// </summary>
        public decimal Subsidy8 { get; set; }

        /// <summary>
        /// Размер дотации на питание 1 (86,21)
        /// </summary>
        public decimal Subsidy12 { get; set; }

        /// <summary>
        /// Размер дотации на питание 1 (172,41)
        /// </summary>
        public decimal Subsidy24 { get; set; }

        /// <summary>
        /// Полное имя файла xslt-шаблона для отчета ФО
        /// </summary>
        public string ReportFOXslt { get; set; }

        /// <summary>
        /// Маска файла для отчета ФО
        /// </summary>
        public string ReportFOFile { get; set; }

        /// <summary>
        /// Маска файла для отчета ФО - резервное сохранение в случае ошибки штатного сохранения
        /// </summary>
        public string ReportFOFileReserve { get; set; }

        /// <summary>
        /// Хост сервера
        /// </summary>
        public string ServerHost { get; set; }

        #endregion Общие настройки

        #region Настройки считывателя пропусков

        /// <summary>
        /// Использовать ли эмулятор
        /// </summary>
        public bool CardReaderEmulator { get; set; }

        #region Настройки эмулятора считывателя пропусков

        /// <summary>
        /// Полное имя файла управления эмулятором считывателя пропусков
        /// </summary>
        public string CardReaderEmulatorFileName { get; set; }

        #endregion Настройки эмулятора считывателя пропусков

        #region Настройки боевого считывателя пропусков

        /// <summary>
        /// Номер COM-порта 
        /// </summary>
        public string CardReaderPort { get; set; }

        /// <summary>
        /// Скорость обмена, бод
        /// </summary>
        public int CardReaderBaudRate { get; set; }

        #endregion Настройки боевого считывателя пропусков

        #endregion Настройки считывателя пропусков

        #region Настройки ККМ

        /// <summary>
        /// Использовать ли эмулятор
        /// </summary>
        public bool KKMEmulator { get; set; }

        #region Настройки эмулятора ККМ

        /// <summary>
        /// Полное имя файла управления эмулятором ККМ
        /// </summary>
        public string KKMEmulatorFileName { get; set; }

        #endregion Настройки эмулятора ККМ

        #region Настройки боевой ККМ

        /// <summary>
        /// Таймаут ошибки при выполнении операций, мсек
        /// </summary>
        public int KKMTimeOut { get; set; }

        /// <summary>
        /// Количество дней до истечения срока действия ФН для выдачи сообщения
        /// </summary>
        public int FnExpireDays { get; set; }

        /// <summary>
        /// Количество дней до даты блокировки ФН из-за неотправленных документов для выдачи сообщения
        /// </summary>
        public int FnLockDays { get; set; }

        /// <summary>
        /// Количество дней, в течение которых ФН может накапливать документы без передачи в ОФД
        /// </summary>
        public int FnLockMaxDays { get; set; }

        /// <summary>
        /// Дата в ФН, эквивалентная пустой дате
        /// </summary>
        public DateTime FnNullDate { get; set; }

        #endregion Настройки боевой ККМ

        #endregion Настройки ККМ

        #region Настройки банковского терминала

        /// <summary>
        /// Количество копий слипа для печати
        /// </summary>
        public int PayTerminalSlipCount { get; set; }

        /// <summary>
        /// Использовать ли эмулятор
        /// </summary>
        public bool PayTerminalEmulator { get; set; }

        #region Настройки эмулятора банковского терминала

        /// <summary>
        /// Полное имя файла управления эмулятором банковского терминала
        /// </summary>
        public string PayTerminalEmulatorFileName { get; set; }

        #endregion Настройки эмулятора банковского терминала

        #region Настройки боевого банковского терминала

        /// <summary>
        /// Каталог обмена с АС
        /// </summary>
        public string PayTerminalpathAC { get; set; }

        /// <summary>
        /// Каталог драйвера
        /// </summary>
        public string PayTerminalPathDB { get; set; }

        /// <summary>
        /// Протокол обмена с платежной системой (3 - Сбербанк, см. документацию драйвера Атол)
        /// </summary>
        public int PayTerminalProtocol { get; set; }

        #endregion Настройки боевого банковского терминала

        #endregion Настройки банковского терминала

        #region Настройки для переноса текста

        /// <summary>
        /// Путь к файлу правил переноса
        /// </summary>
        public string TextWrapperPatterns { get; set; }

        /// <summary>
        /// Путь к файлу исключений переноса
        /// </summary>
        public string TextWrapperExceptions { get; set; }

        #endregion Настройки для переноса текста

        /// <summary>
        /// Вспомогательный метод для десериализации строкового представления Enum+Flags из XML
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="str"></param>
        /// <returns></returns>
        /// <remarks>
        /// см. https://stackoverflow.com/questions/41292279/how-to-represent-composite-flagged-enum-values-in-xml-config-file
        /// ответ 1
        /// </remarks>
        private T ParseEnum<T>(string str) where T : struct, IConvertible
        {
            var result = 0;
            foreach (var s in str.Split(','))
            {
                string name = s.Trim();
                if (name.StartsWith("~"))
                {
                    result &= ~(int)(Enum.Parse(typeof(T), name.Substring(1), true));
                }
                else
                {
                    result |= (int)(Enum.Parse(typeof(T), name, true));
                }
            }

            return (T)(object)result;
        }
    }
}
