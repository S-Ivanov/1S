﻿using System;

namespace Drg.CashDeskLib
{
    public class DeviceAddingEventArgs : EventArgs
    {
        public DeviceAddingEventArgs(string message) : base()
        {
            Message = message;
        }

        public readonly string Message;
    }
}
