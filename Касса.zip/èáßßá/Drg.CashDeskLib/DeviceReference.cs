﻿using Drg.Equipment;

namespace Drg.CashDeskLib
{
    public class DeviceReference
    {
        public IDevice Device { get; set; }
        public DeviceError DeviceError { get; set; }
    }
}
