﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Drg.CashDeskLib.ReportFO;
using Drg.CashDeskLib.Utils;
using Drg.Equipment;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Drg.CashDeskLib
{
    public partial class CashDesk
    {
        public void MenuLoad()
        {
            if (!Configuration.UseMenuService)
                return;

            try
            {
                MenuLoad("ExtCashDeskExchange_MenuServiceSoap12", Configuration.ExchangeBuhID);

                remoteServiceError = false;
            }
            catch
            {
                remoteServiceError = true;
            }
        }

        public void MenuLoad(string pointName, string exchangeBuhID)
        {
            MenuLoad(pointName, localDB, exchangeBuhID, () => OnMenuLoaded?.Invoke(this, EventArgs.Empty));
        }

        public static void MenuLoad(string pointName, LocalDB localDB, string exchangeBuhID, Action onMenuLoadedAction = null)
        {
            DateTime? menuTimeStamp = localDB.GetMenuTimeStamp();
            MenuServiceReference.Parameter parameter = new MenuServiceReference.Parameter
            {
                IdExchange = exchangeBuhID,
                TimeStampClient = menuTimeStamp == null ? default(DateTime) : menuTimeStamp.Value,
                TimeStampClientSpecified = menuTimeStamp != null
            };

            MenuServiceReference.ResultData data = null;
            using (MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient client = new MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient(pointName))
            {
                client.Open();
                data = client.LoadMenu(parameter);
            }

            if (!string.IsNullOrEmpty(data.TextMenuFileXML))
            {
                // разбор меню
                Menus menus = MenuReader.MenuReader.Read(new StringReader(data.TextMenuFileXML));
                if (menus.AllMenus.Any())
                {
                    localDB.SaveMenus(menus);

                    // вызвать событие обновления меню
                    onMenuLoadedAction?.Invoke();
                }
            }

            if (data.TimeStampServerSpecified)
            {
                localDB.SaveMenuTimeStamp(data.TimeStampServer);
            }
        }

        public event EventHandler OnMenuLoaded;

        public static void SaveReportFO(
            string pointName, 
            ReportFOGenerator reportFOGenerator, 
            string cashDescNumber, 
            string exchangeBuhID,
            Func<IEnumerable<Guid>> loadSessionsForReportFOFunc,
            Action<IEnumerable<ReportFOServiceReference.FO>> saveSessionReportFOFlagAction)
        {
            //// список объектов Id смены + номер отчета ФО
            //var foSessionList = loadSessionsForReportFOFunc()
            //    .Select(session =>
            //        new
            //        {
            //            SessionId = session.Id,
            //            Number = ReportFO.ReportFOGenerator.GenerateReportNumber(session.Begin.Year, cashDescNumber, session.Number.ToString())
            //        })
            //    .ToList();

            //if (!foSessionList.Any())
            //    return;

            // список идентификаторов смен для сервиса
            var foList = loadSessionsForReportFOFunc()
                .Select(_ =>
                    new ReportFOServiceReference.FO
                    {
                        //IdFO = _.Id.ToString()
                        IdFO = _.ToString()
                    }
                )
                .ToArray();

            if (!foList.Any())
                return;

            using (ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient client = new ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient(pointName))
            {
                client.Open();

                // получить номера записанных отчетов ФО
                var savedFoList = client.CheckFOs(foList);

                //var foSavedSessionList = foSessionList.Where(_ => savedFoList.Any(fo => fo.IdFO == _.Number));
                //var foSavedSessionList = foList.Where(_ => savedFoList.Any(fo => fo.IdFO == _.IdFO));

                // зафиксировать в БД то, что для этих смен отчеты ФО уже есть на сервере
                //saveSessionReportFOFlagAction(foSavedSessionList.Select(_ => _.Id));
                saveSessionReportFOFlagAction(savedFoList);

                // получить объекты Id смены + номер отчета ФО, по которым нужно генерировать отчеты ФО:
                //      foSessionList - savedFoList
                //var unsavedFoList = foSessionList.Except(foSavedSessionList);
                var unsavedFoList = foList.Where(_ => !savedFoList.Any(fo => fo.IdFO == _.IdFO)); 

                if (unsavedFoList.Any())
                {
                    ReportFO.ReportFO reportFO = reportFOGenerator.CreateReportFO(unsavedFoList.Select(_ => new Guid(_.IdFO)).ToArray());
                    ReportFOServiceReference.Parameter parameter = new ReportFOServiceReference.Parameter()
                    {
                        IdExchange = exchangeBuhID,
                        //TextFOFileXML = XmlDocumentToString(reportFOGenerator.Generate(unsavedFoList.Select(_ => _.Id).ToArray()), new UTF8Encoding(false))
                        TextFOFileXML = XmlDocumentToString(reportFOGenerator.GenerateXml(reportFO), new UTF8Encoding(false))
                    };
                    client.SaveFOs(parameter);

                    // зафиксировать в БД передачу отчетов ФО 
                    //saveSessionReportFOFlagAction(unsavedFoList.Select(_ => _.Id));
                    saveSessionReportFOFlagAction(reportFO.Reports.Select(_ => new ReportFOServiceReference.FO { IdFO = _.SessionId, Number = _.Number }));
                }
            }
        }

        public void SaveReportFO(string pointName, LocalDB localDB, ReportFOGenerator reportFOGenerator, string cashDescNumber, string exchangeBuhID)
        {
            SaveReportFO(
                pointName,
                reportFOGenerator,
                cashDescNumber,
                exchangeBuhID,
                () => localDB.LoadSessionsForReportFO(),
                sessionIds => localDB.SaveSessionReportFOFlag(sessionIds));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        /// <see cref="https://stackoverflow.com/questions/203528/what-is-the-simplest-way-to-get-indented-xml-with-line-breaks-from-xmldocument"/>
        /// <remarks>ответ 10</remarks>
        public static string XmlDocumentToString(XmlDocument xmlDocument, Encoding encoding)
        {
            XmlWriterSettings settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = "\r\n",
                NewLineHandling = NewLineHandling.Replace,
                Encoding = encoding
            };
            using (var ms = new MemoryStream())
            using (var writer = XmlWriter.Create(ms, settings))
            {
                xmlDocument.Save(writer);
                var xmlString = Encoding.UTF8.GetString(ms.ToArray());
                return xmlString;
            }
        }

        public void PrintTotalMoneyReport(IEnumerable<MoneyReportItem> moneyReportItems, IEnumerable<MoneyReportItem> talonItems)
        {
            var kkm = GetKKM();

            if (kkm != null) // && !kkm.IsReady)
            {
                kkm.CheckErrors();
                uint lineLength = kkm.LineLength;

                // формировать отчет
                List<TextInfo> lines = new List<TextInfo>();
                // заголовок
                lines.Add(
                    new TextInfo()
                    {
                        Text = "Отчет по продажам",
                        Alignment = TextAlignment.Center,
                        DoubleHeight = true,
                    });
                lines.Add(
                    new TextInfo()
                    {
                        Text = "",
                    });
                lines.Add(
                    new TextInfo()
                    {
                        Text = Session.Number > 0 ? $"Смена № {Session.Number}, начата {Session.Begin:g}" : $"Смена б/н, начата {Session.Begin:g}",
                        //Alignment = TextAlignment.Left,
                    });
                lines.Add(
                    new TextInfo()
                    {
                        Text = $"Кассир: {Operator.FInitials}",
                        //Alignment = TextAlignment.Left,
                    });

                // деньги
                lines.Add(
                    new TextInfo()
                    {
                        Text = "Деньги",
                        Alignment = TextAlignment.Center,
                        DoubleHeight = true,
                    });

                uint[] columnWidths = GetTotalMoneyReportMoneyColumnWidths(lineLength);

                // заголовок табличной части
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Вид оплаты"),
                        TextInfo.CreateRight("Баланс"),
                        TextInfo.CreateRight("Приход"),
                        TextInfo.CreateRight("Возврат")));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // содержимое
                foreach (var moneyReportItem in moneyReportItems)
                {
                    lines.Add(
                        FormatTotalMoneyReportLine(
                            columnWidths,
                            TextInfo.CreateLeft(PaymentUtils.GetPaymentName(moneyReportItem.Payment, true)),
                            TextInfo.CreateRight(moneyReportItem.Balance.ToString("N2")),
                            TextInfo.CreateRight(moneyReportItem.Incoming.ToString("N2")),
                            TextInfo.CreateRight(moneyReportItem.Refund.ToString("N2"))));
                }

                // итог
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Итого:"),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Balance).Sum().ToString("N2")),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Incoming).Sum().ToString("N2")),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Refund).Sum().ToString("N2"))));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // заказы
                columnWidths = GetTotalMoneyReportOrderColumnWidths(lineLength);
                lines.Add(
                    new TextInfo()
                    {
                        Text = "Заказы",
                        Alignment = TextAlignment.Center,
                        DoubleHeight = true,
                    });

                // заголовок табличной части
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Вид оплаты"),
                        TextInfo.CreateRight("Всего"),
                        TextInfo.CreateRight("Приход"),
                        TextInfo.CreateRight("Возврат"),
                        TextInfo.CreateRight("Средняя")));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // содержимое
                foreach (var moneyReportItem in moneyReportItems)
                {
                    lines.Add(
                        FormatTotalMoneyReportLine(
                            columnWidths,
                            TextInfo.CreateLeft(PaymentUtils.GetPaymentName(moneyReportItem.Payment, true)),
                            TextInfo.CreateRight(moneyReportItem.BalanceCount.ToString()),
                            TextInfo.CreateRight(moneyReportItem.IncomingCount.ToString()),
                            TextInfo.CreateRight(moneyReportItem.RefundCount.ToString()),
                            TextInfo.CreateRight(moneyReportItem.Average.ToString("N2"))));
                }

                // итог
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                var totalAvegage = moneyReportItems.Select(_ => _.IncomingCount).Sum() == 0 ? 0 : moneyReportItems.Select(_ => _.Incoming).Sum() / moneyReportItems.Select(_ => _.IncomingCount).Sum();
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Итого:"),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.BalanceCount).Sum().ToString()),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.IncomingCount).Sum().ToString()),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.RefundCount).Sum().ToString()),
                        TextInfo.CreateRight(totalAvegage.ToString("N2"))));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // талоны
                columnWidths = GetTotalMoneyReportMoneyColumnWidths(lineLength);
                lines.Add(
                    new TextInfo()
                    {
                        Text = "Талоны",
                        Alignment = TextAlignment.Center,
                        DoubleHeight = true,
                    });

                // заголовок табличной части
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Вид оплаты"),
                        TextInfo.CreateRight("Баланс"),
                        TextInfo.CreateRight("Приход"),
                        TextInfo.CreateRight("Возврат")));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // содержимое
                foreach (var talonItem in talonItems)
                {
                    lines.Add(
                        FormatTotalMoneyReportLine(
                            columnWidths,
                            TextInfo.CreateLeft(PaymentUtils.GetPaymentName(talonItem.Payment, true)),
                            TextInfo.CreateRight(talonItem.Balance.ToString()),
                            TextInfo.CreateRight(talonItem.Incoming.ToString()),
                            TextInfo.CreateRight(talonItem.Refund.ToString())));
                }

                // итог
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Итого:"),
                        TextInfo.CreateRight(talonItems.Select(_ => _.Balance).Sum().ToString()),
                        TextInfo.CreateRight(talonItems.Select(_ => _.Incoming).Sum().ToString()),
                        TextInfo.CreateRight(talonItems.Select(_ => _.Refund).Sum().ToString())));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // печать отчета
                kkm.DoAction((int)PrintAction.PrintNotFiscal, new Tuple<IEnumerable<TextInfo>, bool>(lines, true));
            }
        }

        static uint[] GetTotalMoneyReportMoneyColumnWidths(uint lineLength)
        {
            if (lineLength < 40)
                throw new ArgumentOutOfRangeException();

            return new uint[] { lineLength - 3 * 10 - 3, 10, 10, 10};
        }

        static uint[] GetTotalMoneyReportOrderColumnWidths(uint lineLength)
        {
            if (lineLength < 40)
                throw new ArgumentOutOfRangeException();

            return new uint[] { lineLength - 6 - 7 - 2 * 8 - 4, 6, 7, 8, 8 };
        }

        static TextInfo FormatTotalMoneyReportLine(uint[] columnWidths, params TextInfo[] items)
        {
            if (items == null)
                throw new ArgumentNullException(nameof(items));
            if (columnWidths.Length != items.Length)
                throw new ArgumentException(nameof(items));

            string line = "";
            for (int i = 0; i < columnWidths.Length; i++)
            {
                line += GetColumnText((int)columnWidths[i], items[i]);
                if (i < columnWidths.Length - 1)
                    line += " ";
            }
            return TextInfo.CreateLeft(line);
        }

        static string GetColumnText(int columnWidth, TextInfo item)
        {
            string text = item.Text.Length <= columnWidth ? item.Text : item.Text.Substring(0, columnWidth);
            if (text.Length == columnWidth)
                return text;

            switch (item.Alignment)
            {
                case TextAlignment.Left: return text.PadRight(columnWidth);
                case TextAlignment.Right: return text.PadLeft(columnWidth);
                case TextAlignment.Center:
                default:
                    int spaceCount = columnWidth - text.Length;
                    return text.PadLeft(text.Length + spaceCount / 2).PadRight(columnWidth);
            }
        }

        public List<MoneyReportItem> LoadMoneyReportItems() => localDB.LoadMoneyReportItems(Session.Id);

        public List<ProductReportItem> LoadProductReportItemList()
        { 

            List<ProductReportItem> HierarchyToList(List<ProductReportItem> productReportItems)
            {
                List<ProductReportItem> result = new List<ProductReportItem>();
                FillResult(result, productReportItems);
                return result;
            }

            void FillResult(List<ProductReportItem> result, List<ProductReportItem> items)
            {
                bool IsLeaf(ProductReportItem item) => !item.Children.Any();

                result.AddRange(items.Where(_ => IsLeaf(_)));
                foreach (var item in items.Where(_ => !IsLeaf(_)))
                {
                    FillResult(result, item.Children);
                }
            }

            var productReportItemHierarchy = localDB.LoadProductReportItemList(Session.Id);
            var productReportItemList = HierarchyToList(productReportItemHierarchy);

            // ?
            return productReportItemList
                .Where(_ => !_.Children.Any())
                .OrderBy(_ => _.GroupName)
                .ThenBy(_ => _.Name)
                .ThenBy(_ => _.MeasureName)
                .ToList();
        }
    }
}
