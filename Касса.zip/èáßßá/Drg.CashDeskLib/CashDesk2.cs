﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Drg.CashDeskLib.ReportFO;
using Drg.CashDeskLib.Utils;
using Drg.Equipment;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Drg.CashDeskLib
{
    public partial class CashDesk
    {
        public void MenuLoad()
        {
            if (!Configuration.UseMenuService)
                return;

            try
            {
                MenuLoad("ExtCashDeskExchange_MenuServiceSoap12", localDB, Configuration.ExchangeBuhID);
            }
            catch
            {
                throw;
            }
        }

        public static void MenuLoad(string pointName, LocalDB localDB, string exchangeBuhID)
        {
            DateTime? menuTimeStamp = localDB.GetMenuTimeStamp();
            MenuServiceReference.Parameter parameter = new MenuServiceReference.Parameter
            {
                IdExchange = exchangeBuhID,
                TimeStampClient = menuTimeStamp == null ? default(DateTime) : menuTimeStamp.Value,
                TimeStampClientSpecified = menuTimeStamp != null
            };

            MenuServiceReference.ResultData data = null;
            using (MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient client = new MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient(pointName))
            {
                client.Open();
                data = client.LoadMenu(parameter);
            }

            if (!string.IsNullOrEmpty(data.TextMenuFileXML))
            {
                // разбор меню
                Menus menus = MenuReader.MenuReader.Read(new StringReader(data.TextMenuFileXML));
                if (menus.AllMenus.Any())
                {
                    localDB.SaveMenus(menus);
                }
            }

            if (data.TimeStampServerSpecified)
            {
                localDB.SaveMenuTimeStamp(data.TimeStampServer);
            }
        }

        public static void SaveReportFO(
            string pointName, 
            ReportFOGenerator reportFOGenerator, 
            string cashDescNumber, 
            string exchangeBuhID,
            Func<IEnumerable<Session>> loadSessionsForReportFOFunc,
            Action<IEnumerable<Guid>> saveSessionReportFOFlagAction)
        {
            // список объектов Id смены + номер отчета ФО
            var foSessionList = loadSessionsForReportFOFunc()
                .Select(session =>
                    new
                    {
                        session.Id,
                        Number = ReportFO.ReportFOGenerator.GenerateReportNumber(session.Begin.Year, cashDescNumber, session.Number.ToString())
                    })
                .ToList();

            if (!foSessionList.Any())
                return;

            // список номеров отчетов ФО для сервиса
            var foList = foSessionList
                .Select(_ =>
                    new ReportFOServiceReference.FO
                    {
                        IdFO = _.Number
                    }
                )
                .ToArray();

            using (ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient client = new ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient(pointName))
            {
                client.Open();

                // получить номера записанных отчетов ФО
                var savedFoList = client.CheckFOs(foList);

                var foSavedSessionList = foSessionList.Where(_ => savedFoList.Any(fo => fo.IdFO == _.Number));

                // зафиксировать в БД то, что для этих смен отчеты ФО уже есть на сервере
                saveSessionReportFOFlagAction(foSavedSessionList.Select(_ => _.Id));

                // получить объекты Id смены + номер отчета ФО, по которым нужно генерировать отчеты ФО:
                //      foSessionList - savedFoList
                var unsavedFoList = foSessionList.Except(foSavedSessionList);

                if (unsavedFoList.Any())
                {
                    ReportFOServiceReference.Parameter parameter = new ReportFOServiceReference.Parameter()
                    {
                        IdExchange = exchangeBuhID,
                        TextFOFileXML = XmlDocumentToString(reportFOGenerator.Generate(unsavedFoList.Select(_ => _.Id).ToArray()), new UTF8Encoding(false))
                    };
                    client.SaveFOs(parameter);

                    // зафиксировать в БД передачу отчетов ФО 
                    saveSessionReportFOFlagAction(unsavedFoList.Select(_ => _.Id));
                }
            }
        }

        public static void SaveReportFO(string pointName, LocalDB localDB, ReportFOGenerator reportFOGenerator, string cashDescNumber, string exchangeBuhID)
        {
            SaveReportFO(
                pointName,
                reportFOGenerator,
                cashDescNumber,
                exchangeBuhID,
                () => localDB.LoadSessionsForReportFO(),
                sessionIds => localDB.SaveSessionReportFOFlag(sessionIds));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        /// <see cref="https://stackoverflow.com/questions/203528/what-is-the-simplest-way-to-get-indented-xml-with-line-breaks-from-xmldocument"/>
        /// <remarks>ответ 10</remarks>
        public static string XmlDocumentToString(XmlDocument xmlDocument, Encoding encoding)
        {
            XmlWriterSettings settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = "\r\n",
                NewLineHandling = NewLineHandling.Replace,
                Encoding = encoding
            };
            using (var ms = new MemoryStream())
            using (var writer = XmlWriter.Create(ms, settings))
            {
                xmlDocument.Save(writer);
                var xmlString = Encoding.UTF8.GetString(ms.ToArray());
                return xmlString;
            }
        }

        public void PrintTotalMoneyReport(IEnumerable<MoneyReportItem> moneyReportItems)
        {
            var kkm = GetKKM();

            if (kkm != null) // && !kkm.IsReady)
            {
                kkm.CheckErrors();
                uint lineLength = kkm.LineLength;

                // формировать отчет
                List<TextInfo> lines = new List<TextInfo>();
                // заголовок
                lines.Add(
                    new TextInfo()
                    {
                        Text = "Отчет по продажам (деньги)",
                        Alignment = TextAlignment.Center,
                        DoubleHeight = true,
                    });
                lines.Add(
                    new TextInfo()
                    {
                        Text = $"Смена № {Session.Number}, начата {Session.Begin:g}",
                        //Alignment = TextAlignment.Left,
                    });
                lines.Add(
                    new TextInfo()
                    {
                        Text = $"Кассир: {Operator.FInitials}",
                        //Alignment = TextAlignment.Left,
                    });

                uint[] columnWidths = GetTotalMoneyReportColumnWidths(lineLength);

                // заголовок табличной части
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Вид оплаты"),
                        TextInfo.CreateRight("Приход"),
                        TextInfo.CreateRight("Возврат"),
                        TextInfo.CreateRight("Баланс")));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // содержимое
                foreach (var moneyReportItem in moneyReportItems)
                {
                    lines.Add(
                        FormatTotalMoneyReportLine(
                            columnWidths,
                            TextInfo.CreateLeft(PaymentUtils.GetPaymentName(moneyReportItem.Payment, true)),
                            TextInfo.CreateRight(moneyReportItem.Incoming.ToString("N2")),
                            TextInfo.CreateRight(moneyReportItem.Refund.ToString("N2")),
                            TextInfo.CreateRight(moneyReportItem.Balance.ToString("N2"))));
                }

                // итог
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));
                lines.Add(
                    FormatTotalMoneyReportLine(
                        columnWidths,
                        TextInfo.CreateLeft("Итого:"),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Incoming).Sum().ToString("N2")),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Refund).Sum().ToString("N2")),
                        TextInfo.CreateRight(moneyReportItems.Select(_ => _.Balance).Sum().ToString("N2"))));
                lines.Add(TextInfo.CreateLeft(new string('-', (int)lineLength)));

                // печать отчета
                kkm.DoAction((int)PrintAction.PrintNotFiscal, lines);
            }
        }

        static uint[] GetTotalMoneyReportColumnWidths(uint lineLength)
        {
            if (lineLength < 40)
                throw new ArgumentOutOfRangeException();

            return new uint[] { lineLength - 3 * 10 - 3, 10, 10, 10};
        }

        static TextInfo FormatTotalMoneyReportLine(uint[] columnWidths, params TextInfo[] items)
        {
            if (items == null)
                throw new ArgumentNullException(nameof(items));
            if (columnWidths.Length != items.Length)
                throw new ArgumentException(nameof(items));

            string line = "";
            for (int i = 0; i < columnWidths.Length; i++)
            {
                line += GetColumnText((int)columnWidths[i], items[i]);
                if (i < columnWidths.Length - 1)
                    line += " ";
            }
            return TextInfo.CreateLeft(line);
        }

        static string GetColumnText(int columnWidth, TextInfo item)
        {
            string text = item.Text.Length <= columnWidth ? item.Text : item.Text.Substring(0, columnWidth);
            if (text.Length == columnWidth)
                return text;

            switch (item.Alignment)
            {
                case TextAlignment.Left: return text.PadRight(columnWidth);
                case TextAlignment.Right: return text.PadLeft(columnWidth);
                case TextAlignment.Center:
                default:
                    int spaceCount = columnWidth - text.Length;
                    return text.PadLeft(text.Length + spaceCount / 2).PadRight(columnWidth);
            }
        }

        public List<MoneyReportItem> LoadMoneyReportItems() => localDB.LoadMoneyReportItems(Session.Id);

        public List<ProductReportItem> LoadProductReportItemList()
        { 

            List<ProductReportItem> HierarchyToList(List<ProductReportItem> productReportItems)
            {
                List<ProductReportItem> result = new List<ProductReportItem>();
                FillResult(result, productReportItems);
                return result;
            }

            void FillResult(List<ProductReportItem> result, List<ProductReportItem> items)
            {
                bool IsLeaf(ProductReportItem item) => !item.Children.Any();

                result.AddRange(items.Where(_ => IsLeaf(_)));
                foreach (var item in items.Where(_ => !IsLeaf(_)))
                {
                    FillResult(result, item.Children);
                }
            }

            var productReportItemHierarchy = localDB.LoadProductReportItemList(Session.Id);
            var productReportItemList = HierarchyToList(productReportItemHierarchy);

            // ?
            return productReportItemList
                .Where(_ => !_.Children.Any())
                .OrderBy(_ => _.GroupName)
                .ThenBy(_ => _.Name)
                .ThenBy(_ => _.MeasureName)
                .ToList();
        }
    }
}
