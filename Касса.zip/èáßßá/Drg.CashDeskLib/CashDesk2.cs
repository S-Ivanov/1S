﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Drg.CashDeskLib.ReportFO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Drg.CashDeskLib
{
    public partial class CashDesk
    {
        public void MenuLoad()
        {
            if (!Configuration.UseMenuService)
                return;

            try
            {
                MenuLoad("ExtCashDeskExchange_MenuServiceSoap12", localDB, Configuration.ExchangeBuhID);
            }
            catch
            {
                throw;
            }
        }

        public static void MenuLoad(string pointName, LocalDB localDB, string exchangeBuhID)
        {
            DateTime? menuTimeStamp = localDB.GetMenuTimeStamp();
            MenuServiceReference.Parameter parameter = new MenuServiceReference.Parameter
            {
                IdExchange = exchangeBuhID,
                TimeStampClient = menuTimeStamp == null ? default(DateTime) : menuTimeStamp.Value,
                TimeStampClientSpecified = menuTimeStamp != null
            };

            MenuServiceReference.ResultData data = null;
            using (MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient client = new MenuServiceReference.ExtCashDeskExchange_MenuServicePortTypeClient(pointName))
            {
                client.Open();
                data = client.LoadMenu(parameter);
            }

            if (!string.IsNullOrEmpty(data.TextMenuFileXML))
            {
                // разбор меню
                Menus menus = MenuReader.MenuReader.Read(new StringReader(data.TextMenuFileXML));
                if (menus.AllMenus.Any())
                {
                    localDB.SaveMenus(menus);
                }
            }

            if (data.TimeStampServerSpecified)
            {
                localDB.SaveMenuTimeStamp(data.TimeStampServer);
            }
        }

        public static void SaveReportFO(
            string pointName, 
            ReportFOGenerator reportFOGenerator, 
            string cashDescNumber, 
            string exchangeBuhID,
            Func<IEnumerable<Session>> loadSessionsForReportFOFunc,
            Action<IEnumerable<Guid>> saveSessionReportFOFlagAction)
        {
            // список объектов Id смены + номер отчета ФО
            var foSessionList = loadSessionsForReportFOFunc()
                .Select(session =>
                    new
                    {
                        session.Id,
                        Number = ReportFO.ReportFOGenerator.GenerateReportNumber(session.Begin.Year, cashDescNumber, session.Number.ToString())
                    })
                .ToList();

            if (!foSessionList.Any())
                return;

            // список номеров отчетов ФО для сервиса
            var foList = foSessionList
                .Select(_ =>
                    new ReportFOServiceReference.FO
                    {
                        IdFO = _.Number
                    }
                )
                .ToArray();

            using (ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient client = new ReportFOServiceReference.ExtCashDeskExchange_ReportFOServicePortTypeClient(pointName))
            {
                client.Open();

                // получить номера записанных отчетов ФО
                var savedFoList = client.CheckFOs(foList);

                var foSavedSessionList = foSessionList.Where(_ => savedFoList.Any(fo => fo.IdFO == _.Number));

                // зафиксировать в БД то, что для этих смен отчеты ФО уже есть на сервере
                saveSessionReportFOFlagAction(foSavedSessionList.Select(_ => _.Id));

                // получить объекты Id смены + номер отчета ФО, по которым нужно генерировать отчеты ФО:
                //      foSessionList - savedFoList
                var unsavedFoList = foSessionList.Except(foSavedSessionList);

                if (unsavedFoList.Any())
                {
                    ReportFOServiceReference.Parameter parameter = new ReportFOServiceReference.Parameter()
                    {
                        IdExchange = exchangeBuhID,
                        TextFOFileXML = XmlDocumentToString(reportFOGenerator.Generate(unsavedFoList.Select(_ => _.Id).ToArray()), new UTF8Encoding(false))
                    };
                    client.SaveFOs(parameter);

                    // зафиксировать в БД передачу отчетов ФО 
                    saveSessionReportFOFlagAction(unsavedFoList.Select(_ => _.Id));
                }
            }
        }

        public static void SaveReportFO(string pointName, LocalDB localDB, ReportFOGenerator reportFOGenerator, string cashDescNumber, string exchangeBuhID)
        {
            SaveReportFO(
                pointName,
                reportFOGenerator,
                cashDescNumber,
                exchangeBuhID,
                () => localDB.LoadSessionsForReportFO(),
                sessionIds => localDB.SaveSessionReportFOFlag(sessionIds));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        /// <see cref="https://stackoverflow.com/questions/203528/what-is-the-simplest-way-to-get-indented-xml-with-line-breaks-from-xmldocument"/>
        /// <remarks>ответ 10</remarks>
        public static string XmlDocumentToString(XmlDocument xmlDocument, Encoding encoding)
        {
            XmlWriterSettings settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = "\r\n",
                NewLineHandling = NewLineHandling.Replace,
                Encoding = encoding
            };
            using (var ms = new MemoryStream())
            using (var writer = XmlWriter.Create(ms, settings))
            {
                xmlDocument.Save(writer);
                var xmlString = Encoding.UTF8.GetString(ms.ToArray());
                return xmlString;
            }
        }

        public List<MoneyReportItem> LoadMoneyReportItems() => localDB.LoadMoneyReportItems(Session.Id);

        public List<ProductReportItem> LoadProductReportItems() => localDB.LoadProductReportItems(Session.Id);
    }
}
