﻿namespace Drg.CashDeskLib
{
    /// <summary>
    /// Утилиты
    /// </summary>
    public static class Utils
    {
        public static string FIO2FInitials(string fio)
        {
            if (string.IsNullOrWhiteSpace(fio))
                return string.Empty;

            string[] items = fio.Split(' ');
            if (items.Length == 1)
                return items[0];
            else if (items.Length == 2)
                return $"{items[0]} {items[1][0]}.";
            else
                return $"{items[0]} {items[1][0]}.{items[2][0]}.";
        }
    }
}
