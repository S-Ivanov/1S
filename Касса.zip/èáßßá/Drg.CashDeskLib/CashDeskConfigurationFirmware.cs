﻿namespace Drg.CashDeskLib
{
    public class CashDeskConfigurationFirmware : CashDeskConfiguration
    {
        #region Настройки считывателя пропусков

        /// <summary>
        /// Номер COM-порта 
        /// </summary>
        public int CardReaderPort { get; set; }

        /// <summary>
        /// Скорость обмена, бод
        /// </summary>
        public int CardReaderBaudRate { get; set; }

        #endregion Настройки считывателя пропусков
    }
}
