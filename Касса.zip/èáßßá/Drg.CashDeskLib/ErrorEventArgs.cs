﻿using System;

namespace Drg.CashDeskLib
{
    public class ErrorEventArgs : EventArgs
    {
        public ErrorEventArgs(int errorCode, string description, string message) : base()
        {
            ErrorCode = errorCode;
            Description = description;
            Message = message;
        }

        public readonly int ErrorCode;
        public readonly string Description;
        public readonly string Message;
    }
}
