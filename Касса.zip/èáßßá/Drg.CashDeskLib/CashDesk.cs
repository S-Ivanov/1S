﻿using Drg.CashDeskLib.Configuration;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Equipment;
using Drg.CashDeskLib.ReportFO;
using Drg.CashDeskLib.Session;
using Drg.CashDeskLib.Utils;
using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Timers;
using System.Xml;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public partial class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit();

            CreateOrderPayment();

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();

            localDB = new DB.LocalDB(configuration.DBConnectionString);

            reportFOGenerator = new ReportFOGenerator(
                localDB,
                Configuration.ReportFOXslt,
                Configuration.ReportFOFile,
                Configuration.ReportFOFileReserve,
                Configuration.EateryID,
                Configuration.EateryName,
                Configuration.CashDeskNumber);

            FrontDataExchange();

            LoadClients();
        }

        public bool IsKKMReadyForNonFiscalPrint()
        {
            var kkm = GetKKM();
            return kkm != null && kkm.LastError == DeviceError.NoError;
        }

        public IKKM GetKKM() => (Devices.TryGetValue(Device.KKM, out IDevice device)) ? device as IKKM : null;

        IDevice GetDevice(Device device) => (Devices.TryGetValue(Device.KKM, out IDevice d)) ? d : null;

        private void CreateOrderPayment()
        {
            orderPayment = new OrderPayment(GetDevice(Device.KKM) as IKKM, GetDevice(Device.PayTerminal) as IPayTerminal);
        }

        public void OpenSession(Operator @operator)
        {
            Operator = @operator;

            // загрузить информацию о последней смене из БД
            Session = localDB.LoadLastSession();

            // загрузить информацию о смене из ККМ
            var kkm = GetKKM();

            //// обработка ошибок ККМ пользователем
            //if (kkm != null && kkm.LastError != DeviceError.NoError)
            //{
            //    if (kkm.LastError.IsUserError)
            //    {
            //        // вывести сообщение пользователю -> 
            //        DeviceErrorEvent?.Invoke(kkm, new DataModelEventArgs<DeviceError> { Data = kkm.LastError });
            //    }
            //}

            SessionManagerParameters parameters = new SessionManagerParameters
            {
                HasKKM = kkm != null,
                KkmHasError = kkm?.LastError != DeviceError.NoError,
                KkmSessionState = kkm?.SessionState ?? SessionState.Closed,
                FnChanged = Session.IdFN != kkm?.FnNumber,
                DbSessionState = Session.SessionState,
                OperatorChanged = @operator.Id != Session.OperatorId
            };
            sessionManager.OpenSession(
                parameters,
                closeKKMSessionAction: () => kkm.CloseSession(),
                closeDbSessionAction: () => localDB.CloseSession(Session.Id, DateTime.Now),
                openKKMSessionAction: () => kkm.OpenSession($"{ @operator.FIO} - { @operator.Post}", @operator.INN),
                openDbSessionAction: () => Session = localDB.OpenSession(DateTime.Now, @operator.Id, kkm?.FnNumber, kkm?.SessionNumber ?? 0)
                );
        }

        //public event EventHandler<DataModelEventArgs<DeviceError>> DeviceErrorEvent;

        SessionManager sessionManager = new SessionManager();

        public event EventHandler<CashPaymentEventArgs> CashPaymentEvent
        {
            add { orderPayment.CashPaymentEvent += value; }
            remove { orderPayment.CashPaymentEvent -= value; }
        }

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        private void CheckPaymentMethod()
        {
            PaymentMethod = Configuration.PaymentMethods;

            if ((PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
            {
                var cardReader = devices[Device.CardReader];
                DeviceError cardReaderError = devices[Device.CardReader].LastError;
                PaymentMethod &=
                    cardReader != null && (cardReaderError == null || cardReaderError.ErrorCode == DeviceError.NO_ERROR) ?
                    PaymentMethod.All :
                    ~PaymentMethod.Pass;
            }

            if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard || (PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
            {
                var kkm = GetKKM();
                if (kkm != null)
                {
                    DeviceError kkmError = devices[Device.KKM].LastError;
                    var kkmFiscal = (kkmError == null || kkmError.ErrorCode == DeviceError.NO_ERROR) && kkm.Fiscal;
                    if (kkmFiscal)
                    {
                        PaymentMethod &= PaymentMethod.All;
                        if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                        {
                            var payTerminal = devices[Device.PayTerminal];
                            DeviceError payTerminalError = devices[Device.PayTerminal].LastError;
                            PaymentMethod &=
                                payTerminal != null && (payTerminalError == null || payTerminalError.ErrorCode == DeviceError.NO_ERROR) ?
                                PaymentMethod.All :
                                ~PaymentMethod.BankCard;
                        }
                    }
                    else
                    {
                        PaymentMethod &= ~PaymentMethod.Cash;
                        PaymentMethod &= ~PaymentMethod.BankCard;
                    }
                }
                else
                {
                    PaymentMethod &= ~PaymentMethod.Cash;
                    PaymentMethod &= ~PaymentMethod.BankCard;
                }
            }
        }

        public void AddMenuItemExt(Guid menuId, MenuItemExt menuItem) => localDB.AddMenuItem(menuId, menuItem);

        /// <summary>
        /// Загрузить возвраты
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public List<Order> LoadReturns(Guid orderId) => localDB.LoadReturns(orderId);

        public Tuple<string, DataModel.Order> LoadOrder(Guid orderId) => localDB.LoadOrder(orderId);

        //public void NewSession(DateTime dateTimeClose)
        //{
        //    CloseSession(dateTimeClose);
        //    Session = OpenSession();
        //}

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit()
        {
            // считыватель пропусков 
            if ((Configuration.Devices & Device.CardReader) == Device.CardReader)
                AddDevice(Device.CardReader, () => CardReader.Create(Configuration));

            // ККМ 
            if ((Configuration.Devices & Device.KKM) == Device.KKM)
                AddDevice(Device.KKM, () => Equipment.KKM.Create(Configuration));

            // банковский терминал
            if ((Configuration.Devices & Device.PayTerminal) == Device.PayTerminal)
                AddDevice(Device.PayTerminal, () => PayTerminal.Create(Configuration));
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(Device deviceType, Func<IDevice> createDevice)
        {
            var device = createDevice();
            //device.CheckErrors();
            devices.Add(deviceType, device);
        }

        #endregion Частные методы

        #region События

        #endregion События

        #region Частные поля и свойства

        DB.LocalDB localDB;

        OrderPayment orderPayment;

        #endregion Частные поля и свойства

        #region Публичные методы

        /// <summary>
        /// Смена
        /// </summary>
        public DataModel.Session Session { get; private set; }

        public void DeleteMenuItemExt(MenuItemExt menuItem) => localDB.DeleteMenuItemExt(menuItem);

        /// <summary>
        /// Загрузить кассиров
        /// </summary>
        /// <returns></returns>
        public List<Operator> GetOperators() => localDB.GetOperators();

        /// <summary>
        /// Прочитать номер нового заказа
        /// </summary>
        /// <returns></returns>
        public int GetNewOrderNumber() => localDB.GetNewOrderNumber();

        /// <summary>
        /// Загрузить последние меню, дата которых меньше или равна указанной
        /// </summary>
        /// <param name="date"></param>
        /// <param name="menuCount">количество меню для загрузки</param>
        /// <returns></returns>
        public List<Menu> LoadMenus(DateTime date, int menuCount) => localDB.LoadMenus(date, menuCount);

        public void ChangeMenuItemCountExt(MenuItemExt menuItem, decimal newCount) => localDB.ChangeMenuItemCountExt(menuItem, newCount);

        /// <summary>
        /// Загрузить последние меню, дата которых меньше или равна указанной
        /// </summary>
        /// <param name="date"></param>
        /// <param name="menuCount">количество меню для загрузки</param>
        /// <returns></returns>
        public List<MenuExt> LoadMenusExt(DateTime date, int menuCount) => localDB.LoadMenusExt(date, menuCount);

        ///// <summary>
        ///// Загрузить клиента
        ///// </summary>
        ///// <param name="cardCode">код пропуска</param>
        ///// <returns></returns>
        //public DataModel.Client GetClient(uint cardCode)
        //{
        //    Client client = localDB.GetClient(cardCode);
        //    //LoadPhotoFromParsec(client);
        //    return client;
        //}

        public void FrontDataExchange()
        {
            if (!Configuration.UseFrontService)
                return;

            try
            {
                FrontDataExchange("FrontServiceSoap12", localDB, Configuration.CashDeskID, Configuration.LPPNominal, Configuration.IsTestMode);
            }
            catch
            {
                throw;
            }


        }

        public static void FrontDataExchange(string pointName, LocalDB localDB, string cashDeskID, decimal lppNominal, bool isTestMode)
        {
            DateTime? serverTimeStamp = localDB.GetServerTimeStamp();
            DateTime? clientTimeStamp = localDB.GetCashDeskTimeStamp();
            DateTime newClientTimeStamp = DateTime.UtcNow;

            FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
            {
                IsTest = isTestMode,
                IdCashDesk = cashDeskID,
                OrderDocument = localDB.LoadOrderDocument(clientTimeStamp, newClientTimeStamp, isTestMode),
                TransactionDocument = localDB.LoadTransactionDocument(clientTimeStamp, newClientTimeStamp, isTestMode)
            };

            // дата/время последнего сеанса обмена данными - чтение
            if (serverTimeStamp != null)
            {
                parameter.ClientTimeStamp = serverTimeStamp.Value;
                parameter.ClientTimeStampSpecified = true;
            }

            using (FrontServiceReference.FrontServicePortTypeClient frontServiceClient = new FrontServiceReference.FrontServicePortTypeClient(pointName))
            {
                FrontServiceReference.ResultData resultData = frontServiceClient.ExchangeData(parameter);

                // зафиксировать успешность передачи заказов
                if (resultData.IsOrdersSaved)
                {
                    localDB.SaveClientTimeStamp(newClientTimeStamp);
                }

                // записать полученные данные
                localDB.SaveExchangeData(resultData, cashDeskID, lppNominal, isTestMode);
            }
        }

        public void ReturnWholeOrder(Guid sourceOrderId, List<OrderPaymentItem> orderPaymentItems)
        {
            //OrderReturn orderReturn = new OrderReturn(GetDevice(Device.KKM) as IKKM, GetDevice(Device.PayTerminal) as IPayTerminal);
            //try
            //{
            //    orderReturn.ReturnWholeOrder(orderId, orderPaymentItems);
            //}
            //catch
            //{
            //}

            // TODO: выплнить возврат оплаты на оборудовании <- orderPaymentItems

            // записать информацию в БД
            localDB.ReturnWholeOrder(sourceOrderId);
        }

        public List<OrderPaymentItem> LoadOrderPaymentItems(Guid orderId) => localDB.LoadOrderPaymentItems(orderId);

        /// <summary>
        /// Добавить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool AddMenuItem(MenuItem menuItem) => localDB.AddMenuItem(menuItem);

        /// <summary>
        /// Полный список клиентов
        /// </summary>
        /// <remarks>
        /// Словарь:
        /// - табельный номер
        /// - работник
        /// </remarks>
        public ConcurrentDictionary<string, Client> Clients { get; } = new ConcurrentDictionary<string, Client>();

        /// <summary>
        /// Загрузить список локальных заказов
        /// </summary>
        public List<OrderSource> LoadLocalOrders()
        {
            List<OrderSource> orders = localDB.LoadOrderSources(Configuration.IsTestMode);

            if (orders.Any())
            {
                // загрузить клиентов
                lock (Clients)
                {
                    foreach (var order in orders.Where(_ => _.Client != null))
                    {
                        if (Clients.TryGetValue(order.Client.TabNum, out Client client))
                        {
                            order.Client = client;
                        }
                    }
                }
            }

            return orders;
        }

        public Client GetClient(uint cardCode)
        {
            lock (Clients)
            {
                return Clients.Select(kvp => kvp.Value).FirstOrDefault(_ => _.CardCode == cardCode);
            }
        }

        /// <summary>
        /// Загрузить исходные заказы для возвратов
        /// </summary>
        /// <returns></returns>
        //public void LoadOrderSources()
        //{
        //    LocalOrders.Clear();
        //    // TODO: загружать заказы только в пределах суток и с учетом только своих заказов, а также тестового режима работы
        //    LocalOrders.AddRange(localDB.LoadOrderSources(Configuration.IsTestMode));
        //}

        /// <summary>
        /// Прочитать полный список клиентов
        /// </summary>
        /// <returns></returns>
        public void LoadClients()
        {
            lock (Clients)
            {
                Clients.Clear();

                foreach (Client client in localDB.LoadClients())
                {
                    Clients.TryAdd(client.TabNum, client);
                }
            }
        }

        /// <summary>
        /// Проверить оборудование
        /// </summary>
        public void CheckEquipment()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.CheckErrors();
            }

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();
        }

        /// <summary>
        /// Удалить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool DeleteMenuItem(MenuItem menuItem) => localDB.DeleteMenuItem(menuItem);

        #endregion Публичные методы

        #region Публичные свойства

        /// <summary>
        /// Кассир
        /// </summary>
        public Operator Operator { get; set; }

        /// <summary>
        /// Закрыть смену
        /// </summary>
        public void CloseSession()
        {
            // загрузить информацию о смене из ККМ
            var kkm = GetKKM();

            SessionManagerParametersBase parameters = new SessionManagerParametersBase
            {
                HasKKM = kkm != null,
                KkmHasError = kkm?.LastError != DeviceError.NoError,
                KkmSessionState = kkm?.SessionState ?? SessionState.Closed,
                DbSessionState = Session.SessionState
            };
            sessionManager.CloseSession(
                parameters,
                closeKKMSessionAction: () => kkm.CloseSession(),
                closeDbSessionAction: () => localDB.CloseSession(Session.Id, DateTime.Now)
                );

            // сформировать отчет ФО
            reportFOGenerator.Generate(Session.Id);
        }

        ReportFO.ReportFOGenerator reportFOGenerator;

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        /// <summary>
        /// Изменить количество в элементе меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <param name="newCount"></param>
        /// <returns></returns>
        public bool ChangeMenuItemCount(MenuItem menuItem, decimal newCount) => localDB.ChangeMenuItemCount(menuItem, newCount);

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

        public Dictionary<Device, IDevice> Devices => devices;
        Dictionary<Device, IDevice> devices = new Dictionary<Device, IDevice>();

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.Dispose();
            }
            devices.Clear();
        }

        #endregion Реализация интерфейса IDisposable

        ///// <summary>
        ///// Записать заказ и оплату
        ///// </summary>
        ///// <param name="client">клиент</param>
        ///// <param name="order">заказ</param>
        ///// <param name="payments">оплата</param>
        //public void SaveOrderAndPayment(Client client, Order order, Dictionary<Payment, decimal> payments) => localDB.SaveOrderAndPayment(client, order, payments);

        /// <summary>
        /// Выполнить оплату
        /// </summary>
        /// <param name="client">клиент</param>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата: вид оплаты + сумма</param>
        /// <returns>виды оплат, которые не удалось выполнить</returns>
        public Payment Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out List<Payment> noPayments)
        {
            // TODO: проверить корректность входных параметров

            Payment cancelPayment = orderPayment.Pay(client, order, payments, out noPayments, out IDictionary <Payment, List<OrderItem>> orderItems);
            if (cancelPayment == Payment.None && noPayments.Count == 0)
            {
                localDB.SaveOrderAndPayment(Session, client, order, orderItems, Configuration.IsTestMode);
                // корректировать информацию о работниках и заказах после оплаты заказа
                CorrectClients(client, order, orderItems);
            }
            return cancelPayment;
        }

        private void CorrectClients(Client orderClient, Order order, IDictionary<Payment, List<OrderItem>> orderItems)
        {
            if (!string.IsNullOrEmpty(orderClient.TabNum))
            {
                decimal sumZP = orderItems.ContainsKey(Payment.ZP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
                decimal sumLPP = orderItems.ContainsKey(Payment.LPP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
                if (sumZP != 0 || sumLPP != 0)
                {
                    lock (Clients)
                    {
                        if (Clients.TryGetValue(orderClient.TabNum, out Client client))
                        {
                            client.UsedZP += sumZP;
                            client.UsedLPP += sumLPP;
                        }
                    }

                    orderClient.UsedZP += sumZP;
                    orderClient.UsedLPP += sumLPP;
                }
            }
        }

        public static FrontServiceReference.ResultData ExchangeData(string cashDeskID, DateTime? timeStamp)
        {
            FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
            {
                IdCashDesk = cashDeskID,
                ClientTimeStamp = timeStamp ?? DateTime.MinValue,
                ClientTimeStampSpecified = timeStamp != null,
            };

            using (FrontServiceReference.FrontServicePortTypeClient client = new FrontServiceReference.FrontServicePortTypeClient("FrontServiceSoap12"))
            {
                client.Open();

                var data = client.ExchangeData(parameter);

                return data;
            }
        }
    }
}
