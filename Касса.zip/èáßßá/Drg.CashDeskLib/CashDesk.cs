﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            this.Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit(configuration);

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod(configuration);
        }

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        private void CheckPaymentMethod(CashDeskConfiguration configuration)
        {
            PaymentMethod = configuration.PaymentMethod;
            PaymentMethod &= kkm != null && kkm.Fiscal ? PaymentMethod.Cash : ~PaymentMethod.Cash;
            PaymentMethod &= kkm != null && kkm.Fiscal && payTerminal != null ? PaymentMethod.BankCard : ~PaymentMethod.BankCard;
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit(CashDeskConfiguration configuration)
        {
            EquipmentFactory equipmentFactory = null;

            if (configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryEmulator(configuration);
            else // if (!configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryFirmware(configuration);

            // считыватель пропусков нужен только при оплате по пропуску
            if ((configuration.PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
                AddDevice("Подключение считывателя пропусков", () => cardReader = equipmentFactory.CreateCardReader());

            // ККМ используется всегда
            AddDevice("Подключение контрольно-кассовой машины", () => kkm = equipmentFactory.CreateKKM());

            // банковский терминал используется, если есть расчет по банковской карте
            if ((configuration.PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                AddDevice("Подключение банковского терминала", () => payTerminal = equipmentFactory.CreatePayTerminal());
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(string message, Action addDeviceAction)
        {
            OnDeviceAddingEvent(message);
            try
            {
                addDeviceAction();
                OnDeviceAddedEvent(message);
            }
            catch (DeviceException ex)
            {
                OnDeviceAddedEvent(message, ex.ErrorCode, ex.Description);
            }
            catch (Exception ex)
            {
                OnDeviceAddedEvent(message, 1, ex.Message);
            }
        }

        /// <summary>
        /// Генерация события перед подключением устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        void OnDeviceAddingEvent(string message)
        {
            DeviceAddingEvent?.Invoke(this, new DeviceAddingEventArgs(message));
        }

        /// <summary>
        /// Генерация события после подключения устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="errorCode">код ошибки; 0 - нет ошибок</param>
        /// <param name="description">пояснение к ошибке</param>
        void OnDeviceAddedEvent(string message, int errorCode = 0, string description = "")
        {
            DeviceAddedEvent?.Invoke(this, new DeviceAddedEventArgs(message, errorCode, description));
        }

        #endregion Частные методы

        #region События

        /// <summary>
        /// Событие перед подключением устройства
        /// </summary>
        public event EventHandler<DeviceAddingEventArgs> DeviceAddingEvent;

        /// <summary>
        /// Событие после подключения устройства
        /// </summary>
        public event EventHandler<DeviceAddedEventArgs> DeviceAddedEvent;

        #endregion События

        #region Частные поля и свойства

        /// <summary>
        /// Считыватель пропусков
        /// </summary>
        ICardReader cardReader = null;

        /// <summary>
        /// ККМ
        /// </summary>
        IKKM kkm = null;

        /// <summary>
        /// Банковский терминал
        /// </summary>
        IPayTerminal payTerminal = null;

        #endregion Частные поля и свойства

        #region Публичные свойства

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            cardReader?.Dispose();
            kkm?.Dispose();
            payTerminal?.Dispose();
        }

        #endregion Реализация интерфейса IDisposable

    }
}
