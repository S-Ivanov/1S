﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance 
        {
            get => instance;
        }
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static void Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {

        }

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

    }
}
