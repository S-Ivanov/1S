﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance 
        {
            get => instance;
        }
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            this.configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit(configuration);

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod(configuration);
        }

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        private void CheckPaymentMethod(CashDeskConfiguration configuration)
        {
            // TODO: нужно предупредить пользователя, что поддерживаются не все способы оплаты, определенные в конфигурации
            PaymentMethod = configuration.PaymentMethod;
            PaymentMethod &= kkm != null && kkm.Fiscal ? PaymentMethod.Cash : ~PaymentMethod.Cash;
            PaymentMethod &= kkm != null && kkm.Fiscal && payTerminal != null ? PaymentMethod.BankCard : ~PaymentMethod.BankCard;
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit(CashDeskConfiguration configuration)
        {
            EquipmentFactory equipmentFactory = null;

            if (configuration is CashDeskConfigurationFirmware)
                equipmentFactory = new EquipmentFactoryFirmware(configuration as CashDeskConfigurationFirmware);
            else if (configuration is CashDeskConfigurationEmulator)
                equipmentFactory = new EquipmentFactoryEmulator(configuration as CashDeskConfigurationEmulator);

            // считыватель пропусков нужен только при оплате по пропуску
            if ((configuration.PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
            {
                try
                {
                    cardReader = equipmentFactory.CreateCardReader();
                }
                catch (DeviceException ex)
                {
                    OnErrorEvent(ex.ErrorCode, ex.Description, "Ошибка считывателя");
                }
                catch (Exception ex)
                {
                    OnErrorEvent(0, ex.Message, "Ошибка считывателя");
                }
            }

            // ККМ используется всегда
            try
            {
                kkm = equipmentFactory.CreateKKM();
            }
            catch (DeviceException ex)
            {
                OnErrorEvent(ex.ErrorCode, ex.Description, "Ошибка ККМ");
            }
            catch (Exception ex)
            {
                OnErrorEvent(0, ex.Message, "Ошибка ККМ");
            }

            // банковский терминал используется, если есть расчет по банковской карте
            if ((configuration.PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
            {
                try
                {
                    payTerminal = equipmentFactory.CreatePayTerminal();
                }
                catch (DeviceException ex)
                {
                    OnErrorEvent(ex.ErrorCode, ex.Description, "Ошибка банковского терминала");
                }
                catch (Exception ex)
                {
                    OnErrorEvent(0, ex.Message, "Ошибка банковского терминала");
                }
            }
        }

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
        }

        #endregion Реализация интерфейса IDisposable

        void OnErrorEvent(int errorCode, string description, string message)
        {
            ErrorEvent?.Invoke(this, new ErrorEventArgs(errorCode, description, message));
        }

        public event EventHandler<ErrorEventArgs> ErrorEvent;

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        CashDeskConfiguration configuration;

        /// <summary>
        /// Считыватель пропусков
        /// </summary>
        ICardReader cardReader = null;

        /// <summary>
        /// ККМ
        /// </summary>
        IKKM kkm = null;

        /// <summary>
        /// Банковский терминал
        /// </summary>
        IPayTerminal payTerminal = null;

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

    }
}
