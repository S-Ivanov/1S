﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            this.Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit(configuration);

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod(configuration);
        }

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        private void CheckPaymentMethod(CashDeskConfiguration configuration)
        {
            PaymentMethod = configuration.PaymentMethods;
            if (devices.TryGetValue(Device.KKM, out DeviceInfo kkmInfo))
            {
                var kkm = kkmInfo.Device as IKKM;
                var kkmFiscal = kkm != null && (kkm.DeviceError == null || kkm.DeviceError.ErrorCode == DeviceError.NO_ERROR) && kkm.Fiscal;
                PaymentMethod &= kkmFiscal ? PaymentMethod.Cash : ~PaymentMethod.Cash;
                if (kkmFiscal && devices.TryGetValue(Device.KKM, out DeviceInfo payTerminalInfo))
                {
                    PaymentMethod &=
                        payTerminalInfo.Device != null && (payTerminalInfo.DeviceError == null || payTerminalInfo.DeviceError.ErrorCode == DeviceError.NO_ERROR)
                        ? PaymentMethod.BankCard
                        : ~PaymentMethod.BankCard;
                }
                else
                    PaymentMethod &= ~PaymentMethod.BankCard;
            }
            else
            {
                PaymentMethod &= ~PaymentMethod.Cash;
                PaymentMethod &= ~PaymentMethod.BankCard;
            }
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit(CashDeskConfiguration configuration)
        {
            EquipmentFactory equipmentFactory = null;

            if (configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryEmulator(configuration);
            else // if (!configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryFirmware(configuration);

            // считыватель пропусков
            if ((configuration.Devices & Device.CardReader) == Device.CardReader)
                AddDevice(Device.CardReader, () => equipmentFactory.CreateCardReader());

            //// ККМ используется всегда
            AddDevice(Device.KKM, () => equipmentFactory.CreateKKM());

            // банковский терминал
            if ((configuration.Devices & Device.PayTerminal) == Device.PayTerminal)
                AddDevice(Device.PayTerminal, () => equipmentFactory.CreatePayTerminal());
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(Device deviceType, Func<IDevice> createDevice)
        {
            try
            {
                var device = createDevice();
                devices.Add(deviceType, new DeviceInfo { Device = device, DeviceError = device?.DeviceError });
            }
            catch (DeviceException ex)
            {
                devices.Add(deviceType, new DeviceInfo { Device = null, DeviceError = ex.DeviceError });
            }
            catch (Exception ex)
            {
                devices.Add(deviceType, new DeviceInfo { Device = null, DeviceError = new DeviceError(DeviceError.CREATE_ERROR, ex.Message) });
            }
        }

        #endregion Частные методы

        #region События

        #endregion События

        #region Частные поля и свойства

        #endregion Частные поля и свойства

        #region Публичные методы

        public List<Operator> GetOperators()
        {
            List<Operator> list = new List<Operator>();
            using (SqlConnection connection = new SqlConnection(Configuration.DBConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select k.КодПропуска, k.ФИО, k.Должность, k.ИНН, k.Пароль
from Кассиры k
order by k.ФИО", 
                    connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Operator
                    {
                        CardID = reader.GetInt64(0),
                        FIO = reader.GetString(1),
                        Post = reader.IsDBNull(2) ? null : reader.GetString(2),
                        INN = reader.GetString(3),
                        Password = reader.GetString(4)
                    });
                }
            }
            return list;
        }

        #endregion Публичные методы

        #region Публичные свойства

        /// <summary>
        /// Кассир
        /// </summary>
        public Operator Operator { get; set; }

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

        public Dictionary<Device, DeviceInfo> Devices
        {
            get => devices;
        }
        Dictionary<Device, DeviceInfo> devices = new Dictionary<Device, DeviceInfo>();

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.Dispose();
            }
            devices.Clear();
        }

        #endregion Реализация интерфейса IDisposable

    }
}
