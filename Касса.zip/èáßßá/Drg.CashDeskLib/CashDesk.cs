﻿using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Timers;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            this.Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit();

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();

            localDB = new LocalDB.LocalDB(configuration.DBConnectionString);
        }

        //private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        //{
        //    //e.
        //    //throw new NotImplementedException();
        //    //EquipmentChecked?.Invoke
        //    //if (EquipmentChecked != null)
        //}

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        private void CheckPaymentMethod()
        {
            PaymentMethod = Configuration.PaymentMethods;

            if ((PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
            {
                var cardReader = devices[Device.CardReader].Device;
                DeviceError cardReaderError = devices[Device.CardReader].DeviceError;
                PaymentMethod &=
                    cardReader != null && (cardReaderError == null || cardReaderError.ErrorCode == DeviceError.NO_ERROR) ?
                    PaymentMethod.Pass :
                    ~PaymentMethod.Pass;
            }

            if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard || (PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
            {
                var kkm = devices[Device.KKM].Device as IKKM;
                DeviceError kkmError = devices[Device.KKM].DeviceError;
                var kkmFiscal = kkm != null && (kkmError == null || kkmError.ErrorCode == DeviceError.NO_ERROR) && kkm.Fiscal;
                if (kkmFiscal)
                {
                    PaymentMethod &= PaymentMethod.Cash;
                    if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                    {
                        var payTerminal = devices[Device.PayTerminal].Device;
                        DeviceError payTerminalError = devices[Device.PayTerminal].DeviceError;
                        PaymentMethod &=
                            payTerminal != null && (payTerminalError == null || payTerminalError.ErrorCode == DeviceError.NO_ERROR) ?
                            PaymentMethod.BankCard :
                            ~PaymentMethod.BankCard;
                    }
                }
                else
                {
                    PaymentMethod &= ~PaymentMethod.Cash;
                    PaymentMethod &= ~PaymentMethod.BankCard;
                }
            }
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit()
        {
            EquipmentFactory equipmentFactory = null;

            if (Configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryEmulator(Configuration);
            else // if (!configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryFirmware(Configuration);

            // считыватель пропусков используем потенциально всегда - или для питания по пропуску, или для идентификации кассира
            if ((Configuration.Devices & Device.CardReader) == Device.CardReader)
                AddDevice(Device.CardReader, () => equipmentFactory.CreateCardReader());

            //// ККМ используется всегда
            AddDevice(Device.KKM, () => equipmentFactory.CreateKKM());

            // банковский терминал
            if ((Configuration.Devices & Device.PayTerminal) == Device.PayTerminal)
                AddDevice(Device.PayTerminal, () => equipmentFactory.CreatePayTerminal());
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(Device deviceType, Func<IDevice> createDevice)
        {
            try
            {
                var device = createDevice();
                devices.Add(deviceType, new DeviceReference { Device = device, DeviceError = device?.CheckState() });
            }
            catch (DeviceException ex)
            {
                devices.Add(deviceType, new DeviceReference { Device = null, DeviceError = ex.DeviceError });
            }
            catch (Exception ex)
            {
                devices.Add(deviceType, new DeviceReference { Device = null, DeviceError = new DeviceError(DeviceError.CREATE_ERROR, ex.Message) });
            }
        }

        #endregion Частные методы

        #region События

        //public event EventHandler<ElapsedEventArgs> EquipmentChecked;

        //{
        //    add
        //    {
        //        lock (lockEquipmentChecked)
        //        {
        //            if (countEquipmentChecked == 0)
        //                timer.Start();
        //            countEquipmentChecked++;
        //        }
        //    }
        //    remove
        //    {
        //        lock (lockEquipmentChecked)
        //        {
        //            countEquipmentChecked--;
        //            if (countEquipmentChecked == 0)
        //                timer.Stop();
        //        }
        //    }
        //}
        //object lockEquipmentChecked = new object();
        //int countEquipmentChecked = 0;

        #endregion События

        #region Частные поля и свойства

        LocalDB.LocalDB localDB;

        #endregion Частные поля и свойства

        #region Публичные методы

        public List<Operator> GetOperators()
        {
            return localDB.GetOperators();
        }

        //public void CheckEquipmentStart()
        //{
        //    //timer = new Timer(1000);
        //    //timer.Elapsed += Timer_Elapsed;

        //}

        public void CheckEquipment()
        {
            foreach (var kvp in devices)
            {
                if (kvp.Value.Device != null)
                {
                    var deviceError = kvp.Value.Device.CheckState();
                    kvp.Value.DeviceError = deviceError;
                }
            }

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();
        }

        #endregion Публичные методы

        #region Публичные свойства

        /// <summary>
        /// Кассир
        /// </summary>
        public Operator Operator { get; set; }

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

        public Dictionary<Device, DeviceReference> Devices
        {
            get => devices;
        }
        Dictionary<Device, DeviceReference> devices = new Dictionary<Device, DeviceReference>();

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            //timer?.Dispose();

            foreach (var kvp in devices)
            {
                kvp.Value.Device?.Dispose();
            }
            devices.Clear();
        }

        #endregion Реализация интерфейса IDisposable

    }
}
