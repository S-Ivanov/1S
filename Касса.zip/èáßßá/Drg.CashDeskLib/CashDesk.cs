﻿using Drg.CashDeskLib.Configuration;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Equipment;
using Drg.CashDeskLib.ReportFO;
using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Timers;
using System.Xml;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public partial class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration)
        {
            Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit();

            CreateOrderPayment();

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();

            localDB = new DB.LocalDB(configuration.DBConnectionString);
            //parsecDB = new DB.ParsecDB(configuration.ParsecDBConnectionString);

            reportFOGenerator = new ReportFOGenerator(
                localDB,
                Configuration.ReportFOXslt,
                Configuration.ReportFOFile,
                Configuration.ReportFOFileReserve,
                Configuration.EateryID,
                Configuration.EateryName,
                Configuration.CashDeskNumber);

            FrontDataExchange();

            LoadClients();
            LoadOrderSources();
        }

        private void CreateOrderPayment()
        {
            IKKM kkm = null;
            if (devices.TryGetValue(Device.KKM, out DeviceReference deviceReference))
                kkm = deviceReference.Device as IKKM;
            IPayTerminal payTerminal = null;
            if (devices.TryGetValue(Device.PayTerminal, out deviceReference))
                payTerminal = deviceReference.Device as IPayTerminal;
            orderPayment = new OrderPayment(kkm, payTerminal);
        }

        public void OpenSession(Operator @operator)
        {
            Operator = @operator;

            // загрузить информацию о последней смене
            LoadLastSession();
        }

        public event EventHandler<CashPaymentEventArgs> CashPaymentEvent
        {
            add { orderPayment.CashPaymentEvent += value; }
            remove { orderPayment.CashPaymentEvent -= value; }
        }

        /// <summary>
        /// Загрузить информацию о последней смене
        /// </summary>
        private void LoadLastSession()
        {
            Session = localDB.LoadLastSession();
            if (Session.IsEmpty || Session.IsClosed)
                Session = OpenSession();
            else if (!Session.IsClosed)
            {
                DateTime dateTimeNow = DateTime.Now;
                if (Session.Begin.Date != dateTimeNow.Date || Session.OperatorId != Operator.Id)
                {
                    CloseSession(Session.Begin.Date.AddDays(1).AddSeconds(-1));
                    Session = OpenSession();
                }
            }
        }

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        private void CheckPaymentMethod()
        {
            PaymentMethod = Configuration.PaymentMethods;

            if ((PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
            {
                var cardReader = devices[Device.CardReader].Device;
                DeviceError cardReaderError = devices[Device.CardReader].DeviceError;
                PaymentMethod &=
                    cardReader != null && (cardReaderError == null || cardReaderError.ErrorCode == DeviceError.NO_ERROR) ?
                    PaymentMethod.All :
                    ~PaymentMethod.Pass;
            }

            if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard || (PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
            {
                var kkm = devices[Device.KKM].Device as IKKM;
                DeviceError kkmError = devices[Device.KKM].DeviceError;
                var kkmFiscal = kkm != null && (kkmError == null || kkmError.ErrorCode == DeviceError.NO_ERROR) && kkm.Fiscal;
                if (kkmFiscal)
                {
                    PaymentMethod &= PaymentMethod.All;
                    if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                    {
                        var payTerminal = devices[Device.PayTerminal].Device;
                        DeviceError payTerminalError = devices[Device.PayTerminal].DeviceError;
                        PaymentMethod &=
                            payTerminal != null && (payTerminalError == null || payTerminalError.ErrorCode == DeviceError.NO_ERROR) ?
                            PaymentMethod.All :
                            ~PaymentMethod.BankCard;
                    }
                }
                else
                {
                    PaymentMethod &= ~PaymentMethod.Cash;
                    PaymentMethod &= ~PaymentMethod.BankCard;
                }
            }
        }

        /// <summary>
        /// Загрузить возвраты
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public List<Order> LoadReturns(Guid orderId) => localDB.LoadReturns(orderId);

        public Tuple<string, DataModel.Order> LoadOrder(Guid orderId) => localDB.LoadOrder(orderId);

        public void NewSession(DateTime dateTimeClose)
        {
            CloseSession(dateTimeClose);
            Session = OpenSession();
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit()
        {
            EquipmentFactory equipmentFactory = null;

            if (Configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryEmulator(Configuration);
            else // if (!configuration.UseEmulators)
                equipmentFactory = new EquipmentFactoryFirmware(Configuration);

            // считыватель пропусков используем потенциально всегда - или для питания по пропуску, или для идентификации кассира
            if ((Configuration.Devices & Device.CardReader) == Device.CardReader)
                AddDevice(Device.CardReader, () => equipmentFactory.CreateCardReader());

            //// ККМ используется всегда
            AddDevice(Device.KKM, () => equipmentFactory.CreateKKM());

            // банковский терминал
            if ((Configuration.Devices & Device.PayTerminal) == Device.PayTerminal)
                AddDevice(Device.PayTerminal, () => equipmentFactory.CreatePayTerminal());
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(Device deviceType, Func<IDevice> createDevice)
        {
            try
            {
                var device = createDevice();
                devices.Add(deviceType, new DeviceReference { Device = device, DeviceError = device?.CheckState() });
            }
            catch (DeviceException ex)
            {
                devices.Add(deviceType, new DeviceReference { Device = null, DeviceError = ex.DeviceError });
            }
            catch (Exception ex)
            {
                devices.Add(deviceType, new DeviceReference { Device = null, DeviceError = new DeviceError(DeviceError.CREATE_ERROR, ex.Message) });
            }
        }

        #endregion Частные методы

        #region События

        #endregion События

        #region Частные поля и свойства

        DB.LocalDB localDB;
        //DB.ParsecDB parsecDB;

        OrderPayment orderPayment;

        #endregion Частные поля и свойства

        #region Публичные методы

        /// <summary>
        /// Смена
        /// </summary>
        public Session Session { get; private set; }

        /// <summary>
        /// Загрузить кассиров
        /// </summary>
        /// <returns></returns>
        public List<Operator> GetOperators() => localDB.GetOperators();

        /// <summary>
        /// Прочитать номер нового заказа
        /// </summary>
        /// <returns></returns>
        public int GetNewOrderNumber() => localDB.GetNewOrderNumber();

        /// <summary>
        /// Загрузить последние меню, дата которых меньше или равна указанной
        /// </summary>
        /// <param name="date"></param>
        /// <param name="menuCount">количество меню для загрузки</param>
        /// <returns></returns>
        public List<Menu> LoadMenus(DateTime date, int menuCount) => localDB.LoadMenus(date, menuCount);

        ///// <summary>
        ///// Загрузить клиента
        ///// </summary>
        ///// <param name="cardCode">код пропуска</param>
        ///// <returns></returns>
        //public DataModel.Client GetClient(uint cardCode)
        //{
        //    Client client = localDB.GetClient(cardCode);
        //    //LoadPhotoFromParsec(client);
        //    return client;
        //}

        public void FrontDataExchange()
        {
            if (!Configuration.UseFrontService)
                return;

            try
            {
                FrontDataExchange("FrontServiceSoap12", localDB, Configuration.CashDeskID, Configuration.LPPNominal, Configuration.IsTestMode);
            }
            catch
            {
                throw;
            }


        }

        public static void FrontDataExchange(string pointName, LocalDB localDB, string cashDeskID, decimal lppNominal, bool isTestMode)
        {
            DateTime? serverTimeStamp = localDB.GetServerTimeStamp();
            DateTime? clientTimeStamp = localDB.GetCashDeskTimeStamp();
            DateTime newClientTimeStamp = DateTime.UtcNow;

            FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
            {
                IsTest = isTestMode,
                IdCashDesk = cashDeskID,
                OrderDocument = localDB.LoadOrderDocument(clientTimeStamp, newClientTimeStamp, isTestMode),
                TransactionDocument = localDB.LoadTransactionDocument(clientTimeStamp, newClientTimeStamp, isTestMode)
            };

            // дата/время последнего сеанса обмена данными - чтение
            if (serverTimeStamp != null)
            {
                parameter.ClientTimeStamp = serverTimeStamp.Value;
                parameter.ClientTimeStampSpecified = true;
            }

            using (FrontServiceReference.FrontServicePortTypeClient frontServiceClient = new FrontServiceReference.FrontServicePortTypeClient(pointName))
            {
                FrontServiceReference.ResultData resultData = frontServiceClient.ExchangeData(parameter);

                // зафиксировать успешность передачи заказов
                if (resultData.IsOrdersSaved)
                {
                    localDB.SaveClientTimeStamp(newClientTimeStamp);
                }

                // записать полученные данные
                localDB.SaveExchangeData(resultData, cashDeskID, lppNominal, isTestMode);
            }
        }

        /// <summary>
        /// Добавить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool AddMenuItem(MenuItem menuItem) => localDB.AddMenuItem(menuItem);

        //private void LoadPhotoFromParsec(Client client)
        //{
        //    if (client != null && client.Photo == null)
        //    {
        //        try
        //        {
        //            client.Photo = parsecDB.GetPhoto(client.TabNum);
        //        }
        //        catch
        //        {
        //        }

        //        if (client.Photo != null)
        //            localDB.SavePhoto(client);
        //    }
        //}

        ///// <summary>
        ///// Загрузить фотографию
        ///// </summary>
        ///// <param name="client">клиент</param>
        //public void LoadPhoto(Client client)
        //{
        //    if (client != null && client.Photo == null && !client.IsPhotoLoaded)
        //    {
        //        client.Photo = localDB.GetClientPhoto(client.TabNum);
        //        //if (client.Photo == null)
        //        //    LoadPhotoFromParsec(client);
        //        client.IsPhotoLoaded = true;
        //    }
        //}

        /// <summary>
        /// Полный список клиентов
        /// </summary>
        public ConcurrentDictionary<string, Client> Clients { get; } = new ConcurrentDictionary<string, Client>();

        /// <summary>
        /// Список локальных заказов
        /// </summary>
        public List<OrderSource> LocalOrders { get; } = new List<OrderSource>();

        /// <summary>
        /// Загрузить исходные заказы для возвратов
        /// </summary>
        /// <returns></returns>
        public void LoadOrderSources()
        {
            LocalOrders.Clear();
            // TODO: загружать заказы только в пределах суток и с учетом только своих заказов, а также тестового режима работы
            LocalOrders.AddRange(localDB.LoadOrderSources(Configuration.IsTestMode));
        }

        /// <summary>
        /// Прочитать полный список клиентов
        /// </summary>
        /// <returns></returns>
        public void LoadClients()
        {
            lock (Clients)
            {
                Clients.Clear();

                foreach (Client client in localDB.LoadClients())
                {
                    Clients.TryAdd(client.TabNum, client);
                }
            }
        }

        ///// <summary>
        ///// Прочитать список локальных заказов
        ///// </summary>
        ///// <returns></returns>
        //public void LoadLocalOrders()
        //{
        //}

        /// <summary>
        /// Проверить оборудование
        /// </summary>
        public void CheckEquipment()
        {
            // TODO: распараллелить проверку устройств
            foreach (var kvp in devices)
            {
                if (kvp.Value.Device != null)
                {
                    var deviceError = kvp.Value.Device.CheckState();
                    kvp.Value.DeviceError = deviceError;
                }
            }

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();
        }

        /// <summary>
        /// Удалить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool DeleteMenuItem(MenuItem menuItem) => localDB.DeleteMenuItem(menuItem);

        #endregion Публичные методы

        #region Публичные свойства

        /// <summary>
        /// Кассир
        /// </summary>
        public Operator Operator { get; set; }
        //{
        //    get => @operator;
        //    set
        //    {
        //        if (@operator != value)
        //        {
        //            @operator = value;

        //            // при смене оператора нужно проверить смену
        //            bool mustOpenSession = Session.IsEmpty || Session.IsClosed;
        //            if (!mustOpenSession && Session.OperatorId != @operator.Id)
        //            {
        //                // закрыть старую смену 
        //                CloseSession(DateTime.Now);

        //                // нужно открыть новую смену
        //                mustOpenSession = true;
        //            }

        //            if (mustOpenSession)
        //                // открыть новую смену
        //                Session = OpenSession();
        //        }
        //    }
        //}

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <returns></returns>
        private Session OpenSession()
        {
            // TODO: открытие смены - взаимодействие с ККМ
            return localDB.OpenSession(Operator);
        }

        //Operator @operator;

        /// <summary>
        /// Закрыть смену
        /// </summary>
        public void CloseSession(DateTime dateTime)
        {
            if (!Session.IsEmpty)
            {
                // TODO: закрытие смены - взаимодействие с ККМ

                // записать закрытие смены в базу данных
                localDB.CloseSession(Session.Id, dateTime);

                // сформировать отчет ФО
                reportFOGenerator.Generate(Session.Id);
            }
        }

        ReportFO.ReportFOGenerator reportFOGenerator;

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        /// <summary>
        /// Изменить количество в элементе меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <param name="newCount"></param>
        /// <returns></returns>
        public bool ChangeMenuItemCount(MenuItem menuItem, decimal newCount) => localDB.ChangeMenuItemCount(menuItem, newCount);

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; private set; }

        public Dictionary<Device, DeviceReference> Devices => devices;
        Dictionary<Device, DeviceReference> devices = new Dictionary<Device, DeviceReference>();

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.Device?.Dispose();
            }
            devices.Clear();
        }

        #endregion Реализация интерфейса IDisposable

        ///// <summary>
        ///// Записать заказ и оплату
        ///// </summary>
        ///// <param name="client">клиент</param>
        ///// <param name="order">заказ</param>
        ///// <param name="payments">оплата</param>
        //public void SaveOrderAndPayment(Client client, Order order, Dictionary<Payment, decimal> payments) => localDB.SaveOrderAndPayment(client, order, payments);

        /// <summary>
        /// Выполнить оплату
        /// </summary>
        /// <param name="client">клиент</param>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата: вид оплаты + сумма</param>
        /// <returns>виды оплат, которые не удалось выполнить</returns>
        public Payment Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out List<Payment> noPayments)
        {
            // TODO: проверить корректность входных параметров

            Payment cancelPayment = orderPayment.Pay(client, order, payments, out noPayments, out IDictionary <Payment, List<OrderItem>> orderItems);
            if (cancelPayment == Payment.None && noPayments.Count == 0)
            {
                localDB.SaveOrderAndPayment(Session, client, order, orderItems, Configuration.IsTestMode);
                // корректировать информацию о работниках и заказах после оплаты заказа
                CorrectClientAndOrders(client, order, orderItems);
            }
            return cancelPayment;
        }

        private void CorrectClientAndOrders(Client orderClient, Order order, IDictionary<Payment, List<OrderItem>> orderItems)
        {
            if (!string.IsNullOrEmpty(orderClient.TabNum))
            {
                decimal sumZP = orderItems.ContainsKey(Payment.ZP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
                decimal sumLPP = orderItems.ContainsKey(Payment.LPP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
                if (sumZP != 0 || sumLPP != 0)
                {
                    lock (Clients)
                    {
                        if (Clients.TryGetValue(orderClient.TabNum, out Client client))
                        {
                            client.UsedZP += sumZP;
                            client.UsedLPP += sumLPP;
                        }
                    }

                    orderClient.UsedZP += sumZP;
                    orderClient.UsedLPP += sumLPP;
                }
            }

            LocalOrders.Add(new OrderSource { Id = order.Id, Number = order.Number, DateTime = order.DateTime, Client = orderClient });
        }

        public static FrontServiceReference.ResultData ExchangeData(string cashDeskID, DateTime? timeStamp)
        {
            FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
            {
                IdCashDesk = cashDeskID,
                ClientTimeStamp = timeStamp ?? DateTime.MinValue,
                ClientTimeStampSpecified = timeStamp != null,
            };

            using (FrontServiceReference.FrontServicePortTypeClient client = new FrontServiceReference.FrontServicePortTypeClient("FrontServiceSoap12"))
            {
                client.Open();

                var data = client.ExchangeData(parameter);

                return data;
            }
        }
    }
}
