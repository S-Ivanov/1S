﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.ReportFO
{
    // https://stackoverflow.com/questions/38789183/subset-sum-algorithm-efficiency answer 0
    public static class SubsetSumSolver
    {
        public static List<T> SubsetSums<T>(IEnumerable<T> items, decimal target, Func<T, decimal> amountGetter, bool ordered = false)
        {
            Stack<T> unusedItems = new Stack<T>(ordered ? items : items.OrderByDescending(amountGetter));
            Stack<T> usedItems = new Stack<T>();
            List<List<T>> results = new List<List<T>>();
            SubsetSumsRec(unusedItems, usedItems, target, results, amountGetter);
            return results.Count > 0 ? results[0] : new List<T>();
        }

        static void SubsetSumsRec<T>(Stack<T> unusedItems, Stack<T> usedItems, decimal targetSum, List<List<T>> results, Func<T, decimal> amountGetter)
        {
            if (results.Count > 0)
                return;

            if (targetSum == 0)
            {
                results.Add(usedItems.ToList());
                return;
            }

            if (targetSum < 0 || unusedItems.Count == 0)
                return;
            var item = unusedItems.Pop();
            var currentAmount = amountGetter(item);
            if (targetSum >= currentAmount)
            {
                // case 1: use current element
                usedItems.Push(item);
                SubsetSumsRec(unusedItems, usedItems, targetSum - currentAmount, results, amountGetter);
                usedItems.Pop();
                // case 2: skip current element
                SubsetSumsRec(unusedItems, usedItems, targetSum, results, amountGetter);
            }
            unusedItems.Push(item);
        }
    }
}
