﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.ReportFO
{
    public static class OrderSplitter
    {
        /// <summary>
        /// Разбить заказ по видам оплат
        /// </summary>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата заказа: вид оплаты + сумма</param>
        /// <param name="countDecimals">количество знаков после запттой при пересчете количества в элементах меню</param>
        /// <returns>пустой словарь, если разбивка заказа не выполнена</returns>
        public static IDictionary<Payment, List<OrderItem>> Split(Order order, IDictionary<Payment, decimal> payments, int countDecimals = 3)
        {
            if (order == null)
                throw new ArgumentNullException(nameof(order));
            if (order.Items == null || order.Items.Count == 0 || order.Items.Any(_ => _.Sum <= 0))
                throw new ArgumentException(nameof(order));
            if (payments == null)
                throw new ArgumentNullException(nameof(payments));
            if (payments.Count == 0 || payments.Any(kvp => kvp.Value <= 0))
                throw new ArgumentException(nameof(payments));
            if (countDecimals < 0)
                throw new ArgumentOutOfRangeException(nameof(countDecimals));
            if (order.Items.Sum(orderItem => orderItem.Sum) != payments.Sum(kvp => kvp.Value))
                throw new ArgumentOutOfRangeException();

            Dictionary<Payment, List<OrderItem>> result = new Dictionary<Payment, List<OrderItem>>();
            // делаем копию элементов заказа, чтобы не испортить исходные данные
            var orderItems = new List<OrderItem>(order.Items.Select(orderItem => (OrderItem)orderItem.Clone()).OrderBy(orderItem => orderItem.Sum));
            var paymentsList = payments.OrderByDescending(kvp => kvp.Value).ToList();

            while (paymentsList.Any())
            {
                if (paymentsList.Count == 1)
                {
                    result.Add(paymentsList[0].Key, orderItems);
                    break;
                }

                var splited = SplitByBinPack(orderItems, paymentsList);
                if (splited.Any() && splited.Sum(kvp => kvp.Value.Sum(orderItem => orderItem.Sum)) == paymentsList.Sum(kvp => kvp.Value))
                {
                    foreach (var kvp in splited)
                    {
                        result.Add(kvp.Key, kvp.Value);
                    }
                    break;
                }

                // если не удалось точно подобрать сумму, разобъем элементы заказа по одному варианту оплаты
                // после ручной разбивки остальные элементы могут раскладываться !!!
                var splited2 = SplitManual(orderItems, paymentsList, countDecimals);
                if (splited2.Key != Payment.None && splited2.Value.Any())
                    result.Add(splited2.Key, splited2.Value);

                if (paymentsList.Count == 1)
                {
                    result.Add(paymentsList[0].Key, orderItems);
                    break;
                }
            }

            return result;
        }

        static KeyValuePair<Payment, List<OrderItem>> SplitManual(List<OrderItem> orderItems, List<KeyValuePair<Payment, decimal>> payments, int countDecimals)
        {
            Payment payment = payments[0].Key;
            KeyValuePair<Payment, List<OrderItem>> result = new KeyValuePair<Payment, List<OrderItem>>(payment, new List<OrderItem>());
            var sum = payments[0].Value;
            payments.RemoveAt(0);

            decimal resultSum = 0;
            for (int i = orderItems.Count -1; i >= 0 && resultSum < sum; i--)
            {
                var orderItem = orderItems[i];
                if (resultSum + orderItem.Sum <= sum)
                {
                    resultSum += orderItem.Sum;
                    result.Value.Add(orderItem);
                    orderItems.RemoveAt(i);
                }
                else
                {
                    var sum1 = sum - resultSum;
                    if (payment == Payment.LPP || payment == Payment.Talon120)
                        sum1 = Math.Round(sum1, MidpointRounding.AwayFromZero);

                    var sum2 = orderItem.Sum - sum1;

                    var k = sum1 / orderItem.Sum;
                    var count1 = Math.Round(k * orderItem.Count, countDecimals, MidpointRounding.AwayFromZero);
                    var count2 = orderItem.Count - count1;

                    var price1 = Math.Round(sum1 / count1, 2, MidpointRounding.AwayFromZero);
                    var price2 = Math.Round(sum2 / count2, 2, MidpointRounding.AwayFromZero);

                    MenuItem menuItem1;
                    if (price1 == orderItem.MenuItem.Price)
                        menuItem1 = orderItem.MenuItem;
                    else
                    {
                        menuItem1 = (MenuItem)orderItem.MenuItem.Clone();
                        menuItem1.Price = price1;
                    }

                    OrderItem newOrderItem = new OrderItem
                    {
                        Count = count1,
                        MenuItem = menuItem1,
                        
                    };
                    newOrderItem.Sum = sum1;
                    result.Value.Add(newOrderItem);

                    orderItem.Count = count2;
                    if (price2 != orderItem.MenuItem.Price)
                    {
                        MenuItem menuItem2 = (MenuItem)orderItem.MenuItem.Clone();
                        menuItem2.Price = price2;
                        orderItem.MenuItem = menuItem2;
                    }
                    orderItem.Sum = sum2;

                    resultSum = sum;
                }
            }

            return result;
        }

        static Dictionary<Payment, List<OrderItem>> SplitByBinPack(List<OrderItem> orderItems, List<KeyValuePair<Payment, decimal>> payments)
        {
            Dictionary<Payment, List<OrderItem>> result = new Dictionary<Payment, List<OrderItem>>();

            List<OrderItem> orderItemsByOne = SplitByOne(orderItems);

            // переводим суммы в копейки и решаем целочисленную задачу упаковки в контейнеры
            int[] orderItemSums = orderItemsByOne.Select(orderItem => (int)(orderItem.Sum * 100)).ToArray();
            int[] paymentSums = payments.Select(kvp => (int)(kvp.Value * 100)).ToArray();

            BinPacker binPacker = new BinPacker(paymentSums, orderItemSums);
            List<int> binPackerResult = binPacker.First();

            if (binPackerResult.Any())
            {
                var gg = binPackerResult
                    .Select((payIndex, index) => new { Payment = payments[payIndex], OrderItem = orderItemsByOne[index] })
                    .GroupBy(x => x.Payment);

                foreach (var g in gg)
                {
                    // свернуть одинаковые элементы в пределах одного вида оплаты
                    var gg2 = g.GroupBy(g2 => g2.OrderItem.MenuItem);
                    List<OrderItem> orderItemsByMenuItem = gg2.Select(g2 => new OrderItem { MenuItem = g2.Key, Count = g2.Sum(x => x.OrderItem.Count) }).ToList();
                    result.Add(g.Key.Key, orderItemsByMenuItem);
                }
            }

            return result;
        }

        public static List<OrderItem> SplitByOne(List<OrderItem> orderItems)
        {
            List<OrderItem> result = new List<OrderItem>();
            foreach (var orderItem in orderItems)
            {
                var menuItem = orderItem.MenuItem;

                decimal count = orderItem.Count;
                while (count >= 1)
                {
                    result.Add(new OrderItem
                    {
                        Count = 1,
                        MenuItem = menuItem
                    });
                    count -= 1;
                }

                if (count > 0)
                {
                    result.Add(new OrderItem
                    {
                        Count = count,
                        MenuItem = menuItem
                    });
                }
            }
            return result;
        }
    }
}
