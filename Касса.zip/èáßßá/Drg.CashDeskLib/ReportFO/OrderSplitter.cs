﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.ReportFO
{
    public static class OrderSplitter
    {
        /// <summary>
        /// Разбить заказ по видам оплат
        /// </summary>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата заказа: вид оплаты + сумма</param>
        /// <returns></returns>
        public static IDictionary<Payment, List<OrderItem>> Split(Order order, IDictionary<Payment, decimal> payments)
        {
            // TODO: проверить null, пустые, несовпадение суммы

            Dictionary<Payment, List<OrderItem>> result = new Dictionary<Payment, List<OrderItem>>();

            if (payments.Count == 1)
            {
                var paymentSum = payments.First();
                result.Add(paymentSum.Key, order.Items);
                payments.Clear();
            }
            else
            {
                List<OrderItem> orderItemsByOne = SplitByOne(order.Items);

                foreach (var kvp in payments.OrderByDescending(paymentSum => paymentSum.Value))
                {
                    Payment payment = kvp.Key;
                    decimal sum = payments[payment];
                    List<OrderItem> selected = SubsetSumSolver.SubsetSums(orderItemsByOne, sum, orderItem => orderItem.Count * orderItem.MenuItem.Price);
                    if (selected.Sum(orderItem => orderItem.Count * orderItem.MenuItem.Price) == sum)
                    {
                        orderItemsByOne = orderItemsByOne.Except(selected).ToList();
                        payments.Remove(payment);

                        // TODO: свернуть одинаковые элементы
                        result.Add(payment, selected);
                    }
                }
            }

            return result;
        }

        public static List<OrderItem> SplitByOne(List<OrderItem> orderItems)
        {
            List<OrderItem> result = new List<OrderItem>();
            foreach (var orderItem in orderItems)
            {
                var menuItem = orderItem.MenuItem;

                decimal count = orderItem.Count;
                while (count >= 1)
                {
                    result.Add(new OrderItem
                    {
                        Count = 1,
                        MenuItem = menuItem
                    });
                    count -= 1;
                }

                if (count > 0)
                {
                    result.Add(new OrderItem
                    {
                        Count = count,
                        MenuItem = menuItem
                    });
                }
            }
            return result;
        }

        // http://forum.sources.ru/index.php?showtopic=204375&view=showall 
        //// g - сумма, которую нужно набрать
        //// v - остаток
        //// sums - сумма + количество элементов
        //static void Split(int g, int v, Dictionary<int, int> sums, Dictionary<int, int> sol)
        //{
        //    if (v == 0)
        //    {
        //        // сумма набрана
        //    }
        //    else // if (v > 0)
        //    {
        //        foreach (var kvp in sums)
        //        {
        //            if (v >= kvp.Key && kvp.Value > 0)
        //            {
        //                sums[kvp.Key] -= 1;
        //                sol[kvp.Key] += 1;
        //                Split(g - kvp.Key, kvp.Key, sums, sol);
        //            }
        //        }
        //    }
        //}
    }
}
