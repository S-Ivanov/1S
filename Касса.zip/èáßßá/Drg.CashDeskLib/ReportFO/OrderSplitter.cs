﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.ReportFO
{
    public static class OrderSplitter
    {
        /// <summary>
        /// Разбить заказ по видам оплат
        /// </summary>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата заказа: вид оплаты + сумма</param>
        /// <returns>пустой словарь, если разбивка заказа не выполнена</returns>
        public static IDictionary<Payment, List<OrderItem>> Split(Order order, IDictionary<Payment, decimal> payments)
        {
            // TODO: проверить null, пустые, несовпадение суммы

            if (payments.Count == 1)
            {
                var paymentSum = payments.First();
                payments.Clear();
                return new Dictionary<Payment, List<OrderItem>> { { paymentSum.Key, order.Items} };
            }
            else
            {
                Dictionary<Payment, List<OrderItem>> result = SplitByBinPack(order.Items, payments);

            }

            return null;
        }

        public static Dictionary<Payment, List<OrderItem>> SplitByBinPack(List<OrderItem> orderItems, IDictionary<Payment, decimal> payments)
        {
            Dictionary<Payment, List<OrderItem>> result = new Dictionary<Payment, List<OrderItem>>();

            List<OrderItem> orderItemsByOne = SplitByOne(orderItems);

            var paymentsArray = payments.ToArray();
            int[] orderItemSums = orderItems.Select(orderItem => (int)(orderItem.Total * 100)).ToArray();
            int[] paymentSums = paymentsArray.Select(kvp => (int)(kvp.Value * 100)).ToArray();
            BinPacker binPacker = new BinPacker(paymentSums, orderItemSums);
            List<int> binPackerResult = binPacker.First();

            var gg = binPackerResult
                .Select((payIndex, index) => new { Payment = paymentsArray[payIndex], OrderItem = orderItemsByOne[index] })
                .GroupBy(x => x.Payment);

            foreach (var g in gg)
            {
                // TODO: свернуть одинаковые элементы в пределах одного вида оплаты
                List<OrderItem> orderItemsByMenuItem;
            }

            return result;
        }

        public static List<OrderItem> SplitByOne(List<OrderItem> orderItems)
        {
            List<OrderItem> result = new List<OrderItem>();
            foreach (var orderItem in orderItems)
            {
                var menuItem = orderItem.MenuItem;

                decimal count = orderItem.Count;
                while (count >= 1)
                {
                    result.Add(new OrderItem
                    {
                        Count = 1,
                        MenuItem = menuItem
                    });
                    count -= 1;
                }

                if (count > 0)
                {
                    result.Add(new OrderItem
                    {
                        Count = count,
                        MenuItem = menuItem
                    });
                }
            }
            return result;
        }
    }
}
