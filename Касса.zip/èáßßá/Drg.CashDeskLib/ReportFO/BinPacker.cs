﻿using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.ReportFO
{
    /// <summary>
    /// Решение задачи об упаковке в контейнеры (англ. Bin packing problem)
    /// https://ru.wikipedia.org/wiki/Задача_об_упаковке_в_контейнеры
    /// </summary>
    /// <remarks>
    /// За основу взят код Qt C++ https://github.com/AndreyMlashkin/ReconfiguratedSystem
    /// Целесообразно доработать в части использования Stack вместо List (см. методы PushItem, PopItem)
    /// </remarks>
    public class BinPacker
    {
        public BinPacker(int[] bins, int[] items)
        {
            this.bins = bins;
            this.items = items;
            binItems = new List<int>(bins);
        }

        /// <summary>
        /// Первый возможный вариант раскладки
        /// </summary>
        /// <returns>индексы bins, в которые помещаются соответствующие элементы items; пустой список, если нет решения</returns>
        public List<int> First()
        {
            return Next();
        }

        public List<List<int>> All()
        {
            ResetNext();

            List<List<int>> result = new List<List<int>>();
            while (true)
            {
                List<int> nextResult = Next();
                if (nextResult.Count == 0)
                    break;
                result.Add(new List<int>(nextResult));
            }

            return result;
        }

        public List<int> Next()
        {
            if (itemsInBugsStack.Any())
                PopItem();

            while (currentItem < items.Length)
            {
                while (currentBin < binItems.Count)
                {
                    int item = items[currentItem];
                    int binItem = binItems[currentBin];

                    if (binItem >= item)
                    {
                        PushItem();
                        break;
                    }
                    ++currentBin;
                }
                bool placeForItemIsFound = itemsInBugsStack.Count - 1 == currentItem;
                if (placeForItemIsFound)
                    currentBin = 0; 
                else if (itemsInBugsStack.Any())
                {
                    PopItem();
                    continue;
                }
                else
                    return new List<int>();
                ++currentItem;
            }
            return itemsInBugsStack;
        }

        public void ResetNext()
        {
            binItems = new List<int>(bins);
            itemsInBugsStack.Clear();
            currentItem = 0;
            currentBin = 0;
        }

        void PushItem()
        {
            int processRam = items[currentItem];
            binItems[currentBin] -= processRam;
            itemsInBugsStack.Add(currentBin);
        }

        void PopItem()
        {
            currentItem = itemsInBugsStack.Count - 1;
            currentBin = itemsInBugsStack.Last();
            itemsInBugsStack.RemoveAt(itemsInBugsStack.Count - 1);
            binItems[currentBin] += items[currentItem];
            ++currentBin;
        }

        int[] bins;
        int[] items;

        List<int> binItems;
        List<int> itemsInBugsStack = new List<int>();

        int currentItem = 0;
        int currentBin = 0;
    }
}
