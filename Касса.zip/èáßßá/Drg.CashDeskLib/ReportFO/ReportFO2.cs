﻿using System;
using System.Xml.Serialization;

namespace Drg.CashDeskLib.ReportFO
{
    public partial class ReportFOReportRecord
    {
        /// <summary>
        /// Идентификатор смены
        /// </summary>
        [NonSerialized]
        [XmlIgnore]
        public string SessionId;

        /// <summary>
        /// Индикатор возврата
        /// </summary>
        [NonSerialized]
        [XmlIgnore]
        public bool IsReturn;

        [NonSerialized]
        [XmlIgnore]
        public int SessionNumber;

        [NonSerialized]
        [XmlIgnore]
        public DateTime SessionBegin;

        [NonSerialized]
        [XmlIgnore]
        public DateTime SessionEnd;
    }
}
