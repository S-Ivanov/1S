﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.ReportFO
{
    public partial class ReportFO
    {
        [NonSerialized]
        public int LastReportNum;
    }

    public partial class ReportFOReportRecord
    {
        [NonSerialized]
        public DateTime SessionBegin;

        [NonSerialized]
        public DateTime SessionEnd;
    }
}
