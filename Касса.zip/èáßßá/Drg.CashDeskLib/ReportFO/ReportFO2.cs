﻿using System;

namespace Drg.CashDeskLib.ReportFO
{
    public partial class ReportFOReportRecord
    {
        [NonSerialized]
        public int SessionNumber;

        [NonSerialized]
        public DateTime SessionBegin;

        [NonSerialized]
        public DateTime SessionEnd;
    }
}
