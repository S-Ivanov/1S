﻿using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Xsl;

namespace Drg.CashDeskLib.ReportFO
{
    public class ReportFOGenerator
    {
        public ReportFOGenerator(string xsltFileName)
        {
            xslt.Load(xsltFileName);
        }

        public void Generate(ReportFO reportFO, XmlWriter xmlWriter)
        {
            Numerate(reportFO);

            XmlSerializer serializer = new XmlSerializer(typeof(ReportFO));
            using (StringWriter stringWriter = new StringWriter())
            {
                serializer.Serialize(stringWriter, reportFO);

                using (StringReader stringReader = new StringReader(stringWriter.ToString()))
                {
                    using (XmlReader xmlReader = XmlReader.Create(stringReader))
                    {
                        xslt.Transform(xmlReader, xmlWriter);
                    }
                }
            }
        }

        private static void Numerate(ReportFO reportFO)
        {
            int N = 1;

            foreach (var report in reportFO.Reports)
            {
                report.N = N;
                N++;
            }

            foreach (var item in reportFO.Departments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Units)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Payments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Nomenclature)
            {
                item.N = N;
                N++;
            }
        }

        XslCompiledTransform xslt = new XslCompiledTransform();
    }
}
