﻿using Drg.CashDeskLib.DB;
using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Xsl;

namespace Drg.CashDeskLib.ReportFO
{
    /// <summary>
    /// Генератор отчетов ФО
    /// </summary>
    public class ReportFOGenerator
    {
        // TODO: удалить параметры string fileName, string fileNameReserve 
        public ReportFOGenerator(LocalDB localDB, string xsltFileName, string fileName, string fileNameReserve, string cashDescId, string cashDescName, string cashDescNumber)
        {
            this.localDB = localDB;
            //this.fileName = fileName;
            //this.fileNameReserve = fileNameReserve;
            this.cashDescId = cashDescId;
            this.cashDescName = cashDescName;
            this.cashDescNumber = cashDescNumber;

            xslt = new XslCompiledTransform();
            xslt.Load(xsltFileName);
        }

        public XmlDocument Generate(params Guid[] sessionIds)
        {
            // загрузить отчет ФО из базы данных
            ReportFO reportFO = localDB.LoadReportFO(sessionIds);

            if (reportFO.Reports == null || reportFO.Reports.Length == 0)
            {
                return null;
            }
            else
            {
                reportFO.Date = DateTime.Now;

                // сформировать секцию Departments
                reportFO.Departments = new Item[]
                {
                    new Item
                    {
                        Code = cashDescId,
                        Value = cashDescName
                    }
                };

                // сформировать имя отчета в формате 18-081-0143
                foreach (var report in reportFO.Reports)
                {
                    // TODO: заменить на год из базы
                    report.Number = GenerateReportNumber(DateTime.Now.Year, cashDescNumber, report.Number);
                }

                // пронумеровать узлы
                Numerate(reportFO);

                // сформировать результат
                return Generate(reportFO);
            }
        }

        public static string GenerateReportNumber(int year, string cashDescNumber, string reportNumber)
        {
            return $"{year % 100}-{cashDescNumber}-{reportNumber.PadLeft(4, '0')}";
        }

        //public void Generate(params Guid[] sessionIds)
        //{
        //    // загрузить отчет ФО из базы данных
        //    ReportFO reportFO = localDB.LoadReportFO(sessionIds);

        //    if (reportFO.Reports != null && reportFO.Reports.Length > 0)
        //    {
        //        reportFO.Date = DateTime.Now;
                
        //        // сформировать секцию Departments
        //        reportFO.Departments = new Item[]
        //        {
        //            new Item
        //            {
        //                Code = cashDescId,
        //                Value = cashDescName
        //            }
        //        };

        //        // сформировать имя отчета в формате 18-081-0143
        //        foreach (var report in reportFO.Reports)
        //        {
        //            report.Number = $"{DateTime.Now.Year % 100}-{cashDescNumber}-{report.Number.PadLeft(4, '0')}";
        //        }

        //        // пронумеровать узлы
        //        Numerate(reportFO);

        //        // сформировать результат
        //        XmlDocument xmlDocument = Generate(reportFO);

        //        // записать его в выходной файл
        //        try
        //        {
        //            // штатная запись
        //            Save(xmlDocument, fileName, true);
        //        }
        //        catch
        //        {
        //            // резервнаяя запись в случае ошибки
        //            Save(xmlDocument, fileNameReserve, false);
        //        }
        //    }
        //}

        //static void Save(XmlDocument xmlDocument, string fileName, bool throwException)
        //{
        //    if (fileName.Contains("*"))
        //    {
        //        fileName = fileName.Replace("*", Guid.NewGuid().ToString());
        //    }

        //    try
        //    {
        //        using (XmlWriter xmlWriter = XmlWriter.Create(fileName, new XmlWriterSettings { Indent = true }))
        //        {
        //            xmlDocument.Save(xmlWriter);
        //        }
        //    }
        //    catch
        //    {
        //        if (throwException) throw;
        //    }
        //}

        /// <summary>
        /// Сериализовать отчет ФО в памяти
        /// </summary>
        /// <param name="reportFO"></param>
        /// <returns></returns>
        /// <remarks>https://social.msdn.microsoft.com/Forums/en-US/fe0dfec9-aa04-440e-9985-4f710c4a9a08/transform-an-xml-document-with-xslt-in-memory?forum=xmlandnetfx</remarks>
        XmlDocument Generate(ReportFO reportFO)
        {
            XmlDocument result = new XmlDocument();

            XmlSerializer serializer = new XmlSerializer(typeof(ReportFO));
            using (StringWriter stringWriter = new StringWriter())
            {
                serializer.Serialize(stringWriter, reportFO);

                using (StringReader stringReader = new StringReader(stringWriter.ToString()))
                {
                    using (XmlReader xmlReader = XmlReader.Create(stringReader))
                    {
                        using (XmlWriter xmlWriter = result.CreateNavigator().AppendChild())
                        {
                            xslt.Transform(xmlReader, xmlWriter);
                            xmlWriter.Close();
                        }
                    }
                }
            }

            return result;
        }

        private static void Numerate(ReportFO reportFO)
        {
            int N = 1;

            foreach (var report in reportFO.Reports)
            {
                report.N = N;
                N++;
            }

            foreach (var item in reportFO.Departments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Units)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Payments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Nomenclature)
            {
                item.N = N;
                N++;
            }
        }

        XslCompiledTransform xslt;
        LocalDB localDB;
        string fileName, fileNameReserve, cashDescId, cashDescName, cashDescNumber;
    }
}
