﻿using Drg.CashDeskLib.DB;
using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Xsl;

namespace Drg.CashDeskLib.ReportFO
{
    public class ReportFOGenerator
    {
        public ReportFOGenerator(LocalDB localDB, string xsltFileName)
        {
            this.localDB = localDB;
            xslt.Load(xsltFileName);
        }

        public void Generate(string cashDescId, string cashDescName, string cashDescNumber, Guid[] sessionIds, XmlWriter xmlWriter)
        {
            // загрузить отчет ФО из базы данных
            ReportFO reportFO = localDB.LoadReportFO(sessionIds);

            if (reportFO.Reports != null && reportFO.Reports.Length > 0)
            {
                // сформировать секцию Departments
                reportFO.Departments = new Item[]
                {
                    new Item
                    {
                        Code = cashDescId,
                        Value = cashDescName
                    }
                };

                // сформировать имя отчета в формате 18-081-0143
                foreach (var report in reportFO.Reports)
                {
                    report.Number = $"{DateTime.Now.Year % 100}-{cashDescNumber}-{report.Number.PadLeft(4, '0')}";
                }

                // сформировать результат
                Generate(reportFO, xmlWriter);
            }
        }

        public void Generate(ReportFO reportFO, XmlWriter xmlWriter)
        {
            Numerate(reportFO);

            XmlSerializer serializer = new XmlSerializer(typeof(ReportFO));
            using (StringWriter stringWriter = new StringWriter())
            {
                serializer.Serialize(stringWriter, reportFO);

                using (StringReader stringReader = new StringReader(stringWriter.ToString()))
                {
                    using (XmlReader xmlReader = XmlReader.Create(stringReader))
                    {
                        xslt.Transform(xmlReader, xmlWriter);
                    }
                }
            }
        }

        private static void Numerate(ReportFO reportFO)
        {
            int N = 1;

            foreach (var report in reportFO.Reports)
            {
                report.N = N;
                N++;
            }

            foreach (var item in reportFO.Departments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Units)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Payments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Nomenclature)
            {
                item.N = N;
                N++;
            }
        }

        XslCompiledTransform xslt = new XslCompiledTransform();
        LocalDB localDB;
    }
}
