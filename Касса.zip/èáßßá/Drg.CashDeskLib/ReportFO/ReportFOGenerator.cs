﻿using Drg.CashDeskLib.DB;
using System;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Xsl;

namespace Drg.CashDeskLib.ReportFO
{
    /// <summary>
    /// Генератор отчетов ФО
    /// </summary>
    public class ReportFOGenerator
    {
        public ReportFOGenerator(LocalDB localDB, string xsltFileName, string cashDescId, string cashDescName, string cashDescNumber)
        {
            this.localDB = localDB;
            this.cashDescId = cashDescId;
            this.cashDescName = cashDescName;
            this.cashDescNumber = cashDescNumber;

            xslt = new XslCompiledTransform();
            xslt.Load(xsltFileName);
        }

        public ReportFO CreateReportFO(params Guid[] sessionIds)
        {
            // загрузить отчет ФО из базы данных
            ReportFO reportFO = localDB.LoadReportFO(sessionIds);

            if (reportFO.Reports == null || reportFO.Reports.Length == 0)
            {
                return null;
            }
            else
            {
                reportFO.Date = DateTime.Now;

                // сформировать секцию Departments
                reportFO.Departments = new Item[]
                {
                    new Item
                    {
                        Code = cashDescId,
                        Value = cashDescName
                    }
                };

                // сформировать имя отчета в формате 18-081-0143
                foreach (var report in reportFO.Reports)
                {
                    // TODO: заменить на год из базы
                    report.Number = GenerateReportNumber(DateTime.Now.Year, cashDescNumber, report.Number);
                }

                // пронумеровать узлы
                Numerate(reportFO);

                return reportFO;
            }
        }

        public static string GenerateReportNumber(int year, string cashDescNumber, string reportNumber)
        {
            return $"{year % 100}-{cashDescNumber}-{reportNumber.PadLeft(4, '0')}";
        }

        public static int NumberFromReportNumber(string reportNumber)
        {
            if (string.IsNullOrEmpty(reportNumber))
                return 0;

            string[] ss = reportNumber.Split('-');
            return int.Parse(ss.Last());
        }

        /// <summary>
        /// Сериализовать отчет ФО в памяти
        /// </summary>
        /// <param name="reportFO"></param>
        /// <returns></returns>
        /// <remarks>https://social.msdn.microsoft.com/Forums/en-US/fe0dfec9-aa04-440e-9985-4f710c4a9a08/transform-an-xml-document-with-xslt-in-memory?forum=xmlandnetfx</remarks>
        public XmlDocument GenerateXml(ReportFO reportFO)
        {
            XmlDocument result = new XmlDocument();

            XmlSerializer serializer = new XmlSerializer(typeof(ReportFO));
            using (StringWriter stringWriter = new StringWriter())
            {
                serializer.Serialize(stringWriter, reportFO);
                string xml = stringWriter.ToString();
                using (StringReader stringReader = new StringReader(xml))
                {
                    using (XmlReader xmlReader = XmlReader.Create(stringReader))
                    {
                        using (XmlWriter xmlWriter = result.CreateNavigator().AppendChild())
                        {
                            xslt.Transform(xmlReader, xmlWriter);
                            xmlWriter.Close();
                        }
                    }
                }
            }

            return result;
        }

        private static void Numerate(ReportFO reportFO)
        {
            int N = 1;

            foreach (var report in reportFO.Reports)
            {
                report.N = N;
                N++;
            }

            foreach (var item in reportFO.Departments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Units)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Payments)
            {
                item.N = N;
                N++;
            }

            foreach (var item in reportFO.Nomenclature)
            {
                item.N = N;
                N++;
            }
        }

        XslCompiledTransform xslt;
        LocalDB localDB;
        string cashDescId, cashDescName, cashDescNumber;
    }
}
