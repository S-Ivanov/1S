﻿using Drg.PlanMenuReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.LocalDB
{
    /// <summary>
    /// Работа с локальной базой данных
    /// </summary>
    public class LocalDB
    {
        public LocalDB(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public List<Operator> GetOperators()
        {
            List<Operator> list = new List<Operator>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select k.КодПропуска, k.ФИО, k.Должность, k.ИНН, k.Пароль
from Кассиры k
where k.Блокировка = 0
order by k.ФИО",
                    connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Operator
                    {
                        CardID = reader.GetInt64(0),
                        FIO = reader.GetString(1),
                        Post = reader.IsDBNull(2) ? null : reader.GetString(2),
                        INN = reader.GetString(3),
                        Password = reader.GetString(4)
                    });
                }
            }
            return list;
        }

        public void SaveMenus(Menus menus)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // все операции выполняются в рамках одной транзакции
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // общее хранилище данных
                    MenuDataSet sourceMenuDataSet = new MenuDataSet();

                    // запись единиц измерения
                    // TODO: заменить на прямую запись аналогично номенклатуре - ?
                    MenuDataSetTableAdapters.ЕдиницыИзмеренияTableAdapter unitsAdapter = new MenuDataSetTableAdapters.ЕдиницыИзмеренияTableAdapter();
                    unitsAdapter.Connection = connection;
                    unitsAdapter.Transaction = transaction;
                    unitsAdapter.Fill(sourceMenuDataSet.ЕдиницыИзмерения);
                    foreach (var unit in menus.Units)
                    {
                        sourceMenuDataSet.ЕдиницыИзмерения.LoadDataRow(new object[] { unit.Id, unit.Name }, LoadOption.Upsert);
                    }
                    unitsAdapter.Update(sourceMenuDataSet);

                    // запись номенклатуры
                    SaveNomenclature(menus, connection, transaction);

                    // запись меню
                    SaveMenu(menus, connection, transaction);

                    // подтверждение транзакции
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            }
        }

        private static void SaveMenu(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand("select Id from Меню where Номер = @Номер and Дата = @Дата", connection, transaction);
            command.Parameters.Add("@Номер", SqlDbType.NChar, 15);
            command.Parameters.Add("@Дата", SqlDbType.DateTime);
            foreach (var menu in menus.AllMenus)
            {
                object idMenuObject = command.ExecuteScalar();
                Guid idMenu = idMenuObject == null || idMenuObject == DBNull.Value ? Guid.Empty : (Guid)idMenuObject;
                if (idMenu == Guid.Empty)
                {
                    // добавление меню
                }
                else
                {
                    // удаление элементов меню - ?
                }

                // добавление элементов меню
            }
        }

        private static void SaveNomenclature(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand nomenclatureCommand = new SqlCommand(
@"if exists(select 1 from Номенклатура where Id = @Id)
    update Номенклатура
    set Наименование = @Наименование, IdРодителя = @IdРодителя
    where Id = @Id
else
    insert Номенклатура (Id, Наименование, IdРодителя)
    values (@Id, @Наименование, @IdРодителя)",
                connection, transaction);
            nomenclatureCommand.Parameters.Add("@Id", SqlDbType.NChar, 15);
            nomenclatureCommand.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
            nomenclatureCommand.Parameters.Add("@IdРодителя", SqlDbType.NChar, 15);
            foreach (var parent in menus.Nomenclatures.Where(nm => string.IsNullOrEmpty(nm.IdParent)))
            {
                nomenclatureCommand.Parameters["@Id"].Value = parent.Id;
                nomenclatureCommand.Parameters["@Наименование"].Value = parent.Name;
                nomenclatureCommand.Parameters["@IdРодителя"].Value = DBNull.Value;
                nomenclatureCommand.ExecuteNonQuery();
                foreach (var nomenclature in parent.Childs)
                {
                    nomenclatureCommand.Parameters["@Id"].Value = nomenclature.Id;
                    nomenclatureCommand.Parameters["@Наименование"].Value = nomenclature.Name;
                    nomenclatureCommand.Parameters["@IdРодителя"].Value = nomenclature.IdParent;
                    nomenclatureCommand.ExecuteNonQuery();
                }
            }
        }

        string connectionString;
    }
}
