﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.MenuReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Drg.CashDeskLib.LocalDB
{
    /// <summary>
    /// Работа с локальной базой данных
    /// </summary>
    public class LocalDB
    {
        /// <summary>
        /// Работа с локальной базой данных
        /// </summary>
        /// <param name="connectionString">строка соединения с локальной базой данных</param>
        public LocalDB(string connectionString)
        {
            this.connectionString = connectionString;
        }

        /// <summary>
        /// Прочитать информацию о клиенте по коду пропуска
        /// </summary>
        /// <param name="cardCode">код пропуска</param>
        /// <returns></returns>
        public Client GetClient(uint cardCode)
        {
            Client client = null;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
@"select Id, ТабельныйНомер, ФИО, Фотография, ЛимитПоЗП, ОстатокЛПП
from Клиенты
where КодПропуска = @КодПропуска";
                    command.Parameters.AddWithValue("@КодПропуска", (long)cardCode);
                    using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow))
                    {
                        if (reader.Read())
                        {
                            var limitZP = reader.GetDecimal(4);
                            var lpp = reader.GetInt32(5);
                            client = new Client
                            {
                                CardCode = cardCode,
                                Id = reader.GetGuid(0),
                                TabNum = reader.GetString(1),
                                FIO = reader.GetString(2),
                                Photo = reader.IsDBNull(3) ? null : (byte[])reader.GetValue(3),
                                LimitZP = limitZP > 0 ? limitZP : 0,
                                LPP = lpp > 0 ? lpp : 0,
                                IsPhotoLoaded = true,
                                // имитация расходования лимита по з/п
                                UsedZP = 0
                            };
                        }
                    }
                }
            }
            return client;
        }

        /// <summary>
        /// Прочитать фотографию клиента
        /// </summary>
        /// <param name="clientId">Id клиента</param>
        /// <returns></returns>
        public byte[] GetClientPhoto(Guid clientId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "select Фотография from Клиенты where Id = @Id";
                    command.Parameters.AddWithValue("@Id", clientId);
                    object data = command.ExecuteScalar();
                    return data == null || data == DBNull.Value ? null : (byte[])data;
                }
            }
        }

        /// <summary>
        /// Прочитать полный список клиентов
        /// </summary>
        /// <returns></returns>
        public List<Client> GetClients()
        {
            List<Client> clients = new List<Client>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText =
@"select Id, ТабельныйНомер, ФИО, КодПропуска, ЛимитПоЗП, ОстатокЛПП
from Клиенты
order by ФИО, ТабельныйНомер";
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var limitZP = reader.GetDecimal(4);
                            var lpp = reader.GetInt32(5);
                            clients.Add(new Client
                            {
                                Id = reader.GetGuid(0),
                                TabNum = reader.GetString(1),
                                FIO = reader.GetString(2),
                                CardCode = (uint)reader.GetInt64(3),
                                LimitZP = limitZP > 0 ? limitZP : 0,
                                LPP = lpp > 0 ? lpp : 0,
                                IsPhotoLoaded = false,
                                // имитация расходования лимита по з/п
                                UsedZP = 0
                            });
                        }
                    }
                }
            }
            return clients;
        }

        /// <summary>
        /// Записать фотографию клиента
        /// </summary>
        /// <param name="client"></param>
        public void SavePhoto(Client client)
        {
            if (client == null)
                throw new ArgumentNullException(nameof(client));

            if (client.Photo != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = "update Клиенты set Фотография = @Фотография where ТабельныйНомер = @ТабельныйНомер";
                        command.Parameters.AddWithValue("@ТабельныйНомер", client.TabNum);
                        SqlParameter param = command.Parameters.Add("@Фотография", SqlDbType.VarBinary);
                        param.Value = client.Photo;
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        /// <summary>
        /// Получить список кассиров
        /// </summary>
        /// <returns></returns>
        public List<Operator> GetOperators()
        {
            List<Operator> list = new List<Operator>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select k.КодПропуска, k.ФИО, k.Должность, k.ИНН, k.Пароль
from Кассиры k
where k.Блокировка = 0
order by k.ФИО",
                    connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Operator
                    {
                        CardID = reader.GetInt64(0),
                        FIO = reader.GetString(1),
                        Post = reader.IsDBNull(2) ? null : reader.GetString(2),
                        INN = reader.GetString(3),
                        Password = reader.GetString(4)
                    });
                }
            }
            return list;
        }

        /// <summary>
        /// Прочитать номер нового заказа
        /// </summary>
        /// <returns></returns>
        public int GetNewOrderNumber()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select MAX(Номер)
from Заказы
where Год = @Год",
                    connection);
                command.Parameters.AddWithValue("@Год", DateTime.Today.Year);
                var result = command.ExecuteScalar();
                return result == DBNull.Value || result == null ? 1 : (int)result + 1;
            }
        }

        /// <summary>
        /// Получить даты меню в пределах диапазона дат
        /// </summary>
        /// <param name="dateStart">дата начала, включительно</param>
        /// <param name="dateEnd">дата окончания, включительно</param>
        /// <returns></returns>
        public List<DateTime> GetMenuDates(DateTime dateStart, DateTime dateEnd)
        {
            List<DateTime> dates = new List<DateTime>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"select Дата
from Меню
where @dateStart <= Дата and Дата <= @dateEnd 
order by Дата",
                    connection);
                command.Parameters.AddWithValue("@dateStart", dateStart);
                command.Parameters.AddWithValue("@dateEnd", dateEnd);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    dates.Add(reader.GetDateTime(0));
                }
            }
            return dates;
        }

        /// <summary>
        /// Добавить локальный элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool AddMenuItem(MenuItem menuItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"insert into ЭлементыМеню (Id, IdМеню, IdТовара, Количество, ЛокальныйЭлемент)
values (@Id, @IdМеню, @IdТовара, @Количество, @ЛокальныйЭлемент)",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                command.Parameters.AddWithValue("@IdМеню", menuItem.MenuId);
                command.Parameters.AddWithValue("@IdТовара", menuItem.ProductId);
                command.Parameters.AddWithValue("@Количество", menuItem.Count);
                command.Parameters.AddWithValue("@ЛокальныйЭлемент", menuItem.IsLocal);
                return command.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Прочитать план-меню
        /// </summary>
        /// <param name="date">дата меню</param>
        /// <returns></returns>
        public DataModel.Menu GetMenu(DateTime date)
        {
            DataModel.Menu menu = null;

            List<MenuItemGroup> menuItemGroups = new List<MenuItemGroup>();
            List<Tuple<string, MenuItem>> menuItems = new List<Tuple<string, MenuItem>>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // транзакция для исключения несогласованного чтения
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.Transaction = transaction;
                        command.CommandText = "select Id, Номер from Меню where Дата = @Дата";
                        command.Parameters.AddWithValue("@Дата", date.Date);
                        using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow))
                        {
                            if (!reader.Read())
                                return null;
                            else
                                menu = new DataModel.Menu
                                {
                                    Id = reader.GetGuid(0),
                                    Date = date.Date,
                                    Number = reader.GetString(1).TrimEnd()
                                };
                        }
                    }

                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.Transaction = transaction;
                        command.CommandText =
@"select 
	n.IdРодителя,
	i.Id,
	n.Наименование,
	m.Наименование,
	t.Цена,
	i.Количество,
    i.ЛокальныйЭлемент,
    i.IdМеню,
    i.IdТовара
from 
	ЭлементыМеню i
	inner join Товары t on i.IdТовара = t.Id
	inner join Номенклатура n on t.IdНоменклатуры = n.Id
	inner join ЕдиницыИзмерения m on t.IdЕдиницыИзмерения = m.Id
where 
	i.IdМеню = @IdМеню";
                        command.Parameters.AddWithValue("@IdМеню", menu.Id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                menuItems.Add(new Tuple<string, MenuItem>(
                                    reader.GetString(0),
                                    new MenuItem
                                    {
                                        Id = reader.GetGuid(1),
                                        Name = reader.GetString(2),
                                        Unit = reader.GetString(3),
                                        Price = reader.GetDecimal(4), //* reader.GetDecimal(5),
                                        Count = reader.GetDecimal(5),
                                        IsLocal = reader.IsDBNull(6) ? false : reader.GetBoolean(6),
                                        MenuId = reader.GetGuid(7),
                                        ProductId = reader.GetGuid(8)
                                    }));
                            }
                        }
                    }

                    if (menuItems.Count == 0)
                        return menu;

                    string menuGroupIds = string.Join(",", menuItems.Select(t => $"'{t.Item1}'"));
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.Transaction = transaction;
                        command.CommandText = $"select Id, Наименование from Номенклатура where Id in ({menuGroupIds})";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                menuItemGroups.Add(new MenuItemGroup
                                {
                                    Id = reader.GetString(0),
                                    Name = reader.GetString(1)
                                });
                            }
                        }
                    }

                    // подтверждение транзакции
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            }

            if (menuItemGroups.Count == 0)
                return menu;

            var menuItemsByGroup = menuItems.GroupBy(t => t.Item1).ToDictionary(g => g.Key, g => g.Select(t => t.Item2));
            menuItemGroups.ForEach(g =>
            {
                if (menuItemsByGroup.TryGetValue(g.Id, out IEnumerable<MenuItem> items))
                {
                    g.Items.AddRange(items.OrderBy(item => item.Name).ThenBy(item => item.Price).ThenBy(item => item.Count));
                }
            });

            menu.Items = menuItemGroups;

            return menu;
        }

        /// <summary>
        /// Записать заказ и оплату
        /// </summary>
        /// <param name="client">клиент</param>
        /// <param name="order">заказ</param>
        /// <param name="payments">оплата</param>
        public void SaveOrderAndPayment(Client client, Order order, Dictionary<Payment, decimal> payments)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    SqlCommand command1 = new SqlCommand(
@"declare @MaxOrderNumber int
select @MaxOrderNumber = COALESCE(MAX(Номер), 0)
from Заказы 
where Год = YEAR(@Дата) 

if @Номер <= @MaxOrderNumber
	set @Номер = @MaxOrderNumber + 1

insert into Заказы (Id, Дата, Номер, IdКлиента)
values (@Id, @Дата, @Номер, @IdКлиента)",
                        connection, transaction);
                    command1.Parameters.AddWithValue("@Id", order.Id);
                    command1.Parameters.AddWithValue("@Дата", order.DateTime);
                    command1.Parameters.AddWithValue("@Номер", order.Number);
                    if (client.Id == Guid.Empty)
                        command1.Parameters.AddWithValue("@IdКлиента", DBNull.Value);
                    else
                        command1.Parameters.AddWithValue("@IdКлиента", client.Id);
                    command1.ExecuteNonQuery();

                    SqlCommand command2 = new SqlCommand(
@"insert into ЭлементыЗаказов (Id, IdЗаказа, IdТовара, Количество)
values (@Id, @IdЗаказа, @IdТовара, @Количество)",
                        connection, transaction);
                    command2.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
                    command2.Parameters.AddWithValue("@IdЗаказа", order.Id);
                    command2.Parameters.Add("@IdТовара", SqlDbType.UniqueIdentifier);
                    command2.Parameters.Add(new SqlParameter { ParameterName = "@Количество", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
                    foreach (var orderItem in order.Items)
                    {
                        command2.Parameters["@Id"].Value = Guid.NewGuid();
                        command2.Parameters["@IdТовара"].Value = orderItem.MenuItem.ProductId;
                        command2.Parameters["@Количество"].Value = orderItem.Count;
                        command2.ExecuteNonQuery();
                    }

                    SqlCommand command3 = new SqlCommand(
@"insert into ОплатаЗаказов (Id, IdЗаказа, IdВидаОплаты, Сумма)
values (@Id, @IdЗаказа, @IdВидаОплаты, @Сумма)",
                        connection, transaction);
                    command3.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
                    command3.Parameters.AddWithValue("@IdЗаказа", order.Id);
                    command3.Parameters.Add("@IdВидаОплаты", SqlDbType.Int);
                    command3.Parameters.Add(new SqlParameter { ParameterName = "@Сумма", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
                    foreach (var kvp in payments)
                    {
                        command3.Parameters["@Id"].Value = Guid.NewGuid();
                        command3.Parameters["@IdВидаОплаты"].Value = (int)kvp.Key;
                        command3.Parameters["@Сумма"].Value = kvp.Value;
                        command3.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        /// <summary>
        /// Изменить количество в элементе меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <param name="newCount"></param>
        /// <returns></returns>
        public bool ChangeMenuItemCount(MenuItem menuItem, decimal newCount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"update ЭлементыМеню 
set Количество = @Количество
where Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                command.Parameters.AddWithValue("@Количество", newCount);
                return command.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Удалить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <returns></returns>
        public bool DeleteMenuItem(MenuItem menuItem)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
@"delete from ЭлементыМеню 
where Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", menuItem.Id);
                return command.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Записать планы-меню
        /// </summary>
        /// <param name="menus"></param>
        public void SaveMenus(Menus menus)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // все операции записи выполняются в рамках одной транзакции
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // запись единиц измерения
                    SaveUnits(menus, connection, transaction);

                    // запись номенклатуры
                    SaveNomenclature(menus, connection, transaction);

                    // запись товаров
                    SaveProducts(menus, connection, transaction);

                    // запись меню
                    SaveMenu(menus, connection, transaction);

                    // подтверждение транзакции
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            }
        }

        private void SaveUnits(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from ЕдиницыИзмерения where Id = @Id)
    update ЕдиницыИзмерения
    set Наименование = @Наименование
    where Id = @Id
else
    insert ЕдиницыИзмерения (Id, Наименование)
    values (@Id, @Наименование)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.Char, 4);
            command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 25);
            foreach (var unit in menus.Units)
            {
                command.Parameters["@Id"].Value = unit.Id;
                command.Parameters["@Наименование"].Value = unit.Name;
                command.ExecuteNonQuery();
            }
        }

        // TODO: изменить запись товаров
        private void SaveProducts(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Товары where Id = @Id)
    update Товары
    set IdНоменклатуры = @IdНоменклатуры, IdЕдиницыИзмерения = @IdЕдиницыИзмерения, Цена = @Цена, Количество = @Количество
    where Id = @Id
else
    insert Товары (Id, IdНоменклатуры, IdЕдиницыИзмерения, Цена, Количество)
    values (@Id, @IdНоменклатуры, @IdЕдиницыИзмерения, @Цена, @Количество)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command.Parameters.Add("@IdНоменклатуры", SqlDbType.NChar, 15);
            command.Parameters.Add("@IdЕдиницыИзмерения", SqlDbType.Char, 4);
            command.Parameters.Add(new SqlParameter { ParameterName = "@Цена", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            command.Parameters.Add(new SqlParameter { ParameterName = "@Количество", SqlDbType = SqlDbType.Decimal, Precision = 8, Scale = 2 });
            foreach (var kvp in menus.Products)
            {
                command.Parameters["@Id"].Value = kvp.Key;
                command.Parameters["@IdНоменклатуры"].Value = kvp.Value.NomenclatureId;
                command.Parameters["@IdЕдиницыИзмерения"].Value = kvp.Value.UnitId;
                command.Parameters["@Цена"].Value = kvp.Value.Price;
                command.Parameters["@Количество"].Value = kvp.Value.Count;
                command.ExecuteNonQuery();
            }
        }

        // TODO: изменить запись элементов меню
        private static void SaveMenu(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command1 = new SqlCommand("select Id from Меню where Номер = @Номер and Дата = @Дата", connection, transaction);
            command1.Parameters.Add("@Номер", SqlDbType.NChar, 15);
            command1.Parameters.Add("@Дата", SqlDbType.DateTime);

            SqlCommand command2 = new SqlCommand("insert Меню (Id, Номер, Дата) values (@Id, @Номер, @Дата)", connection, transaction);
            command2.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command2.Parameters.Add("@Номер", SqlDbType.NChar, 15);
            command2.Parameters.Add("@Дата", SqlDbType.DateTime);

            SqlCommand command3 = new SqlCommand("delete from ЭлементыМеню where IdМеню = @IdМеню", connection, transaction);
            command3.Parameters.Add("@IdМеню", SqlDbType.UniqueIdentifier);

            SqlCommand command4 = new SqlCommand(
@"insert ЭлементыМеню (Id, IdМеню, IdТовара) 
values (@Id, @IdМеню, @IdТовара)",
                connection, transaction);
            command4.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
            command4.Parameters.Add("@IdМеню", SqlDbType.UniqueIdentifier);
            command4.Parameters.Add("@IdТовара", SqlDbType.UniqueIdentifier);

            foreach (var menu in menus.AllMenus)
            {
                command1.Parameters["@Номер"].Value = menu.Number;
                command1.Parameters["@Дата"].Value = menu.DateTime.Date;
                object idMenuObject = command1.ExecuteScalar();
                Guid idMenu = idMenuObject == null || idMenuObject == DBNull.Value ? Guid.Empty : (Guid)idMenuObject;
                if (idMenu == Guid.Empty)
                {
                    // добавление меню
                    idMenu = Guid.NewGuid();
                    command2.Parameters["@Id"].Value = idMenu;
                    command2.Parameters["@Номер"].Value = menu.Number;
                    command2.Parameters["@Дата"].Value = menu.DateTime.Date;
                    command2.ExecuteNonQuery();
                }
                else
                {
                    // удаление элементов меню
                    command3.Parameters["@IdМеню"].Value = idMenu;
                    command3.ExecuteNonQuery();
                }

                // добавление элементов меню
                foreach (var menuItem in menu.Items)
                {
                    command4.Parameters["@Id"].Value = Guid.NewGuid();
                    command4.Parameters["@IdМеню"].Value = idMenu;
                    command4.Parameters["@IdТовара"].Value = menuItem.Id;
                    command4.ExecuteNonQuery();
                }
            }
        }

        private static void SaveNomenclature(Menus menus, SqlConnection connection, SqlTransaction transaction)
        {
            SqlCommand command = new SqlCommand(
@"if exists(select 1 from Номенклатура where Id = @Id)
    update Номенклатура
    set Наименование = @Наименование, IdРодителя = @IdРодителя
    where Id = @Id
else
    insert Номенклатура (Id, Наименование, IdРодителя)
    values (@Id, @Наименование, @IdРодителя)",
                connection, transaction);
            command.Parameters.Add("@Id", SqlDbType.NChar, 15);
            command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
            command.Parameters.Add("@IdРодителя", SqlDbType.NChar, 15);
            foreach (var parent in menus.Nomenclatures.Where(nm => string.IsNullOrEmpty(nm.IdParent)))
            {
                command.Parameters["@Id"].Value = parent.Id;
                command.Parameters["@Наименование"].Value = parent.Name;
                command.Parameters["@IdРодителя"].Value = DBNull.Value;
                command.ExecuteNonQuery();
                foreach (var nomenclature in parent.Childs)
                {
                    command.Parameters["@Id"].Value = nomenclature.Id;
                    command.Parameters["@Наименование"].Value = nomenclature.Name;
                    command.Parameters["@IdРодителя"].Value = nomenclature.IdParent;
                    command.ExecuteNonQuery();
                }
            }
        }

        string connectionString;
    }
}
