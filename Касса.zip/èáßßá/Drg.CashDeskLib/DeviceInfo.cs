﻿using Drg.Equipment;
using System;

namespace Drg.CashDeskLib
{
    public class DeviceInfo : IDisposable
    {
        public IDevice Device { get; set; }
        public DeviceError DeviceError { get; set; }

        public void Dispose()
        {
            Device?.Dispose();
        }
    }
}
