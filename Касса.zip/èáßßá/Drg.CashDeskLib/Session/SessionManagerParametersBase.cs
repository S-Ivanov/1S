﻿using Drg.Equipment.KKM;

namespace Drg.CashDeskLib.Session
{
    public class SessionManagerParametersBase
    {
        public bool HasKKM { get; set; }

        public bool KkmHasError { get; set; }

        public SessionState KkmSessionState { get; set; }

        public SessionState DbSessionState { get; set; }
    }
}
