﻿namespace Drg.CashDeskLib.Session
{
    public class SessionManagerParameters : SessionManagerParametersBase
    {
        public bool FnChanged { get; set; }

        public bool OperatorChanged { get; set; }
    }
}
