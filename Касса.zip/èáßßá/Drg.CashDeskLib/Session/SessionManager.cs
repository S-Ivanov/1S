﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.Session
{
    public class SessionManager
    {
        public void CloseSession(
            SessionManagerParametersBase parameters,
            Action closeKKMSessionAction,
            Action closeDbSessionAction)
        {
            string stringInfo = new string(
                new char[]
                {
                    parameters.HasKKM ? '1' : '0',
                    parameters.KkmHasError ? '1' : '0',
                    ((uint)parameters.KkmSessionState).ToString()[0],
                    ((uint)parameters.DbSessionState).ToString()[0],
                });

            switch (stringInfo)
            {
                case "1000":
                    // нет действий
                    break;
                case "1001":
                case "1002":
                    closeDbSessionAction();
                    break;
                case "1010":
                    closeKKMSessionAction();
                    break;
                case "1011":
                case "1012":
                    closeKKMSessionAction();
                    closeDbSessionAction();
                    break;
                case "1020":
                    closeKKMSessionAction();
                    break;
                case "1021":
                case "1022":
                    closeKKMSessionAction();
                    closeDbSessionAction();
                    break;
                default:
                    if (Regex.IsMatch(stringInfo, GetRegExpPattern("(0**0)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11*0)")))
                    {
                        // нет действий
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(0**1)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(0**2)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11*1)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11*2)")))
                    {
                        closeDbSessionAction();
                    }
                    break;
            }
        }

        public void OpenSession(
            SessionManagerParameters parameters,
            Action closeKKMSessionAction,
            Action closeDbSessionAction,
            Action openKKMSessionAction,
            Action openDbSessionAction)
        {
            string stringInfo = new string(
                new char[]
                {
                    parameters.HasKKM ? '1' : '0',
                    parameters.KkmHasError ? '1' : '0',
                    ((uint)parameters.KkmSessionState).ToString()[0],
                    parameters.FnChanged ? '1' : '0',
                    ((uint)parameters.DbSessionState).ToString()[0],
                    parameters.OperatorChanged ? '1' : '0'
                });

            switch (stringInfo)
            {
                case "100010":
                case "100011":
                    openKKMSessionAction();
                    closeDbSessionAction();
                    openDbSessionAction();
                    break;
                case "101000":
                    openDbSessionAction();
                    break;
                case "101001":
                case "101100":
                    closeKKMSessionAction();
                    openKKMSessionAction();
                    openDbSessionAction();
                    break;
                case "101010":
                    // нет действий
                    break;
                case "101011":
                case "101021":
                case "101101":
                    closeKKMSessionAction();
                    openKKMSessionAction();
                    closeDbSessionAction();
                    openDbSessionAction();
                    break;
                case "101020":
                    closeDbSessionAction();
                    openDbSessionAction();
                    break;
                default:
                    if (Regex.IsMatch(stringInfo, GetRegExpPattern("(0***0*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11**0*)")))
                    {
                        openDbSessionAction();
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(0***10)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11**10)")))
                    {
                        // нет действий
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(0***11)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(0***2*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11**11)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(11**2*)")))
                    {
                        closeDbSessionAction();
                        openDbSessionAction();
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(10000*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(1001**)")))
                    {
                        openKKMSessionAction();
                        openDbSessionAction();
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(10002*)")))
                    {
                        openKKMSessionAction();
                        closeDbSessionAction();
                        openDbSessionAction();
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(10111*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(10112*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(10211*)")) ||
                        Regex.IsMatch(stringInfo, GetRegExpPattern("(10212*)")))
                    {
                        closeKKMSessionAction();
                        openKKMSessionAction();
                        closeDbSessionAction();
                        openDbSessionAction();
                    }
                    else if (Regex.IsMatch(stringInfo, GetRegExpPattern("(10210*)")))
                    {
                        closeKKMSessionAction();
                        openKKMSessionAction();
                        openDbSessionAction();
                    }
                    break;
            }
        }

        string GetRegExpPattern(string pattern) => pattern.Replace("*", @"\d");
    }
}
