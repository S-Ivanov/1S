﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.CardReader;

namespace Drg.CashDeskLib.Equipment
{
    public static class CardReader
    {
        /// <summary>
        /// Создать считыватель пропусков
        /// </summary>
        /// <returns></returns>
        public static ICardReader Create(CashDeskConfiguration cashDeskConfiguration)
        {
            return cashDeskConfiguration.CardReaderEmulator ? new Drg.EquipmentEmulators.CardReader(cashDeskConfiguration.CardReaderEmulatorFileName) : null;
        }
    }
}
