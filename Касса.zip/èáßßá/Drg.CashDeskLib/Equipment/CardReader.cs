﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.CardReader;

namespace Drg.CashDeskLib.Equipment
{
    public static class CardReader
    {
        /// <summary>
        /// Создать считыватель пропусков
        /// </summary>
        /// <returns></returns>
        public static ICardReader Create(CashDeskConfiguration cashDeskConfiguration) =>
            cashDeskConfiguration.CardReaderEmulator ? 
            (ICardReader)(new EquipmentEmulators.CardReader(cashDeskConfiguration.CardReaderEmulatorFileName)) : 
            (ICardReader)(new Drg.Equipment.CardReaderAtol.CardReader(cashDeskConfiguration.CardReaderPort, cashDeskConfiguration.CardReaderBaudRate));
    }
}
