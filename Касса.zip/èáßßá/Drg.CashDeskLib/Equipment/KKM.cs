﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.KKM;

namespace Drg.CashDeskLib.Equipment
{
    public static class KKM
    {
        /// <summary>
        /// Создать ККМ
        /// </summary>
        /// <returns></returns>
        public static IKKM Create(CashDeskConfiguration cashDeskConfiguration)
        {
            return cashDeskConfiguration.KKMEmulator ? new Drg.EquipmentEmulators.KKM(cashDeskConfiguration.KkmEmulatorFileName) : null;
        }
    }
}
