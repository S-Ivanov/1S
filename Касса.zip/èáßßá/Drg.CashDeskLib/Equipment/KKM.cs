﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.KKM;

namespace Drg.CashDeskLib.Equipment
{
    public static class KKM
    {
        /// <summary>
        /// Создать ККМ
        /// </summary>
        /// <returns></returns>
        public static IKKM Create(CashDeskConfiguration cashDeskConfiguration)
        {
            return 
                cashDeskConfiguration.KKMEmulator ? 
                (IKKM)new Drg.EquipmentEmulators.KKM(cashDeskConfiguration.KKMEmulatorFileName) :
                new Drg.Equipment.KKMAtol10_3_1.KKM(cashDeskConfiguration.KKMTimeOut);
        }
    }
}
