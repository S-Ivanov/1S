﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib.Equipment
{
    public static class PayTerminal
    {
        /// <summary>
        /// Создать платежный терминал
        /// </summary>
        /// <returns></returns>
        public static IPayTerminal Create(CashDeskConfiguration cashDeskConfiguration)
        {
            return cashDeskConfiguration.PayTerminalEmulator ? new Drg.EquipmentEmulators.PayTerminal(cashDeskConfiguration.PayTerminalEmulatorFileName) : null;
        }
    }
}
