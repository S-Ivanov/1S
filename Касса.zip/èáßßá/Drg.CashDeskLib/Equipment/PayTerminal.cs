﻿using Drg.CashDeskLib.Configuration;
using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib.Equipment
{
    public static class PayTerminal
    {
        /// <summary>
        /// Создать платежный терминал
        /// </summary>
        /// <param name="cashDeskConfiguration">конфигурация</param>
        /// <param name="charLineLength">ширина ленты ККМ в символах - для печати слипов</param>
        /// <returns></returns>
        public static IPayTerminal Create(CashDeskConfiguration cashDeskConfiguration, int charLineLength) =>
            cashDeskConfiguration.PayTerminalEmulator ?
            (IPayTerminal)new Drg.EquipmentEmulators.PayTerminal(cashDeskConfiguration.PayTerminalEmulatorFileName) :
            new Drg.Equipment.PayTerminalAtol.PayTerminal(
                charLineLength, 
                cashDeskConfiguration.PayTerminalpathAC, 
                cashDeskConfiguration.PayTerminalPathDB, 
                cashDeskConfiguration.PayTerminalProtocol);
    }
}
