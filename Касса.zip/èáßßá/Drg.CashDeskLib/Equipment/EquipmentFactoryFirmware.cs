﻿using System;
using Drg.CashDeskLib.Configuration;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib.Equipment
{
    public class EquipmentFactoryFirmware : EquipmentFactory
    {
        public EquipmentFactoryFirmware(CashDeskConfiguration cashDeskConfiguration)
        {
            this.cashDeskConfiguration = cashDeskConfiguration;
        }

        public override ICardReader CreateCardReader()
        {
            throw new NotImplementedException();
        }

        public override IKKM CreateKKM()
        {
            throw new NotImplementedException();
        }

        public override IPayTerminal CreatePayTerminal()
        {
            throw new NotImplementedException();
        }

        CashDeskConfiguration cashDeskConfiguration;
    }
}
