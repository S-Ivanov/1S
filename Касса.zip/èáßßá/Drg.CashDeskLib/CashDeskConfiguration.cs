﻿using System;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration : XmlDeserializeConfigSectionHandler
    {
        #region Общие настройки

        /// <summary>
        /// Идентификатор кассы
        /// </summary>
        public Guid CashDeskID { get; set; }

        /// <summary>
        /// Наименование кассы
        /// </summary>
        public string CashDeskName { get; set; }

        /// <summary>
        /// Использовать эмуляторы оборудования
        /// </summary>
        public bool UseEmulators { get; set; }

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; set; }

        #endregion Общие настройки

        #region Настройки считывателя пропусков

        #region Настройки эмулятора считывателя пропусков

        /// <summary>
        /// Полное имя файла управления эмулятором считывателя пропусков
        /// </summary>
        public string CardReaderEmulatorFileName { get; set; }

        #endregion Настройки эмулятора считывателя пропусков

        #region Настройки боевого считывателя пропусков

        /// <summary>
        /// Номер COM-порта 
        /// </summary>
        public int CardReaderPort { get; set; }

        /// <summary>
        /// Скорость обмена, бод
        /// </summary>
        public int CardReaderBaudRate { get; set; }

        #endregion Настройки боевого считывателя пропусков

        #endregion Настройки считывателя пропусков

        #region Настройки ККМ

        #region Настройки эмулятора ККМ

        /// <summary>
        /// Полное имя файла управления эмулятором ККМ
        /// </summary>
        public string KkmEmulatorFileName { get; set; }

        #endregion Настройки эмулятора ККМ

        #endregion Настройки ККМ

        #region Настройки банковского терминала

        #region Настройки эмулятора банковского терминала

        /// <summary>
        /// Полное имя файла управления эмулятором банковского терминала
        /// </summary>
        public string PayTerminalEmulatorFileName { get; set; }

        #endregion Настройки эмулятора банковского терминала

        #endregion Настройки банковского терминала
    }
}
