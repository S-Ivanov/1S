﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration
    {
        /// <summary>
        /// Используется расчет наличными
        /// </summary>
        public bool UseCash { get; set; }
    }
}
