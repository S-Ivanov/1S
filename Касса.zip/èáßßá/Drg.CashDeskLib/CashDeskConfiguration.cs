﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration
    {
        #region Общие настройки

        /// <summary>
        /// Использовать оплату наличными
        /// </summary>
        public bool UseCash { get; set; }

        #endregion Общие настройки

        #region Настройки считывателя пропусков

        /// <summary>
        /// Использовать считыватель пропусков
        /// </summary>
        public bool UseCardReader { get; set; }

        /// <summary>
        /// Номер COM-порта 
        /// </summary>
        public int CardReaderPort { get; set; }

        /// <summary>
        /// Скорость обмена, бод
        /// </summary>
        public int CardReaderBaudRate { get; set; }

        #endregion Настройки считывателя пропусков
    }
}
