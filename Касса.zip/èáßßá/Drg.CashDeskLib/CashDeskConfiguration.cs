﻿namespace Drg.CashDeskLib
{
    /// <summary>
    /// Конфигурация кассы
    /// </summary>
    public class CashDeskConfiguration
    {
        #region Общие настройки

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; set; }

        #endregion Общие настройки

        #region Настройки считывателя пропусков

        #endregion Настройки считывателя пропусков
    }
}
