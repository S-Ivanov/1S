﻿namespace Drg.CashDeskLib
{
    /// <summary>
    /// Кассир
    /// </summary>
    public class Operator
    {
        /// <summary>
        /// Код пропуска
        /// </summary>
        public long CardID { get; set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; set; }

        /// <summary>
        /// Фамилия, инициалы
        /// </summary>
        public string FInitials => Utils.StringUtils.FIO2FInitials(FIO);

        /// <summary>
        /// Должность
        /// </summary>
        public string Post { get; set; }

        /// <summary>
        /// ИНН
        /// </summary>
        public string INN { get; set; }

        /// <summary>
        /// Пароль
        /// </summary>
        public string Password { get; set; }
    }
}
