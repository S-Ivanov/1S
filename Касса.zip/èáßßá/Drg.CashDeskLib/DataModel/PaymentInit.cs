﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public static class PaymentInit
    {
        /// <summary>
        /// Cформировать автоматическую разноску суммы заказа по видам оплат
        /// </summary>
        /// <param name="payments">доступные клиенту варианты оплаты</param>
        /// <param name="zpLimit">лимит по питанию в счет з/п</param>
        /// <param name="lppNominal">номинал талона ЛПП</param>
        /// <param name="talon120Nominal">номинал талона 120</param>
        /// <param name="sum">сумма заказа</param>
        /// <returns>заполненный словарь оплат: вариант оплаты + сумма оплаты</returns>
        /// <remarks>
        /// Например, сумма заказа = 250, оплата талоном ЛПП
        /// Предлагаемая разноска: 1 талон ЛПП + 2 руб. в счет з/п
        /// Возврат:
        /// - (код ЛПП) = 248
        /// - (код з/п) = 2
        /// </remarks>
        public static Dictionary<Payment, decimal> Init(List<Payment> payments, decimal zpLimit, decimal lppNominal, decimal talon120Nominal, decimal sum)
        {
            Dictionary<Payment, decimal> result = new Dictionary<Payment, decimal>();

            // приоритеты:
            // - ЛПП
            // - з/п
            // - безнал
            // - нал
            // - талон 120

            if (sum > 0 && payments.Contains(Payment.LPP) && sum >= lppNominal)
            {
                result.Add(Payment.LPP, lppNominal);
                sum -= lppNominal;
            }

            if (sum > 0 && zpLimit > 0 && payments.Contains(Payment.ZP))
            {
                var value = sum > zpLimit ? zpLimit : sum;
                result.Add(Payment.ZP, value);
                sum -= value;
            }

            if (sum > 0 && payments.Contains(Payment.BankCard))
            {
                result.Add(Payment.BankCard, sum);
                sum = 0;
            }

            if (sum > 0 && payments.Contains(Payment.Cash))
            {
                result.Add(Payment.Cash, sum);
                sum = 0;
            }

            if (sum > talon120Nominal && payments.Contains(Payment.Talon120))
            {
                var talonSum = (int)(sum / talon120Nominal) * talon120Nominal;
                result.Add(Payment.Talon120, talonSum);
            }

            return result;
        }
    }
}
