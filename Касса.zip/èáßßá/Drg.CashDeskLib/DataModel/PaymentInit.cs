﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public static class PaymentInit
    {
        /// <summary>
        /// Cформировать автоматическую разноску суммы заказа по видам оплат
        /// </summary>
        /// <param name="payments">доступные клиенту варианты оплаты + лимиты использования (руб.); если лимит больше 0, он учитывается</param>
        /// <param name="lppNominal">номинал талона ЛПП</param>
        /// <param name="talon120Nominal">номинал талона 120</param>
        /// <param name="sum">сумма заказа</param>
        /// <returns>варианты оплаты + сумма оплаты</returns>
        /// <remarks>
        /// Например, сумма заказа = 250, оплата талоном ЛПП
        /// Предлагаемая разноска: 1 талон ЛПП + 2 руб. в счет з/п
        /// Возврат:
        /// - (код ЛПП) = 248
        /// - (код з/п) = 2
        /// </remarks>
        public static IDictionary<Payment, decimal> Init(IDictionary<Payment, decimal> payments, decimal lppNominal, decimal talon120Nominal, decimal sum)
        {
            var result = new Dictionary<Payment, decimal>();

            // приоритеты:
            // - ЛПП
            // - з/п
            // - безнал
            // - нал
            // - талон 120

            if (payments.TryGetValue(Payment.LPP, out decimal limit) && limit >= lppNominal && sum >= lppNominal)
            {
                result.Add(Payment.LPP, lppNominal);
                if (sum > lppNominal)
                    //result.Add(Payment.ZP, sum - lppNominal);
                    AddZP(payments, sum - lppNominal, result);
            }
            //else if (payments.TryGetValue(Payment.ZP, out limit) && limit != 0)
            //{
            //    result.Add(Payment.ZP, (limit < 0 || limit >= sum) ? sum : limit);
            //}
            else if (!AddZP(payments, sum, result))
            {
                if (payments.ContainsKey(Payment.BankCard))
                {
                    result.Add(Payment.BankCard, sum);
                }
                else if (payments.ContainsKey(Payment.Cash))
                {
                    result.Add(Payment.Cash, sum);
                }
                else if (payments.ContainsKey(Payment.Talon120) && sum >= talon120Nominal)
                {
                    result.Add(Payment.Talon120, (int)(sum / talon120Nominal) * talon120Nominal);
                }
            }
            return result;
        }

        static bool AddZP(IDictionary<Payment, decimal> payments, decimal sum, IDictionary<Payment, decimal> result)
        {
            if (payments.TryGetValue(Payment.ZP, out decimal limit) && limit != 0)
            {
                result.Add(Payment.ZP, (limit < 0 || limit >= sum) ? sum : limit);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Cформировать автоматическую разноску суммы заказа по видам оплат
        /// </summary>
        /// <param name="paymentTypes">варианты оплаты + стоимость единицы оплаты</param>
        /// <param name="limits">варианты оплаты + лимит использования в единицах оплаты</param>
        /// <param name="sum">сумма</param>
        /// <param name="startPaymentType">инициируемый вариант оплаты</param>
        /// <returns>варианты оплаты + количество единиц оплаты</returns>
        /// <remarks>
        /// Например, сумма заказа = 250, оплата талоном ЛПП
        /// Предлагаемая разноска: 1 талон ЛПП + 2 руб. в счет з/п
        /// Возврат:
        /// - (код ЛПП) = 1
        /// - (код з/п) = 2
        /// </remarks>
        public static IDictionary<Payment, decimal> Init0(IDictionary<Payment, decimal> paymentTypes, IDictionary<Payment, decimal> limits, decimal sum, ref Payment startPaymentType)
        {
            var result = new Dictionary<Payment, decimal>();
            decimal limit;
            switch (startPaymentType)
            {
                case Payment.ZP:
                    if (!limits.TryGetValue(Payment.ZP, out limit))
                        result.Add(Payment.ZP, sum);
                    else
                    {
                        if (limit <= 0 || limit >= sum)
                            result.Add(Payment.ZP, sum);
                        else
                        {
                            result.Add(Payment.ZP, limit);
                            if (paymentTypes.ContainsKey(Payment.BankCard))
                            {
                                result.Add(Payment.BankCard, sum - limit);
                                startPaymentType = Payment.BankCard;
                            }
                            else if (paymentTypes.ContainsKey(Payment.Cash))
                            {
                                result.Add(Payment.Cash, sum - limit);
                                startPaymentType = Payment.Cash;
                            }
                        }
                    }
                    break;
                case Payment.LPP:
                    if (!limits.TryGetValue(Payment.LPP, out limit) || limit < 1)
                    {
                        result.Add(Payment.ZP, sum);
                        startPaymentType = Payment.ZP;
                    }
                    else
                    {
                        // у человека есть 1 или более талонов ЛПП
                        var lppSum = paymentTypes[Payment.LPP];
                        if (sum < lppSum)
                            result.Add(Payment.ZP, sum);
                        else if (sum == lppSum)
                            result.Add(Payment.LPP, 1);
                        else // if (sum > lppSum)
                        {
                            result.Add(Payment.LPP, 1);
                            result.Add(Payment.ZP, sum - lppSum);
                            startPaymentType = Payment.ZP;
                        }
                    }
                    break;
                case Payment.BankCard:
                    if (paymentTypes.ContainsKey(Payment.BankCard))
                        result.Add(Payment.BankCard, sum);
                    else if (paymentTypes.ContainsKey(Payment.Cash))
                    {
                        result.Add(Payment.Cash, sum);
                        startPaymentType = Payment.Cash;
                    }
                    break;
                case Payment.Cash:
                    if (paymentTypes.ContainsKey(Payment.Cash))
                        result.Add(Payment.Cash, sum);
                    else if (paymentTypes.ContainsKey(Payment.BankCard))
                    {
                        result.Add(Payment.BankCard, sum);
                        startPaymentType = Payment.BankCard;
                    }
                    break;
                case Payment.Talon120:
                    var talonCost = paymentTypes[Payment.Talon120];
                    var talonCount = sum / talonCost;
                    if (talonCount >= 1)
                        result.Add(Payment.Talon120, Math.Truncate(talonCount));
                    var moreSum = sum - Math.Truncate(talonCount) * talonCost;
                    if (moreSum > 0)
                    {
                        if (paymentTypes.ContainsKey(Payment.BankCard))
                        {
                            result.Add(Payment.BankCard, moreSum);
                            startPaymentType = Payment.BankCard;
                        }
                        else if (paymentTypes.ContainsKey(Payment.Cash))
                        {
                            result.Add(Payment.Cash, moreSum);
                            startPaymentType = Payment.Cash;
                        }
                    }
                    break;
            }

            return result;
        }
    }
}
