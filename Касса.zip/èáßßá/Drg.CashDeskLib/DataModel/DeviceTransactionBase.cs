﻿using Drg.Equipment;
using System.Transactions;

namespace Drg.CashDeskLib.DataModel
{
    public abstract class DeviceTransactionBase<T> : IEnlistmentNotification
    {
        public void DoAction(T parameters)
        {
            Transaction currentTx = Transaction.Current;
            if (currentTx != null)
                currentTx.EnlistVolatile(this, EnlistmentOptions.None);

            this.parameters = parameters;
            DoActionInternal(parameters);
        }

        #region IEnlistmentNotification

        public void Commit(Enlistment enlistment)
        {
        }

        public void InDoubt(Enlistment enlistment)
        {
        }

        public void Prepare(PreparingEnlistment preparingEnlistment)
        {
            // однофазная транзакция - Commit() не вызывается
            preparingEnlistment.Done();
        }

        public void Rollback(Enlistment enlistment)
        {
            DoRollbackInternal(parameters);
        }

        #endregion IEnlistmentNotification

        protected abstract void DoActionInternal(T parameters);
        protected abstract void DoRollbackInternal(T parameters);

        T parameters;
    }
}
