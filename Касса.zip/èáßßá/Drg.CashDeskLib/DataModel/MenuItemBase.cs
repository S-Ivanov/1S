﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItemBase 
    {
        /// <summary>
        /// Идентификатор номенклатуры
        /// </summary>
        public string IdNomenclature { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Родительский элемент
        /// </summary>
        public MenuItemBase Parent { get; set; }

        /// <summary>
        /// Дочерние элементы
        /// </summary>
        public List<MenuItemBase> Children { get; } = new List<MenuItemBase>();
    }
}
