﻿using Drg.Equipment.KKM;
using System;

namespace Drg.CashDeskLib.DataModel
{
    public abstract class KKMTransactionBase<T> : DeviceTransactionBase<T>
    {
        public KKMTransactionBase(IKKM kkm)
        {
            this.kkm = kkm;
        }

        protected override void DoActionInternal(T parameters)
        {
            try
            {
                // отправить нефискальный чек на ККМ
                DoPrint(parameters);
            }
            catch (Exception ex)
            {
                // перадать ошибку пользователю для возможной обработки
                FixErrorEventArgs args = new FixErrorEventArgs { Device = kkm, Exception = ex };
                FixErrorEvent?.Invoke(this, args);
                if (!args.ErrorFixed)
                    throw;
            }
        }

        protected abstract void DoPrint(T parameters);

        protected override void DoRollbackInternal(T parameters)
        {
        }

        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent;

        protected IKKM kkm;
    }
}
