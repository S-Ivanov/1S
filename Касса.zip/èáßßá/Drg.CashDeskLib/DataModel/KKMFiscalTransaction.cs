﻿using Drg.Equipment.KKM;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMFiscalTransaction : KKMTransactionBase<Order>
    {
        public KKMFiscalTransaction(IKKM kkm) : base(kkm)
        {
        }

        protected override void DoPrint(Order order)
        {
            // отправить чек на ККМ
            kkm.PrintReceipt(GetKKMReceipt(order));
        }

        Drg.Equipment.KKM.Receipt GetKKMReceipt(Order order)
        {
            var result = new Drg.Equipment.KKM.Receipt
            {
                ReceiptType = order is OrderReturn ? ReceiptType.LIBFPTR_RT_BUY_RETURN : ReceiptType.LIBFPTR_RT_BUY
            };

            var fiscal = order.Items.Where(_ => _.Payment == Payment.BankCard || _.Payment == Payment.Cash);

            foreach (var orderItem in fiscal.OrderBy(_ => _.MenuItem.Name).ThenBy(_ => _.Price))
            {
                result.Items.Add(
                    new ReceiptItem
                    {
                        Name = orderItem.MenuItem.Name,
                        Price = (double)orderItem.Price,
                        Count = (double)orderItem.Count,
                        TaxType = orderItem.MenuItem.VATCode < 0 ? TaxType.CUSTOM : (TaxType)orderItem.MenuItem.VATCode,
                        VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                    });
            }

            var orderItemsByPayment = fiscal.GroupBy(_ => _.Payment);
            foreach (var paymentGroup in orderItemsByPayment)
            {
                // привести тип оплаты
                PaymentType paymentType =
                    paymentGroup.Key == Payment.BankCard ?
                    PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                    PaymentType.LIBFPTR_PT_CASH;

                result.Payments.Add(paymentType, (double)paymentGroup.Sum(_ => _.Sum));
            }

            return result;
        }
    }
}
