﻿using Atol.Drivers10.Fptr;
using Drg.Equipment.KKM;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMFiscalTransaction : KKMTransactionBase<Order>
    {
        public KKMFiscalTransaction(IKKM kkm) : base(kkm, 1)
        {
        }

        protected override void DoPrint(Order order)
        {
            // отправить чек на ККМ:
            Drg.Equipment.KKM.Receipt receipt = GetKKMReceipt(order);
            var header = MakeHeader(order, kkm.LineLength);

            // нефискальный заголовок
            kkm.PrintNonFiscalDocument(header, false);

            // фискальный чек
            kkm.PrintReceipt(receipt);
        }

        protected override void DoRollbackInternal(Order order)
        {
            //kkm.CancelReceipt();
        }

        Drg.Equipment.KKM.Receipt GetKKMReceipt(Order order)
        {
            var result = new Drg.Equipment.KKM.Receipt
            {
                ReceiptType = order is OrderReturn ? ReceiptType.LIBFPTR_RT_SELL_RETURN : ReceiptType.LIBFPTR_RT_SELL
            };

            var fiscal = order.Items.Where(_ => _.Payment == Payment.BankCard || _.Payment == Payment.Cash);

            foreach (var orderItem in fiscal.OrderBy(_ => _.MenuItem.Name).ThenBy(_ => _.Price))
            {
                result.Items.Add(
                    new ReceiptItem
                    {
                        Name = orderItem.MenuItem.Name,
                        Price = (double)orderItem.Price,
                        Count = (double)orderItem.Count,
                        TaxType = orderItem.MenuItem.VATCode < 0 ? TaxType.CUSTOM : (TaxType)orderItem.MenuItem.VATCode,
                        VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                    });
            }

            var orderItemsByPayment = fiscal.GroupBy(_ => _.Payment);
            foreach (var paymentGroup in orderItemsByPayment)
            {
                // привести тип оплаты
                PaymentType paymentType =
                    paymentGroup.Key == Payment.BankCard ?
                    PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                    PaymentType.LIBFPTR_PT_CASH;

                result.Payments.Add(paymentType, (double)paymentGroup.Sum(_ => _.Sum));
            }

            return result;
        }
    }
}
