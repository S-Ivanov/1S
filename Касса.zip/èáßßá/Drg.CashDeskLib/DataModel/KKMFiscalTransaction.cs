﻿using Drg.Equipment.KKM;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMFiscalTransaction : KKMTransactionBase<Dictionary<Payment, List<OrderItem>>>
    {
        public KKMFiscalTransaction(IKKM kkm) : base(kkm)
        {
        }

        protected override void DoPrint(Dictionary<Payment, List<OrderItem>> parameters)
        {
            // отправить чек на ККМ
            kkm.PrintReceipt(GetKKMReceipt(parameters));
        }

        Drg.Equipment.KKM.Receipt GetKKMReceipt(Dictionary<Payment, List<OrderItem>> parameters)
        {
            var result = new Drg.Equipment.KKM.Receipt { ReceiptType = ReceiptType.LIBFPTR_RT_BUY };

            IEnumerable<OrderItem> orderItems = parameters
                .SelectMany(kvp => kvp.Value)
                .OrderBy(_ => _.MenuItem.Name)
                .ThenBy(_ => _.Price);

            foreach (var orderItem in orderItems)
            {
                result.Items.Add(
                    new Drg.Equipment.KKM.ReceiptItem
                    {
                        Name = orderItem.MenuItem.Name,
                        Price = (double)orderItem.Price,
                        Count = (double)orderItem.Count,
                        TaxType = orderItem.MenuItem.VATCode < 0 ? TaxType.CUSTOM : (TaxType)orderItem.MenuItem.VATCode,
                        VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                    });
            }

            foreach (var kvp in parameters)
            {
                // привести тип оплаты
                PaymentType paymentType =
                    kvp.Key == Payment.BankCard ?
                    PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                    PaymentType.LIBFPTR_PT_CASH;

                result.Payments.Add(paymentType, (double)kvp.Value.Sum(_ => _.Sum));
            }

            return result;
        }
    }
}
