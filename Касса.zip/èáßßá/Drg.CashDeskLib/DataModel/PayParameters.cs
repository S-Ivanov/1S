﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Информация для оплаты
    /// </summary>
    public class PayParameters
    {
        public Dictionary<Payment, decimal> Payments { get; set; }
    }
}
