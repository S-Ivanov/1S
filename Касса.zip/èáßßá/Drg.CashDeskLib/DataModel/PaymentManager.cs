﻿using Drg.Equipment.KKM;
using Stateless;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.DataModel
{
    public class PaymentManager
    {
        public PaymentManager(Drg.Equipment.KKM.IKKM kkm)
        {
            this.kkm = kkm;

            InitStateMachine();
        }

        public void Pay(Order order)
        {
            this.order = order;
            NoPaymentTypes.Clear();
            machine.Fire(Trigger.Start);
        }

        private void InitStateMachine()
        {
            machine.Configure(State.Start)
                .Permit(Trigger.Start, State.MakePayment);

            machine.Configure(State.MakePayment)
                .OnEntry(
                    () =>
                    {
                        this.usedTerminal = this.usedKKMFiscal = false;
                        receipt = MakeReceipt(this.order);
                        machine.Fire(Trigger.StartPayment);
                    })
                .PermitDynamic(Trigger.StartPayment,
                    () =>
                    {
                        if (this.receipt == null || !this.receipt.Payments.Any())
                            return State.PaymentFailed;
                        else if (this.receipt.Payments.ContainsKey(Payment.BankCard))
                            return State.TerminalPayment;
                        else if (this.receipt.Payments.ContainsKey(Payment.Cash))
                            return State.KKMFiscal;
                        else
                            return State.KKMNotFiscal;
                    });

            machine.Configure(State.TerminalPayment)
                .OnEntry(
                    () =>
                    {
                        this.terminalResult = DoTerminalPayment();
                        machine.Fire(Trigger.FinishTerminal);
                    })
                .PermitDynamic(Trigger.FinishTerminal,
                    () =>
                    {
                        if (this.terminalResult == NO_ERROR)
                        {
                            // сохранить результаты в БД
                            this.usedTerminal = true;
                            return State.KKMFiscal;
                        }
                        else
                        {
                            if (this.terminalResult == ERROR)
                            {
                                // сохранить результаты в БД
                                LockPaymentType(Payment.BankCard);
                            }
                            return State.MakePayment;
                        }
                    });

            machine.Configure(State.KKMFiscal)
                .OnEntry(
                    () =>
                    {
                        this.kkmResult = DoKKMFiscal();
                        machine.Fire(Trigger.FinishKKMFiscal);
                    })
                .PermitDynamic(Trigger.FinishKKMFiscal,
                    () =>
                    {
                        if (this.kkmResult == ERROR)
                            return State.KKMFiscalFixError;
                        else
                        {
                            this.usedKKMFiscal = true;
                            if (this.receipt.Payments.ContainsKey(Payment.ZP) || this.receipt.Payments.ContainsKey(Payment.LPP) || this.receipt.Payments.ContainsKey(Payment.Talon120))
                                return State.KKMNotFiscal;
                            else
                                return State.FinishedOK;
                        }
                    });

            machine.Configure(State.KKMFiscalFixError)
                .OnEntry(
                    () =>
                    {
                        this.kkmResult = DoKKMFiscalFixError(this.kkmResult);
                        machine.Fire(Trigger.FinishKKMFiscalFixError);
                    })
                .PermitDynamic(Trigger.FinishKKMFiscalFixError,
                    () =>
                    {
                        if (kkmResult == NO_ERROR)
                            return State.KKMFiscal;
                        else
                        {
                            if (usedTerminal)
                                CancelTerminal();
                            if (usedKKMFiscal)
                                CancelKKMFiscal();

                            LockPaymentType(Payment.BankCard);
                            LockPaymentType(Payment.Cash);

                            return State.MakePayment;
                        }
                    });

            machine.Configure(State.KKMNotFiscal)
                .OnEntry(
                    () =>
                    {
                        this.kkmResult = DoKKMNotFiscal();
                        machine.Fire(Trigger.FinishKKMNotFiscal);
                    })
                .PermitDynamic(Trigger.FinishKKMNotFiscal, () => this.kkmResult == NO_ERROR ? State.FinishedOK : State.KKMNotFiscalFixError);

            machine.Configure(State.KKMNotFiscalFixError)
                .OnEntry(
                    () =>
                    {
                        this.kkmResult = DoKKMNotFiscalFixError(this.kkmResult);
                        machine.Fire(Trigger.FinishKKMNotFiscalFixError);
                    })
                .PermitDynamic(Trigger.FinishKKMNotFiscalFixError,
                    () =>
                    {
                        if (this.kkmResult == NO_ERROR)
                            return State.KKMNotFiscal;
                        else
                        {
                            if (this.usedTerminal)
                                CancelTerminal();
                            if (this.usedKKMFiscal)
                                CancelKKMFiscal();

                            LockPaymentType(Payment.ZP);
                            LockPaymentType(Payment.LPP);
                            LockPaymentType(Payment.Talon120);

                            return State.PaymentFailed;
                        }
                    });
        }

        private Receipt MakeReceipt(Order order)
        {
            // TODO: передавать в аргументах события заблокированные виды оплат
            MakeReceiptEventArgs args = new MakeReceiptEventArgs { Order = order, NoPaymentTypes = this.NoPaymentTypes };
            MakeReceiptEvent?.Invoke(this, args);
            return args.Receipt;
        }

        private int DoKKMFiscal()
        {
            // сформировать фискальный чек ККМ
            this.kkmReceipt = GetKKMReceipt();

            // TODO: проверить, что есть записи фискального чека

            try
            {
                // отправить чек на ККМ
                kkm.DoAction((int)Drg.Equipment.KKM.PrintAction.PrintReceipt, this.kkmReceipt);
                return NO_ERROR;
            }
            catch (Exception ex)
            {
                this.exception = ex;
                return ERROR;
            }
        }

        Drg.Equipment.KKM.Receipt GetKKMReceipt()
        {
            var result = new Drg.Equipment.KKM.Receipt { ReceiptType = Drg.Equipment.KKM.ReceiptType.LIBFPTR_RT_BUY };

            // выделить из сводного чека позиции, которые нужно обрабатывать в фискальном чеке
            var orderItemsByPayment = this.receipt.Payments.Where(kvp => kvp.Key == Payment.BankCard || kvp.Key == Payment.Cash);

            if (orderItemsByPayment.Any())
            {
                IEnumerable<OrderItem> orderItems = orderItemsByPayment
                    .SelectMany(kvp => kvp.Value)
                    .OrderBy(_ => _.MenuItem.Name)
                    .ThenBy(_ => _.Price);

                foreach (var orderItem in orderItems)
                {
                    result.Items.Add(
                        new Drg.Equipment.KKM.ReceiptItem
                        {
                            Name = orderItem.MenuItem.Name,
                            Price = (double)orderItem.Price,
                            Count = (double)orderItem.Count,
                            TaxType = orderItem.MenuItem.VATCode < 0 ? Drg.Equipment.KKM.TaxType.CUSTOM : (Drg.Equipment.KKM.TaxType)orderItem.MenuItem.VATCode,
                            VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                        });
                }

                foreach (var kvp in orderItemsByPayment)
                {
                    // привести тип оплаты
                    Drg.Equipment.KKM.PaymentType paymentType =
                        kvp.Key == Payment.BankCard ?
                        Drg.Equipment.KKM.PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                        Drg.Equipment.KKM.PaymentType.LIBFPTR_PT_CASH;

                    result.Payments.Add(paymentType, (double)kvp.Value.Sum(_ => _.Sum));
                }
            }

            return result;
        }

        private int DoKKMNotFiscal()
        {
            List<TextInfo> notFiscalReceipt = GetNotFiscalReceipt();

            // TODO: проверить, что есть записи нефискального чека

            try
            {
                // отправить нефискальный чек на ККМ
                kkm.DoAction((int)Drg.Equipment.KKM.PrintAction.PrintNotFiscal, notFiscalReceipt);
                return NO_ERROR;
            }
            catch (Exception ex)
            {
                this.exception = ex;
                return ERROR;
            }
        }

        private List<TextInfo> GetNotFiscalReceipt()
        {
            List<TextInfo> result = new List<TextInfo>();

            result.Add(new TextInfo { Text = "Нефискальный чек" });

            // выделить из сводного чека позиции, которые нужно обрабатывать в фискальном чеке
            var orderItemsByPayment = this.receipt.Payments.Where(kvp => !(kvp.Key == Payment.BankCard || kvp.Key == Payment.Cash));

            if (orderItemsByPayment.Any())
            {
                IEnumerable<OrderItem> orderItems = orderItemsByPayment
                    .SelectMany(kvp => kvp.Value)
                    .OrderBy(_ => _.MenuItem.Name)
                    .ThenBy(_ => _.Price);

                // TODO: формировать нефискальный чек
            }

            return result;
        }

        private int DoKKMFiscalFixError(int errorCode) => DoKKMFixError(errorCode);

        private int DoKKMNotFiscalFixError(int errorCode) => DoKKMFixError(errorCode);

        private int DoKKMFixError(int errorCode)
        {
            if (errorCode == NO_ERROR)
                return errorCode;
            else
            {
                FixErrorEventArgs args = new FixErrorEventArgs { Exception = exception };
                FixErrorEvent?.Invoke(this, args);
                return args.ErrorFixed ? NO_ERROR : errorCode;
            }
        }

        private void CancelKKMFiscal()
        {
            // TODO: отменить фискальный чек
        }

        private void CancelTerminal()
        {
            // TODO: отменить оплату по банковской карте
        }

        private void LockPaymentType(Payment payment)
        {
            NoPaymentTypes.Add(payment);
        }

        private int DoTerminalPayment()
        {
            // TODO: выполнить оплату по банковской карте

            return NO_ERROR;
        }

        /// <summary>
        /// Событие для формирования чека на основе заказа
        /// </summary>
        public event EventHandler<MakeReceiptEventArgs> MakeReceiptEvent;

        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent;

        Drg.Equipment.KKM.IKKM kkm;
        StateMachine<State, Trigger> machine = new StateMachine<State, Trigger>(State.Start);
        bool usedTerminal = false, usedKKMFiscal = false;
        Order order;
        Receipt receipt;
        int terminalResult;
        int kkmResult;
        HashSet<Payment> NoPaymentTypes { get; set; } = new HashSet<Payment>();
        Drg.Equipment.KKM.Receipt kkmReceipt;
        Exception exception;

        const int NO_ERROR = 0;
        const int ERROR = 1;
        const int CANCEL = 2;

        enum Trigger
        {
            /// <summary>
            /// Начать работу
            /// </summary>
            Start,

            /// <summary>
            /// Начать оплату
            /// </summary>
            StartPayment,

            /// <summary>
            /// Закончить оплату через теримнал
            /// </summary>
            FinishTerminal,

            /// <summary>
            /// ККМ - закончить обработку фискального чека
            /// </summary>
            FinishKKMFiscal,

            /// <summary>
            /// ККМ - закончить обработку ошибки фискального чека
            /// </summary>
            FinishKKMFiscalFixError,

            /// <summary>
            /// ККМ - закончить обработку нефискального чека
            /// </summary>
            FinishKKMNotFiscal,

            /// <summary>
            /// ККМ - закончить обработку ошибки нефискального чека
            /// </summary>
            FinishKKMNotFiscalFixError,

            Finish
        }

        enum State
        {
            Start,

            /// <summary>
            /// Формирование оплаты
            /// </summary>
            MakePayment,

            /// <summary>
            /// Оплата через терминал
            /// </summary>
            TerminalPayment,

            /// <summary>
            /// Выход - нет доступных вариантов оплаты
            /// </summary>
            PaymentFailed,

            /// <summary>
            /// ККМ - обработка фискального чека
            /// </summary>
            KKMFiscal,

            /// <summary>
            /// ККМ - обработка ошибки фискального чека
            /// </summary>
            KKMFiscalFixError,

            /// <summary>
            /// ККМ - обработка нефискального чека
            /// </summary>
            KKMNotFiscal,

            /// <summary>
            /// ККМ - обработка ошибки нефискального чека
            /// </summary>
            KKMNotFiscalFixError,

            /// <summary>
            /// Выход - оплата завершена успешно
            /// </summary>
            FinishedOK
        }

    }
}
