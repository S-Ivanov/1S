﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class ProductReportItem
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string MeasureName { get; set; }
        public decimal Count { get; set; }
        public decimal ReturnCount { get; set; }
        public decimal Balance => Count - ReturnCount;
        public ProductReportItem Parent { get; set; }
        public List<ProductReportItem> Children { get; set; } = new List<ProductReportItem>();

        public string GroupName
        {
            get
            {
                string groupName = "";
                var parent = Parent;
                while (parent != null)
                {
                    groupName = string.IsNullOrEmpty(groupName) ? parent.Name : parent.Name + " / " + groupName;
                    parent = parent.Parent;
                }
                return groupName;
            }
        }
    }
}
