﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class ProductReportItem
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string MeasureName { get; set; }
        public decimal Count { get; set; }
        public decimal ReturnCount { get; set; }
        public ProductReportItem Parent { get; set; }
        public List<ProductReportItem> Children { get; set; } = new List<ProductReportItem>();
    }
}
