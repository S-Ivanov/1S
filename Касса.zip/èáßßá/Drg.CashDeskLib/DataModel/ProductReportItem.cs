﻿namespace Drg.CashDeskLib.DataModel
{
    public class ProductReportItem
    {
        public string Name { get; set; }
        public decimal Count { get; set; }
        public string GroupName { get; set; }
    }
}
