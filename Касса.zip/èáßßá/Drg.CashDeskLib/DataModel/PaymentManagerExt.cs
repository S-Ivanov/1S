﻿using Drg.CashDeskLib.DB;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Transactions;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Управление устройствами в процессе оплаты заказа
    /// </summary>
    public class PaymentManagerExt
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="kkm">ККМ</param>
        /// <param name="payTerminal">платежный терминал</param>
        /// <param name="localDB">база данных</param>
        /// <param name="textWrapper">перенос текста</param>
        /// <param name="slipCount">количество копий слипа</param>
        /// <param name="isTestMode">флаг тестового режима работы</param>
        /// <param name="returnCopies">количество копий чеков возврата</param>
        public PaymentManagerExt(
            IKKM kkm, 
            IPayTerminal payTerminal, 
            ILocalDBPayment localDB, 
            TextWrapper.TextWrapper textWrapper, 
            int slipCount, 
            bool isTestMode, 
            int returnCopies)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
            this.localDB = localDB;
            this.isTestMode = isTestMode;

            if (this.payTerminal != null && this.kkm != null)
                this.payTerminal.LineLength = this.kkm.LineLength;

            payTerminalTransaction = new PayTerminalTransaction(payTerminal, localDB);
            kkmNotFiscalTransaction = new KKMNotFiscalTransaction(kkm, textWrapper, returnCopies);
            kkmFiscalTransaction = new KKMFiscalTransaction(kkm);
            printSlipTransaction = new PrintSlipTransaction(kkm, slipCount);
        }

        /// <summary>
        /// Выполнить оплату/возврат чека
        /// </summary>
        /// <param name="session">смена</param>
        /// <param name="receipt">чек</param>
        /// <returns>ошибка устройства + варианты оплаты, которые нельзя использовать</returns>
        public Tuple<bool, PaymentManagerExtException, IEnumerable<Payment>> PayReceipt(Session session, Receipt receipt)
        {
            HashSet<Payment> receiptPayments = new HashSet<Payment>(receipt.Order.Items.Select(_ => _.Payment).Distinct());
            HashSet <Payment> usedPayments = new HashSet<Payment>();
            PaymentManagerExtException paymentManagerExtException = null;

            using (TransactionScope ts = new TransactionScope())
            {
                if (receipt.Order.ZP != 0 || receipt.Order.LPP != 0 || receipt.Order.Talon120 != 0)
                {
                    try
                    {
                        kkmNotFiscalTransaction.DoAction(receipt);
                        usedPayments.Add(Payment.ZP);
                        usedPayments.Add(Payment.LPP);
                        usedPayments.Add(Payment.Talon120);
                    }
                    catch (Drg.Equipment.DeviceException ex)
                    {
                        paymentManagerExtException = new PaymentManagerExtException(Drg.Equipment.Device.KKM, ex.DeviceError);
                    }
                    catch (Exception ex)
                    {
                        paymentManagerExtException = new PaymentManagerExtException(
                            Drg.Equipment.Device.KKM,
                            new Drg.Equipment.DeviceError
                            {
                                ErrorCode = Drg.Equipment.DeviceError.UNKNOWN_ERROR,
                                Description = ex.Message
                            });
                    }
                }

                if (receipt.Order.BankCard != 0)
                {
                    try
                    {
                        payTerminalTransaction.DoAction(
                            new PayTerminalTransactionArgs
                            {
                                SessionId = session.Id,
                                OrderId = receipt.Order.Id,
                                SessionNumber = (int)session.Number,
                                CheckNumber = receipt.Order.Number,
                                Sum = receipt.Order.BankCard,
                                IsReturn = receipt.Order is OrderReturn
                            });
                        usedPayments.Add(Payment.BankCard);
                        if (payTerminalTransaction.Canceled)
                        {
                            usedPayments.Add(Payment.BankCard);
                            // TODO: уточнить платеж налом
                            usedPayments.Add(Payment.Cash);
                            goto Exit;
                        }
                    }
                    catch (Drg.Equipment.DeviceException ex)
                    {
                        paymentManagerExtException = new PaymentManagerExtException(Drg.Equipment.Device.PayTerminal, ex.DeviceError);
                    }
                    catch (Exception ex)
                    {
                        // запомнить ошибку для возврата пользователю
                        paymentManagerExtException = new PaymentManagerExtException(
                            Drg.Equipment.Device.PayTerminal,
                            new Drg.Equipment.DeviceError
                            {
                                ErrorCode = Drg.Equipment.DeviceError.UNKNOWN_ERROR,
                                Description = ex.Message
                            });
                    }

                    // распечатать слип
                    try
                    {
                        printSlipTransaction.DoAction(payTerminalTransaction.SlipText);
                    }
                    catch
                    {
                    }
                }

                if (receipt.Order.BankCard != 0 || receipt.Order.Cash != 0)
                {
                    try
                    {
                        kkmFiscalTransaction.DoAction(receipt.Order);
                        usedPayments.Add(Payment.BankCard);
                        usedPayments.Add(Payment.Cash);
                    }
                    catch (Drg.Equipment.DeviceException ex)
                    {
                        paymentManagerExtException = new PaymentManagerExtException(Drg.Equipment.Device.KKM, ex.DeviceError);
                    }
                    catch (Exception ex)
                    {
                        // запомнить ошибку для возврата пользователю
                        paymentManagerExtException = new PaymentManagerExtException(
                            Drg.Equipment.Device.KKM,
                            new Drg.Equipment.DeviceError
                            {
                                ErrorCode = Drg.Equipment.DeviceError.UNKNOWN_ERROR,
                                Description = ex.Message
                            });
                    }
                }

                // сохранить оплату заказа или возврат
                if (paymentManagerExtException == null)
                {
                    localDB.SavePayment(session.Id, receipt, isTestMode);
                    if (receipt.Order.BankCard != 0)
                        localDB.SaveAuthorizationInfo(Guid.NewGuid(), session.Id, receipt.Order.Id, payTerminalTransaction.AuthorizationInfo);
                }

                Exit:

                ts.Complete();
            }

            return new Tuple<bool, PaymentManagerExtException, IEnumerable<Payment>>(
                payTerminalTransaction.Canceled,
                paymentManagerExtException, 
                receiptPayments.Except(usedPayments));
        }

        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent
        {
            add
            {
                kkmNotFiscalTransaction.FixErrorEvent += value;
                kkmFiscalTransaction.FixErrorEvent += value;
                printSlipTransaction.FixErrorEvent += value;
            }
            remove
            {
                kkmNotFiscalTransaction.FixErrorEvent -= value;
                kkmFiscalTransaction.FixErrorEvent -= value;
                printSlipTransaction.FixErrorEvent -= value;
            }
        }

        public event EventHandler<CancelEventArgs> OnBeforePayTerminalCancel
        {
            add
            {
                payTerminalTransaction.OnBeforePayTerminalCancel += value;
            }
            remove
            {
                payTerminalTransaction.OnBeforePayTerminalCancel -= value;
            }
        }

        PayTerminalTransaction payTerminalTransaction;
        KKMNotFiscalTransaction kkmNotFiscalTransaction;
        KKMFiscalTransaction kkmFiscalTransaction;
        PrintSlipTransaction printSlipTransaction;

        IKKM kkm;
        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
        bool isTestMode;
    }
}
