﻿using Drg.CashDeskLib.DB;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace Drg.CashDeskLib.DataModel
{
    public class PaymentManagerExt
    {
        public PaymentManagerExt(IKKM kkm, IPayTerminal payTerminal, ILocalDBPayment localDB, bool isTestMode)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
            this.localDB = localDB;
            this.isTestMode = isTestMode;

            payTerminalTransaction = new PayTerminalTransaction(payTerminal, localDB);
            kkmNotFiscalTransaction = new KKMNotFiscalTransaction(kkm);
            kkmFiscalTransaction = new KKMFiscalTransaction(kkm);
            printSlipTransaction = new PrintSlipTransaction(kkm);
        }

        /// <summary>
        /// Выполнить оплату чека
        /// </summary>
        /// <param name="receipt">чек</param>
        /// <returns>варианты оплаты, которые нельзя использовать</returns>
        public IEnumerable<Payment> PayReceipt(Session session, Order order, string tabNum, Receipt receipt)
        {
            HashSet<Payment> allPayments = new HashSet<Payment>(Enum.GetValues(typeof(Payment)).Cast<Payment>());
            HashSet<Payment> usedPayments = new HashSet<Payment>();

            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    var notFiscal = receipt.Payments.Where(kvp => kvp.Key == Payment.ZP || kvp.Key == Payment.LPP || kvp.Key == Payment.Talon120);
                    if (notFiscal.Any())
                    {
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        kkmNotFiscalTransaction.DoAction(notFiscal.ToDictionary(kvp => kvp.Key, kvp => kvp.Value));
                        usedPayments.Add(Payment.ZP);
                        usedPayments.Add(Payment.LPP);
                        usedPayments.Add(Payment.Talon120);
                    }

                    if (receipt.Payments.ContainsKey(Payment.BankCard))
                    {
                        if (payTerminal == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.PayTerminal };
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        payTerminalTransaction.DoAction(
                            new PayTerminalTransactionArgs
                            {
                                SessionNumber = (int)session.Number,
                                CheckNumber = order.Number,
                                Sum = receipt.Payments[Payment.BankCard].Sum(_ => _.Sum)
                            });
                        usedPayments.Add(Payment.BankCard);

                        // распечатать слип
                        try
                        {
                            printSlipTransaction.DoAction(payTerminalTransaction.SlipText);
                        }
                        catch
                        {
                        }
                    }

                    var fiscal = receipt.Payments.Where(kvp => kvp.Key == Payment.BankCard || kvp.Key == Payment.Cash);
                    if (fiscal.Any())
                    {
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        kkmFiscalTransaction.DoAction(fiscal.ToDictionary(kvp => kvp.Key, kvp => kvp.Value));
                        usedPayments.Add(Payment.BankCard);
                        usedPayments.Add(Payment.Cash);
                    }

                    // сохранить оплату заказа
                    localDB.SavePayment(session.Id, order, tabNum, receipt, isTestMode);

                    ts.Complete();
                }
            }
            catch (PaymentManagerExtException)
            {
                throw;
            }
            catch
            {
            }

            return allPayments.Except(usedPayments);
        }

        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent
        {
            add
            {
                kkmNotFiscalTransaction.FixErrorEvent += value;
                kkmFiscalTransaction.FixErrorEvent += value;
                printSlipTransaction.FixErrorEvent += value;
            }
            remove
            {
                kkmNotFiscalTransaction.FixErrorEvent -= value;
                kkmFiscalTransaction.FixErrorEvent -= value;
                printSlipTransaction.FixErrorEvent -= value;
            }
        }

        PayTerminalTransaction payTerminalTransaction;
        KKMNotFiscalTransaction kkmNotFiscalTransaction;
        KKMFiscalTransaction kkmFiscalTransaction;
        PrintSlipTransaction printSlipTransaction;

        IKKM kkm;
        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
        bool isTestMode;
    }
}
