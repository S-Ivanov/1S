﻿using Drg.CashDeskLib.DB;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace Drg.CashDeskLib.DataModel
{
    public class PaymentManagerExt
    {
        public PaymentManagerExt(IKKM kkm, IPayTerminal payTerminal, ILocalDBPayment localDB, TextWrapper.TextWrapper textWrapper, bool isTestMode)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
            this.localDB = localDB;
            this.isTestMode = isTestMode;

            payTerminalTransaction = new PayTerminalTransaction(payTerminal, localDB);
            kkmNotFiscalTransaction = new KKMNotFiscalTransaction(kkm, textWrapper);
            kkmFiscalTransaction = new KKMFiscalTransaction(kkm);
            printSlipTransaction = new PrintSlipTransaction(kkm);
        }

        /// <summary>
        /// Выполнить оплату чека
        /// </summary>
        /// <param name="receipt">чек</param>
        /// <returns>варианты оплаты, которые нельзя использовать</returns>
        public IEnumerable<Payment> PayReceipt(Session session, Receipt receipt)
        {
            HashSet<Payment> allPayments = new HashSet<Payment>(Enum.GetValues(typeof(Payment)).Cast<Payment>());
            HashSet<Payment> usedPayments = new HashSet<Payment>();

            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    //var notFiscal = receipt.Order.Items.Where(_ => _.Payment == Payment.ZP || _.Payment == Payment.LPP || _.Payment == Payment.Talon120);
                    //if (notFiscal.Any())
                    if (receipt.Order.ZP != 0 || receipt.Order.LPP != 0 || receipt.Order.Talon120 != 0)
                    {
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        kkmNotFiscalTransaction.DoAction(receipt);
                        usedPayments.Add(Payment.ZP);
                        usedPayments.Add(Payment.LPP);
                        usedPayments.Add(Payment.Talon120);
                    }

                    //if (receipt.Order.Items.Exists(_ => _.Payment == Payment.BankCard))
                    if (receipt.Order.BankCard != 0)
                    {
                        if (payTerminal == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.PayTerminal };
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        payTerminalTransaction.DoAction(
                            new PayTerminalTransactionArgs
                            {
                                SessionNumber = (int)session.Number,
                                CheckNumber = receipt.Order.Number,
                                //Sum = receipt.Order.Items.Where(_ => _.Payment == Payment.BankCard).Sum(_ => _.Sum),
                                Sum = receipt.Order.BankCard,
                                IsReturn = receipt.Order is OrderReturn
                            });
                        usedPayments.Add(Payment.BankCard);

                        // распечатать слип
                        try
                        {
                            printSlipTransaction.DoAction(payTerminalTransaction.SlipText);
                        }
                        catch
                        {
                        }
                    }

                    //if (receipt.Order.Items.Where(_ => _.Payment == Payment.BankCard || _.Payment == Payment.Cash).Any())
                    if (receipt.Order.BankCard != 0 || receipt.Order.Cash != 0)
                    {
                        if (kkm == null)
                            throw new PaymentManagerExtException { Device = Drg.Equipment.Device.KKM };

                        kkmFiscalTransaction.DoAction(receipt.Order);
                        usedPayments.Add(Payment.BankCard);
                        usedPayments.Add(Payment.Cash);
                    }

                    // сохранить оплату заказа или возврат
                    localDB.SavePayment(session.Id, receipt, isTestMode);

                    ts.Complete();
                }
            }
            catch (PaymentManagerExtException)
            {
                throw;
            }
            catch
            {
            }

            return allPayments.Except(usedPayments);
        }

        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent
        {
            add
            {
                kkmNotFiscalTransaction.FixErrorEvent += value;
                kkmFiscalTransaction.FixErrorEvent += value;
                printSlipTransaction.FixErrorEvent += value;
            }
            remove
            {
                kkmNotFiscalTransaction.FixErrorEvent -= value;
                kkmFiscalTransaction.FixErrorEvent -= value;
                printSlipTransaction.FixErrorEvent -= value;
            }
        }

        PayTerminalTransaction payTerminalTransaction;
        KKMNotFiscalTransaction kkmNotFiscalTransaction;
        KKMFiscalTransaction kkmFiscalTransaction;
        PrintSlipTransaction printSlipTransaction;

        IKKM kkm;
        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
        bool isTestMode;
    }
}
