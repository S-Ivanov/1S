﻿using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Группа элементов меню
    /// </summary>
    public class MenuItemGroup 
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Элементы меню
        /// </summary>
        public List<MenuItem> Items => items;
        List<MenuItem> items = new List<MenuItem>();
    }
}
