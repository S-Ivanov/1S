﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.DataModel
{
    public class Receipt
    {
        public IDictionary<Payment, List<OrderItem>> Payments { get; set; } = new Dictionary<Payment, List<OrderItem>>();
    }
}
