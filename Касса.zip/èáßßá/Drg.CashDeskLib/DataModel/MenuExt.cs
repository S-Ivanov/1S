﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Меню
    /// </summary>
    public class MenuExt
    {
        /// <summary>
        /// Идентификатор меню
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Номер меню
        /// </summary>
        public string Number { get; set; }

        /// <summary>
        /// Дата меню
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Элементы меню
        /// </summary>
        public List<MenuItemBaseExt> Items { get; set; }
    }
}
