﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    public class DeviceAddedEventArgs : EventArgs
    {
        public DeviceAddedEventArgs(string message, int errorCode, string description) : base()
        {
            Message = message;
            ErrorCode = errorCode;
            Description = description;
        }

        public bool HasError => ErrorCode != 0;

        public readonly string Message;
        public readonly int ErrorCode;
        public readonly string Description;
    }
}
