﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Событие для исправления ошибки
    /// </summary>
    /// <remarks>
    /// Если пользователь устранил ошибку, ErrorFixed = true
    /// </remarks>
    public class FixErrorEventArgs : EventArgs
    {
        /// <summary>
        /// Ошибка
        /// </summary>
        public Exception Exception { get; set; }

        /// <summary>
        /// Индикатор того, что пользователь устранил ошибку
        /// </summary>
        public bool ErrorFixed { get; set; }
    }
}
