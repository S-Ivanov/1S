﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Смена
    /// </summary>
    public class Session
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Номер смены
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// Начало смены
        /// </summary>
        public DateTime Begin { get; set; }

        /// <summary>
        /// Конец смены
        /// </summary>
        public DateTime? End { get; set; }

        /// <summary>
        /// Идентификатор кассира
        /// </summary>
        public Guid OperatorId { get; set; }

        public bool IsEmpty => Id == Guid.Empty;

        public bool IsClosed => !IsEmpty && End != null;
    }
}
