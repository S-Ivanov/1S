﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Параметр универсального события
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DataModelEventArgs<T> : EventArgs
    {
        public T Data { get; set; }
    }
}
