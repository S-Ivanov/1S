﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Информация для отмены оплаты
    /// </summary>
    public class UnPayParameters
    {
    }
}
