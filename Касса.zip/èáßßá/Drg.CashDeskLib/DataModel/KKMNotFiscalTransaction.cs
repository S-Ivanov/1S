﻿using Drg.Equipment.KKM;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMNotFiscalTransaction : KKMTransactionBase<Dictionary<Payment, List<OrderItem>>>
    {
        public KKMNotFiscalTransaction(IKKM kkm) : base(kkm)
        {
        }

        protected override void DoPrint(Dictionary<Payment, List<OrderItem>> parameters)
        {
            // отправить нефискальный чек на ККМ
            kkm.PrintNonFiscalDocument(GetNotFiscalReceipt(parameters));
        }

        private List<TextInfo> GetNotFiscalReceipt(Dictionary<Payment, List<OrderItem>> parameters)
        {
            List<TextInfo> result = new List<TextInfo>();

            result.Add(new TextInfo { Text = "Нефискальный чек" });

            //// выделить из сводного чека позиции, которые нужно обрабатывать в фискальном чеке
            //var orderItemsByPayment = receipt.Payments.Where(kvp => !(kvp.Key == Payment.BankCard || kvp.Key == Payment.Cash));

            //if (orderItemsByPayment.Any())
            //{
            //    IEnumerable<OrderItem> orderItems = orderItemsByPayment
            //        .SelectMany(kvp => kvp.Value)
            //        .OrderBy(_ => _.MenuItem.Name)
            //        .ThenBy(_ => _.Price);

            //    // TODO: формировать нефискальный чек
            //}

            return result;
        }

    }
}
