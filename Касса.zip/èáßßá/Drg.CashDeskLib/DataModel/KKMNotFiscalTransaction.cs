﻿using Drg.Equipment.KKM;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMNotFiscalTransaction : KKMTransactionBase<Receipt>
    {
        public KKMNotFiscalTransaction(IKKM kkm, TextWrapper.TextWrapper textWrapper) : base(kkm)
        {
            this.textWrapper = textWrapper;
        }

        protected override void DoPrint(Receipt receipt)
        {
            // отправить нефискальный чек на ККМ
            decimal nominalLPP = CashDesk.Instance.Nominals.LPP;
            decimal nominalTalon120 = CashDesk.Instance.Nominals.Talon120;
            kkm.PrintNonFiscalDocument(GetNotFiscalReceipt(receipt, this.textWrapper, kkm.LineLength, nominalLPP, nominalTalon120));
        }

        public static List<TextInfo> GetNotFiscalReceipt(Receipt receipt, TextWrapper.TextWrapper textWrapper, uint lineLength, decimal nominalLPP, decimal nominalTalon120)
        {
            List<TextInfo> result = new List<TextInfo>();

            // длина максимальной суммы подвала
            int orderTotalSumSigns = receipt.Order.Items.Sum(_ => _.Sum).ToString("N2").Length;

            // длина максимальной суммы тела
            int orderSumSigns = receipt.Order.Items.Max(_ => _.Sum).ToString("N2").Length;

            // сумма чека в счёт ЗП
            // используется для вычисления общей затраченной суммы из ЗП работником
            //decimal orderSumZP = receipt.Order.Items.Where(_ => _.Payment == Payment.ZP).Sum(_ => _.Sum);
            decimal orderSumZP = receipt.Order.ZP;

            // сумма чека в счёт ЛПП
            // используется для вычисления общей затраченной суммы из ЛПП работником
            //decimal orderSumLPP = receipt.Order.Items.Where(_ => _.Payment == Payment.LPP).Sum(_ => _.Sum);
            decimal orderSumLPP = receipt.Order.LPP;

            // сумма чека в счёт талона 120
            //decimal orderSumTalon120 = receipt.Order.Items.Where(_ => _.Payment == Payment.Talon120).Sum(_ => _.Sum);
            decimal orderSumTalon120 = receipt.Order.Talon120;

            // формировать заголовок 1
            string orderNumber = receipt.Order.Number.ToString();
            string orderDateTime = receipt.Order.DateTime.ToString();

            string title11 = receipt.Order is OrderReturn ? "ВОЗВРАТ" : "ОПЛАТА";
            string title12 = title11 + " " + "Заказ № ";
            int spacesCount = (int)lineLength - (title12.Length + orderNumber.Length + orderDateTime.Length) >= 1 ? (int)lineLength - (title12.Length + orderNumber.Length + orderDateTime.Length) : 1;
            result.Add(TextInfo.CreateLeft(title12 + orderNumber + new String(' ', spacesCount) + orderDateTime));
            result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));

            // формировать заголовок 2 только при наличии клиента
            if (receipt.Client != null)
            {
                int sign = receipt.Order is OrderReturn ? -1 : 1;

                string clienFIOandTumNum = receipt.Client.FIO + " " + receipt.Client.TabNum;
                string title21 = "ЗП: ";
                string zp = (receipt.Client.UsedZP + sign * orderSumZP).ToString("N2");
                string zpFull = string.Empty;
                
                // проверить наличие ЛПП
                string lpp = string.Empty;
                string lppCount = string.Empty;
                string lppFull = string.Empty;
                int lppCountDiff = 0;
                if (receipt.Client.MonthLimitLPP != 0 || orderSumLPP > 0)
                {
                    lppCountDiff = receipt.Client.MonthLimitLPP - sign * (int)(orderSumLPP / nominalLPP);
                    decimal lppDiff = lppCountDiff * nominalLPP;
                    lpp = Math.Abs(lppDiff).ToString("N2");
                    lppCount = Math.Abs(lppCountDiff).ToString();
                }
                string title22 = (lppCountDiff < 0 ? "Перерасход" : "Остаток") + " ЛПП: ";
                
                if (lpp != string.Empty)
                {
                    if (lpp.Length >= zp.Length)
                    {
                        zp = zp.PadLeft(lpp.Length);
                    }
                    else
                    {
                        lpp = lpp.PadLeft(zp.Length);
                    }
                    lppFull = lppCount + " = " + lpp;
                    zp = zp.PadLeft(lppFull.Length);
                }

                zpFull = title21 + zp;

                spacesCount = (int)lineLength - (clienFIOandTumNum.Length + zpFull.Length) >= 1 ? (int)lineLength - (clienFIOandTumNum.Length + zpFull.Length) : 1;
                result.Add(TextInfo.CreateLeft(clienFIOandTumNum + new String(' ', spacesCount) + zpFull));

                if (lppFull != string.Empty)
                    result.Add(TextInfo.CreateRight(title22 + lppFull));
                result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));
            }

            // формировать шапку списка товаров
            string title3 = "Наименования блюд и товаров";
            result.Add(TextInfo.CreateCenter(title3));

            result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));

            // формировать тело списка товаров
            var orderItemsByMenuItem = receipt.Order.Items.OrderBy(_ => _.MenuItem.Name).ThenBy(_ => _.Price).GroupBy(_ => _.MenuItem);
            int count = 0;
            foreach (var g in orderItemsByMenuItem)
            {
                count++;

                string itemString = count.ToString() + ". " + g.Key.Name + ", " + g.Key.Unit;
                IEnumerable<string> wrappedString = textWrapper.WrapText(itemString, (int)lineLength);
                foreach (var line in wrappedString)
                {
                    result.Add(TextInfo.CreateLeft(line));
                }

                decimal countMenuItem = g.Sum(_ => _.Count);
                decimal sumMenuItem = g.Sum(_ => _.Sum);
                string leftPart = new String(' ', (count.ToString() + ". ").Length) + DecimalToString(countMenuItem, 3) + " X " + g.Key.Price.ToString("N2");
                string rightPart = "= " + sumMenuItem.ToString("N2").PadLeft(orderSumSigns);
                result.Add(TextInfo.CreateRight(leftPart + new String(' ', (int)lineLength - (leftPart.Length + rightPart.Length)) + rightPart));
            }

            // формировать подвал списка товаров
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });

            var orderItemsByPayment = receipt.Order.Items.GroupBy(_ => _.Payment);
            var dictionarySums = orderItemsByPayment.ToDictionary(_ => _.Key, _ => _.Sum(x => x.Sum));

            string title5 = "ВСЕГО";
            string totalSum = dictionarySums.Sum(_ => _.Value).ToString("N2");
            result.Add(TextInfo.CreateRight(title5 + " = " + totalSum));

            foreach (var item in dictionarySums)
            {
                result.Add(TextInfo.CreateRight(GetPaymentName(item.Key, orderSumLPP, nominalLPP, orderSumTalon120, nominalTalon120) + " = " + item.Value.ToString("N2").PadLeft(orderTotalSumSigns)));
            }

            return result;
        }

        static string DecimalToString(decimal value, int decimals) => value % 1 == 0 ? ((int)value).ToString() : value.ToString($"N{decimals}");

        // преобразовать тип оплаты Payment в строковый вид
        static string GetPaymentName(Payment payment, decimal orderSumLPP, decimal nominalLPP, decimal orderSumTalon120, decimal nominalTalon120)
        {
            switch (payment)
            {
                case Payment.BankCard: return "Банковской картой";
                case Payment.Cash: return "Наличными";
                case Payment.LPP: return "Талон ЛПП: " + (int)(orderSumLPP / nominalLPP);
                case Payment.Talon120: return "Талон 120: " + (int)(orderSumTalon120 / nominalTalon120);
                case Payment.ZP: return "В счёт ЗП";
            }
            return string.Empty;
        }

        TextWrapper.TextWrapper textWrapper;
    }
}
