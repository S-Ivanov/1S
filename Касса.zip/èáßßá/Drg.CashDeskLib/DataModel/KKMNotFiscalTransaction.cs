﻿using Drg.Equipment.KKM;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class KKMNotFiscalTransaction : KKMTransactionBase<Receipt>
    {
        public KKMNotFiscalTransaction(IKKM kkm) : base(kkm)
        {
        }

        protected override void DoPrint(Receipt receipt)
        {
            // отправить нефискальный чек на ККМ
            
            kkm.PrintNonFiscalDocument(GetNotFiscalReceipt(receipt, kkm.LineLength));
        }

        public static List<TextInfo> GetNotFiscalReceipt(Receipt receipt, uint lineLength)
        {
            
            List<TextInfo> result = new List<TextInfo>();

            // формировать заголовок 1
            string orderNumber = "10101";
            string orderDateTime = "21.11.2018 12:03:59";
            string title1 = "Заказ № ";
            int spacesCount = (int)lineLength - (title1.Length + orderNumber.Length + orderDateTime.Length) >= 1 ? (int)lineLength - (title1.Length + orderNumber.Length + orderDateTime.Length) : 1;
            result.Add(new TextInfo
            {
                Text = title1 + orderNumber + new String(' ', spacesCount) + orderDateTime,
                Alignment = TextAlignment.Left
            });
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });

            // формировать заголовок 2
            string clienFIOandTumNum = "Белышев И.А. 5188";
            string title21 = "ЗП: ";
            string zp = "14 384,15";
            string title22 = "Остаток ЛПП: ";
            string lpp = "99 = 2 480,00";
            spacesCount = (int)lineLength - (clienFIOandTumNum.Length + title21.Length + zp.Length) >= 1 ? (int)lineLength - (clienFIOandTumNum.Length + title21.Length + zp.Length) : 1;
            result.Add(new TextInfo
            {
                Text = clienFIOandTumNum + new String(' ', spacesCount) + title21 + zp,
                Alignment = TextAlignment.Left
            });
            if (lpp.Length > 0)
                result.Add(new TextInfo
                {
                    Text = title22 + lpp,
                    Alignment = TextAlignment.Right
                });
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });

            // формировать шапку списка товаров
            string title3 = "Наименования блюд и товаров";
            result.Add(new TextInfo
            {
                Text = title3,
                Alignment = TextAlignment.Center
            });
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });

            // формировать тело списка товаров
            int count = 0;
            //foreach (var payment in parameters)
            //{
            //    foreach (var item in payment.Value)
            //    {
            //        count++;
            //        result.Add(new TextInfo
            //        {
            //            Text = count.ToString() + ". " + item.MenuItem.Name + ", " + item.MenuItem.Unit,
            //            Alignment = TextAlignment.Left
            //        });
            //        result.Add(new TextInfo
            //        {
            //            Text = item.MenuItem.Count.ToString("N3") + " X " + item.Price.ToString("N2") + " = " + item.Sum.ToString("N2"),
            //            Alignment = TextAlignment.Right
            //        });
            //    }
            //}

            string DecimalToString(decimal value, int decimals) => value % 1 == 0 ? ((int)value).ToString() : value.ToString($"N{decimals}");

            foreach (var orderItem in receipt.Order.Items)
            {
                count++;

                result.Add(TextInfo.CreateLeft(
                    count.ToString() + ". " + orderItem.MenuItem.Name + ", " + orderItem.MenuItem.Unit
                ));
                result.Add(TextInfo.CreateRight(
                    DecimalToString(orderItem.Count, 3) + " X " + orderItem.Price.ToString("N2") + " = " + orderItem.Sum.ToString("N2")
                ));
            }


            // формировать подвал списка товаров
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });
            var dictionarySums = receipt.Payments.ToDictionary(_ => _.Key, _ => _.Value.Sum(x => x.Sum));
            string title5 = "ВСЕГО";
            string totalSum = dictionarySums.Sum(_ => _.Value).ToString("N2");
            int maxSumLength = totalSum.Length;
            result.Add(new TextInfo
            {
                Text = title5 + " = " + totalSum,
                Alignment = TextAlignment.Right
            });

            // преобразовать тип оплаты Payment в строковый вид
            string GetPaymentName(Payment payment)
            {
                switch (payment)
                {
                    case Payment.BankCard: return "Банковской картой";
                    case Payment.Cash: return "Наличными";
                    case Payment.LPP: return "Талон ЛПП";
                    case Payment.Talon120: return "Талон 120";
                    case Payment.ZP: return "В счёт ЗП";
                }
                return string.Empty;
            }

            foreach (var item in dictionarySums)
            {
                result.Add(new TextInfo
                {
                    Text = GetPaymentName(item.Key) + " = " + item.Value.ToString("N2").PadLeft(maxSumLength),
                    Alignment = TextAlignment.Right
                });
            }

            return result;
        }
    }
}
