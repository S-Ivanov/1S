﻿using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Диспетчер оплаты заказов и возврата оплат
    /// </summary>
    public class PaymentDispatcher
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="kkm">ККМ</param>
        /// <param name="payTerminal">платежный терминал</param>
        public PaymentDispatcher(IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        /// <summary>
        /// Оплатить заказ
        /// </summary>
        /// <param name="parameters">параметры оплаты</param>
        /// <returns></returns>
        public PayResult Pay(PayParameters parameters)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Вернуть оплату заказа
        /// </summary>
        /// <param name="parameters">параметры оплаты</param>
        /// <returns></returns>
        public UnPayResult UnPay(UnPayParameters parameters)
        {
            throw new NotImplementedException();
        }

        IKKM kkm;
        IPayTerminal payTerminal;
    }
}
