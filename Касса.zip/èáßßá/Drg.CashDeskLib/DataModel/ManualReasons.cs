﻿namespace Drg.CashDeskLib.DataModel
{
    public enum ManualReasons : int
    {
        User = 1,
        Error = 2
    }
}
