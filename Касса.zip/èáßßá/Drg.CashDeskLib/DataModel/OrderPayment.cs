﻿using Drg.CashDeskLib.ReportFO;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Оплата заказа
    /// </summary>
    public class OrderPayment
    {
        public OrderPayment(IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        public Payment Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out List<Payment> noPayments, out IDictionary<Payment, List<OrderItem>> orderItems)
        {
            // TODO: проверить входные параметры

            Payment cancelPayment = Payment.None;

            noPayments = new List<Payment>();
            orderItems = new Dictionary<Payment, List<OrderItem>>();

            // проверить возможность оплат, требующих ККМ и/или банковского терминала
            if (payments.ContainsKey(Payment.BankCard) || payments.ContainsKey(Payment.Cash))
            {
                if (payments.ContainsKey(Payment.BankCard) && (payTerminal == null || payTerminal.CheckState() != DeviceError.NoError))
                    noPayments.Add(Payment.BankCard);
                else if (kkm == null || kkm.CheckState() != DeviceError.NoError || !kkm.Fiscal)
                {
                    noPayments.Add(Payment.BankCard);
                    noPayments.Add(Payment.Cash);
                }
            }

            if (!noPayments.Any())
            {
                // разложить записи заказа по суммам платежей
                var splitted = OrderSplitter.Split(order, payments);

                // упорядочить виды оплат
                var orderedPayments = payments.OrderBy(kvp => kvp.Key);
                try
                {
                    cancelPayment = DoPayments(client, order, splitted, orderedPayments, out noPayments);
                    orderItems = splitted;
                }
                catch
                {
                    // отменить невыполненные оплаты
                    ResetPayments(client, order, payments, noPayments);
                }
            }

            return cancelPayment;
        }

        Payment DoPayments(Client client, Order order, IDictionary<Payment, List<OrderItem>> orderItems, IEnumerable<KeyValuePair<Payment, decimal>> payments, out List<Payment> noPayments)
        {
            noPayments = new List<Payment>();

            bool notFiscalPredicate(Payment payment) => payment == Payment.ZP || payment == Payment.LPP || payment == Payment.Talon120;
            bool fiscalPredicate(Payment payment) => payment == Payment.BankCard || payment == Payment.Cash;

            if (payments.Any(kvp => notFiscalPredicate(kvp.Key)))
            {
                try
                {
                    // печать нефискального чека
                    PrintNotFiscalCheck(client, order, orderItems.Where(kvp => notFiscalPredicate(kvp.Key)));
                }
                catch
                {
                    //// в случае ошибки добавим необработанные варианты оплаты 
                    //noPayments.AddRange(payments.Where(kvp => notFiscalPredicate(kvp.Key)).Select(kvp => kvp.Key));

                    // в случае ошибки добавим все варианты оплаты, т.к. фискальные чеки также не смогут печататься
                    noPayments.AddRange(payments.Select(kvp => kvp.Key));
                    throw;
                }
            }

            var fiscalPayments = payments.Where(kvp => fiscalPredicate(kvp.Key));
            if (fiscalPayments.Any())
            {
                if (!DoCanceledPayment(Payment.BankCard, client, order, orderItems, payments, noPayments, PayBankCard))
                    return Payment.BankCard;

                if (!DoCanceledPayment(Payment.Cash, client, order, orderItems, payments, noPayments, PayCash))
                    return Payment.Cash;

                try
                {
                    // печать фискального чека
                    PrintFiscalCheck(client, order, orderItems.Where(kvp => fiscalPredicate(kvp.Key)));
                }
                catch
                {
                    // в случае ошибки добавим необработанные варианты оплаты 
                    noPayments.AddRange(fiscalPayments.Select(kvp => kvp.Key));
                    throw;
                }
            }

            return Payment.None;
        }

        bool DoCanceledPayment(
            Payment payment, 
            Client client, 
            Order order, 
            IDictionary<Payment, List<OrderItem>> orderItems, 
            IEnumerable<KeyValuePair<Payment, decimal>> payments, 
            List<Payment> noPayments,
            Func<Client, Order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>>, bool> payFunction)
        {
            if (payments.Any(kvp => kvp.Key == payment))
            {
                try
                {
                    return payFunction(client, order, orderItems.Where(kvp => kvp.Key == payment));
                }
                catch
                {
                    // в случае ошибки добавим необработанный вариант оплаты 
                    noPayments.Add(payment);
                    throw;
                }
            }

            return false;
        }

        private bool PayBankCard(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> enumerable)
        {
            // TODO: оплата по банковской карте
            //PayResult payResult = payTerminal.Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)

            return true;
        }

        private bool PayCash(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> enumerable)
        {
            // TODO: оплата наличным

            return true;
        }

        private void PrintFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> enumerable)
        {
            // TODO: передать параметры для печати фискального чека
            kkm.PrintFiscalCheck();
        }

        private void PrintNotFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> orderItems)
        {
            // TODO: передать параметры для печати нефискального чека
            kkm.PrintNotFiscalCheck();
        }

        void ResetPayments(Client client, Order order, Dictionary<Payment, decimal> payments, List<Payment> noPayments)
        {
            if (noPayments.Any())
            {
                // отменить невыполненные оплаты
            }
        }

        IKKM kkm;
        IPayTerminal payTerminal;

    }
}
