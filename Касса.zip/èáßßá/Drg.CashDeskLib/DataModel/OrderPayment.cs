﻿using Drg.CashDeskLib.ReportFO;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Оплата заказа
    /// </summary>
    public class OrderPayment
    {
        public OrderPayment(IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        IKKM kkm;
        IPayTerminal payTerminal;

        public Payment[] Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out IDictionary<Payment, List<OrderItem>> orderItems)
        {
            // TODO: проверить входные параметры

            orderItems = new Dictionary<Payment, List<OrderItem>>();

            List<Payment> noPayments = new List<Payment>();

            // проверить возможность оплат, требующих ККМ и/или банковского терминала
            if (payments.ContainsKey(Payment.BankCard) || payments.ContainsKey(Payment.Cash))
            {
                if (payments.ContainsKey(Payment.BankCard) && (payTerminal == null || payTerminal.CheckState() != DeviceError.NoError))
                    noPayments.Add(Payment.BankCard);
                else if (kkm == null || kkm.CheckState() != DeviceError.NoError || !kkm.Fiscal)
                {
                    noPayments.Add(Payment.BankCard);
                    noPayments.Add(Payment.Cash);
                }
            }

            if (!noPayments.Any())
            {
                // разложить записи заказа по суммам платежей
                var splitted = OrderSplitter.Split(order, payments);

                // упорядочить виды оплат
                var orderedPayments = payments.OrderBy(kvp => kvp.Key);
                try
                {
                    DoPayments(client, order, splitted, orderedPayments, noPayments);
                    orderItems = splitted;
                }
                catch
                {
                    // отменить невыполненные оплаты
                    ResetPayments(client, order, orderedPayments, noPayments);
                }
            }

            return noPayments.ToArray();
        }

        // TODO: возвращать noPayments
        void DoPayments(Client client, Order order, IDictionary<Payment, List<OrderItem>> orderItems, IEnumerable<KeyValuePair<Payment, decimal>> payments, List<Payment> noPayments)
        {
            bool notFiscalPredicate(Payment payment) => payment == Payment.ZP || payment == Payment.LPP || payment == Payment.Talon120;
            bool fiscalPredicate(Payment payment) => payment == Payment.BankCard || payment == Payment.Cash;

            int notFiscalPaymentCount = payments.Count(kvp => notFiscalPredicate(kvp.Key));
            int fiscalPaymentCount = payments.Count(kvp => fiscalPredicate(kvp.Key));

            if (notFiscalPaymentCount > 0)
            {
                CancelEventArgs args = new CancelEventArgs();
                QueryNotFiscalPayment?.Invoke(this, args);
                if (!args.Cancel)
                {
                    try
                    {
                        // печать нефискального чека
                        PrintNotFiscalCheck(client, order, orderItems.Where(kvp => notFiscalPredicate(kvp.Key)));
                    }
                    catch
                    {
                        // в случае ошибки добавим необработанные варианты оплаты 
                        noPayments.AddRange(payments.Where(kvp => notFiscalPredicate(kvp.Key)).Select(kvp => kvp.Key));
                        throw;
                    }
                }
            }

            if (fiscalPaymentCount > 0)
            {
                CancelEventArgs args = new CancelEventArgs();
                QueryFiscalPayment?.Invoke(this, args);
                try
                {
                    if (args.Cancel)
                        SaveFiscalInfo(client, order, orderItems.Where(kvp => fiscalPredicate(kvp.Key)));
                    else
                        // печать фискального чека
                        PrintFiscalCheck(client, order, orderItems.Where(kvp => fiscalPredicate(kvp.Key)));
                }
                catch
                {
                    // в случае ошибки добавим необработанные варианты оплаты 
                    noPayments.AddRange(payments.Where(kvp => fiscalPredicate(kvp.Key)).Select(kvp => kvp.Key));
                    throw;
                }
            }
        }

        private void PrintFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> enumerable)
        {
            // TODO: передать параметры для печати фискального чека
            kkm.PrintFiscalCheck();
        }

        private void SaveFiscalInfo(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> enumerable)
        {
            // TODO: передать параметры для сохранения фискального чека
            kkm.SaveFiscalInfo();
        }

        private void PrintNotFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> orderItems)
        {
            // TODO: передать параметры для печати нефискального чека
            kkm.PrintNotFiscalCheck();
        }

        void ResetPayments(Client client, Order order, IEnumerable<KeyValuePair<Payment, decimal>> payments, List<Payment> noPayments)
        {
            if (noPayments.Any())
            {
                // отменить невыполненные оплаты
            }
        }

        public event EventHandler<CancelEventArgs> QueryFiscalPayment;

        public event EventHandler<CancelEventArgs> QueryNotFiscalPayment;

        //void PrintFiscalCheck()
        //{

        //}

    }
}
