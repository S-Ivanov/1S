﻿using Drg.CashDeskLib.ReportFO;
using Drg.Equipment;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Оплата заказа
    /// </summary>
    /// <remarks>
    /// TODO: перенести функциональность в класс PaymentDispatcher
    /// </remarks>
    public class OrderPayment
    {
        public OrderPayment(Drg.Equipment.KKM.IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        public Payment Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out List<Payment> noPayments, out IDictionary<Payment, List<OrderItem>> orderItems)
        {
            // TODO: проверить входные параметры

            Payment cancelPayment = Payment.None;

            noPayments = new List<Payment>();
            orderItems = new Dictionary<Payment, List<OrderItem>>();

            // проверить возможность оплат, требующих ККМ и/или банковского терминала
            if (payments.ContainsKey(Payment.BankCard) || payments.ContainsKey(Payment.Cash))
            {
                if (payments.ContainsKey(Payment.BankCard))
                {
                    try
                    {
                        payTerminal.CheckErrors();
                    }
                    catch
                    {
                        noPayments.Add(Payment.BankCard);
                    }
                }
                else
                {
                    try
                    {
                        kkm.CheckErrors();
                        if (!kkm.Fiscal)
                        {
                            noPayments.Add(Payment.BankCard);
                            noPayments.Add(Payment.Cash);
                        }
                    }
                    catch
                    {
                        noPayments.Add(Payment.BankCard);
                        noPayments.Add(Payment.Cash);
                    }
                }
            }

            if (!noPayments.Any())
            {
                // разложить записи заказа по суммам платежей
                var splitted = OrderSplitter.Split(order, payments);

                // упорядочить виды оплат
                var orderedPayments = payments.OrderBy(kvp => kvp.Key);
                try
                {
                    cancelPayment = DoPayments(client, order, splitted, orderedPayments, out noPayments);
                    orderItems = splitted;
                }
                catch
                {
                    // отменить невыполненные оплаты
                    ResetPayments(client, order, payments, noPayments);
                }
            }

            return cancelPayment;
        }

        Payment DoPayments(Client client, Order order, IDictionary<Payment, List<OrderItem>> orderItems, IEnumerable<KeyValuePair<Payment, decimal>> payments, out List<Payment> noPayments)
        {
            noPayments = new List<Payment>();

            bool notFiscalPredicate(Payment payment) => payment == Payment.ZP || payment == Payment.LPP || payment == Payment.Talon120;
            bool fiscalPredicate(Payment payment) => payment == Payment.BankCard || payment == Payment.Cash;

            if (payments.Any(kvp => notFiscalPredicate(kvp.Key)))
            {
                try
                {
                    // печать нефискального чека
                    PrintNotFiscalCheck(client, order, orderItems.Where(kvp => notFiscalPredicate(kvp.Key)));
                }
                catch
                {
                    //// в случае ошибки добавим необработанные варианты оплаты 
                    //noPayments.AddRange(payments.Where(kvp => notFiscalPredicate(kvp.Key)).Select(kvp => kvp.Key));

                    // в случае ошибки добавим все варианты оплаты, т.к. фискальные чеки также не смогут печататься
                    noPayments.AddRange(payments.Select(kvp => kvp.Key));
                    throw;
                }
            }

            var fiscalPayments = payments.Where(kvp => fiscalPredicate(kvp.Key));
            if (fiscalPayments.Any())
            {
                if (!DoCanceledPayment(Payment.BankCard, client, order, orderItems, payments, noPayments, PayBankCard))
                    return Payment.BankCard;

                if (!DoCanceledPayment(Payment.Cash, client, order, orderItems, payments, noPayments, PayCash))
                    return Payment.Cash;

                try
                {
                    // печать фискального чека
                    PrintFiscalCheck(client, order, orderItems.Where(kvp => fiscalPredicate(kvp.Key)));
                }
                catch
                {
                    // в случае ошибки добавим необработанные варианты оплаты 
                    noPayments.AddRange(fiscalPayments.Select(kvp => kvp.Key));
                    throw;
                }
            }

            return Payment.None;
        }

        bool DoCanceledPayment(
            Payment payment, 
            Client client, 
            Order order, 
            IDictionary<Payment, List<OrderItem>> orderItems, 
            IEnumerable<KeyValuePair<Payment, decimal>> payments, 
            List<Payment> noPayments,
            Func<Client, Order, KeyValuePair<Payment, List<OrderItem>>, bool> payFunction)
        {
            if (payments.Any(kvp => kvp.Key == payment))
            {
                try
                {
                    return payFunction(client, order, orderItems.Where(kvp => kvp.Key == payment).FirstOrDefault());
                }
                catch
                {
                    // в случае ошибки добавим необработанный вариант оплаты 
                    noPayments.Add(payment);
                    throw;
                }
            }

            return true;
        }

        private bool PayBankCard(Client client, Order order, KeyValuePair<Payment, List<OrderItem>> orderItems)
        {
            // TODO: оплата по банковской карте
            //PayResult payResult = payTerminal.Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum)

            return true;
        }

        private bool PayCash(Client client, Order order, KeyValuePair<Payment, List<OrderItem>> orderItems)
        {
            if (orderItems.Key != Payment.Cash || CashPaymentEvent == null)
                return true;
            else
            {
                var sum = orderItems.Value.Sum(orderItem => orderItem.Sum);
                if (sum <= 0)
                    return false;
                else
                {
                    CashPaymentEventArgs args = new CashPaymentEventArgs { Sum = sum };
                    CashPaymentEvent(this, args);
                    return !args.Cancel;
                }
            }
        }

        private void PrintFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> orderItems)
        {
            // TODO: передать параметры для печати фискального чека
            //kkm.PrintFiscalCheck();

            // сформировать чек
            var kkmPayments = orderItems.Where(_ => _.Key == Payment.BankCard || _.Key == Payment.Cash);
            if (kkmPayments.Any())
            {
                Drg.Equipment.KKM.Receipt receipt = new Drg.Equipment.KKM.Receipt { ReceiptType = Drg.Equipment.KKM.ReceiptType.LIBFPTR_RT_BUY };
                foreach (var orderItemPayment in kkmPayments)
                {
                    foreach (var orderItem in orderItemPayment.Value)
                    {
                        receipt.Items.Add(
                            new Drg.Equipment.KKM.ReceiptItem
                            {
                                Name = orderItem.MenuItem.Name,
                                Price = (double)orderItem.Price,
                                Count = (double)orderItem.Count,
                                TaxType = orderItem.MenuItem.VATCode < 0 ? Drg.Equipment.KKM.TaxType.CUSTOM : (Drg.Equipment.KKM.TaxType)orderItem.MenuItem.VATCode,
                                VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                            });
                    }

                    // привести тип оплаты
                    Drg.Equipment.KKM.PaymentType paymentType = 
                        orderItemPayment.Key == Payment.BankCard ?
                        Drg.Equipment.KKM.PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                        Drg.Equipment.KKM.PaymentType.LIBFPTR_PT_CASH;

                    receipt.Payments.Add(paymentType, (double)orderItemPayment.Value.Sum(_ => _.Sum));
                }

                // TODO: отключить проверку ККМ

                try
                {
                    // отправить чек на ККМ
                    kkm.DoAction((int)Drg.Equipment.KKM.PrintAction.PrintReceipt, receipt);
                }
                catch (DeviceException ex)
                {
                    // вывести сообщение пользователю об ошибке
                    
                }
                finally
                {
                    // TODO: включить проверку ККМ
                }
            }


        }

        private void PrintNotFiscalCheck(Client client, Order order, IEnumerable<KeyValuePair<Payment, List<OrderItem>>> orderItems)
        {
            // TODO: передать параметры для печати нефискального чека
            //kkm.PrintNotFiscalCheck();
        }

        void ResetPayments(Client client, Order order, Dictionary<Payment, decimal> payments, List<Payment> noPayments)
        {
            if (noPayments.Any())
            {
                // отменить невыполненные оплаты
            }
        }

        public event EventHandler<CashPaymentEventArgs> CashPaymentEvent;

        Drg.Equipment.KKM.IKKM kkm;
        IPayTerminal payTerminal;
    }
}
