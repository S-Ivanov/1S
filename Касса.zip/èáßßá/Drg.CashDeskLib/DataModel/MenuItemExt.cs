﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItemExt : MenuItemBaseExt
    {
        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }
    }
}
