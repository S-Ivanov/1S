﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    public class DateRange
    {
        public DateRange(DateTime start, DateTime end)
        {
            if (start > end)
                throw new ArgumentException();

            Start = start;
            End = end;
        }

        public DateTime Start { get; private set; }
        public DateTime End { get; private set; }
    }
}
