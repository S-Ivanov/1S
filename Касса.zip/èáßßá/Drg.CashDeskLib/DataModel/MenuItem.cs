﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem //: ICloneable
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal { get; set; }

        /// <summary>
        /// Id меню
        /// </summary>
        public Guid MenuId { get; set; }

        /// <summary>
        /// Id товара
        /// </summary>
        public Guid ProductId { get; set; }

        /// <summary>
        /// Копирование
        /// </summary>
        /// <param name="count"></param>
        /// <param name="price"></param>
        /// <param name="isLocal"></param>
        /// <returns></returns>
        public MenuItem Copy(decimal count = 0, decimal price = 0, bool isLocal = true)
        {
            return new MenuItem
            {
                Id = Guid.NewGuid(),
                Name = Name,
                Unit = Unit,
                Count = count == 0 ? Count : count,
                Price = price == 0 ? Price : price,
                IsLocal = isLocal,
                MenuId = MenuId,
                ProductId = ProductId
            };
        }

        //#region Реализация ICloneable

        //public object Clone() => this.MemberwiseClone();

        //#endregion Реализация ICloneable
    }
}
