﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem : MenuItemBase, ICloneable
    {
        /// <summary>
        /// Идентификатор элемента меню
        /// </summary>
        public Guid IdMenuItem { get; set; }

        /// <summary>
        /// Идентификатор товара
        /// </summary>
        public Guid IdProduct { get; set; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }

        /// <summary>
        /// Сумма
        /// </summary>
        public decimal Sum => Price * Count;

        /// <summary>
        /// Код ставки НДС
        /// </summary>
        /// <remarks>
        /// если больше или равно 0, то соответствует перечислению LIBFPTR_PARAM_TAX_TYPE в драйвере Атол
        /// иначе в драйвере Атол соответствия нет и НДС считается умножением суммы на коэффициент VATCoefficient
        /// </remarks>
        public int VATCode { get; set; }

        /// <summary>
        /// Коэффициент НДС
        /// </summary>
        /// <remarks>
        /// если равно 0, то не используется и НДС считается автоматически в драйвере Атол через VATCode
        /// иначе НДС считается умножением суммы на коэффициент VATCoefficient
        /// </remarks>
        public decimal VATCoefficient { get; set; }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal { get; set; }

        #region Реализация ICloneable

        public object Clone() => this.MemberwiseClone();

        #endregion Реализация ICloneable
    }
}
