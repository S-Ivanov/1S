﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem : MenuItemBase, ICloneable
    {
        /// <summary>
        /// Идентификатор элемента меню
        /// </summary>
        public Guid IdMenuItem { get; set; }

        /// <summary>
        /// Идентификатор товара
        /// </summary>
        public Guid IdProduct { get; set; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal { get; set; }

        #region Реализация ICloneable

        public object Clone() => this.MemberwiseClone();

        #endregion Реализация ICloneable
    }
}
