﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItem 
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal { get; set; }

        /// <summary>
        /// Копирование
        /// </summary>
        /// <param name="count"></param>
        /// <param name="price"></param>
        /// <param name="isLocal"></param>
        /// <returns></returns>
        public MenuItem Copy(decimal count, decimal price, bool isLocal = true)
        {
            return new MenuItem
            {
                Id = Guid.NewGuid(),
                Name = Name,
                Unit = Unit,
                Count = count,
                Price = price,
                IsLocal = isLocal
            };
        }
    }
}
