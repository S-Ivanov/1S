﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItemBaseExt 
    {
        /// <summary>
        /// Идентификатор номенклатуры
        /// </summary>
        public string IdNomenclature { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Родительский элемент
        /// </summary>
        public MenuItemBaseExt Parent { get; set; }

        /// <summary>
        /// Дочерние элементы
        /// </summary>
        public List<MenuItemBaseExt> Children { get; } = new List<MenuItemBaseExt>();
    }
}
