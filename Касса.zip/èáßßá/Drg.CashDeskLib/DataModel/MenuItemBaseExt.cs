﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент меню
    /// </summary>
    public class MenuItemBaseExt 
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Наименование
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Локальный элемент меню
        /// </summary>
        public bool IsLocal { get; set; }

        /// <summary>
        /// Дочерние элементы
        /// </summary>
        public List<MenuItemBaseExt> Children { get; } = new List<MenuItemBaseExt>();
    }
}
