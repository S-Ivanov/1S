﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент заказа
    /// </summary>
    public class OrderItem : ICloneable
    {
        /// <summary>
        /// Элемент меню
        /// </summary>
        public MenuItem MenuItem
        {
            get => menuItem;
            set
            {
                if (menuItem != value)
                {
                    menuItem = value;
                    RecalcSum();
                }
            }
        }
        MenuItem menuItem;

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count
        {
            get => count;
            set
            {
                if (count != value)
                {
                    count = value;
                    RecalcSum();
                }
            }
        }
        decimal count;

        /// <summary>
        /// Цена элемента заказа
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Сумма элемента заказа
        /// </summary>
        public decimal Sum { get; set; }

        /// <summary>
        /// Вариант оплаты
        /// </summary>
        public Payment Payment { get; set; }

        /// <summary>
        /// Пересчет суммы
        /// </summary>
        void RecalcSum()
        {
            Sum = MenuItem == null ? 0 : Math.Round(Count * MenuItem.Price, 2, MidpointRounding.AwayFromZero);
        }

        #region Реализация ICloneable

        public object Clone() => this.MemberwiseClone();

        #endregion Реализация ICloneable
    }
}
