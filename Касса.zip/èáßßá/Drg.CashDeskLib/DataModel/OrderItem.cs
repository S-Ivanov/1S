﻿namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Элемент заказа
    /// </summary>
    public class OrderItem
    {
        /// <summary>
        /// Элемент меню
        /// </summary>
        public MenuItem MenuItem { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public decimal Count { get; set; }
    }
}
