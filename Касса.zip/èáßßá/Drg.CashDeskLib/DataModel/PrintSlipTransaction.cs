﻿using Drg.Equipment.KKM;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class PrintSlipTransaction : KKMTransactionBase<string>
    {
        public PrintSlipTransaction(IKKM kkm) : base(kkm)
        {
        }

        protected override void DoPrint(string parameters)
        {
            kkm.PrintNonFiscalDocument(MakeSlip(parameters));
        }

        protected override void DoRollbackInternal(string parameters)
        {
        }

        IEnumerable<TextInfo> MakeSlip(string slipText)
        {
            return new List<TextInfo> { new TextInfo { Text = slipText } };
        }
    }
}
