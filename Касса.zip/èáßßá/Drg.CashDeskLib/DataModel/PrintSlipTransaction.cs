﻿using System;
using System.Linq;
using Drg.Equipment.KKM;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class PrintSlipTransaction : KKMTransactionBase<string>
    {
        public PrintSlipTransaction(IKKM kkm, int slipCount) : base(kkm)
        {
            this.slipCount = slipCount;
        }

        protected override void DoPrint(string slipText)
        {
            var slip = MakeSlip(slipText).ToArray();
            if (slip.Any())
            {
                for (int i = 0; i < slipCount; i++)
                {
                    kkm.PrintNonFiscalDocument(slip);
                }
            }
        }

        protected override void DoRollbackInternal(string parameters)
        {
        }

        public static IEnumerable<TextInfo> MakeSlip(string slipText) =>
            string.IsNullOrEmpty(slipText) ?
            Enumerable.Empty<TextInfo>() :
            slipText.Split(new char[] { (char)13, (char)10 }, StringSplitOptions.RemoveEmptyEntries).Select(_ => TextInfo.CreateLeft(_));

        readonly int slipCount;
    }
}

