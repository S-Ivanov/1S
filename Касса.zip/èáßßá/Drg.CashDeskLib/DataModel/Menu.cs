﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Меню
    /// </summary>
    public class Menu
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Номер меню
        /// </summary>
        public string Number { get; set; }

        /// <summary>
        /// Дата меню
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Группы элементов меню
        /// </summary>
        public List<MenuItemGroup> Items { get; set; }
    }
}
