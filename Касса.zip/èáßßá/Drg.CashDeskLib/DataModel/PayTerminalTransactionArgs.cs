﻿namespace Drg.CashDeskLib.DataModel
{
    public class PayTerminalTransactionArgs
    {
        /// <summary>
        /// Номер смены
        /// </summary>
        public int SessionNumber { get; set; }

        /// <summary>
        /// Номер чека
        /// </summary>
        public int CheckNumber { get; set; }

        /// <summary>
        /// Сумма оплаты
        /// </summary>
        public decimal Sum { get; set; }
    }
}
