﻿using Drg.Equipment;
using System;

namespace Drg.CashDeskLib.DataModel
{
    public class PaymentManagerExtException : Exception
    {
        public Device Device { get; set; }
    }
}
