﻿using System.ComponentModel;

namespace Drg.CashDeskLib.DataModel
{
    public class CashPaymentEventArgs : CancelEventArgs
    {
        /// <summary>
        /// Сумма
        /// </summary>
        public decimal Sum { get; set; }
    }
}
