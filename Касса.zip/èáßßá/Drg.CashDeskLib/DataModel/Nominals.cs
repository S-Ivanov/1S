﻿namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Номиналы талонов и дотаций
    /// </summary>
    public class Nominals
    {
        public decimal LPP { get; set; }
        public decimal Talon120 { get; set; }
        public decimal Subsidy8 { get; set; }
        public decimal Subsidy12 { get; set; }
        public decimal Subsidy24 { get; set; }
    }
}
