﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order
    {
        /// <summary>
        /// Идентификатор (транзакции)
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Дата+время формирования заказа
        /// </summary>
        public DateTime DateTime { get; set; }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// Элементы заказа
        /// </summary>
        public List<OrderItem> Items { get; set; }
    }
}
