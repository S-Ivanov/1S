﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order
    {
        /// <summary>
        /// Идентификатор (транзакции)
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Дата+время формирования заказа
        /// </summary>
        public DateTime DateTime { get; set; }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// Элементы заказа
        /// </summary>
        public List<OrderItem> Items { get; set; }

        public decimal ZP => GetPaymentSum(Payment.ZP);
        public decimal LPP => GetPaymentSum(Payment.LPP);
        public decimal BankCard => GetPaymentSum(Payment.BankCard);
        public decimal Cash => GetPaymentSum(Payment.Cash);
        public decimal Talon120 => GetPaymentSum(Payment.Talon120);

        decimal GetPaymentSum(Payment payment) => Items == null ? 0 : Items.Where(_ => _.Payment == payment).Sum(_ => _.Sum);
    }
}
