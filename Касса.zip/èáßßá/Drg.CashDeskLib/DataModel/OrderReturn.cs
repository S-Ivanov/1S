﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Возврат заказов
    /// </summary>
    public class OrderReturn
    {
        public OrderReturn(IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        public void ReturnWholeOrder(Guid orerId, List<OrderPaymentItem> payments)
        {
            // проверить возможность оплат, требующих ККМ и/или банковского терминала
            decimal bankSum = payments.FirstOrDefault(_ => _.Payment == Payment.BankCard)?.Sum ?? 0;
            decimal cashSum = payments.FirstOrDefault(_ => _.Payment == Payment.Cash)?.Sum ?? 0;

            if (bankSum != 0 || cashSum != 0)
            {
                if (bankSum != 0 && (payTerminal == null || payTerminal.CheckState() != DeviceError.NoError))
                {
                    throw new OrderReturnException { Payments = new[] { Payment.BankCard } };
                }
                else if (kkm == null || kkm.CheckState() != DeviceError.NoError || !kkm.Fiscal)
                {
                    throw new OrderReturnException { Payments = new[] { Payment.BankCard, Payment.Cash } };
                }
            }

            if (bankSum != 0)
            {
                ReturnBank(bankSum);
            }

            if (cashSum != 0)
            {
                ReturnCash(cashSum);
            }
        }

        private void ReturnCash(decimal cashSum)
        {
        }

        private void ReturnBank(decimal bankSum)
        {
        }

        private IKKM kkm;
        private IPayTerminal payTerminal;
    }
}
