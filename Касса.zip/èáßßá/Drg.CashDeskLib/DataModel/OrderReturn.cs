﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Возврат заказов
    /// </summary>
    public class OrderReturn
    {
        public OrderReturn(IKKM kkm, IPayTerminal payTerminal)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
        }

        public void ReturnWholeOrder(Guid orerId, List<OrderPaymentItem> payments)
        {
            // проверить возможность оплат, требующих ККМ и/или банковского терминала
            decimal bankSum = payments.FirstOrDefault(_ => _.Payment == Payment.BankCard)?.Sum ?? 0;
            decimal cashSum = payments.FirstOrDefault(_ => _.Payment == Payment.Cash)?.Sum ?? 0;

            if (bankSum != 0 || cashSum != 0)
            {
                try
                {
                    kkm.CheckErrors();
                    if (!kkm.Fiscal)
                        throw new OrderReturnException { Payments = new[] { Payment.BankCard, Payment.Cash } };
                }
                catch
                {
                    throw new OrderReturnException { Payments = new[] { Payment.BankCard, Payment.Cash } };
                }
            }

            if (bankSum != 0)
            {
                try
                {
                    payTerminal.CheckErrors();
                    ReturnBank(bankSum);
                }
                catch
                {
                    throw new OrderReturnException { Payments = new[] { Payment.BankCard } };
                }
            }

            if (cashSum != 0)
            {
                ReturnCash(cashSum);
            }
        }

        private void ReturnCash(decimal cashSum)
        {
        }

        private void ReturnBank(decimal bankSum)
        {
        }

        private IKKM kkm;
        private IPayTerminal payTerminal;
    }
}
