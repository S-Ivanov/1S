﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Заказ возврата
    /// </summary>
    public class OrderReturn : Order
    {
        /// <summary>
        /// Идентификатор исходного заказа
        /// </summary>
        public Guid IdSourceOrder { get; set; }

        public int SourceNumber { get; set; }
        public DateTime SourceDate { get; set; }
    }
}
