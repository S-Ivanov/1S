﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Исходный заказ для возврата
    /// </summary>
    public class OrderSource : Order
    {
        public Client Client { get; set; }

        public bool HasReturns { get; set; }
    }
}
