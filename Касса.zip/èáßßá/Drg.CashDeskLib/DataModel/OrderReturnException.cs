﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    public class OrderReturnException : ApplicationException
    {
        public Payment[] Payments { get; set; }
    }
}
