﻿using Drg.CashDeskLib.DB;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Транзакционный платежный терминал
    /// </summary>
    public class PayTerminalTransaction : DeviceTransactionBase<PayTerminalTransactionArgs>
    {
        public PayTerminalTransaction(IPayTerminal payTerminal, ILocalDBPayment localDB)
        {
            this.payTerminal = payTerminal;
            this.localDB = localDB;
        }

        protected override void DoActionInternal(PayTerminalTransactionArgs parameters)
        {
            PayResult payResult = payTerminal.Pay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum);
            SlipText = payResult.SlipText;

            // записать информацию об оплате в БД
            authorizationInfoId = Guid.NewGuid();
            localDB.SaveAuthorizationInfo(authorizationInfoId, payResult.AuthorizationInfo);
        }

        protected override void DoRollbackInternal(PayTerminalTransactionArgs parameters)
        {
            try
            {
                PayResult payResult = payTerminal.ReturnPay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum);

                // записать информацию о возврате в БД
                localDB.SaveAuthorizationInfo(Guid.NewGuid(), payResult.AuthorizationInfo);
            }
            catch
            {
                // записать информацию об ошибке возврата в БД
                // структура таблицы:
                //  - Id - Guid - PK - сформировать
                //  - Id ТранзакцииБанковскихКарт, которую не удалось отменить = authorizationInfoId
                //  - номер смены = parameters.SessionNumber
                //  - номер чека = parameters.CheckNumber
                
                localDB.SavePayTerminalReturnError(authorizationInfoId, parameters.SessionNumber, parameters.CheckNumber);
            }
        }

        public string SlipText { get; private set; }

        Guid authorizationInfoId;

        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
    }
}
