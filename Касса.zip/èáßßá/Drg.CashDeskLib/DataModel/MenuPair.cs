﻿namespace Drg.CashDeskLib.DataModel
{
    public class MenuPair
    {
        public Menu Current { get; set; }
        public Menu Last { get; set; }
    }
}
