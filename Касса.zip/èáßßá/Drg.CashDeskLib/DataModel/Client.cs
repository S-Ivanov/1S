﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Клиент
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Код пропуска
        /// </summary>
        public uint CardCode { get; set; }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum { get; set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; set; }

        /// <summary>
        /// Фотография
        /// </summary>
        public byte[] Photo { get; set; }

        /// <summary>
        /// Загружена фотография
        /// </summary>
        public bool IsPhotoLoaded { get; set; }

        /// <summary>
        /// Разрешено питание в счет ЗП
        /// </summary>
        public bool HasZP { get; set; }
    }
}
