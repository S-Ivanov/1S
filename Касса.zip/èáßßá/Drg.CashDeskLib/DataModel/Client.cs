﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Клиент
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Код пропуска
        /// </summary>
        public uint CardCode { get; set; }

        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum { get; set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; set; }

        /// <summary>
        /// Фотография
        /// </summary>
        public byte[] Photo { get; set; }

        /// <summary>
        /// Загружена фотография
        /// </summary>
        public bool IsPhotoLoaded { get; set; }

        /// <summary>
        /// Разрешено питание в счет ЗП
        /// </summary>
        public bool HasZP => LimitZP > 0;

        /// <summary>
        /// Остаток месячного лимита питания в счет з/п
        /// </summary>
        public decimal ZP
        {
            get
            {
                var zp = LimitZP - UsedZP;
                return zp > 0 ? zp : 0;
            }
        }

        /// <summary>
        /// Месячный лимит питания в счет з/п
        /// </summary>
        public decimal LimitZP { get; set; }

        /// <summary>
        /// Истрачено в счет з/п (в пределах месячного лимита)
        /// </summary>
        public decimal UsedZP { get; set; }

        /// <summary>
        /// Остаток талонов ЛПП
        /// </summary>
        public int LPP { get; set; }

        /// <summary>
        /// Разрешено ЛПП
        /// </summary>
        public bool HasLPP => LPP > 0;
    }
}
