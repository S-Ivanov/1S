﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Клиент
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Табельный номер
        /// </summary>
        public string TabNum { get; set; }

        /// <summary>
        /// ФИО
        /// </summary>
        public string FIO { get; set; }

        /// <summary>
        /// Код пропуска
        /// </summary>
        public uint CardCode { get; set; }

        /// <summary>
        /// Фотография
        /// </summary>
        public byte[] Photo { get; set; }

        /// <summary>
        /// Разрешено питание в счет ЗП
        /// </summary>
        public bool HasZP { get; set; }

        /// <summary>
        /// Остаток месячного лимита питания в счет з/п
        /// </summary>
        public decimal LimitZP
        {
            get
            {
                if (HasZP)
                {
                    var zp = MonthLimitZP - UsedZP;
                    return zp > 0 ? zp : 0;
                }
                else
                    return 0;
            }
        }

        /// <summary>
        /// Месячный лимит питания в счет з/п
        /// </summary>
        public decimal MonthLimitZP { get; set; }

        /// <summary>
        /// Истрачено в счет з/п (в пределах месячного лимита)
        /// </summary>
        public decimal UsedZP { get; set; }

        /// <summary>
        /// Количество талонов ЛПП на месяц
        /// </summary>
        public int MonthLimitLPP { get; set; }

        /// <summary>
        /// Истрачено в счет ЛПП
        /// </summary>
        public decimal UsedLPP { get; set; }

        ///// <summary>
        ///// Остаток месячного лимита талонов ЛПП
        ///// </summary>
        //public decimal LimitLPP
        //{
        //    get
        //    {
        //        if (HasLPP)
        //        {
        //            var lpp = MonthLimitLPP - UsedLPP / CashDesk.Instance.Configuration.LPPNominal;
        //            return lpp > 0 ? lpp : 0;
        //        }
        //        else
        //            return 0;
        //    }
        //}


        /// <summary>
        /// Разрешено ЛПП
        /// </summary>
        public bool HasLPP => MonthLimitLPP > 0;
    }
}
