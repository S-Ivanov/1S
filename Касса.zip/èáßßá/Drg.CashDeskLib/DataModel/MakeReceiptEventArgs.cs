﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Аргумент события для формирования чека на основе заказа
    /// </summary>
    public class MakeReceiptEventArgs : EventArgs
    {
        /// <summary>
        /// Исходный заказ
        /// </summary>
        public Order Order { get; set; }

        /// <summary>
        /// Заблокированные варианты оплаты
        /// </summary>
        public HashSet<Payment> NoPaymentTypes { get; set; }

        /// <summary>
        /// Сформированный чек
        /// </summary>
        public Receipt Receipt { get; set; }
    }
}
