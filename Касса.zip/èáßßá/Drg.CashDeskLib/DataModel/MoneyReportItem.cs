﻿namespace Drg.CashDeskLib.DataModel
{
    public class MoneyReportItem
    {
        /// <summary>
        /// Вид оплаты
        /// </summary>
        public Payment Payment { get; set; }

        /// <summary>
        /// Приход сумма
        /// </summary>
        public decimal Incoming { get; set; }

        /// <summary>
        /// Приход количество
        /// </summary>
        public int IncomingCount { get; set; }

        /// <summary>
        /// Возврат сумма
        /// </summary>
        public decimal Refund { get; set; }

        /// <summary>
        /// Возврат количество
        /// </summary>
        public int RefundCount { get; set; }

        /// <summary>
        /// Баланс сумма
        /// </summary>
        public decimal Balance => Incoming - Refund;

        /// <summary>
        /// Баланс количество
        /// </summary>
        public int BalanceCount => IncomingCount + RefundCount;

        /// <summary>
        /// Средняя покупка
        /// </summary>
        public decimal Average => IncomingCount != 0 ? Incoming / IncomingCount : 0;

        public string ToString(uint lineLength)
        {
            return "";
        }
    }
}
