﻿namespace Drg.CashDeskLib.DataModel
{
    public class MoneyReportItem
    {
        /// <summary>
        /// Вид оплаты
        /// </summary>
        public Payment Payment { get; set; }
        /// <summary>
        /// Приход
        /// </summary>
        public decimal Incoming { get; set; }
        /// <summary>
        /// Возврат
        /// </summary>
        public decimal Refund { get; set; }
        /// <summary>
        /// Баланс
        /// </summary>
        public decimal Balance => Incoming - Refund;
    }
}
