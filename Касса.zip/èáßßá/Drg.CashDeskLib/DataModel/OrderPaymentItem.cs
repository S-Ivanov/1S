﻿namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Оплата заказа
    /// </summary>
    public class OrderPaymentItem
    {
        /// <summary>
        /// Вид оплаты
        /// </summary>
        public Payment Payment { get; set; }

        /// <summary>
        /// Сумма
        /// </summary>
        public decimal Sum { get; set; }
    }
}
