﻿using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using Drg.EquipmentEmulators;

namespace Drg.CashDeskLib
{
    public class EquipmentFactoryEmulator : EquipmentFactory
    {
        public EquipmentFactoryEmulator(CashDeskConfiguration cashDeskConfiguration)
        {
            this.cashDeskConfiguration = cashDeskConfiguration;
        }

        #region Перекрытые методы EquipmentFactoryBase

        /// <summary>
        /// Создание эмулятора считывателя пропусков
        /// </summary>
        public override ICardReader CreateCardReader()
        {
            return string.IsNullOrEmpty(cashDeskConfiguration.CardReaderEmulatorFileName) ? null : new CardReader(cashDeskConfiguration.CardReaderEmulatorFileName);
        }

        /// <summary>
        /// Создание эмулятора банковского терминала
        /// </summary>
        public override IPayTerminal CreatePayTerminal()
        {
            return string.IsNullOrEmpty(cashDeskConfiguration.PayTerminalEmulatorFileName) ? null : new PayTerminal(cashDeskConfiguration.PayTerminalEmulatorFileName);
        }

        public override IKKM CreateKKM()
        {
            return string.IsNullOrEmpty(cashDeskConfiguration.KkmEmulatorFileName) ? null : new KKM(cashDeskConfiguration.KkmEmulatorFileName);
        }

        #endregion Перекрытые методы EquipmentFactoryBase

        private CashDeskConfiguration cashDeskConfiguration;
    }
}
