﻿using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using Drg.EquipmentEmulators;

namespace Drg.CashDeskLib
{
    public class EquipmentFactoryEmulator : EquipmentFactoryBase
    {
        public EquipmentFactoryEmulator(string cardReaderEmulatorFileName)
        {
            this.cardReaderEmulatorFileName = cardReaderEmulatorFileName;
        }

        #region Перекрытые методы EquipmentFactoryBase

        /// <summary>
        /// Создание эмулятора считывателя пропусков
        /// </summary>
        public override ICardReader CreateCardReader()
        {
            return new CardReader(cardReaderEmulatorFileName);
        }

        /// <summary>
        /// Создание эмулятора банковского терминала
        /// </summary>
        public override IPayTerminal CreatePayTerminal()
        {
            return new PayTerminal();
        }

        public override IKKM CreateKKM()
        {
            throw new System.NotImplementedException();
        }

        #endregion Перекрытые методы EquipmentFactoryBase

        string cardReaderEmulatorFileName;
    }
}
