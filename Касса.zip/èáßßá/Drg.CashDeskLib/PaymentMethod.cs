﻿using System;
using System.ComponentModel;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Способы оплаты
    /// </summary>
    [Flags]
    public enum PaymentMethod
    {
        None = 0,

        /// <summary>
        /// Пропуск
        /// </summary>
        [Description("Оплата по пропуску")]
        Pass = 1,

        /// <summary>
        /// Банковская карта
        /// </summary>
        [Description("Оплата по банковской карте")]
        BankCard = 2,

        /// <summary>
        /// Наличные
        /// </summary>
        [Description("Оплата наличными")]
        Cash = 4,

        /// <summary>
        /// Талон (бумажный)
        /// </summary>
        [Description("Оплата талонами")]
        Talon = 8
    }
}
