﻿using System;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Способы оплаты
    /// </summary>
    [Flags]
    public enum PaymentMethod
    {
        None = 0,

        /// <summary>
        /// Пропуск
        /// </summary>
        Pass = 1,

        /// <summary>
        /// Банковская карта
        /// </summary>
        BankCard = 2,

        /// <summary>
        /// Наличные
        /// </summary>
        Cash = 4,

        /// <summary>
        /// Талон (бумажный)
        /// </summary>
        Talon = 8
    }
}
