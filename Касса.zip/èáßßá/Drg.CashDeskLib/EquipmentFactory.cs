﻿using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Абстрактная фабрика создания объектов управления оборудованием
    /// </summary>
    public abstract class EquipmentFactory
    {
        /// <summary>
        /// Создать считыватель пропусков
        /// </summary>
        /// <returns></returns>
        public abstract ICardReader CreateCardReader();

        /// <summary>
        /// Создать считыватель пропусков
        /// </summary>
        /// <returns></returns>
        public abstract IKKM CreateKKM();

        /// <summary>
        /// Создать платежный терминал
        /// </summary>
        /// <returns></returns>
        public abstract IPayTerminal CreatePayTerminal();
    }
}
