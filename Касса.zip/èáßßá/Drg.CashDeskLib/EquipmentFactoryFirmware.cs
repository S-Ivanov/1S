﻿using System;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;

namespace Drg.CashDeskLib
{
    public class EquipmentFactoryFirmware : EquipmentFactory
    {
        public EquipmentFactoryFirmware(CashDeskConfigurationFirmware cashDeskConfiguration)
        {
            this.cashDeskConfiguration = cashDeskConfiguration;
        }

        public override ICardReader CreateCardReader()
        {
            throw new NotImplementedException();
        }

        public override IKKM CreateKKM()
        {
            throw new NotImplementedException();
        }

        public override IPayTerminal CreatePayTerminal()
        {
            throw new NotImplementedException();
        }

        CashDeskConfigurationFirmware cashDeskConfiguration;
    }
}
