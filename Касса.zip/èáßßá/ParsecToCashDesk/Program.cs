﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ParsecToCashDesk
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Загрузка работников из Парсек в кассу.");

            string parsecConnectionString = ConfigurationManager.AppSettings["parsecConnectionString"];
            string cashDeskConnectionString = ConfigurationManager.AppSettings["cashDeskConnectionString"];
            using (SqlConnection parsecConnection = new SqlConnection(parsecConnectionString))
            using (SqlConnection cashDeskConnection = new SqlConnection(cashDeskConnectionString))
            {
                parsecConnection.Open();
                cashDeskConnection.Open();

                SqlTransaction transaction = cashDeskConnection.BeginTransaction();
                try
                {
                    SqlCommand parsecCommand = new SqlCommand(
@"SELECT PERSON.PERS_ID, CONVERT(varchar(50), PERSON.TAB_NUM) AS TAB, PERSON.LAST_NAME, PERSON.FIRST_NAME, PERSON.MIDDLE_NAME, Cards.SERIAL, PERSON.PHOTO
FROM     PERSON 
	INNER JOIN IDENTIFIER ON PERSON.PERS_ID = IDENTIFIER.PERS_ID 
	INNER JOIN Cards on dbo.HexStringToInt(IDENTIFIER.CODE) = Cards.CARD_NUM
WHERE  (LEFT(CONVERT(varchar(50), PERSON.TAB_NUM), 1) <> 'p')", 
                        parsecConnection);

                    SqlCommand cashDeskCommand = new SqlCommand(
@"insert into Клиенты (Id, ТабельныйНомер, ФИО, КодПропуска, РазрешеноПитаниеЗП, Фотография)
values (@Id, @ТабельныйНомер, @ФИО, @КодПропуска, 1, @Фотография)", 
                        cashDeskConnection, transaction);
                    cashDeskCommand.Parameters.Add("@Id", SqlDbType.UniqueIdentifier);
                    cashDeskCommand.Parameters.Add("@ТабельныйНомер", SqlDbType.NVarChar, 16);
                    cashDeskCommand.Parameters.Add("@ФИО", SqlDbType.NVarChar, 50);
                    cashDeskCommand.Parameters.Add("@КодПропуска", SqlDbType.BigInt);
                    cashDeskCommand.Parameters.Add("@Фотография", SqlDbType.VarBinary);

                    SqlDataReader parsecReader = parsecCommand.ExecuteReader();
                    while (parsecReader.Read())
                    {
                        cashDeskCommand.Parameters["@Id"].Value = parsecReader.GetValue(0);
                        cashDeskCommand.Parameters["@ТабельныйНомер"].Value = parsecReader.GetValue(1);
                        string fio = parsecReader.GetString(2).TrimEnd();
                        if (!parsecReader.IsDBNull(3))
                        {
                            var s1 = parsecReader.GetString(3);
                            if (!string.IsNullOrEmpty(s1))
                            {
                                fio += " " + s1[0] + ".";
                                if (!parsecReader.IsDBNull(4))
                                {
                                    var s2 = parsecReader.GetString(4);
                                    if (!string.IsNullOrEmpty(s2))
                                        fio += s2[0] + ".";
                                }
                            }
                        }
                        cashDeskCommand.Parameters["@ФИО"].Value = fio;
                        cashDeskCommand.Parameters["@КодПропуска"].Value = parsecReader.GetValue(5);
                        cashDeskCommand.Parameters["@Фотография"].Value = parsecReader.GetValue(6);
                        cashDeskCommand.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}
