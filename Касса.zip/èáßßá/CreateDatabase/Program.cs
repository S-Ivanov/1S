﻿using System;
using System.Data.SqlClient;
using System.IO;

namespace CreateDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Генерация базы данных для кассы.");

            if (args.Length == 0)
            {
                Console.WriteLine("Необходим параметр запуска - имя файла скрипта генерации базы данных.");
                goto Exit;
            }

            string scriptFileName = args[0];

            string script = File.ReadAllText(scriptFileName);

            Console.Write("Введите имя сервера базы данных: ");
            string server = Console.ReadLine();

            Console.Write("Введите логин системного администратора БД: ");
            string login = Console.ReadLine();

            Console.Write("Введите пароль системного администратора БД: ");
            string password = Console.ReadLine();

            Console.Write("Введите имя базы данных: ");
            string dbName = Console.ReadLine();

            using (SqlConnection connection = new SqlConnection($@"Server={server};User ID={login};Password={password};database=master"))
            {
                connection.Open();

                SqlCommand checkDbCommand = new SqlCommand($"SELECT IsNull(db_id('{dbName}'), -1)", connection);
                if ((short)checkDbCommand.ExecuteScalar() < 0)
                {
                    (new SqlCommand($"CREATE DATABASE {dbName}", connection)).ExecuteNonQuery();
                }

                (new SqlCommand($"use {dbName}", connection)).ExecuteNonQuery();

                Console.WriteLine($"Создание базы данных [{dbName}] ...");
                (new SqlCommand(script, connection)).ExecuteNonQuery();
                Console.WriteLine($"Базы данных [{dbName}] создана.");
            }

            Exit:
            Console.WriteLine();
            Console.Write("Press Enter to exit ...");
            Console.ReadLine();
        }
    }
}
