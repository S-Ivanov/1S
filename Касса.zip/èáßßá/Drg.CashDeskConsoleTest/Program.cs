﻿using Drg.CashDeskLib;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace Drg.CashDeskConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = File.ReadAllText(ConfigurationManager.AppSettings["configurationFile"]);
            var serializer = new JavaScriptSerializer();
            CashDeskConfigurationEmulator configuration = serializer.Deserialize<CashDeskConfigurationEmulator>(s);

            CashDesk cashDesk = CashDesk.Create(configuration);

            Console.WriteLine($"Варианты оплаты: {cashDesk.PaymentMethod}");

            Console.WriteLine();
            Console.Write("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}
