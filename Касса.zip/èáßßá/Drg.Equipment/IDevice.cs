﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment
{
    /// <summary>
    /// Интерфейс устройства
    /// </summary>
    public interface IDevice : IDisposable
    {
        #region Свойства

        /// <summary>
        /// Индикатор занятости устройства
        /// </summary>
        bool IsBusy { get; }

        /// <summary>
        /// Последняя ошибка устройства
        /// </summary>
        DeviceError LastError { get; }

        #endregion Свойства

        #region Методы

        /// <summary>
        /// Проверка ошибок устройства
        /// </summary>
        /// <exception cref="DeviceException"></exception>
        void CheckErrors();

         void DoAction<T>(int actionType, T parameters);

        Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token);

        #endregion Методы
    }
}
