﻿namespace Drg.Equipment
{
    public class DeviceError
    {
        public const int NO_ERROR = 0;
        public const int CREATE_ERROR = 1;

        public static DeviceError CreateError(string description)
        {
            return new DeviceError(CREATE_ERROR, description);
        }

        public static DeviceError NoError
        {
            get
            {
                if (noError == null)
                    noError = new DeviceError(NO_ERROR, "Нет ошибок");
                return noError;
            }
        }
        static DeviceError noError = null;

        public DeviceError(int errorCode, string description)
        {
            ErrorCode = errorCode;
            Description = description;
        }

        public readonly int ErrorCode;
        public readonly string Description;
    }
}
