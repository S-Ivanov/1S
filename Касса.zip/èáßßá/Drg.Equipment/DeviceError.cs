﻿namespace Drg.Equipment
{
    public class DeviceError
    {
        public const int NO_ERROR = 0;
        public const int CREATE_ERROR = 1;

        //public static DeviceError CreateError(string description)
        //{
        //    return new DeviceError(CREATE_ERROR, description);
        //}

        public static DeviceError NoError
        {
            get
            {
                if (noError == null)
                    //noError = new DeviceError(NO_ERROR, "Нет ошибок");
                    noError = new DeviceError { ErrorCode = NO_ERROR, Description = "Нет ошибок" };
                return noError;
            }
        }
        static DeviceError noError = null;

        //public DeviceError(int errorCode, string description, string recomendation = null, bool isUserError = false)
        //{
        //    ErrorCode = errorCode;
        //    Description = description;
        //    Recomendation = recomendation;
        //    IsUserError = isUserError;
        //}

        public int ErrorCode { get; set; }

        public bool IsUserError { get; set; }

        public string Description { get; set; }

        public string Recomendation { get; set; }
    }
}
