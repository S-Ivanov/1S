﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.Equipment.CardReader
{
    class Class1
    {
    }
}
