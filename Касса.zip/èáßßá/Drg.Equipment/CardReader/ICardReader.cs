﻿using System;

namespace Drg.Equipment.CardReader
{
    /// <summary>
    /// Считыватель пропусков
    /// </summary>
    public interface ICardReader : IDisposable
    {
        /// <summary>
        /// Проверка доступности
        /// </summary>
        void CheckEnabled();

        /// <summary>
        /// Событие чтения пропуска
        /// </summary>
        event EventHandler<CardReaderEventArgs> DataEvent;
    }
}
