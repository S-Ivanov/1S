﻿using System;

namespace Drg.Equipment.CardReader
{
    /// <summary>
    /// Считыватель пропусков
    /// </summary>
    public interface ICardReader : IDevice
    {
        /// <summary>
        /// Событие чтения пропуска
        /// </summary>
        event EventHandler<CardReaderEventArgs> DataEvent;
    }
}
