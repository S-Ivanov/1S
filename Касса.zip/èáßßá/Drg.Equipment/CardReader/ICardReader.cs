﻿using System;

namespace Drg.Equipment.CardReader
{
    /// <summary>
    /// Считыватель пропусков
    /// </summary>
    public interface ICardReader : IDisposable
    {
        /// <summary>
        /// Доступность считывателя
        /// </summary>
        bool Enabled { get; }

        /// <summary>
        /// Событие чтения пропуска
        /// </summary>
        event EventHandler<CardReaderEventArgs> DataEvent;
    }
}
