﻿using System;

namespace Drg.Equipment.CardReader
{
    /// <summary>
    /// Событие чтения пропуска
    /// </summary>
    public class CardReaderEventArgs : EventArgs
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="cardCode">код пропуска</param>
        public CardReaderEventArgs(string cardCode)
        {
            CardCode = cardCode;
        }

        /// <summary>
        /// Код пропуска
        /// </summary>
        public string CardCode { get; private set; }
    }
}
