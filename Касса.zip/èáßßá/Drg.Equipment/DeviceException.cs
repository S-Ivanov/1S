﻿using System;

namespace Drg.Equipment
{
    public class DeviceException : ApplicationException
    {
        public DeviceException(int errorCode, string description) : base()
        {
            ErrorCode = errorCode;
            Description = description;
        }

        public readonly int ErrorCode;
        public readonly string Description;
    }
}
