﻿using System;
using System.Collections.Generic;

namespace Drg.Equipment
{
    public class DeviceException : ApplicationException
    {
        public DeviceException(DeviceError deviceError) : base(deviceError.Description)
        {
            DeviceError = deviceError;
        }

        public DeviceException(int errorCode, string description) : base(description)
        {
            DeviceError = new DeviceError(errorCode, description);
        }

        public readonly DeviceError DeviceError;

        public List<DeviceError> InnerErrors { get; } = new List<DeviceError>();
    }
}
