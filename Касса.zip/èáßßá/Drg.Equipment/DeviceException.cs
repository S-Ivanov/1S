﻿using System;

namespace Drg.Equipment
{
    public class DeviceException : ApplicationException
    {
        public DeviceException(DeviceError deviceError) : base()
        {
            DeviceError = deviceError;
        }

        public DeviceException(int errorCode, string description) : base()
        {
            DeviceError = new DeviceError(errorCode, description);
        }

        public readonly DeviceError DeviceError;
    }
}
