﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment
{
    public abstract class DeviceBase : IDevice
    {
        public bool IsBusy => Monitor.IsEntered(lockObject);

        public DeviceError LastError { get; protected set; }

        object lockObject = new object();

        public void CheckErrors()
        {
            if (IsBusy)
                return;

            DoLockAction(CheckErrorsInternal);
        }

        void DoLockAction(Action action)
        {
            Monitor.Enter(lockObject);
            try
            {
                action();
            }
            finally
            {
                Monitor.Exit(lockObject);
            }
        }

        protected virtual void CheckErrorsInternal()
        {
        }

        public void Dispose()
        {
            DisposeInternal();
        }

        protected virtual void DisposeInternal()
        {
        }

        public void DoAction<T>(int actionType, T parameters)
        {
            DoLockAction(() => DoActionInternal(actionType, parameters));
        }

        protected virtual void DoActionInternal<T>(int actionType, T parameters)
        {
        }

        public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            Task task = null;
            DoLockAction(() => task = DoActionInternalAsync(actionType, parameters, token, itemCompletedAction, finishAction));
            return task;
        }

        protected virtual Task DoActionInternalAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            throw new NotSupportedException();
        }
    }
}
