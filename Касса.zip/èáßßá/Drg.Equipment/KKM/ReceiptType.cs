﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Тип чека
    /// </summary>
    public enum ReceiptType : int
    {
        LIBFPTR_RT_CLOSED = 0,
        LIBFPTR_RT_SELL = 1,
        LIBFPTR_RT_SELL_RETURN = 2,
        LIBFPTR_RT_SELL_CORRECTION = 7,
        LIBFPTR_RT_BUY = 4,
        LIBFPTR_RT_BUY_RETURN = 5,
        LIBFPTR_RT_BUY_CORRECTION = 9
    }
}
