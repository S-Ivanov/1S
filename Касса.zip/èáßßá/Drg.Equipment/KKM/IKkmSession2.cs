﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Интерфейс ККМ для работы со сменами
    /// </summary>
    public interface IKkmSession2
    {
        #region Свойства

        /// <summary>
        /// Состояние смены
        /// </summary>
        SessionState SessionState { get; }

        /// <summary>
        /// Номер смены
        /// </summary>
        uint SessionNumber { get; }

        /// <summary>
        /// Номер ФН
        /// </summary>
        string FnNumber { get; }

        #endregion Свойства

        #region Методы

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <param name="operatorInfo">должность и ФИО кассира</param>
        /// <param name="operatorINN">ИНН кассира</param>
        void OpenSession(string operatorInfo, string operatorINN);

        /// <summary>
        /// Закрыть смену
        /// </summary>
        /// <param name="operatorInfo">должность и ФИО кассира</param>
        /// <param name="operatorINN">ИНН кассира</param>
        void CloseSession(string operatorInfo, string operatorINN);
        
        #endregion Методы
    }
}
