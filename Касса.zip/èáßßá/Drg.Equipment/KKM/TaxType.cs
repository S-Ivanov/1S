﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Ставка НДС
    /// </summary>
    public enum TaxType : int
    {
        LIBFPTR_TAX_DEPARTMENT = 0,
        LIBFPTR_TAX_VAT18 = 1,
        LIBFPTR_TAX_VAT10,
        LIBFPTR_TAX_VAT118,
        LIBFPTR_TAX_VAT110,
        LIBFPTR_TAX_VAT0,
        LIBFPTR_TAX_NO
    }
}
