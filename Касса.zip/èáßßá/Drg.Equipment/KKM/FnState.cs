﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние фискального накопителя
    /// </summary>
    public enum FnState
    {
        /// <summary>
        /// Настройка ФН
        /// </summary>
        Initial = 0,

        /// <summary>
        /// Готовность к активации
        /// </summary>
        Configured = 1,

        /// <summary>
        /// Фискальный режим
        /// </summary>
        Fiscal = 3,

        /// <summary>
        /// Постфискальный режим
        /// </summary>
        PostFiscal = 7,

        /// <summary>
        /// Доступ к архиву
        /// </summary>
        Archive = 15
    }
}
