﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Позиция чека
    /// </summary>
    public class ReceiptItem
    {
        /// <summary>
        /// Наименование товара
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Цена за единицу товара, р
        /// </summary>
        public double Price { get; set; }

        /// <summary>
        /// Количество товара, ед.
        /// </summary>
        public double Count { get; set; }

        /// <summary>
        /// Ставка НДС
        /// </summary>
        public TaxType TaxType { get; set; }
    }
}
