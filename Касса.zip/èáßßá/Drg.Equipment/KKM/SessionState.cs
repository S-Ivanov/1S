﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние смены
    /// </summary>
    public enum SessionState
    {
        /// <summary>
        /// Закрыта
        /// </summary>
        Closed,

        /// <summary>
        /// Открыта
        /// </summary>
        Opened,

        /// <summary>
        /// Истекло время действия смены
        /// </summary>
        Expired
    }
}
