﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние смены
    /// </summary>
    public enum SessionState : uint
    {
        /// <summary>
        /// Неопределенное состояние, например, когда ККМ неисправна
        /// </summary>
        Unknown = uint.MaxValue,

        /// <summary>
        /// Закрыта
        /// </summary>
        Closed = 0,

        /// <summary>
        /// Открыта
        /// </summary>
        Opened = 1,

        /// <summary>
        /// Истекло время действия смены
        /// </summary>
        Expired = 2
    }
}
