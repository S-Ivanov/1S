﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние смены
    /// </summary>
    public enum SessionState
    {
        /// <summary>
        /// Закрыта
        /// </summary>
        Closed = 0,

        /// <summary>
        /// Открыта
        /// </summary>
        Opened = 1,

        /// <summary>
        /// Истекло время действия смены
        /// </summary>
        Expired = 2
    }
}
