﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.Equipment.KKM
{
    public interface IKKMPayment : IDevice
    {
        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        uint LineLength { get; }

        /// <summary>
        /// Печать нефискального документа
        /// </summary>
        /// <param name="textInfo">содержимое построчно</param>
        /// <exception cref="DeviceException"/>
        void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument);

        /// <summary>
        /// Печать фискального чека
        /// </summary>
        /// <param name="receipt">чек</param>
        /// <exception cref="DeviceException"/>
        void PrintReceipt(Receipt receipt);

    }
}
