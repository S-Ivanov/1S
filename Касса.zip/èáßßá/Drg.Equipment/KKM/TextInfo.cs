﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drg.Equipment.KKM
{
    public class TextInfo
    {
        public static TextInfo CreateLeft(string text)
        {
            return new TextInfo { Text = text, Alignment = TextAlignment.Left };
        }

        public static TextInfo CreateRight(string text)
        {
            return new TextInfo { Text = text, Alignment = TextAlignment.Right };
        }

        public static TextInfo CreateCenter(string text)
        {
            return new TextInfo { Text = text, Alignment = TextAlignment.Center };
        }

        /// <summary>
        /// Строка. Переносится посимвольно. По умолчанию - пустая строка (промотка ленты)
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// Выравнивание
        /// </summary>
        public TextAlignment Alignment { get; set; }

        /// <summary>
        /// Способ переноса строки
        /// </summary>
        public TextWrap Wrap { get; set; }

        /// <summary>
        /// Шрифт. Зависит от модели ККТ, по умолчанию - 0
        /// </summary>
        public int Font { get; set; }

        /// <summary>
        /// Двойная ширина, по умолчанию - false
        /// </summary>
        public bool DoubleWidth { get; set; }

        /// <summary>
        /// Двойная высота, по умолчанию - false
        /// </summary>
        public bool DoubleHeight { get; set; }

        /// <summary>
        /// Межстрочный интервал. Зависит от модели ККТ, по умолчанию - 0
        /// </summary>
        public int LineSpacing { get; set; }

        /// <summary>
        /// Яркость. Зависит от модели ККТ, по умолчанию - 0
        /// </summary>
        public int Brightness { get; set; }

    }
}
