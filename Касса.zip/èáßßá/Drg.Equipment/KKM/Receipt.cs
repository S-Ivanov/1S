﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Чек - фискальный
    /// </summary>
    public class Receipt
    {
        public ReceiptType ReceiptType { get; set; }

        public List<ReceiptItem> Items { get; set; } = new List<ReceiptItem>();

        public Dictionary<PaymentType, double> Payments { get; set; } = new Dictionary<PaymentType, double>();
    }
}
