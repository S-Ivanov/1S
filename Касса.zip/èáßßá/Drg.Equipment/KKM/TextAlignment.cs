﻿namespace Drg.Equipment.KKM
{
    public enum TextAlignment : int
    {
        Left = 0,
        Center,
        Right
    }
}
