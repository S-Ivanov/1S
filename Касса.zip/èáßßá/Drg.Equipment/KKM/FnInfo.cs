﻿using System;

namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Информация о фискальном накопителе
    /// </summary>
    public class FnInfo
    {
        /// <summary>
        /// Номер ФН
        /// </summary>
        public string FnNumber;

        /// <summary>
        /// Состояние ФН
        /// </summary>
        public FnState State;

        /// <summary>
        /// Требуется срочная замена ФН
        /// </summary>
        public bool NeedReplacement;

        /// <summary>
        /// Исчерпан ресурс ФН
        /// </summary>
        public bool Exhausted;

        /// <summary>
        /// Память ФН переполнена
        /// </summary>
        public bool MemoryOverflow;

        /// <summary>
        /// Критическая ошибка ФН
        /// </summary>
        public bool CriticalError;

        /// <summary>
        /// Срок действия ФН
        /// </summary>
        public DateTime ExpireDate;

        /// <summary>
        /// Дата и время первого неотправленного документа
        /// </summary>
        public DateTime FirstNonSendDateTime;
    }
}
