﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment.KKM
{
    /// <summary>
    /// ККМ
    /// </summary>
    public interface IKKM : IDevice
    {
        #region Свойства

        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        uint LineLength { get; }

        /// <summary>
        /// Состояние смены
        /// </summary>
        SessionState SessionState { get; }

        /// <summary>
        /// Номер смены
        /// </summary>
        uint SessionNumber { get; }

        /// <summary>
        /// Номер ФН
        /// </summary>
        string FnNumber { get; }

        /////// <summary>
        /////// Состояние текущего чека
        /////// </summary>
        ////CheckState CheckState { get; }

        ///// <summary>
        ///// Номер текущего чека
        ///// </summary>
        //int CheckNumber { get; }

        ///// <summary>
        ///// Документ закрыт, но не допечатан
        ///// </summary>
        ///// <remarks>
        ///// Рекомендуется вывести пользователю сообщение о сбое печати и попросить устранить неисправность (самый стандартный случай - закончилась бумага). 
        ///// После устранения неисправности требуется продолжить печать (Продолжение печати документа)
        ///// </remarks>
        //bool DocumentNotPrinted { get; }

        /// <summary>
        /// Касса фискализирована
        /// </summary>
        bool Fiscal { get; }

        #endregion Свойства

        #region Методы

        ///// <summary>
        ///// Регистрация кассира
        ///// </summary>
        ///// <param name="operatorInfo">должность + ФИО</param>
        ///// <param name="operatorINN">ИНН кассира</param>
        //void RegisterOperator(string operatorInfo, string operatorINN);

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <param name="operatorInfo">должность + ФИО</param>
        /// <param name="operatorINN">ИНН кассира</param>
        void OpenSession(string operatorInfo, string operatorINN);

        /// <summary>
        /// Закрыть смену
        /// </summary>
        void CloseSession();

        //void PrintNotFiscalCheck();

        //void PrintFiscalCheck();

        ///// <summary>
        ///// Печать нефискального документа
        ///// </summary>
        ///// <param name="textInfo">содержимое построчно</param>
        //void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo);

        ///// <summary>
        ///// Асинхронная печать нефискального документа
        ///// </summary>
        ///// <param name="textInfo">содержимое построчно</param>
        ///// <param name="token">прерывание процесса</param>
        ///// <returns></returns>
        //Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token);

        #endregion Методы
    }
}
