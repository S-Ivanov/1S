﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;

namespace Drg.Equipment.KKM
{
    /// <summary>
    /// ККМ
    /// </summary>
    public interface IKKM : IDevice, IKkmSession2, IKKMPayment
    {
        #region Свойства

        ///// <summary>
        ///// Ширина ленты ККМ для печати слипа, символы
        ///// </summary>
        //uint LineLength { get; }

        ///// <summary>
        ///// Состояние смены
        ///// </summary>
        //SessionState SessionState { get; }

        ///// <summary>
        ///// Номер смены
        ///// </summary>
        //uint SessionNumber { get; }

        /// <summary>
        /// Информация о фискальном накопителе
        /// </summary>
        FnInfo FnInfo { get; }

        /////// <summary>
        /////// Состояние текущего чека
        /////// </summary>
        ////CheckState CheckState { get; }

        ///// <summary>
        ///// Номер текущего чека
        ///// </summary>
        //int CheckNumber { get; }

        ///// <summary>
        ///// Документ закрыт, но не допечатан
        ///// </summary>
        ///// <remarks>
        ///// Рекомендуется вывести пользователю сообщение о сбое печати и попросить устранить неисправность (самый стандартный случай - закончилась бумага). 
        ///// После устранения неисправности требуется продолжить печать (Продолжение печати документа)
        ///// </remarks>
        //bool DocumentNotPrinted { get; }

        /// <summary>
        /// Касса фискализирована
        /// </summary>
        bool Fiscal { get; }

        #endregion Свойства

        #region Методы

        ///// <summary>
        ///// Открыть смену
        ///// </summary>
        ///// <param name="operatorInfo">должность + ФИО</param>
        ///// <param name="operatorINN">ИНН кассира</param>
        //void OpenSession(string operatorInfo, string operatorINN);

        /// <summary>
        /// Закрыть смену
        /// </summary>
        void CloseSession();

        ///// <summary>
        ///// Печать фискального чека
        ///// </summary>
        ///// <param name="receipt">чек</param>
        ///// <exception cref="DeviceException"/>
        //void PrintReceipt(Receipt receipt);

        /// <summary>
        /// Отмена фискального чека
        /// </summary>
        void CancelReceipt();

        ///// <summary>
        ///// Печать нефискального документа
        ///// </summary>
        ///// <param name="textInfo">содержимое построчно</param>
        ///// <exception cref="DeviceException"/>
        //void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument);

        /// <summary>
        /// Асинхронная печать нефискального документа
        /// </summary>
        /// <param name="textInfo">содержимое построчно</param>
        /// <param name="token">прерывание процесса</param>
        /// <param name="itemCompletedAction"></param>
        /// <param name="finishAction"></param>
        /// <returns>запущенная задача</returns>
        Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction);

        /// <summary>
        /// Внесение/выемка денег из кассы
        /// </summary>
        /// <param name="sum">сумма; если больше 0 - внесение, иначе - выемка</param>
        void CasheChange(decimal sum);

        #endregion Методы

        event EventHandler<CloseFiscalDocumentErrorEventArgs> OnCloseFiscalDocumentError;
    }
}
