﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// ККМ
    /// </summary>
    public interface IKKM
    {
        #region Свойства

        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        int SlipCharLineLength { get; }

        /// <summary>
        /// Номер смены
        /// </summary>
        int Session { get; }

        /// <summary>
        /// Номер текущего чека
        /// </summary>
        int CheckNumber { get; }

        /// <summary>
        /// Состояние текущего чека
        /// </summary>
        CheckState CheckState { get; }

        /// <summary>
        /// Состояние смены
        /// </summary>
        SessionState SessionState { get; }

        /// <summary>
        /// Документ закрыт, но не допечатан
        /// </summary>
        /// <remarks>
        /// Рекомендуется вывести пользователю сообщение о сбое печати и попросить устранить неисправность (самый стандартный случай - закончилась бумага). 
        /// После устранения неисправности требуется продолжить печать (Продолжение печати документа)
        /// </remarks>
        bool DocumentNotPrinted { get; }

        #endregion Свойства

        #region Методы

        ///// <summary>
        ///// Открыть смену
        ///// </summary>
        SessionState OpenSession(string operatorFIO, string operatorPost, string operatorINN);

        ///// <summary>
        ///// Закрыть смену
        ///// </summary>
        void CloseSession(string operatorFIO, string operatorPost, string operatorINN);

        #endregion Методы
    }
}
