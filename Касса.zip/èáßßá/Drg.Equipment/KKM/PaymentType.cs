﻿namespace Drg.Equipment.KKM
{
    public enum PaymentType : int
    {
        LIBFPTR_PT_CASH = 0,
        LIBFPTR_PT_ELECTRONICALLY,
        LIBFPTR_PT_PREPAID,
        LIBFPTR_PT_CREDIT,
        LIBFPTR_PT_OTHER,
        LIBFPTR_PT_6,
        LIBFPTR_PT_7,
        LIBFPTR_PT_8,
        LIBFPTR_PT_9,
        LIBFPTR_PT_10
    }
}
