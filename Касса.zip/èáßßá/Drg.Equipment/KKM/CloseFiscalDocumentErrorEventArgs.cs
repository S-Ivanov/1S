﻿using System.ComponentModel;

namespace Drg.Equipment.KKM
{
    public class CloseFiscalDocumentErrorEventArgs : CancelEventArgs
    {
        public int ErrorCode { get; set; }

        public string Description { get; set; }

        public string Message { get; set; }
    }
}
