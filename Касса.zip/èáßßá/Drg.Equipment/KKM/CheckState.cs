﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние чека
    /// </summary>
    public enum CheckState
    {
        /// <summary>
        /// Чек закрыт
        /// </summary>
        Closed = 0,

        /// <summary>
        /// Открыт чек продажи
        /// </summary>
        Sell = 1,

        /// <summary>
        /// Открыт чек возврата продажи
        /// </summary>
        SellReturn = 2,

        /// <summary>
        /// Открыт чек аннулирования продажи
        /// </summary>
        SellCancel = 3,

        /// <summary>
        /// Открыт чек покупки
        /// </summary>
        Buy = 4,

        /// <summary>
        /// Открыт чек возврата покупки
        /// </summary>
        BuyReturn = 5
    }
}
