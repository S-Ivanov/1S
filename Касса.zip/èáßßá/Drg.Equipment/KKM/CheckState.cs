﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Состояние чека
    /// </summary>
    public enum CheckState
    {
        /// <summary>
        /// Чек закрыт
        /// </summary>
        Closed,

        /// <summary>
        /// Открыт чек продажи
        /// </summary>
        Sell,

        /// <summary>
        /// Открыт чек возврата продажи
        /// </summary>
        SellReturn,

        /// <summary>
        /// Открыт чек аннулирования продажи
        /// </summary>
        SellCancel,

        /// <summary>
        /// Открыт чек покупки
        /// </summary>
        Buy,

        /// <summary>
        /// Открыт чек возврата покупки
        /// </summary>
        BuyReturn
    }
}
