﻿namespace Drg.Equipment.KKM
{
    public enum TextWrap : int
    {
        None = 0,
        Words,
        Chars
    }
}
