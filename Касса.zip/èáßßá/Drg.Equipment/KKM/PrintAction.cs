﻿namespace Drg.Equipment.KKM
{
    public enum PrintAction
    {
        PrintNotFiscal
    }
}
