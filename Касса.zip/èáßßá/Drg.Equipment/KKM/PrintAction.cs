﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Варианты использования ККМ
    /// </summary>
    public enum PrintAction
    {
        /// <summary>
        /// Нефискальная печать 
        /// </summary>
        PrintNotFiscal,

        /// <summary>
        /// Печать фискального чека
        /// </summary>
        PrintReceipt
    }
}
