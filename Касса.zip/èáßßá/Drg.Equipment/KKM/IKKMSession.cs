﻿namespace Drg.Equipment.KKM
{
    /// <summary>
    /// Управление сменами на ККМ
    /// </summary>
    public interface IKKMSession
    {
        /// <summary>
        /// Номер смены
        /// </summary>
        uint SessionNumber { get; }

        /// <summary>
        /// Состояние смены в ККМ
        /// </summary>
        SessionState SessionState { get; }

        /// <summary>
        /// Закрыть смену
        /// </summary>
        void CloseSession();

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <param name="operatorInfo">должность + ФИО</param>
        /// <param name="operatorINN">ИНН кассира</param>
        void OpenSession(string operatorInfo, string operatorINN);
    }
}
