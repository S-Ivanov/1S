﻿using System;
using System.Xml.Serialization;

namespace Drg.Equipment
{
    /// <summary>
    /// Виды поддерживаемого оборудования
    /// </summary>
    [Flags]
    public enum Device
    {
        //[XmlEnum(Name = "None")]
        None = 0,

        /// <summary>
        /// Считыватель пропусков
        /// </summary>
        CardReader = 1,

        /// <summary>
        /// ККМ
        /// </summary>
        KKM = 2,

        /// <summary>
        /// Банковский терминал
        /// </summary>
        PayTerminal = 4,

        /// <summary>
        /// Денежный ящик
        /// </summary>
        MoneyBox = 8
    }
}
