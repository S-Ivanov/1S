﻿using System;
using System.ComponentModel;

namespace Drg.Equipment
{
    /// <summary>
    /// Виды поддерживаемого оборудования
    /// </summary>
    [Flags]
    public enum Device
    {
        None = 0,

        /// <summary>
        /// Считыватель пропусков
        /// </summary>
        [Description("Считыватель пропусков")]
        CardReader = 1,

        /// <summary>
        /// ККМ
        /// </summary>
        [Description("Контрольно-кассовая машина")]
        KKM = 2,

        /// <summary>
        /// Банковский терминал
        /// </summary>
        [Description("Банковский терминал")]
        PayTerminal = 4
    }
}
