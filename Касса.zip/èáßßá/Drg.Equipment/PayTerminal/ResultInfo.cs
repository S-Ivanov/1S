﻿namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Результат выполнения операции
    /// </summary>
    public class ResultInfo
    {
        /// <summary>
        /// Ошибка устройства
        /// </summary>
        public DeviceError DeviceError { get; set; }

        /// <summary>
        /// Рекомендация к результату
        /// </summary>
        public string ResultPrompt { get; set; }
    }
}
