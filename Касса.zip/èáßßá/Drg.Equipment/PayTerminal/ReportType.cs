﻿namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Тип отчета
    /// </summary>
    public enum ReportType : int
    {
        /// <summary>
        /// Закрытие смены
        /// </summary>
        CloseSession = 0,

        /// <summary>
        /// Журнал операций
        /// </summary>
        OperationsLog = 1,

        /// <summary>
        /// Итоги операций
        /// </summary>
        OperationsTotal = 2
    }
}
