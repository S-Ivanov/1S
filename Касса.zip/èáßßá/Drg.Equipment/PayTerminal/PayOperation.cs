﻿namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Вид операции
    /// </summary>
    public enum PayOperation
    {
        /// <summary>
        /// Оплата (списание денег со счета карты)
        /// </summary>
        Payment = 0,

        /// <summary>
        /// Возврат (зачисление денег на счет карты)
        /// </summary>
        Return = 1
    }
}
