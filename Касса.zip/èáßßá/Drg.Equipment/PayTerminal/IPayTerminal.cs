﻿namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Платежный (эквайринговый) терминал
    /// </summary>
    public interface IPayTerminal : IDevice
    {
        /// <summary>
        /// Выполнение операции с терминалом (оплата / возврат оплаты)
        /// </summary>
        /// <param name="payOperation">вид операции</param>
        /// <param name="sessionNumber">номер смены ККМ</param>
        /// <param name="checkNumber">номер чека ККМ</param>
        /// <param name="sum">сумма</param>
        /// <returns>объект PayResult - если оплата выполнена (возможно, с ошибкой процессингового центра), null - если клиент отказался от оплаты (в процессе авторизации)</returns>
        PayResult Operation(PayOperation payOperation, int sessionNumber, int checkNumber, decimal sum);
    }
}
