﻿namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Платежный (эквайринговый) терминал
    /// </summary>
    public interface IPayTerminal : IDevice
    {
        /// <summary>
        /// Оплата
        /// </summary>
        /// <param name="sessionNumber"></param>
        /// <param name="checkNumber"></param>
        /// <param name="sum"></param>
        /// <returns></returns>
        PayResult Pay(int sessionNumber, int checkNumber, decimal sum);

        /// <summary>
        /// Возврат оплаты
        /// </summary>
        /// <param name="sessionNumber"></param>
        /// <param name="checkNumber"></param>
        /// <param name="sum"></param>
        /// <returns></returns>
        PayResult ReturnPay(int sessionNumber, int checkNumber, decimal sum);
    }
}
