﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Drg.Equipment.PayTerminal
{
    /// <summary>
    /// Платежный (эквайринговый) терминал
    /// </summary>
    public interface IPayTerminal : IDevice
    {
        /// <summary>
        /// Ширина ленты ККМ для печати слипа, символы
        /// </summary>
        uint LineLength { get; set; }

        /// <summary>
        /// Формирование отчета
        /// </summary>
        /// <param name="reportType">тип отчета</param>
        string Report(ReportType reportType, IEnumerable<AuthorizationInfo> authorizationInfoCollection);

        /// <summary>
        /// Оплата
        /// </summary>
        /// <param name="sessionNumber">номер смены</param>
        /// <param name="checkNumber">номер чека</param>
        /// <param name="sum">сумма</param>
        /// <returns></returns>
        PayResult Pay(int sessionNumber, int checkNumber, decimal sum);

        /// <summary>
        /// Отмена оплаты
        /// </summary>
        /// <param name="sessionNumber">номер смены</param>
        /// <param name="checkNumber">номер чека</param>
        /// <param name="sum">сумма</param>
        /// <returns></returns>
        PayResult CancelPay(int sessionNumber, int checkNumber, decimal sum);

        /// <summary>
        /// Возврат оплаты
        /// </summary>
        /// <param name="sessionNumber">номер смены</param>
        /// <param name="checkNumber">номер чека</param>
        /// <param name="sum">сумма</param>
        /// <returns></returns>
        PayResult ReturnPay(int sessionNumber, int checkNumber, decimal sum);

        /// <summary>
        /// Отмена возврата оплаты
        /// </summary>
        /// <param name="sessionNumber">номер смены</param>
        /// <param name="checkNumber">номер чека</param>
        /// <param name="sum">сумма</param>
        /// <returns></returns>
        PayResult CancelReturnPay(int sessionNumber, int checkNumber, decimal sum);

        //event EventHandler<CancelEventArgs> OnBeforeCancel;
    }
}
