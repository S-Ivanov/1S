﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.ProgressBarTest
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarDialog progressBarDialog = new ProgressBarDialog();
            progressBarDialog.ProcessProgressBar.Minimum = 0;
            progressBarDialog.ProcessProgressBar.Maximum = 100;

            CancellationTokenSource cancelTokenSource = new CancellationTokenSource();
            CancellationToken token = cancelTokenSource.Token;

            Task.Run(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    if (token.CanBeCanceled && token.IsCancellationRequested)
                    {
                        break;
                    }

                    Thread.Sleep(25);
                    Dispatcher.Invoke(() => progressBarDialog.ProcessProgressBar.Value = i);
                }

                Dispatcher.Invoke(() => progressBarDialog.Close());
                MessageBox.Show("Finish");
            },
            token);

            if (progressBarDialog.ShowDialog() == true)
            {
                cancelTokenSource.Cancel();
            }
        }
    }
}
