﻿using Drg.Equipment.KKM;
using System;

namespace Drg.CashDeskLib.DB
{
    /// <summary>
    /// Управление сменами в базе данных
    /// </summary>
    public interface IDBSession
    {
        /// <summary>
        /// Изменить номер смены
        /// </summary>
        /// <param name="sessionId">идентификатор смены</param>
        /// <param name="sessionNumber">номер смены</param>
        void ChangeSessionNumber(Guid sessionId, uint sessionNumber);

        /// <summary>
        /// Открыть смену
        /// </summary>
        DataModel.Session OpenSession(Guid operatorId, string fnNumber, uint sessionNumber);

        /// <summary>
        /// Закрыть смену
        /// </summary>
        /// <param name="sessionId">идентификатор смены</param>
        void CloseSession(Guid sessionId);

        /// <summary>
        /// Загрузить информацию о последней смене
        /// </summary>
        DataModel.Session LoadLastSession();
    }
}
