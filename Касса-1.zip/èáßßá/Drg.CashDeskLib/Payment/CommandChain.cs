﻿using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.Payment
{
    /// <summary>
    /// Цепочка команд
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CommandChain<T>
    {
        /// <summary>
        /// Фабричный метод создания
        /// </summary>
        /// <returns></returns>
        public static CommandChain<T> Create(bool interruptUndoOnException = false) => new CommandChain<T>(interruptUndoOnException);

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="interruptUndoOnException">
        /// флаг прерывания цепочки отката:
        /// true - прерывать цепочку отката, если при откате очередной команды произошла ошибка
        /// </param>
        private CommandChain(bool interruptUndoOnException)
        {
            this.interruptUndoOnException = interruptUndoOnException;
        }

        /// <summary>
        /// Добавление команды
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public CommandChain<T> Add(Command<T> command)
        {
            commands.Add(command);
            return this;
        }

        /// <summary>
        /// Выполнение цепочки команд
        /// </summary>
        /// <param name="data"></param>
        public void Execute(T data)
        {
            // очистить список ошибок отката
            undoExceptions.Clear();

            int commandIndex = 0;
            try
            {
                // последовательное выполнение команд
                for (; commandIndex < commands.Count; commandIndex++)
                {
                    commands[commandIndex].Execute(data);
                }
            }
            catch (Exception ex)
            {
                // в случае ошибки в какой-либо команде откат команд в обратном порядке
                bool started = true;
                for (; commandIndex >= 0; commandIndex--)
                {
                    try
                    {
                        if ((started && commands[commandIndex].UndoSelfException) || !started)
                            commands[commandIndex].Undo(data);
                    }
                    catch (Exception undoException)
                    {
                        // в случае ошибки отката команды запомним ее для последующего использования
                        undoExceptions.Add(undoException);

                        // если установлен флаг прерывания цепочки отката, прервать цикл отката
                        if (interruptUndoOnException)
                            break;
                    }

                    started = false;
                }

                // прокинуть ошибку выполнения команды
                throw ex;
            }
        }

        /// <summary>
        /// Список ошибок отката
        /// </summary>
        public IEnumerable<Exception> UndoExceptions => undoExceptions;
        List<Exception> undoExceptions = new List<Exception>();

        /// <summary>
        /// Команды
        /// </summary>
        List<Command<T>> commands = new List<Command<T>>();

        /// <summary>
        /// Флаг прерывания цепочки отката:
        /// true - прерывать цепочку отката, если при откате очередной команды произошла ошибка
        /// </summary>
        bool interruptUndoOnException;
    }
}
