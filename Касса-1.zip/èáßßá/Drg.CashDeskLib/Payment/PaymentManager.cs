﻿using Drg.CashDeskLib.DB;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDeskLib.Payment
{
    /// <summary>
    /// Менеджер оплаты
    /// </summary>
    /// <remarks>Управление устройствами в процессе оплаты/возврата заказа</remarks>
    public class PaymentManager
    {
        #region Конструктор

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="kkm">ККМ</param>
        /// <param name="payTerminal">платежный терминал</param>
        /// <param name="localDB">база данных</param>
        /// <param name="textWrapper">перенос текста</param>
        /// <param name="configuration">конфигурация менеджера оплаты</param>
        public PaymentManager(
            IKKMPayment2 kkm,
            IPayTerminal payTerminal,
            ILocalDBPayment localDB,
            TextWrapper.TextWrapper textWrapper,
            PaymentManagerConfiguration configuration)
        {
            this.kkm = kkm;
            this.payTerminal = payTerminal;
            this.localDB = localDB;
            this.textWrapper = textWrapper;
            this.configuration = configuration;

            if (this.payTerminal != null && this.kkm != null)
                this.payTerminal.LineLength = this.kkm.LineLength;

            InitCommandChain();
        }

        #endregion Конструктор

        #region Свойства

        /// <summary>
        /// Список ошибок отката
        /// </summary>
        public IEnumerable<Exception> UndoExceptions => commandChain.UndoExceptions;

        #endregion Свойства

        #region Методы

        #region Публичные методы

        /// <summary>
        /// Выполнить оплату/возврат чека
        /// </summary>
        /// <param name="session">смена</param>
        /// <param name="receipt">чек</param>
        /// <param name="@operator">оператор</param>
        /// <param name="operatorINN">ИНН оператора</param>
        /// <returns>
        /// true - если оплата выполнена
        /// false - если пользователь отменил оплату банковской картой
        /// </returns>
        /// <exception cref="DataModel.PaymentManagerExtException"></exception>
        public bool PayReceipt(DataModel.Session session, DataModel.Receipt receipt, string @operator, string operatorINN)
        {
            PaymentInfo paymentInfo = new PaymentInfo
            {
                Session = session,
                Receipt = receipt,
                Operator = @operator,
                OperatorINN = operatorINN
            };

            try
            {
                commandChain.Execute(paymentInfo);
                localDB.SavePayment(session.Id, receipt, configuration.IsTestMode);
                return true;
            }
            catch (DataModel.PaymentManagerExtException)
            {
                if (paymentInfo.PayTerminalCanceled)
                    return false;
                else
                    throw;
            }
            catch (Exception ex)
            {
                throw new DataModel.PaymentManagerExtException(Device.None, null, "Неизвестная ошибка менеджера оплаты", ex);
            }
        }

        /// <summary>
        /// Получить запрещенные варианты оплаты
        /// </summary>
        /// <param name="errorDevice">устройство, на котором произошла ошибка</param>
        /// <returns></returns>
        public static IEnumerable<DataModel.Payment> GetForbiddenPayments(Device errorDevice)
        {
            List<DataModel.Payment> forbiddenPayments = new List<DataModel.Payment>();

            if (errorDevice == Device.PayTerminal)
                forbiddenPayments.Add(DataModel.Payment.BankCard);
            else if (errorDevice == Device.KKM)
            {
                forbiddenPayments.Add(DataModel.Payment.BankCard);
                forbiddenPayments.Add(DataModel.Payment.Cash);
            }

            return forbiddenPayments;
        }

        #endregion Публичные методы

        #region Приватные методы

        #region Основные методы

        /// <summary>
        /// Инициализация схемы управления устройствами
        /// </summary>
        private void InitCommandChain()
        {
            commandChain = CommandChain<PaymentInfo>
                .Create()
                // нефискальная оплата
                .Add(new Command<PaymentInfo>(
                    p => p.Receipt.Order.ZP != 0 || p.Receipt.Order.LPP != 0 || p.Receipt.Order.Talon120 != 0,
                    p => NotfiscalPrintAction(p)))
                // банковский терминал
                .Add(new Command<PaymentInfo>(
                    p => p.Receipt.Order.BankCard != 0,
                    p => PayTerminalAction(p),
                    p => PayTerminalUndo(p)))
                // печать слипа
                .Add(new Command<PaymentInfo>(
                    p => p.Receipt.Order.BankCard != 0,
                    p => SlipPrintAction(p)))
                // фискальная оплата
                .Add(new Command<PaymentInfo>(
                    p => p.Receipt.Order.BankCard != 0 || p.Receipt.Order.Cash != 0,
                    p => FiscalPrintAction(p)));
        }

        /// <summary>
        /// Напечатать нефискальный чек
        /// </summary>
        /// <param name="p"></param>
        void NotfiscalPrintAction(PaymentInfo p)
        {
            if (kkm == null)
                return;

            PrintNonFiscalDocument(
                GetNotFiscalReceipt(
                    p.Receipt, 
                    this.textWrapper, 
                    kkm.LineLength,
                    configuration.NominalLPP,
                    configuration.NominalTalon120, 
                    MakeHeader),
                p.Receipt.Order is DataModel.OrderReturn ? configuration.ReturnCopies : 1, 
                "Нефискальный чек");
        }

        /// <summary>
        /// Напечатать нефискальный документ
        /// </summary>
        /// <param name="nonFiscalDocument"></param>
        /// <param name="copies">количество копий</param>
        /// <param name="errorMessage">сообщение об ошибке</param>
        void PrintNonFiscalDocument(IEnumerable<TextInfo> nonFiscalDocument, int copies, string errorMessage)
        {
            if (kkm == null)
                return;

            for (int i = 0; i < copies; i++)
            {
                try
                {
                    //kkm.PrintNonFiscalDocument(nonFiscalDocument, true);
                    kkm.PrintNonFiscalDocument2(nonFiscalDocument);
                }
                catch (Exception ex)
                {
                    throw new DataModel.PaymentManagerExtException(Device.KKM, kkm.LastError, errorMessage, ex);
                }

                if (kkm.LastError != null && kkm.LastError.HasError)
                    throw new DataModel.PaymentManagerExtException(Device.KKM, kkm.LastError, errorMessage);
            }
        }

        /// <summary>
        /// Оплата по банковскому терминалу
        /// </summary>
        /// <param name="p"></param>
        void PayTerminalAction(PaymentInfo p)
        {
            if (payTerminal == null)
                return;

            PayResult payResult = null;
            try
            {
                payResult =
                    p.Receipt.Order is DataModel.OrderReturn ?
                    payTerminal.ReturnPay((int)p.Session.Number, p.Receipt.Order.Number, p.Receipt.Order.BankCard) :
                    payTerminal.Pay((int)p.Session.Number, p.Receipt.Order.Number, p.Receipt.Order.BankCard);

                if (payResult != null)
                {
                    // записать информацию о выполнении операции в БД
                    localDB.SaveAuthorizationInfo(Guid.NewGuid(), p.Session.Id, Guid.Empty, payResult.AuthorizationInfo);
                    if (payResult.DeviceError.HasError)
                        throw new DataModel.PaymentManagerExtException(Device.PayTerminal, payResult.DeviceError, "Терминал: ошибка платежа");
                }
            }
            catch (DataModel.PaymentManagerExtException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new DataModel.PaymentManagerExtException(Device.PayTerminal, payTerminal.LastError, "Терминал: ошибка платежа", ex);
            }

            if (payResult != null)
                p.SlipText = payResult.SlipText;
            else
            {
                p.PayTerminalCanceled = true;
                throw new DataModel.PaymentManagerExtException(Device.PayTerminal, null, "Терминал: отказ платежа");
            }
        }

        /// <summary>
        /// Отмена оплаты по банковскому терминалу
        /// </summary>
        /// <param name="p"></param>
        void PayTerminalUndo(PaymentInfo p)
        {
            // локальная функция отказа от отмены
            void CancelUndo()
            {
                // записать информацию об ошибке возврата в БД
                localDB.SavePayTerminalReturnError(Guid.NewGuid(), (int)p.Session.Number, p.Receipt.Order.Number);
                throw new DataModel.PaymentManagerExtException(Device.PayTerminal, null, "Терминал: отказ отмены");
            }

            if (payTerminal == null)
                return;

            // если пользователь отменил оплату, откат делать не нужно
            if (p.PayTerminalCanceled)
                return;

            if (OnBeforePayTerminalCancel != null)
            {
                CancelEventArgs eventArgs = new CancelEventArgs();
                OnBeforePayTerminalCancel(this, eventArgs);
                if (eventArgs.Cancel)
                    CancelUndo();
            }

            PayResult payResult = null;
            try
            {
                payResult =
                    p.Receipt.Order is DataModel.OrderReturn ?
                    payTerminal.CancelReturnPay((int)p.Session.Number, p.Receipt.Order.Number, p.Receipt.Order.BankCard) :
                    payTerminal.CancelPay((int)p.Session.Number, p.Receipt.Order.Number, p.Receipt.Order.BankCard);

                if (payResult == null)
                    CancelUndo();
                else
                {
                    // записать информацию о выполнении операции в БД
                    localDB.SaveAuthorizationInfo(Guid.NewGuid(), p.Session.Id, Guid.Empty, payResult.AuthorizationInfo);
                    if (payResult.DeviceError.HasError)
                        throw new DataModel.PaymentManagerExtException(Device.PayTerminal, payTerminal.LastError, "Терминал: ошибка отмены");
                }
            }
            catch (DataModel.PaymentManagerExtException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new DataModel.PaymentManagerExtException(Device.PayTerminal, payTerminal.LastError, "Терминал: ошибка отмены", ex);
            }
        }

        /// <summary>
        /// Печать слипа
        /// </summary>
        /// <param name="p"></param>
        void SlipPrintAction(PaymentInfo p)
        {
            if (kkm == null || string.IsNullOrEmpty(p.SlipText))
                return;

            var slip = TextInfo.ConvertText(p.SlipText).ToArray();
            if (slip.Any())
            {
                for (int i = 0; i < configuration.SlipCount; i++)
                {
                    PrintNonFiscalDocument(slip, configuration.SlipCount, "Печать слипа");
                }
            }
        }

        /// <summary>
        /// Печать фискального чека
        /// </summary>
        /// <param name="p"></param>
        void FiscalPrintAction(PaymentInfo p)
        {
            if (kkm == null)
                return;

            // фискальный чек
            Receipt receipt = GetKKMReceipt(p.Receipt.Order);
            // нефискальный заголовок
            var header = MakeHeader(p.Receipt.Order, kkm.LineLength);

            try
            {
                kkm.PrintReceipt2(header, receipt, configuration.PaymentsPlace, p.Operator, p.OperatorINN);

                if (p.Receipt.Order is DataModel.OrderReturn)
                {
                    for (int i = 1; i < configuration.ReturnCopies; i++)
                    {
                        kkm.PrintLastReceiptCopy();
                    }
                }
            }
            catch (DeviceException ex)
            {
                throw new DataModel.PaymentManagerExtException(Device.KKM, ex.DeviceError, "Фискальный чек");
            }
        }

        #endregion Основные методы

        #region Вспомогательные методы

        Receipt GetKKMReceipt(DataModel.Order order)
        {
            var result = new Drg.Equipment.KKM.Receipt
            {
                ReceiptType = order is DataModel.OrderReturn ? ReceiptType.LIBFPTR_RT_SELL_RETURN : ReceiptType.LIBFPTR_RT_SELL
            };

            var fiscal = order.Items.Where(_ => _.Payment == DataModel.Payment.BankCard || _.Payment == DataModel.Payment.Cash);

            foreach (var orderItem in fiscal.OrderBy(_ => _.MenuItem.Name).ThenBy(_ => _.Price))
            {
                result.Items.Add(
                    new ReceiptItem
                    {
                        Name = orderItem.MenuItem.Name,
                        Price = (double)orderItem.Price,
                        Count = (double)orderItem.Count,
                        TaxType = orderItem.MenuItem.VATCode < 0 ? TaxType.CUSTOM : (TaxType)orderItem.MenuItem.VATCode,
                        VATCoefficient = (double)orderItem.MenuItem.VATCoefficient
                    });
            }

            var orderItemsByPayment = fiscal.GroupBy(_ => _.Payment);
            foreach (var paymentGroup in orderItemsByPayment)
            {
                // привести тип оплаты
                PaymentType paymentType =
                    paymentGroup.Key == DataModel.Payment.BankCard ?
                    PaymentType.LIBFPTR_PT_ELECTRONICALLY :
                    PaymentType.LIBFPTR_PT_CASH;

                result.Payments.Add(paymentType, (double)paymentGroup.Sum(_ => _.Sum));
            }

            return result;
        }

        static List<TextInfo> GetNotFiscalReceipt(
            DataModel.Receipt receipt,
            TextWrapper.TextWrapper textWrapper,
            uint lineLength,
            decimal nominalLPP,
            decimal nominalTalon120,
            Func<DataModel.Order, uint, IEnumerable<TextInfo>> makeHeaderFunc = null)
        {
            List<TextInfo> result = new List<TextInfo>();

            // длина максимальной суммы подвала
            int orderTotalSumSigns = receipt.Order.Items.Sum(_ => _.Sum).ToString("N2").Length;

            // длина максимальной суммы тела
            int orderSumSigns = receipt.Order.Items.Max(_ => _.Sum).ToString("N2").Length;

            // сумма чека в счёт ЗП
            // используется для вычисления общей затраченной суммы из ЗП работником
            decimal orderSumZP = receipt.Order.ZP;

            // сумма чека в счёт ЛПП
            // используется для вычисления общей затраченной суммы из ЛПП работником
            decimal orderSumLPP = receipt.Order.LPP;

            // сумма чека в счёт талона 120
            decimal orderSumTalon120 = receipt.Order.Talon120;

            // формировать заголовок 1
            if (makeHeaderFunc != null)
                result.AddRange(makeHeaderFunc(receipt.Order, lineLength));

            // формировать заголовок 2 только при наличии клиента
            if (receipt.Client != null)
            {
                int sign = receipt.Order is DataModel.OrderReturn ? -1 : 1;

                string clienFIOandTumNum = receipt.Client.FIO + " " + receipt.Client.TabNum;
                string title21 = "ЗП: ";
                string zp = (receipt.Client.UsedZP + sign * orderSumZP).ToString("N2");
                string zpFull = string.Empty;

                // проверить наличие ЛПП
                string lpp = string.Empty;
                string lppCount = string.Empty;
                string lppFull = string.Empty;
                int lppCountDiff = 0;
                //if (receipt.Client.MonthLimitLPP != 0 || orderSumLPP > 0)
                if (orderSumLPP > 0)
                {
                    //lppCountDiff = receipt.Client.MonthLimitLPP - sign * (int)(orderSumLPP / nominalLPP);
                    lppCountDiff = (int)((receipt.Client.UsedLPP + sign * orderSumLPP) / nominalLPP);
                    if (lppCountDiff != 0)
                    {
                        decimal lppDiff = lppCountDiff * nominalLPP;
                        lpp = Math.Abs(lppDiff).ToString("N2");
                        lppCount = Math.Abs(lppCountDiff).ToString();
                    }
                }
                string title22 = string.Empty;
                if (lppCountDiff > receipt.Client.MonthLimitLPP)
                    title22 = "Перерасход";
                else if (lppCountDiff < receipt.Client.MonthLimitLPP)
                    title22 = "Остаток";
                if (!string.IsNullOrEmpty(title22))
                {
                    title22 += " ЛПП: ";
                    //lppCountDiff == 0 ? "" : ((lppCountDiff < 0 ? "Перерасход" : "Остаток") + " ЛПП: ");

                    //if (lpp != string.Empty)
                    //{
                    if (lpp.Length >= zp.Length)
                    {
                        zp = zp.PadLeft(lpp.Length);
                    }
                    else
                    {
                        lpp = lpp.PadLeft(zp.Length);
                    }
                    lppFull = lppCount + " = " + lpp;
                    zp = zp.PadLeft(lppFull.Length);
                }

                zpFull = title21 + zp;

                int spacesCount = (int)lineLength - (clienFIOandTumNum.Length + zpFull.Length) >= 1 ? (int)lineLength - (clienFIOandTumNum.Length + zpFull.Length) : 1;
                result.Add(TextInfo.CreateLeft(clienFIOandTumNum + new String(' ', spacesCount) + zpFull));

                if (lppFull != string.Empty)
                    result.Add(TextInfo.CreateRight(title22 + lppFull));

                result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));
            }

            // формировать шапку списка товаров
            string title3 = "Наименования блюд и товаров";
            result.Add(TextInfo.CreateCenter(title3));

            result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));

            // формировать тело списка товаров
            var orderItemsByMenuItem = receipt.Order.Items.OrderBy(_ => _.MenuItem.Name).ThenBy(_ => _.Price).GroupBy(_ => _.MenuItem);
            int count = 0;
            foreach (var g in orderItemsByMenuItem)
            {
                count++;

                string lineNumber = $"{count}. ";
                string itemString = g.Key.Name + ", " + g.Key.Unit;

                //IEnumerable<string> wrappedString = textWrapper.WrapText(itemString, (int)lineLength - lineNumber.Length);
                IEnumerable<string> wrappedString =
                    textWrapper == null ?
                    new string[] { itemString } :
                    textWrapper.WrapText(itemString, (int)lineLength - lineNumber.Length);

                bool firstLine = true;
                foreach (var line in wrappedString)
                {
                    result.Add(TextInfo.CreateLeft((firstLine ? lineNumber : new string(' ', lineNumber.Length)) + line));
                    firstLine = false;
                }

                decimal countMenuItem = g.Sum(_ => _.Count);
                decimal sumMenuItem = g.Sum(_ => _.Sum);
                string leftPart = new String(' ', (count.ToString() + ". ").Length) + DecimalToString(countMenuItem, 3) + " X " + g.Key.Price.ToString("N2");
                string rightPart = "= " + sumMenuItem.ToString("N2").PadLeft(orderSumSigns);
                result.Add(TextInfo.CreateRight(leftPart + new String(' ', (int)lineLength - (leftPart.Length + rightPart.Length)) + rightPart));
            }

            // формировать подвал списка товаров
            result.Add(new TextInfo
            {
                Text = new String('-', (int)lineLength),
                Alignment = TextAlignment.Left
            });

            var orderItemsByPayment = receipt.Order.Items.GroupBy(_ => _.Payment);
            var dictionarySums = orderItemsByPayment.ToDictionary(_ => _.Key, _ => _.Sum(x => x.Sum));

            string title5 = "ВСЕГО";
            string totalSum = dictionarySums.Sum(_ => _.Value).ToString("N2");
            result.Add(TextInfo.CreateRight(title5 + " = " + totalSum));

            foreach (var item in dictionarySums)
            {
                result.Add(TextInfo.CreateRight(GetPaymentName(item.Key, orderSumLPP, nominalLPP, orderSumTalon120, nominalTalon120) + " = " + item.Value.ToString("N2").PadLeft(orderTotalSumSigns)));
            }

            return result;
        }

        static string DecimalToString(decimal value, int decimals) => value % 1 == 0 ? ((int)value).ToString() : value.ToString($"N{decimals}");

        /// <summary>
        /// Преобразовать тип оплаты Payment в строковый вид
        /// </summary>
        /// <param name="payment"></param>
        /// <param name="orderSumLPP"></param>
        /// <param name="nominalLPP"></param>
        /// <param name="orderSumTalon120"></param>
        /// <param name="nominalTalon120"></param>
        /// <returns></returns>
        static string GetPaymentName(DataModel.Payment payment, decimal orderSumLPP, decimal nominalLPP, decimal orderSumTalon120, decimal nominalTalon120)
        {
            switch (payment)
            {
                case DataModel.Payment.BankCard: return "Банковской картой";
                case DataModel.Payment.Cash: return "Наличными";
                case DataModel.Payment.LPP: return "Талон ЛПП: " + (int)(orderSumLPP / nominalLPP);
                case DataModel.Payment.Talon120: return "Талон 120: " + (int)(orderSumTalon120 / nominalTalon120);
                case DataModel.Payment.ZP: return "В счёт ЗП";
            }
            return string.Empty;
        }

        List<TextInfo> MakeHeader(DataModel.Order order, uint lineLength)
        {
            List<TextInfo> result = new List<TextInfo>();

            string title11;
            int orderNumber;
            DateTime orderDate;
            if (order is DataModel.OrderReturn orderReturn)
            {
                title11 = "ВОЗВРАТ";
                orderNumber = orderReturn.SourceNumber;
                orderDate = orderReturn.SourceDate;
            }
            else
            {
                title11 = "ПРИХОД";
                orderNumber = order.Number;
                orderDate = order.DateTime;
            }

            string orderNumberStr = orderNumber.ToString();
            string orderDateTimeStr = orderDate.ToString();

            string title12 = title11 + " " + "Заказ № ";
            int spacesCount = (int)lineLength - (title12.Length + orderNumberStr.Length + orderDateTimeStr.Length) >= 1 ? (int)lineLength - (title12.Length + orderNumberStr.Length + orderDateTimeStr.Length) : 1;
            result.Add(TextInfo.CreateLeft(title12 + orderNumberStr + new String(' ', spacesCount) + orderDateTimeStr));
            result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));

            return result;
        }

        #endregion Вспомогательные методы

        #endregion Приватные методы

        #endregion Методы

        #region События

        /// <summary>
        /// Событие перед отменой оплаты банковской картой
        /// </summary>
        /// <remarks>
        /// Генерируется в случае, если в процессе оплаты банковской картой на ККМ возникла ошибка, перед отменой платежа - чтобы пользователю сообщить, что нужно приложить карту
        /// </remarks>
        public event EventHandler<CancelEventArgs> OnBeforePayTerminalCancel;

        #endregion События

        #region Поля

        CommandChain<PaymentInfo> commandChain;

        IKKMPayment2 kkm;
        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
        TextWrapper.TextWrapper textWrapper;
        PaymentManagerConfiguration configuration;

        #endregion Поля
    }
}
