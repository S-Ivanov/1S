﻿namespace Drg.CashDeskLib.Payment
{
    /// <summary>
    /// Конфигурация менеджера оплаты
    /// </summary>
    public class PaymentManagerConfiguration
    {
        /// <summary>
        /// Количество копий слипа
        /// </summary>
        public int SlipCount { get; set; }

        /// <summary>
        /// Флаг тестового режима работы
        /// </summary>
        public bool IsTestMode { get; set; }

        /// <summary>
        /// Количество копий чеков возврата
        /// </summary>
        public int ReturnCopies { get; set; }

        /// <summary>
        /// Номинал талонов ЛПП
        /// </summary>
        public decimal NominalLPP { get; set; }

        /// <summary>
        /// Номинал талонов 120
        /// </summary>
        public decimal NominalTalon120 { get; set; }

        /// <summary>
        /// Место проведения расчета
        /// </summary>
        public string PaymentsPlace { get; set; }
    }
}
