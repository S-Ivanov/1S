﻿using Drg.CashDeskLib.Utils;
using System;

namespace Drg.CashDeskLib.Payment
{
    /// <summary>
    /// Команда
    /// </summary>
    /// <typeparam name="T">тип параметра, передаваемого в операции выполнения и отката</typeparam>
    public class Command<T>
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="executeCondition">условие выполнения команды</param>
        /// <param name="executeAction">операция выполнения</param>
        /// <param name="undoAction">операция отката</param>
        /// <param name="undoSelfException">индикатор отката операции выполнения, если в ней возникла ошибка</param>
        public Command(Func<T, bool> executeCondition, Action<T> executeAction, Action<T> undoAction = null, bool undoSelfException = false)
        {
            Contract.Requires<ArgumentNullException>(executeCondition != null, nameof(executeCondition));
            Contract.Requires<ArgumentNullException>(executeAction != null, nameof(executeAction));

            this.executeCondition = executeCondition;
            this.executeAction = executeAction;
            this.undoAction = undoAction;
            UndoSelfException = undoSelfException;
        }

        /// <summary>
        /// Операция выполнения
        /// </summary>
        /// <param name="data">параметр операции</param>
        public void Execute(T data)
        {
            if (executeCondition(data))
                executeAction(data);
        }

        /// <summary>
        /// Операция отката
        /// </summary>
        /// <param name="data">параметр операции</param>
        public void Undo(T data)
        {
            if (undoAction != null && executeCondition(data))
                undoAction(data);
        }

        /// <summary>
        /// Индикатор отката операции выполнения, если в ней возникла ошибка
        /// </summary>
        public readonly bool UndoSelfException;

        /// <summary>
        /// Условие выполнения команды
        /// </summary>
        Func<T, bool> executeCondition;

        /// <summary>
        /// Операция выполнения
        /// </summary>
        Action<T> executeAction;

        /// <summary>
        /// Операция отката
        /// </summary>
        Action<T> undoAction;
    }
}
