﻿using Drg.CashDeskLib.Configuration;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment.KKM;

namespace Drg.CashDeskLib.Equipment
{
    public static class KKM
    {
        /// <summary>
        /// Создать ККМ
        /// </summary>
        /// <returns></returns>
        public static IKKM Create(CashDeskConfiguration cashDeskConfiguration) =>
            cashDeskConfiguration.KKMEmulator ? 
            (IKKM)new Drg.EquipmentEmulators.KKM(cashDeskConfiguration.KKMEmulatorFileName) :
            //new Drg.Equipment.KKMAtol10_3_1.KKM(cashDeskConfiguration.KKMTimeOut);
            new Drg.Equipment.KKMAtol10_3_1.KKM2(cashDeskConfiguration.KKMTimeOut);

        /// <summary>
        /// Получить строку для передачи кассира в ККМ
        /// </summary>
        /// <param name="@operator"></param>
        /// <returns></returns>
        public static string GetOperatorForKkm(Operator @operator) => $"Кассир: {@operator.FInitials}";
    }
}
