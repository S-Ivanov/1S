﻿using Drg.CashDeskLib.Configuration;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Equipment;
using Drg.CashDeskLib.Payment;
using Drg.CashDeskLib.ReportFO;
using Drg.CashDeskLib.Session;
using Drg.CashDeskLib.Utils;
using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using System.Xml;

namespace Drg.CashDeskLib
{
    /// <summary>
    /// Касса
    /// </summary>
    public partial class CashDesk : IDisposable
    {
        /// <summary>
        /// Синглтон
        /// </summary>
        public static CashDesk Instance => instance;
        static CashDesk instance = null;

        /// <summary>
        /// Создание экземпляра кассы
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        public static CashDesk Create(CashDeskConfiguration configuration, string localDbConnectionString)
        {
            instance?.Dispose();
            instance = new CashDesk(configuration, localDbConnectionString);
            return instance;
        }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="configuration">конфигурация кассы</param>
        CashDesk(CashDeskConfiguration configuration, string localDbConnectionString)
        {
            Configuration = configuration;

            // инициализируем объекты управления оборудованием
            EquipmentInit();

            CreateOrderPayment();

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();

            //localDB = new DB.LocalDB(configuration.DBConnectionString);
            localDB = new DB.LocalDB(localDbConnectionString);

            TextWrapper.TextWrapper textWrapper = new TextWrapper.TextWrapper(configuration.TextWrapperPatterns, configuration.TextWrapperExceptions);

            sessionManager = new SessionManager2(localDB, GetDevice(Device.KKM) as IKKM);
            sessionManager.BeforeOpenSessionKKM += SessionManager_BeforeOpenSessionKKM;

            //PaymentManager = new PaymentManagerExt(
            //    GetDevice(Device.KKM) as IKKM,
            //    GetDevice(Device.PayTerminal) as IPayTerminal,
            //    localDB,
            //    textWrapper,
            //    configuration.PayTerminalSlipCount,
            //    configuration.IsTestMode,
            //    configuration.ReturnCopies);

            // настроить конфигурацию менеджера оплат
            PaymentManagerConfiguration paymentManagerConfiguration = new PaymentManagerConfiguration
            {
                SlipCount = configuration.PayTerminalSlipCount,
                IsTestMode = configuration.IsTestMode,
                ReturnCopies = configuration.ReturnCopies,
                NominalLPP = Nominals.LPP,
                NominalTalon120 = Nominals.Talon120,
                PaymentsPlace = configuration.CashDeskName
            };

            PaymentManager = new PaymentManager(
                GetDevice(Device.KKM) as IKKM,
                GetDevice(Device.PayTerminal) as IPayTerminal,
                localDB,
                textWrapper,
                paymentManagerConfiguration);

            reportFOGenerator = new ReportFOGenerator(
                localDB,
                Configuration.ReportFOXslt,
                Configuration.EateryID,
                Configuration.EateryName,
                Configuration.CashDeskNumber);

            LoadClients();

            Task.Factory.StartNew(() =>
            {
                MenuLoad();
                FrontDataExchange();
            });
        }

        private void SessionManager_BeforeOpenSessionKKM(object sender, SessionManager2.SessionManager2_EventArgs e)
        {
            BeforeOpenSessionKKM?.Invoke(this, e);
        }

        /// <summary>
        /// Событие перед закрытием/открытием смены на ККМ
        /// </summary>
        public event EventHandler<SessionManager2.SessionManager2_EventArgs> BeforeOpenSessionKKM;

        public bool EquipmentIsReady { get; private set; }

        public bool IsKKMReadyForNonFiscalPrint()
        {
            var kkm = GetKKM();
            return kkm != null && !kkm.LastError.HasError;
        }

        public IKKM GetKKM() => (Devices.TryGetValue(Device.KKM, out IDevice device)) ? device as IKKM : null;

        IDevice GetDevice(Device device) => (Devices.TryGetValue(device, out IDevice d)) ? d : null;

        private void CreateOrderPayment()
        {
            orderPayment = new OrderPayment(GetDevice(Device.KKM) as IKKM, GetDevice(Device.PayTerminal) as IPayTerminal);
        }

        public DataModel.Session LoadLastSession()
        {
            //return localDB.LoadLastSession();

            var lastSession = sessionManager.BeforeStart();

            if (lastSession.Item2 == SessionState.Closed)
                lastSession.Item1.End = DateTime.Now;
            else if (lastSession.Item2 == SessionState.Expired)
                lastSession.Item1.End = lastSession.Item1.Begin.AddHours(25);

            return lastSession.Item1;
        }

        public void OpenSession(Operator @operator)
        {
            Operator = @operator;

            /*
            // загрузить информацию о последней смене из БД
            //Session = localDB.LoadLastSession();
            Session = LoadLastSession();

            // загрузить информацию о смене из ККМ
            var kkm = GetKKM();

            if (kkm != null && kkm.SessionState == SessionState.Expired)
            {
                kkm.CloseSession();
                localDB.CloseSession(Session.Id, DateTime.Now);
                //kkm.CheckErrors();
            }

            SessionManagerParameters parameters = new SessionManagerParameters
            {
                HasKKM = kkm != null,
                KkmHasError = kkm?.LastError.HasError ?? true,
                KkmSessionState = kkm?.SessionState ?? SessionState.Closed,
                FnChanged = Session.IdFN != kkm?.FnInfo.FnNumber,
                DbSessionState = Session.SessionState,
                OperatorChanged = @operator.Id != Session.OperatorId
            };
            sessionManager.OpenSession(
                parameters,
                closeKKMSessionAction: () => kkm.CloseSession(),
                closeDbSessionAction: () => localDB.CloseSession(Session.Id, DateTime.Now),
                openKKMSessionAction: () => kkm.OpenSession($"{@operator.FIO} - {@operator.Post}", @operator.INN),
                openDbSessionAction: () => Session = localDB.OpenSession(DateTime.Now, @operator.Id, kkm?.FnInfo.FnNumber, kkm?.SessionNumber ?? 0)
                );
            */

            Session = sessionManager.Start(@operator);
        }

        //SessionManager sessionManager = new SessionManager();

        SessionManager2 sessionManager;

        //public event EventHandler<CashPaymentEventArgs> CashPaymentEvent
        //{
        //    add { orderPayment.CashPaymentEvent += value; }
        //    remove { orderPayment.CashPaymentEvent -= value; }
        //}

        #region Частные методы

        /// <summary>
        /// Уточнить возможные способы оплаты в зависимости от готовности оборудования
        /// </summary>
        private void CheckPaymentMethod()
        {
            PaymentMethod = Configuration.PaymentMethods;

            if ((PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
            {
                var cardReader = devices[Device.CardReader];
                DeviceError cardReaderError = devices[Device.CardReader].LastError;
                PaymentMethod &=
                    cardReader != null && (cardReaderError == null || cardReaderError.ErrorCode == DeviceError.NO_ERROR) ?
                    PaymentMethod.All :
                    ~PaymentMethod.Pass;
            }

            if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard || (PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
            {
                var kkm = GetKKM();
                if (kkm != null)
                {
                    DeviceError kkmError = devices[Device.KKM].LastError;
                    var kkmFiscal = (kkmError == null || kkmError.ErrorCode == DeviceError.NO_ERROR) && kkm.Fiscal;
                    if (kkmFiscal)
                    {
                        PaymentMethod &= PaymentMethod.All;
                        if ((PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                        {
                            var payTerminal = devices[Device.PayTerminal];
                            DeviceError payTerminalError = devices[Device.PayTerminal].LastError;
                            PaymentMethod &=
                                payTerminal != null && (payTerminalError == null || payTerminalError.ErrorCode == DeviceError.NO_ERROR) ?
                                PaymentMethod.All :
                                ~PaymentMethod.BankCard;
                        }
                    }
                    else
                    {
                        PaymentMethod &= ~PaymentMethod.Cash;
                        PaymentMethod &= ~PaymentMethod.BankCard;
                    }
                }
                else
                {
                    PaymentMethod &= ~PaymentMethod.Cash;
                    PaymentMethod &= ~PaymentMethod.BankCard;
                }
            }
        }

        public Nominals Nominals
        {
            get
            {
                if (nominals == null)
                {
                    nominals = localDB.LoadNominals();
                    if (nominals == null)
                    {
                        nominals = new Nominals
                        {
                            LPP = Configuration.LPPNominal,
                            Talon120 = Configuration.Talon120Nominal,
                            Subsidy8 = Configuration.Subsidy8,
                            Subsidy12 = Configuration.Subsidy12,
                            Subsidy24 = Configuration.Subsidy24
                        };
                        localDB.SaveNominals(nominals);
                    }
                }
                return nominals;
            }
        }
        Nominals nominals = null;

        public Tuple<int, int> LoadOrderCountInfo() => localDB.LoadOrderCountInfo(Session.Id);

        /// <summary>
        /// Добавить элемент меню
        /// </summary>
        /// <param name="menuId">идентификатор меню</param>
        /// <param name="menuItem"></param>
        public void AddMenuItemExt(Guid menuId, MenuItem menuItem) => localDB.AddMenuItem(menuId, menuItem);

        /// <summary>
        /// Загрузить возвраты
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public List<Order> LoadReturns(Guid orderId) => localDB.LoadReturns(orderId);

        public void UpdateClient(DataModel.Receipt receipt)
        {
            if (receipt.Client != null && !string.IsNullOrEmpty(receipt.Client.TabNum))
            {
                lock (Clients)
                {
                    if (Clients.TryGetValue(receipt.Client.TabNum, out Client client))
                    {
                        int sign = receipt.Order is OrderReturn ? -1 : 1;
                        client.UsedZP += sign * receipt.Order.ZP;
                        client.UsedLPP += sign * receipt.Order.LPP;
                    }
                }
            }
        }

        public Tuple<string, DataModel.Order> LoadOrder(Guid orderId) => localDB.LoadOrder(orderId);

        //public PaymentManagerExt PaymentManager { get; private set; }
        public PaymentManager PaymentManager { get; private set; }

        /// <summary>
        /// Выполнить оплату заказа
        /// </summary>
        /// <param name="session"></param>
        /// <param name="receipt"></param>
        /// <returns>
        /// Результат оплаты:
        /// - Item1 - true, если оплата отменена
        /// - Item2 - ошибка при выполнении оплаты
        /// - Item3 - варианты оплаты, которые нельзя использовать
        /// </returns>
        public Tuple<bool, PaymentManagerExtException, IEnumerable<DataModel.Payment>> PayReceipt(DataModel.Session session, DataModel.Receipt receipt)
        {
            //return PaymentManager.PayReceipt(session, receipt);

            // реализация сложная, т.к. нужно обеспечить совместимость с внешним кодом

            bool paymentOk = false;
            try
            {
                paymentOk = PaymentManager.PayReceipt(session, receipt, Operator.FInitials, Operator.INN);

                if (paymentOk)
                {
                    // TODO: записать оплаченный заказ в резервный backup-файл транзакций
                }

                return new Tuple<bool, PaymentManagerExtException, IEnumerable<DataModel.Payment>>(!paymentOk, null, Enumerable.Empty<DataModel.Payment>());
            }
            catch (PaymentManagerExtException ex)
            {
                // обрабатываем только исключение PaymentManagerExtException, т.к. другие в методе PaymentManager.PayReceipt генерироваться не могут
                return new Tuple<bool, PaymentManagerExtException, IEnumerable<DataModel.Payment>>(true, ex, Enumerable.Empty<DataModel.Payment>());
            }
        }

        public static void AddPaymentToBackupFile(CashDeskConfiguration configuration, DataModel.Session session, DataModel.Receipt receipt, string backupTransacrionsFile)
        {
            using (StreamWriter sw = File.AppendText(backupTransacrionsFile))
            {
                // заказ:
                /*
CREATE TABLE [dbo].[Заказы](
	[Id] [uniqueidentifier] NOT NULL,
	[IdСмены] [uniqueidentifier] NULL,
	[Дата] [datetime] NOT NULL,
	[Номер] [int] NOT NULL,
	[ТабельныйНомер] [varchar](10) NULL,
	[IdИсходногоЗаказа] [uniqueidentifier] NULL,
	[Тест] [bit] NOT NULL,
	[Год]  AS (datepart(year,[Дата])),
	[РучнаяИдентификация] [int] NULL,
                */

                Guid IdСмены = session.Id;
                DateTime Дата = receipt.Order.DateTime;
                int Номер = receipt.Order.Number;
                string ТабельныйНомер = receipt.Client.TabNum;
                Guid? IdИсходногоЗаказа = (receipt.Order as OrderReturn)?.IdSourceOrder;
                bool Тест = configuration.IsTestMode;
                int РучнаяИдентификация = (int)receipt.Client.ManualReason;

                // элементы заказа:
                /*
CREATE TABLE [dbo].[ОплатаЗаказов](
	[Id] [uniqueidentifier] NOT NULL,
	[IdЗаказа] [uniqueidentifier] NOT NULL,
	[IdТовара] [uniqueidentifier] NOT NULL,
	[Цена] [decimal](8, 2) NOT NULL,
	[Количество] [decimal](8, 3) NOT NULL,
	[Сумма] [decimal](8, 2) NOT NULL,
	[IdВидаОплаты] [int] NOT NULL,                 
                */
                foreach (var orderItem in receipt.Order.Items)
                {
                    // вместо IdТовара ид номенклатуры:
                    string IdNomenclature = orderItem.MenuItem.IdNomenclature;
                    decimal ЦенаNomenclature = orderItem.MenuItem.Price;

                    decimal Цена = orderItem.Price;
                    decimal Количество = orderItem.Count;
                    decimal Сумма = orderItem.Sum;
                    int IdВидаОплаты = (int)orderItem.Payment;
                }
            }
        }

        /// <summary>
        /// Инициализируем объекты управления оборудованием
        /// </summary>
        /// <remarks>Объекты управления оборудованием создаются на все время работы кассы</remarks>
        private void EquipmentInit()
        {
            // считыватель пропусков 
            if ((Configuration.Devices & Device.CardReader) == Device.CardReader)
                AddDevice(Device.CardReader, () => CardReader.Create(Configuration));

            // ККМ 
            IKKM kkm = null;
            if ((Configuration.Devices & Device.KKM) == Device.KKM)
            {
                AddDevice(
                    Device.KKM, 
                    () =>
                    {
                        kkm = Equipment.KKM.Create(Configuration);
                        return kkm;
                    });
            }
            //if (kkm != null)
            //    kkm.OnCloseFiscalDocumentError += Kkm_OnCloseFiscalDocumentError;

            // банковский терминал
            if ((Configuration.Devices & Device.PayTerminal) == Device.PayTerminal)
            {
                AddDevice(
                    Device.PayTerminal, 
                    () =>
                    {
                        var payTerminal = PayTerminal.Create(Configuration);
                        return payTerminal;
                    });
            }

            EquipmentIsReady = true;
        }

        /// <summary>
        /// Добавление устройства
        /// </summary>
        /// <param name="message">сообщение</param>
        /// <param name="addDeviceAction">действие подключения устройства</param>
        void AddDevice(Device deviceType, Func<IDevice> createDevice)
        {
            var device = createDevice();
            //device.CheckErrors();
            if (device != null)
                devices.Add(deviceType, device);
        }

        #endregion Частные методы

        #region События

        #endregion События

        #region Частные поля и свойства

        DB.LocalDB localDB;

        OrderPayment orderPayment;

        #endregion Частные поля и свойства

        #region Публичные методы

        /// <summary>
        /// Смена
        /// </summary>
        public DataModel.Session Session { get; private set; }

        /// <summary>
        /// Удалить элемент меню
        /// </summary>
        /// <param name="menuItem"></param>
        public void DeleteMenuItemExt(MenuItem menuItem) => localDB.DeleteMenuItemExt(menuItem);

        /// <summary>
        /// Загрузить кассиров
        /// </summary>
        /// <returns></returns>
        public List<Operator> GetOperators() => localDB.GetOperators();

        /// <summary>
        /// Прочитать номер нового заказа
        /// </summary>
        /// <returns></returns>
        public int GetNewOrderNumber() => localDB.GetNewOrderNumber();

        ///// <summary>
        ///// Загрузить последние меню, дата которых меньше или равна указанной
        ///// </summary>
        ///// <param name="date"></param>
        ///// <param name="menuCount">количество меню для загрузки</param>
        ///// <returns></returns>
        //public List<Menu> LoadMenus(DateTime date, int menuCount) => localDB.LoadMenus(date, menuCount);

        /// <summary>
        /// Изменить количество в элементе меню
        /// </summary>
        /// <param name="menuItem"></param>
        /// <param name="newCount"></param>
        public void ChangeMenuItemCountExt(MenuItem menuItem, decimal newCount) => localDB.ChangeMenuItemCountExt(menuItem, newCount);

        /// <summary>
        /// Загрузить последние меню, дата которых меньше или равна указанной
        /// </summary>
        /// <param name="date"></param>
        /// <param name="menuCount">количество меню для загрузки</param>
        /// <returns></returns>
        public List<Menu> LoadMenusExt(DateTime date, int menuCount) => localDB.LoadMenu(date, menuCount);

        /// <summary>
        /// Индикатор ошибки связи с удаленными сервисами
        /// </summary>
        public bool RemoteServiceError
        {
            get => remoteServiceError;
            set { remoteServiceError = value; }
        }
        volatile bool remoteServiceError;

        public void FrontDataExchange()
        {
            if (!Configuration.UseFrontService)
                return;

            try
            {
                // отправить зависшие отчеты ФО
                SaveReportFO();

                // выполнить обмен данными с сервером
                // TODO: добавить имя файла для записи транзакций
                var data = FrontDataExchange("FrontServiceSoap12", localDB, Configuration.CashDeskID, Configuration.LPPNominal, Configuration.IsTestMode);

                // обновить кэш клиентов
                UpdateClients(data);

                remoteServiceError = false;
            }
            catch
            {
                remoteServiceError = true;
            }
        }

        public static FrontServiceReference.ResultData FrontDataExchange(string pointName, LocalDB localDB, string cashDeskID, decimal lppNominal, bool isTestMode, string backupTransacrionsFile = null)
        {
            DateTime? serverLastTimeStamp = localDB.GetServerTimeStamp();
            DateTime? clientTimeStamp = localDB.GetCashDeskTimeStamp();
            DateTime newClientTimeStamp = DateTime.UtcNow;

            FrontServiceReference.Parameter data = new FrontServiceReference.Parameter
            {
                IsTest = isTestMode,
                IdCashDesk = cashDeskID,
                OrderDocument = localDB.LoadOrderDocument(clientTimeStamp, newClientTimeStamp, isTestMode),
                TransactionDocument = localDB.LoadTransactionDocument(clientTimeStamp, newClientTimeStamp, isTestMode)
            };

            // дата/время последнего сеанса обмена данными - чтение
            if (serverLastTimeStamp != null)
            {
                data.ClientTimeStamp = serverLastTimeStamp.Value;
                data.ClientTimeStampSpecified = true;
            }

            using (FrontServiceReference.FrontServicePortTypeClient frontServiceClient = new FrontServiceReference.FrontServicePortTypeClient(pointName))
            {
                FrontServiceReference.ResultData resultData = frontServiceClient.ExchangeData(data);
                
                // зафиксировать успешность передачи заказов
                if (resultData.IsOrdersSaved)
                {
                    localDB.SaveClientTimeStamp(newClientTimeStamp);

                    if (!string.IsNullOrEmpty(backupTransacrionsFile))
                    {
                        // очистить резервный backup-файл транзакций
                        if (File.Exists(backupTransacrionsFile))
                            File.WriteAllText(backupTransacrionsFile, String.Empty);
                    }
                }

                // записать полученные данные
                localDB.SaveExchangeData(resultData, cashDeskID, lppNominal, isTestMode);

                // возврат полученных данных
                return resultData;
            }
        }

        private void UpdateClients(FrontServiceReference.ResultData data)
        {
            if (data == null ||
                (data.ClientDocument == null &&
                data.LPPDocument == null &&
                data.OrderDocument?.Orders == null &&
                data.OrderDocument?.OrderReturns == null &&
                data.PhotoDocument == null &&
                data.TransactionDocument == null))
            {
                return;
            }

            HashSet<string> tabNums = new HashSet<string>();
            if (data.ClientDocument != null)
            {
                foreach (var client in data.ClientDocument)
                {
                    tabNums.Add(client.TabNum);
                }
            }
            if (data.LPPDocument != null)
            {
                foreach (var lpp in data.LPPDocument)
                {
                    tabNums.Add(lpp.TabNum);
                }
            }
            if (data.OrderDocument?.Orders != null)
            {
                foreach (var order in data.OrderDocument.Orders)
                {
                    tabNums.Add(order.TabNum);
                }
            }
            if (data.OrderDocument?.OrderReturns != null)
            {
                foreach (var order in data.OrderDocument.OrderReturns)
                {
                    tabNums.Add(order.TabNum);
                }
            }
            if (data.PhotoDocument != null)
            {
                foreach (var photo in data.PhotoDocument)
                {
                    tabNums.Add(photo.TabNum);
                }
            }
            if (data.TransactionDocument != null)
            {
                foreach (var transaction in data.TransactionDocument)
                {
                    tabNums.Add(transaction.TabNum);
                }
            }

            if (tabNums.Any())
            {
                var clients = localDB.LoadClients(Configuration.AllNew, Configuration.IsTestMode, tabNums);
                if (clients.Any())
                {
                    lock (Clients)
                    {
                        foreach (var client in clients)
                        {
                            Clients.AddOrUpdate(client.TabNum, client, (key, value) => client);
                        }
                    }
                }
            }
        }

        public void ReturnWholeOrder(Guid sourceOrderId, List<OrderPaymentItem> orderPaymentItems)
        {
            // записать информацию в БД
            localDB.ReturnWholeOrder(sourceOrderId);
        }

        public List<OrderPaymentItem> LoadOrderPaymentItems(Guid orderId) => localDB.LoadOrderPaymentItems(orderId);

        ///// <summary>
        ///// Добавить элемент меню
        ///// </summary>
        ///// <param name="menuItem"></param>
        ///// <returns></returns>
        //public bool AddMenuItem(MenuItem menuItem) => localDB.AddMenuItem(menuItem);

        /// <summary>
        /// Полный список клиентов
        /// </summary>
        /// <remarks>
        /// Словарь:
        /// - табельный номер
        /// - работник
        /// </remarks>
        public ConcurrentDictionary<string, Client> Clients { get; } = new ConcurrentDictionary<string, Client>();

        /// <summary>
        /// Загрузить список локальных заказов
        /// </summary>
        public List<OrderSource> LoadLocalOrders()
        {
            List<OrderSource> orders = localDB.LoadOrderSources(Configuration.IsTestMode);

            if (orders.Any())
            {
                // загрузить клиентов
                lock (Clients)
                {
                    foreach (var order in orders.Where(_ => _.Client != null))
                    {
                        if (Clients.TryGetValue(order.Client.TabNum, out Client client))
                        {
                            order.Client = client;
                        }
                    }
                }
            }

            return orders;
        }

        public Client GetClient(uint cardCode)
        {
            lock (Clients)
            {
                return Clients.Select(kvp => kvp.Value).FirstOrDefault(_ => _.CardCode == cardCode);
            }
        }

        /// <summary>
        /// Загрузить исходные заказы для возвратов
        /// </summary>
        /// <returns></returns>
        //public void LoadOrderSources()
        //{
        //    LocalOrders.Clear();
        //    // TODO: загружать заказы только в пределах суток и с учетом только своих заказов, а также тестового режима работы
        //    LocalOrders.AddRange(localDB.LoadOrderSources(Configuration.IsTestMode));
        //}

        /// <summary>
        /// Прочитать полный список клиентов
        /// </summary>
        /// <returns></returns>
        public void LoadClients()
        {
            lock (Clients)
            {
                Clients.Clear();

                foreach (Client client in localDB.LoadClients(Configuration.AllNew, Configuration.IsTestMode))
                {
                    Clients.TryAdd(client.TabNum, client);
                }
            }
        }

        /// <summary>
        /// Проверить оборудование
        /// </summary>
        public void CheckEquipment()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.CheckErrors();
            }

            // уточним возможные способы оплаты в зависимости от готовности оборудования
            CheckPaymentMethod();

            // уточним состояние смены
            sessionManager.CheckSession();
        }

        ///// <summary>
        ///// Удалить элемент меню
        ///// </summary>
        ///// <param name="menuItem"></param>
        ///// <returns></returns>
        //public bool DeleteMenuItem(MenuItem menuItem) => localDB.DeleteMenuItem(menuItem);

        #endregion Публичные методы

        #region Публичные свойства

        /// <summary>
        /// Кассир
        /// </summary>
        public Operator Operator { get; set; }

        /// <summary>
        /// Закрыть смену
        /// </summary>
        public void CloseSession()
        {
            /*
            // загрузить информацию о смене из ККМ
            var kkm = GetKKM();

            SessionManagerParametersBase parameters = new SessionManagerParametersBase
            {
                HasKKM = kkm != null,
                KkmHasError = kkm?.LastError.HasError ?? true,
                KkmSessionState = kkm?.SessionState ?? SessionState.Closed,
                DbSessionState = Session.SessionState
            };
            sessionManager.CloseSession(
                parameters,
                closeKKMSessionAction: () => kkm.CloseSession(),
                closeDbSessionAction: () => localDB.CloseSession(Session.Id, DateTime.Now)
                );

            // закрыть смену на банковском терминале
            CloseSessionPayTerminal();

            if (HasOrders)
                SaveReportFO();
            */

            // закрыть смену на банковском терминале
            CloseSessionPayTerminal();

            // закрыть смену на ККМ и в БД
            sessionManager.Finish();

            // отправить отчет ФО
            SaveReportFO();
        }

        public void SaveReportFO()
        {
            // сформировать отчет ФО
            SaveReportFO(
                "ExtCashDeskExchange_ReportFOServiceSoap12",
                localDB,
                reportFOGenerator,
                Configuration.CashDeskNumber,
                Configuration.ExchangeBuhID);
        }

        private void CloseSessionPayTerminal()
        {
            var payTerminal = GetDevice(Device.PayTerminal) as IPayTerminal;
            if (payTerminal == null)
                return;

            IEnumerable<AuthorizationInfo> authorizationInfoCollection = localDB.LoadAuthorizationInfo(Session.Id);
            if (authorizationInfoCollection.Any())
            {
                var reportText = payTerminal.Report(ReportType.CloseSession, authorizationInfoCollection);
                if (!string.IsNullOrEmpty(reportText))
                {
                    // печать отчета
                    var kkm = GetKKM();
                    if (kkm != null)
                        //kkm.PrintNonFiscalDocument(TextInfo.ConvertText(reportText), true);
                        kkm.PrintNonFiscalDocument2(TextInfo.ConvertText(reportText));
                }
            }
        }

        ReportFO.ReportFOGenerator reportFOGenerator;

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        public CashDeskConfiguration Configuration { get; private set; }

        ///// <summary>
        ///// Изменить количество в элементе меню
        ///// </summary>
        ///// <param name="menuItem"></param>
        ///// <param name="newCount"></param>
        ///// <returns></returns>
        //public bool ChangeMenuItemCount(MenuItem menuItem, decimal newCount) => localDB.ChangeMenuItemCount(menuItem, newCount);

        /// <summary>
        /// Способы оплаты
        /// </summary>
        public PaymentMethod PaymentMethod { get; set; }

        public Dictionary<Device, IDevice> Devices => devices;

        public bool HasOrders => localDB.HasOrders(Session.Id, Configuration.IsTestMode);

        Dictionary<Device, IDevice> devices = new Dictionary<Device, IDevice>();

        #endregion Публичные свойства

        #region Реализация интерфейса IDisposable

        public void Dispose()
        {
            foreach (var kvp in devices)
            {
                kvp.Value.Dispose();
            }
            devices.Clear();
        }

        #endregion Реализация интерфейса IDisposable

        ///// <summary>
        ///// Записать заказ и оплату
        ///// </summary>
        ///// <param name="client">клиент</param>
        ///// <param name="order">заказ</param>
        ///// <param name="payments">оплата</param>
        //public void SaveOrderAndPayment(Client client, Order order, Dictionary<Payment, decimal> payments) => localDB.SaveOrderAndPayment(client, order, payments);

        ///// <summary>
        ///// Выполнить оплату
        ///// </summary>
        ///// <param name="client">клиент</param>
        ///// <param name="order">заказ</param>
        ///// <param name="payments">оплата: вид оплаты + сумма</param>
        ///// <returns>виды оплат, которые не удалось выполнить</returns>
        //public Payment Pay(Client client, Order order, Dictionary<Payment, decimal> payments, out List<Payment> noPayments)
        //{
        //    // TODO: проверить корректность входных параметров

        //    Payment cancelPayment = orderPayment.Pay(client, order, payments, out noPayments, out IDictionary <Payment, List<OrderItem>> orderItems);
        //    if (cancelPayment == Payment.None && noPayments.Count == 0)
        //    {
        //        localDB.SaveOrderAndPayment(Session, client, order, orderItems, Configuration.IsTestMode);
        //        // корректировать информацию о работниках и заказах после оплаты заказа
        //        CorrectClients(client, order, orderItems);
        //    }
        //    return cancelPayment;
        //}

        //private void CorrectClients(Client orderClient, Order order, IDictionary<Payment, List<OrderItem>> orderItems)
        //{
        //    if (!string.IsNullOrEmpty(orderClient.TabNum))
        //    {
        //        decimal sumZP = orderItems.ContainsKey(Payment.ZP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
        //        decimal sumLPP = orderItems.ContainsKey(Payment.LPP) ? orderItems[Payment.ZP].Sum(orderItem => orderItem.Sum) : 0;
        //        if (sumZP != 0 || sumLPP != 0)
        //        {
        //            lock (Clients)
        //            {
        //                if (Clients.TryGetValue(orderClient.TabNum, out Client client))
        //                {
        //                    client.UsedZP += sumZP;
        //                    client.UsedLPP += sumLPP;
        //                }
        //            }

        //            orderClient.UsedZP += sumZP;
        //            orderClient.UsedLPP += sumLPP;
        //        }
        //    }
        //}

        //public static FrontServiceReference.ResultData ExchangeData(string cashDeskID, DateTime? timeStamp)
        //{
        //    FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
        //    {
        //        IdCashDesk = cashDeskID,
        //        ClientTimeStamp = timeStamp ?? DateTime.MinValue,
        //        ClientTimeStampSpecified = timeStamp != null,
        //    };

        //    using (FrontServiceReference.FrontServicePortTypeClient client = new FrontServiceReference.FrontServicePortTypeClient("FrontServiceSoap12"))
        //    {
        //        client.Open();

        //        var data = client.ExchangeData(parameter);

        //        return data;
        //    }
        //}
    }
}
