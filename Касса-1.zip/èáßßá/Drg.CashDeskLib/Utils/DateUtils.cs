﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Drg.CashDeskLib.Utils
{
    public static class DateUtils
    {
        public static List<DateRange> GetPeriodsBetween(this List<DateTime> dates, DateTime start, DateTime end)
        {
            if (start > end)
                throw new ArgumentException();

            if (dates == null || dates.Count == 0)
                return new List<DateRange> { new DateRange(start, end) };

            var orderedDates = dates.OrderBy(d => d).ToList();
            List<DateRange> periods = new List<DateRange>();
            DateTime lastStart = start;
            for (int i = 0; i < orderedDates.Count; i++)
            {
                var date = orderedDates[i];
                if (date < lastStart)
                    continue;
                else if (date > end)
                    break;
                else if (lastStart < date)
                    periods.Add(new DateRange(lastStart, date.AddDays(-1)));
                lastStart = date.AddDays(+1);
            }
            if (lastStart <= end)
                periods.Add(new DateRange(lastStart, end));

            return periods;
        }
    }
}
