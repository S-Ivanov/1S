﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Equipment;
using Drg.CashDeskLib.Utils;
using Drg.Equipment.KKM;
using System;

namespace Drg.CashDeskLib.Session
{
    /// <summary>
    /// Управление сменами
    /// </summary>
    /// <remarks>
    /// Класс не является потокобезопасным, ответственность за безопасную работу в разных потоках лежит на интерфейсах БД и ККМ.
    /// </remarks>
    public class SessionManager2
    {
        #region Конструкторы

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="dbSession">интерфейс БД для работы со сменами</param>
        /// <param name="kkmSession">интерфейс ККМ для работы со сменами</param>
        public SessionManager2(IDbSession2 dbSession, IKkmSession2 kkmSession)
        {
            Contract.Requires<ArgumentNullException>(dbSession != null, nameof(dbSession));

            this.dbSession = dbSession;
            this.kkmSession = kkmSession;
        }

        #endregion Конструкторы

        #region Методы

        #region Публичные методы

        /// <summary>
        /// Перед запуском программы
        /// </summary>
        /// <returns>
        /// Структура данных:
        /// - последняя смена из БД
        /// - состояние смены на ККМ
        /// </returns>
        public Tuple<DataModel.Session, SessionState> BeforeStart()
        {
            //Contract.Requires<InvalidOperationException>(!started);

            // загрузить информацию о последней смене
            LoadLastSession();

            return new Tuple<DataModel.Session, SessionState>(lastSession, kkmSession == null ? SessionState.Unknown : kkmSession.SessionState);
        }

        /// <summary>
        /// Запуск программы
        /// </summary>
        /// <param name="@operator">кассир</param>
        /// <returns>состояние смены</returns>
        public DataModel.Session Start(Operator @operator)
        {
            //Contract.Requires<InvalidOperationException>(!started);

            // загрузить информацию о последней смене
            LoadLastSession();

            // дальнейшие действия определяются в первую очередь состояннием ККМ
            if (kkmSession == null || kkmSession.SessionState == SessionState.Unknown)
                StartDbSession(@operator);
            else if (kkmSession.SessionState == SessionState.Expired)
                OnSessionKkmExpired(@operator);
            else if (kkmSession.SessionState == SessionState.Opened)
            {
                if (lastSession.IsEmpty || lastSession.IsClosed || lastSession.IdFN != kkmSession.FnNumber)
                {
                    // переоткрыть смену в БД
                    lastSession = dbSession.ReopenSession(lastSession.Id, @operator.Id, kkmSession.FnNumber);
                    // зафиксировать номер смены ККМ
                    lastSession.Number = kkmSession.SessionNumber;
                }
            }
            else // if (kkmSession.SessionState == SessionState.Closed)
            { 
                // событие перед открытием смены на ККМ
                BeforeOpenSessionKKM?.Invoke(this, new SessionManager2_EventArgs { CloseAndOpen = false });

                // открыть смену на ККМ
                kkmSession.OpenSession(KKM.GetOperatorForKkm(@operator), @operator.INN);

                // переоткрыть смену в БД
                lastSession = dbSession.ReopenSession(lastSession.Id, @operator.Id, kkmSession.FnNumber);

                // зафиксировать номер смены ККМ
                lastSession.Number = kkmSession.SessionNumber;
            }

            // запомнить кассира
            this.@operator = @operator;

            // зафиксировать, что управление сменами запущено
            started = true;

            return lastSession;
        }

        /// <summary>
        /// Проверить состояние смены
        /// </summary>
        public void CheckSession()
        {
            //Contract.Requires<InvalidOperationException>(started);

            // обрабатываем только ситуацию, когда смена на ККМ просрочена
            if (kkmSession != null && kkmSession.SessionState == SessionState.Expired)
                OnSessionKkmExpired(@operator);
        }

        /// <summary>
        /// Завершение работы = закрытие смены
        /// </summary>
        public void Finish()
        {
            //Contract.Requires<InvalidOperationException>(started);

            // закрыть смену на ККМ
            if (kkmSession != null && kkmSession.SessionState != SessionState.Closed)
                kkmSession.CloseSession(KKM.GetOperatorForKkm(@operator), @operator.INN);

            // закрыть смену в БД
            dbSession.CloseSession(lastSession.Id);
        }

        #endregion Публичные методы

        #region Приватные методы

        /// <summary>
        /// Загрузить информацию о последней смене
        /// </summary>
        void LoadLastSession()
        {
            if (lastSession == null)
                lastSession = dbSession.LoadLastSession();
            if (lastSession == null)
                lastSession = new DataModel.Session();

            if (kkmSession != null)
                lastSession.Number = kkmSession.SessionState == SessionState.Unknown ? 0 : kkmSession.SessionNumber;
        }

        /// <summary>
        /// Открыть смену в БД
        /// </summary>
        /// <param name="operator"></param>
        private void StartDbSession(Operator @operator)
        {
            // если ККМ неисправна, работаем только с БД
            if (lastSession.IsEmpty || lastSession.IsClosed)
                // переоткрыть смену в БД
                lastSession = dbSession.ReopenSession(lastSession.Id, @operator.Id, kkmSession.FnNumber);
            else if (lastSession.OperatorId != @operator.Id)
            {
                // переписать кассира, если смена БД открыта
                dbSession.UpdateSessionOperator(lastSession.Id, @operator.Id);
                lastSession.OperatorId = @operator.Id;
            }
        }

        /// <summary>
        /// Обработать ситуацию, когда смена на ККМ просрочена
        /// </summary>
        /// <param name="operator">кассир</param>
        private void OnSessionKkmExpired(Operator @operator)
        {
            // событие перед закрытием/открытием смены на ККМ
            BeforeOpenSessionKKM?.Invoke(this, new SessionManager2_EventArgs { CloseAndOpen = true });

            // должность и ФИО кассира
            string operatorInfo = KKM.GetOperatorForKkm(@operator);

            // закрыть смену на ККМ
            kkmSession.CloseSession(operatorInfo, @operator.INN);

            // открыть смену на ККМ
            kkmSession.OpenSession(operatorInfo, @operator.INN);

            // переоткрыть смену в БД
            lastSession = dbSession.ReopenSession(lastSession.Id, @operator.Id, kkmSession.FnNumber);

            // зафиксировать номер смены ККМ
            lastSession.Number = kkmSession.SessionNumber;
        }

        #endregion Приватные методы

        #endregion Методы

        #region События

        /// <summary>
        /// Событие перед закрытием/открытием смены на ККМ
        /// </summary>
        public event EventHandler<SessionManager2_EventArgs> BeforeOpenSessionKKM;
        
        #endregion События

        #region Поля

        /// <summary>
        /// Интерфейс БД для работы со сменами
        /// </summary>
        IDbSession2 dbSession;

        /// <summary>
        /// Интерфейс ККМ для работы со сменами
        /// </summary>
        IKkmSession2 kkmSession;

        /// <summary>
        /// Индикатор того, что управление сменами запущено
        /// </summary>
        /// <remarks>
        /// Выполняет функции триггерной защелки:
        /// - начальное состояние: started = false
        /// - при started == false возможен вызов методов BeforeStart, Start
        /// - метод Start устанавливает started = true
        /// - при started == true возможен вызов методов Check, Finish
        /// </remarks>
        bool started = false;

        /// <summary>
        /// Кассир
        /// </summary>
        Operator @operator;

        /// <summary>
        /// Информация о последней смене
        /// </summary>
        DataModel.Session lastSession = null;

        #endregion Поля

        #region Вложенные типы данных

        /// <summary>
        /// Аргумент события перед закрытием/открытием смены на ККМ
        /// </summary>
        public class SessionManager2_EventArgs : EventArgs
        {
            /// <summary>
            /// Индикатор переоткрытия смены на ККМ:
            /// - true - закрытие/открытие смены
            /// - false - только открытие смены
            /// </summary>
            public bool CloseAndOpen { get; set; }
        }

        #endregion Вложенные типы данных
    }
}
