﻿using Drg.Equipment.KKM;
using System;

namespace Drg.CashDeskLib.Session
{
    /// <summary>
    /// Информация о смене
    /// </summary>
    public class SessionInfo
    {
        /// <summary>
        /// Состояние смены
        /// </summary>
        public SessionState SessionState { get; set; }

        /// <summary>
        /// Идентификатор кассира
        /// </summary>
        public Guid OperatorId { get; set; }
    }
}
