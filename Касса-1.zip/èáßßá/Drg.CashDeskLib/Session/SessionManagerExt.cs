﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Utils;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.Session
{
    /// <summary>
    /// Управление сменами
    /// </summary>
    /// <remarks>
    /// Алгоритмы
    /// ---------
    /// 
    /// При загрузке программы - ККМ исправна:
    /// - прочитать из БД состояние смены и кассира
    /// - прочитать из ККМ состояние смены
    /// ...
    /// 
    /// Добавлены файлы:
    /// - Drg.CashDeskLib.DB/IDBSession.cs
    /// - Drg.CashDeskLib.Session/SessionInfo.cs
    /// - Drg.CashDeskLib.Utils/Contract.cs
    /// - Drg.Equipment.KKM/IKKMSession.cs
    /// - UnitTests/SessionManagerExt_Tests.cs
    /// Изменены файлы:
    /// - Drg.CashDeskLib/CashDesk.cs
    /// - Drg.CashDeskLib.DataModel/Session.cs
    /// - Drg.CashDeskLib.DB/LocalDB.cs
    /// - Drg.CashDeskLib.DB/LocalDB2.cs
    /// </remarks>
    public class SessionManagerExt
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="kkmSession">ККМ</param>
        /// <param name="dbSession">база данных</param>
        public SessionManagerExt(IKKMSession kkmSession, IDBSession dbSession)
        {
            Contract.Requires<ArgumentNullException>(kkmSession != null, nameof(kkmSession));
            Contract.Requires<ArgumentNullException>(dbSession != null, nameof(dbSession));

            this.kkmSession = kkmSession;
            this.dbSession = dbSession;
        }

        /// <summary>
        /// Открыть смену
        /// </summary>
        /// <param name="@operator">кассир</param>
        public void OpenSession(Operator @operator)
        {
            Contract.Requires<ArgumentNullException>(@operator != null, nameof(@operator));

            this.lastSession = dbSession.LoadLastSession();
            if (lastSession.IsEmpty)
            {
                // если в БД не было смен
                // TODO: номер фискального накопителя - ?
                string fnNumber = "";
                this.lastSession = dbSession.OpenSession(@operator.Id, fnNumber, kkmSession.SessionNumber);
            }

            var sessionStateDB = lastSession == null ? SessionState.Closed : lastSession.SessionState;
            var sessionStateKKM = kkmSession.SessionState;

            if (sessionStateDB == SessionState.Opened)
            {
                if (sessionStateKKM == SessionState.Opened)
                {
                    // ничего делать не нужно
                }
                else // if (sessionStateKKM == SessionState.Expired || sessionStateKKM == SessionState.Closed)
                {
                    if (sessionStateKKM == SessionState.Expired)
                    {
                        OnSessionExpired?.Invoke(this, EventArgs.Empty);

                        // закрыть смену на ККМ
                        kkmSession.CloseSession();
                    }

                    // открыть смену на ККМ
                    kkmSession.OpenSession($"{@operator.FIO} - {@operator.Post}", @operator.INN);

                    // изменить номер смены в БД
                    // TODO: номер фискального накопителя - ?
                    var sessionNumber = kkmSession.SessionNumber;
                    dbSession.ChangeSessionNumber(lastSession.Id, sessionNumber);
                }
            }
        }

        /// <summary>
        /// Чтение информации о смене
        /// </summary>
        /// <returns></returns>
        public SessionInfo ReadSessionInfo()
        {
            var sessionStateKKM = kkmSession.SessionState;
            //var sessionStateDB = dbSession.SessionState;

            return new SessionInfo { OperatorId = Guid.Empty, SessionState = SessionState.Closed };
            throw new NotImplementedException();
        }

        /// <summary>
        /// Закрыть смену
        /// </summary>
        public void CloseSession()
        {
            var sessionStateKKM = kkmSession.SessionState;
            if (sessionStateKKM != SessionState.Closed)
            {
                kkmSession.CloseSession();
            }
        }

        /// <summary>
        /// Проверить состояние смены
        /// </summary>
        public void CheckSession()
        {

        }

        /// <summary>
        /// Событие истечения времени действия смены
        /// </summary>
        public event EventHandler OnSessionExpired;

        IKKMSession kkmSession;
        IDBSession dbSession;
        DataModel.Session lastSession;
    }
}
