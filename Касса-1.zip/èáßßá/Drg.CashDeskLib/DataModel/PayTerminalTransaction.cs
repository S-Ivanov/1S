﻿using Drg.CashDeskLib.DB;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDeskLib.DataModel
{
    /// <summary>
    /// Транзакционный платежный терминал
    /// </summary>
    public class PayTerminalTransaction : DeviceTransactionBase<PayTerminalTransactionArgs>
    {
        public PayTerminalTransaction(IPayTerminal payTerminal, ILocalDBPayment localDB)
        {
            this.payTerminal = payTerminal;
            this.localDB = localDB;
        }

        protected override void DoActionInternal(PayTerminalTransactionArgs parameters)
        {
            Canceled = false;

            PayResult payResult =
                parameters.IsReturn ?
                payTerminal.ReturnPay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum) :
                payTerminal.Pay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum);

            if (payResult == null)
                Canceled = true;
            else
            {
                AuthorizationInfo = payResult.AuthorizationInfo;
                SlipText = payResult.SlipText;
            }

            if (payResult != null && payResult.DeviceError.HasError)
            {
                throw new DeviceException(payResult.DeviceError);
            }
        }

        public AuthorizationInfo AuthorizationInfo { get; private set; }

        protected override void DoRollbackInternal(PayTerminalTransactionArgs parameters)
        {
            if (OnBeforePayTerminalCancel != null)
            {
                CancelEventArgs args = new CancelEventArgs();
                OnBeforePayTerminalCancel(this, args);
                if (args.Cancel)
                    return;
            }

            Guid authorizationInfoId = Guid.NewGuid();
            PayResult payResult = null;
            try
            {
                payResult =
                    parameters.IsReturn ?
                    payTerminal.CancelReturnPay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum) :
                    payTerminal.CancelPay(parameters.SessionNumber, parameters.CheckNumber, parameters.Sum);

                // записать информацию о возврате в БД
                if (payResult != null)
                    localDB.SaveAuthorizationInfo(authorizationInfoId, parameters.SessionId, Guid.Empty, payResult.AuthorizationInfo);
            }
            catch
            {
                // записать информацию об ошибке возврата в БД
                if (payResult != null)
                    localDB.SavePayTerminalReturnError(authorizationInfoId, parameters.SessionNumber, parameters.CheckNumber);
            }
        }

        public bool Canceled { get; private set; }

        public string SlipText { get; private set; }

        public event EventHandler<CancelEventArgs> OnBeforePayTerminalCancel;

        IPayTerminal payTerminal;
        ILocalDBPayment localDB;
    }
}
