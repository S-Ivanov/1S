﻿using Drg.Equipment;
using System;

namespace Drg.CashDeskLib.DataModel
{
    public class PaymentManagerExtException : Exception
    {
        public PaymentManagerExtException(Device device, DeviceError deviceError = null, string message = null, Exception innerException = null)
            : base(message, innerException)
        {
            Device = device;
            DeviceError = deviceError;
        }

        public Device Device { get; private set; }
        public DeviceError DeviceError { get; private set; }
    }
}
