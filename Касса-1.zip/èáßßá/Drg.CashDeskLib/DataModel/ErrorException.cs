﻿using System;

namespace Drg.CashDeskLib.DataModel
{
    public class ErrorException : ApplicationException
    {
        public ErrorException(string message) : base(message)
        {
        }

        public int ErrorCode { get; set; }
    }
}
