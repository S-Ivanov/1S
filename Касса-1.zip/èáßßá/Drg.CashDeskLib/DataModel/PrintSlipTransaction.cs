﻿using System;
using System.Linq;
using Drg.Equipment.KKM;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public class PrintSlipTransaction : KKMTransactionBase<string>
    {
        public PrintSlipTransaction(IKKM kkm, int slipCount) : base(kkm, 1)
        {
            this.slipCount = slipCount;
        }

        protected override void DoPrint(string slipText)
        {
            var slip = TextInfo.ConvertText(slipText).ToArray();
            if (slip.Any())
            {
                for (int i = 0; i < slipCount; i++)
                {
                    kkm.PrintNonFiscalDocument(slip, true);
                }
            }
        }

        protected override void DoRollbackInternal(string parameters)
        {
        }

        readonly int slipCount;
    }
}

