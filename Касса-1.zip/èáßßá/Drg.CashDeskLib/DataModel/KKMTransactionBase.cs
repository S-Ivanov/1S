﻿using Drg.Equipment;
using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;

namespace Drg.CashDeskLib.DataModel
{
    public abstract class KKMTransactionBase<T> : DeviceTransactionBase<T>
    {
        public KKMTransactionBase(IKKM kkm, int returnCopies)
        {
            this.kkm = kkm;
            this.returnCopies = returnCopies;
        }

        protected override void DoActionInternal(T parameters)
        {
            try
            {
                // отправить нефискальный чек на ККМ
                DoPrint(parameters);
            }
            catch (Exception ex)
            {
                // перадать ошибку пользователю для возможной обработки
                FixErrorEventArgs args = new FixErrorEventArgs { Device = kkm, Exception = ex };
                FixErrorEvent?.Invoke(this, args);
                if (!args.ErrorFixed)
                    throw;
            }
        }

        protected abstract void DoPrint(T parameters);

        protected List<TextInfo> MakeHeader(Order order, uint lineLength)
        {
            List<TextInfo> result = new List<TextInfo>();

            string title11;
            int orderNumber;
            DateTime orderDate;
            if (order is OrderReturn orderReturn)
            {
                title11 = "ВОЗВРАТ";
                orderNumber = orderReturn.SourceNumber;
                orderDate = orderReturn.SourceDate;
            }
            else
            {
                title11 = "ПРИХОД";
                orderNumber = order.Number;
                orderDate = order.DateTime;
            }

            string orderNumberStr = orderNumber.ToString();
            string orderDateTimeStr = orderDate.ToString();

            string title12 = title11 + " " + "Заказ № ";
            int spacesCount = (int)lineLength - (title12.Length + orderNumberStr.Length + orderDateTimeStr.Length) >= 1 ? (int)lineLength - (title12.Length + orderNumberStr.Length + orderDateTimeStr.Length) : 1;
            result.Add(TextInfo.CreateLeft(title12 + orderNumberStr + new String(' ', spacesCount) + orderDateTimeStr));
            result.Add(TextInfo.CreateLeft(new String('-', (int)lineLength)));

            return result;
        }


        /// <summary>
        /// Событие для исправления ошибки
        /// </summary>
        public event EventHandler<FixErrorEventArgs> FixErrorEvent;

        protected IKKM kkm;
        protected int returnCopies;
    }
}
