﻿using Drg.CashDesk.DataModel;
using System;
using System.Windows.Input;

namespace Drg.CashDesk.Commands
{
    public class NewOrderCommand : RelayCommand<Order>
    {
        public NewOrderCommand(Order order)
            : base(
                  _ => order.New(), 
                  _ => order != null && order.SelectedOrderItem != null)
        {
            this.order = order;
        }

        //public void Execute(object parameter)
        //{
        //    order.New();
        //}

        Order order;
    }
}
