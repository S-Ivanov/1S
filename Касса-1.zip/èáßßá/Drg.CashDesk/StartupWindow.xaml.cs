﻿using Drg.CashDesk.Dialogs;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.Utils;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для StartupWindow.xaml
    /// </summary>
    public partial class StartupWindow : Window
    {
        public StartupWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            digitKeyboard.DigitButtonClick += DigitKeyboard_DigitButtonClick;
            abilityIndicator.Title = "";

            try
            {
                var operators = CashDeskLib.CashDesk.Instance.GetOperators();
                if (operators.Count > 0)
                {
                    cbOperators.ItemsSource = operators;
                    cbOperators.DisplayMemberPath = "FInitials";
                }

                var session = CashDeskLib.CashDesk.Instance.LoadLastSession();
                if (session.SessionState == Equipment.KKM.SessionState.Closed)
                {
                    lblSession.Content = "Смена закрыта";
                }
                else
                {
                    if (session.SessionState == Equipment.KKM.SessionState.Expired)
                        lblSession.Content = "Смена просрочена";
                    else
                        lblSession.Content = "Смена открыта";

                    var lastOperator = operators.FirstOrDefault(_ => _.Id == session.OperatorId);
                    if (lastOperator != null)
                        cbOperators.SelectedItem = lastOperator;
                }
            }
            catch (Exception ex)
            {
                WpfMessageBox.Show(
                    "Ошибка",
$@"Ошибка доступа к локальной базе данных, работа программы невозможна.

Комментарий: {ex.Message}",
                    MessageBoxButton.OK, Dialogs.MessageBoxImage.Error);

                throw;
            }

            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
        }

        private void DigitKeyboard_DigitButtonClick(object sender, DataModelEventArgs<string> e)
        {
            if (tbPassword.Text.Length < 10)
            {
                tbPassword.Text += e.Data;
                SetOkButtonEnabledAndResetError();
            }
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            var @operator = CashDeskLib.CashDesk.Instance.GetOperators().FirstOrDefault(op => op.CardID == e.CardCode);
            if (@operator == null)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    SetOkButtonEnabledAndResetError();
                    cardCodeError.Visibility = Visibility.Visible;
                    cardCodeError.Content = "Неверный пропуск";
                    tbPassword.Text = "";
                }));
            }
            else
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    OpenSession(@operator);
                    this.Close();
                }));
            }
        }

        private static void OpenSession(Operator @operator)
        {
            CashDeskLib.CashDesk.Instance.OpenSession(@operator);
        }

        void SetOkButtonEnabledAndResetError()
        {
            btnOk.IsEnabled = cbOperators.SelectedItem != null && !string.IsNullOrEmpty(tbPassword.Text);
            cardCodeError.Visibility = Visibility.Hidden;
            backSpaceButton.IsEnabled = clearButton.IsEnabled = !string.IsNullOrEmpty(tbPassword.Text);
        }

        private void DigitButton_Click(object sender, RoutedEventArgs e)
        {
            if (tbPassword.Text.Length < 10)
            {
                tbPassword.Text += (sender as Button).Content.ToString();
                SetOkButtonEnabledAndResetError();
            }
        }

        private void BackSpaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tbPassword.Text))
            {
                tbPassword.Text = tbPassword.Text.Substring(0, tbPassword.Text.Length - 1);
                SetOkButtonEnabledAndResetError();
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            tbPassword.Text = "";
            SetOkButtonEnabledAndResetError();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Operator @operator = cbOperators.SelectedItem as Operator;
            if (tbPassword.Text != @operator.Password)
            {
                cardCodeError.Visibility = Visibility.Visible;
                cardCodeError.Content = "Неверный пароль";
            }
            else
            {
                OpenSession(@operator);
                this.Close();
            }
        }

        private void CbOperators_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            tbPassword.Text = "";
            SetOkButtonEnabledAndResetError();

            Operator @operator = cbOperators.SelectedItem as Operator;
            if (!CheckINN.IsINN(@operator.INN))
            {
                btnOk.IsEnabled = false;
                cardCodeError.Content = "Неверный ИНН";
                cardCodeError.Visibility = Visibility.Visible;
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            abilityIndicator.CardReaderEvent -= AbilityIndicator_CardReaderEvent;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
