﻿using Drg.CashDeskLib.DataModel;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Threading;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.CashDesk.Dialogs;
using Drg.CashDesk.Utils;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для TotalProductReport.xaml
    /// </summary>
    public partial class TotalProductReport : Window
    {
        public TotalProductReport(Session session, List<CashDeskLib.DataModel.ProductReportItem> productReportItems)
        {
            InitializeComponent();

            DataContext = this;

            Session = session;

            // формирование записей для вывода на экран
            ProductReportItems = new ObservableCollection<DataModel.ProductReportItem>(productReportItems.Select(_ => new DataModel.ProductReportItem(_)));
            dataGridScroller = new DataGridScroller(DataGridProduct, ButtonPageUp, ButtonPageDown);
        }

        public Session Session { get; private set; }
        public DateTime DateTime { get; } = DateTime.Now;
        public ObservableCollection<DataModel.ProductReportItem> ProductReportItems { get; private set; }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        #region Печать

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            // начало печати
            (Application.Current as App).CheckEquipmentStop();
            try
            {
                var kkm = CashDeskLib.CashDesk.Instance.GetKKM();
                if (kkm != null && kkm.LastError == DeviceError.NoError)
                {
                    ProgressBarDialog progressBarDialog = new ProgressBarDialog("Выполняется печать отчёта", true);

                    CancellationTokenSource cancelTokenSource = new CancellationTokenSource();
                    CancellationToken cancelTokenSourceToken = cancelTokenSource.Token;

                    DoPrint(kkm, cancelTokenSourceToken, progressBarDialog);

                    if (progressBarDialog.ShowDialog() == true)
                    {
                        cancelTokenSource.Cancel();
                    }
                }
            }
            finally
            {
                (Application.Current as App).CheckEquipmentStart();
            }
        }

        private void DoPrint(IKKM kkm, CancellationToken cancelTokenSourceToken, ProgressBarDialog progressBarDialog)
        {
            int lineCount = 0;
            // строки для печати
            List<TextInfo> textInfo = new List<TextInfo>();

            // формирование отчета
            // ...

            // формирование строк данных
            var gg = ProductReportItems
                .Where(_ => _.IsSelected)
                .Select(_ => _.RawItem)
                .OrderBy(_ => _.GroupName)
                .ThenBy(_ => _.Name)
                .ThenBy(_ => _.MeasureName)
                .GroupBy(_ => _.GroupName);

            //var lineLength = kkm.LineLength;
            foreach (var g in gg)
            {
                textInfo.Add(
                    new TextInfo
                    {
                        Text = g.Key,
                        DoubleHeight = true
                    });
                lineCount++;

                // можно заменить ?
                //textInfo.AddRange()
                foreach (var x in g)
                {
                    textInfo.Add(
                        new TextInfo
                        {
                            Text = x.Name,
                            Wrap = TextWrap.Words
                        });
                    textInfo.Add(
                        new TextInfo
                        {
                            Text = x.Balance.ToString(),
                            Alignment = Equipment.KKM.TextAlignment.Right
                        });
                    lineCount++;
                }
            }

            //progressBarDialog.ProcessProgressBar.Minimum = 0;
            //progressBarDialog.ProcessProgressBar.Maximum = lineCount;
            int currentLine = 0;

            kkm.PrintNonFiscalDocumentAsync(
                textInfo,
                cancelTokenSourceToken,
                () =>
                {
                    currentLine++;
                    //Dispatcher.Invoke(() => progressBarDialog.ProcessProgressBar.Value = currentLine);
                },
                () => Dispatcher.Invoke(() => progressBarDialog.Close()));
        }

        #endregion Печать

        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool check = (sender as CheckBox).IsChecked == true;
            foreach (var item in ProductReportItems)
            {
                item.IsSelected = check;
            }

            // переключеие чекбоксов в заголовках групп
            SetGroupChecks(check);

            SetPrintButtonEnabled(check);
        }

        private void SetPrintButtonEnabled(bool check)
        {
            PrintButton.IsEnabled = check;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="check"></param>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        private void SetGroupChecks(bool check)
        {
            // Border
            var child = VisualTreeHelper.GetChild(DataGridProduct, 0);

            // ScrollViewer
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // Grid
            var child3 = VisualTreeHelper.GetChild(child2, 0);

            // ScrollContentPresenter
            var child4 = VisualTreeHelper.GetChild(child3, 2);

            // ItemsPresenter
            var child5 = VisualTreeHelper.GetChild(child4, 0);

            // StackPanel
            var child6 = VisualTreeHelper.GetChild(child5, 0);

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(child6); i++)
            {
                // обработка группы

                // GroupItem
                var group = VisualTreeHelper.GetChild(child6, i);

                // StackPanel
                var child7 = VisualTreeHelper.GetChild(group, 0);

                // Border
                var child8 = VisualTreeHelper.GetChild(child7, 0);

                // DockPanel
                var child9 = VisualTreeHelper.GetChild(child8, 0);

                // CheckBox
                if (VisualTreeHelper.GetChild(child9, 1) is CheckBox checkBox)
                {
                    checkBox.IsChecked = check;
                }
            }
        }

        private void FilterDataGrid_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (ItemsControl.ContainerFromElement((DataGrid)sender, e.OriginalSource as DependencyObject) is DataGridRow row)
            {
                (row.Item as CashDesk.DataModel.ProductReportItem).IsSelected = !(row.Item as CashDesk.DataModel.ProductReportItem).IsSelected;
                SetAllCheckBox();
                CheckBox groupHeaderCheckBox = GetGroupHeaderCheckBox(row);
                if (groupHeaderCheckBox != null)
                {
                    SetCheckBoxChecked(groupHeaderCheckBox, ProductReportItems.Where(_ => _.RawItem.GroupName == (row.Item as DataModel.ProductReportItem).RawItem.GroupName));
                }
            }

            SetPrintButtonEnabled(ProductReportItems.Any(_ => _.IsSelected));
            //dataGridScroller.SetScrollButtonsVisibility();
        }

        /// <summary>
        /// Найти в визуальном дереве CheckBox заголовка группы DataGridProduct
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        /// <remarks>
        /// HACK: Код метода зависит от разметки DataGridProduct
        /// </remarks>
        CheckBox GetGroupHeaderCheckBox(DataGridRow row)
        {
            // DataGridRowsPresenter
            var parent = VisualTreeHelper.GetParent(row);

            // ItemsPresenter
            var parent2 = VisualTreeHelper.GetParent(parent);

            // StackPanel
            var parent3 = VisualTreeHelper.GetParent(parent2);

            // StackPanel
            var parent4 = VisualTreeHelper.GetParent(parent3);

            // Border
            var child = VisualTreeHelper.GetChild(parent4, 0);

            // DockPanel
            var child2 = VisualTreeHelper.GetChild(child, 0);

            // CheckBox
            var child3 = VisualTreeHelper.GetChild(child2, 1);

            return child3 as CheckBox;
        }

        private void SetAllCheckBox()
        {
            SetCheckBoxChecked(AllCheckBox, ProductReportItems);
        }

        private void SetCheckBoxChecked(CheckBox checkBox, IEnumerable<DataModel.ProductReportItem> items)
        {
            if (items.All(_ => _.IsSelected))
            {
                checkBox.IsChecked = true;
            }
            else if (items.Any(_ => _.IsSelected))
            {
                checkBox.IsChecked = null;
            }
            else
            {
                checkBox.IsChecked = false;
            }

            SetPrintButtonEnabled(ProductReportItems.Any(_ => _.IsSelected));
        }

        private void GroupCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            string groupName = checkBox.Tag.ToString();

            foreach (var item in ProductReportItems.Where(_ => _.RawItem.GroupName == groupName))
            {
                item.IsSelected = checkBox.IsChecked == true;
            }

            SetAllCheckBox();

            SetPrintButtonEnabled(ProductReportItems.Any(_ => _.IsSelected));
        }

        DataGridScroller dataGridScroller;

    }
}
