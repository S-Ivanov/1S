﻿using Drg.CashDesk.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    /// <summary>
    /// Конвертер для преобразования количества талонов ЛПП к строке вида "(Количество талонов ЛПП) = (Сумма)"
    /// </summary>
    [ValueConversion(typeof(string), typeof(string))]
    public class SearchTextConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var x = (string)value;
            return string.IsNullOrEmpty(x) ? x : x.Replace(' ', '_');
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
