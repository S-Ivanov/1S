﻿using Drg.CashDesk.DataModel;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Drg.CashDesk.Converters
{
    /// <summary>
    /// Конвертер для преобразования суммы
    /// </summary>
    [ValueConversion(typeof(decimal), typeof(string))]
    public class SumConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var x = (decimal)value;
            return x > 0 ? x.ToString("N2") : (string)null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
