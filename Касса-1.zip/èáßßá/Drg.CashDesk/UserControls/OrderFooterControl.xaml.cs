﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDesk.Dialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderFooterControl.xaml
    /// </summary>
    public partial class OrderFooterControl : UserControl, INotifyPropertyChanged
    {
        public OrderFooterControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        /// <summary>
        /// Команда создания нового заказа
        /// </summary>
        public ICommand NewOrderCommand => new RelayCommand<object>(
            o =>
            {
                if (WpfMessageBox.Show("Подтверждение", "Удалить имеющиеся строки и создать новый заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    Order.New();
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                }
            },
            o => Order != null && Order.SelectedOrderItem != null
        );

        /// <summary>
        /// Команда удаления выбранного элемента
        /// </summary>
        public ICommand DeleteOrderItemCommand => new RelayCommand<object>(
            o =>
            {
                var orderItem = Order.SelectedOrderItem;
                var orderItemIndex = Order.Items.IndexOf(orderItem);
                Order.Items.Remove(orderItem);

                // сделать активной какую-то другую запись
                if (orderItemIndex < Order.Items.Count)
                    Order.SelectedOrderItem = Order.Items[orderItemIndex];
                else if (Order.Items.Count == 0)
                    Order.SelectedOrderItem = null;
                else
                    Order.SelectedOrderItem = Order.Items.Last();
            },
            o => Order != null && Order.SelectedOrderItem != null
        );

        /// <summary>
        /// Команда изменения количества у выбранного элемента
        /// </summary>
        public ICommand OrderItemChangeCountCommand => new RelayCommand<object>(
            o =>
            {
                var orderItem = Order.SelectedOrderItem;

                ChangeCount changeCount = new ChangeCount(orderItem.Count);

                Window parentWindow = Window.GetWindow(this);

                changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
                changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2;
                if (changeCount.ShowDialog() == true)
                {
                    orderItem.Count = changeCount.Count;
                    Order.RecalcTotal();
                }
            },
            o => Order != null && Order.SelectedOrderItem != null
        );

        /// <summary>
        /// Команда свёртывания идентичных элементов заказа
        /// </summary>
        public ICommand OrderCollapseCommand => new RelayCommand<object>(
            o =>
            {
                var productId = (Order.SelectedOrderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct;
                Order.Collapse();
                Order.SelectedOrderItem = Order.Items.FirstOrDefault(item => (item.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct == productId);
            },
            o => 
                Order != null && 
                Order.SelectedOrderItem != null &&
                Order.CanCollapse
        );

        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));
                }
            }
        }
        Order order;

        public event PropertyChangedEventHandler PropertyChanged;

        public event EventHandler ServiceEvent;

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceEvent?.Invoke(this, EventArgs.Empty);
        }
    }
}
