﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDesk.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для ReturnFooterControl.xaml
    /// </summary>
    public partial class ReturnFooterControl : UserControl
    {
        public ReturnFooterControl()
        {
            InitializeComponent();
            DataContext = this;
        }

        public event EventHandler ServiceEvent;

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            if (WpfMessageBox.Show("Вопрос", "Отменить возврат заказа?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) == MessageBoxResult.Yes)
                ServiceEvent?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Команда возврата всех элементов заказа
        /// </summary>
        public ICommand ReturnAllItemsCommand
        {
            get
            {
                return new RelayCommand<object>(
                    _ =>
                    {
                        foreach (var item in OrderSource.Items)
                        {
                            decimal count = item.Count - GetReturnCount(item.RawOrderItem.MenuItem.IdProduct);
                            if (count != 0)
                            {
                                decimal sum = count * item.RawOrderItem.MenuItem.Price;
                                OrderSource.OrderReturn.AddItem(
                                    new OrderReturnItem(null, item.RawOrderItem)
                                    {
                                        ReturnCount = count,
                                        SourceCount = count,
                                    });
                            }
                        }
                    },
                    _ =>
                        OrderSource != null &&
                        OrderSource.OrderReturn.CanAddReturn &&
                        OrderSource.Items.Any(item => item.Count > GetReturnCount(item.RawOrderItem.MenuItem.IdProduct))
                    );
            }
        }

        /// <summary>
        /// Исходный заказ
        /// </summary>
        public OrderSource OrderSource { get; set; }

        decimal GetReturnCount(Guid productId) => OrderSource.OrderReturn.AllItems.Where(_ => _.RawOrderItem.MenuItem.IdProduct == productId).Sum(_ => _.ReturnCount);

    }
}
