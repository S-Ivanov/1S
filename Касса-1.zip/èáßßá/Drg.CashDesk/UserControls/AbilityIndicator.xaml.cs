﻿using Drg.CashDesk.Dialogs;
using Drg.CashDeskLib.DataModel;
using Drg.Equipment;
using Drg.Equipment.CardReader;
using Drg.Equipment.KKM;
using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для AbilityIndicator.xaml
    /// </summary>
    public partial class AbilityIndicator : UserControl 
    {
        public AbilityIndicator()
        {
            InitializeComponent();

            if (Application.Current is App)
            {
                ActivateIndicators();

                (Application.Current as App).CheckEquipmentEvent += AbilityIndicator_CheckEquipmentEvent;
            }
        }

        private void AbilityIndicator_CheckEquipmentEvent(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() => ActivateIndicators());
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // переспросить подтверждение выхода
            if (OnExit == null)
                Application.Current.Shutdown();
            else
            {
                CancelEventArgs cancelEventArgs = new CancelEventArgs();
                OnExit(this, cancelEventArgs);
                if (!cancelEventArgs.Cancel)
                    Application.Current.Shutdown();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).Tag != null)
                //MessageBox.Show((sender as Button).Tag.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                WpfMessageBox.Show("Ошибка", (sender as Button).Tag.ToString(), MessageBoxButton.OK, Dialogs.MessageBoxImage.Error);
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // выполняется только в рантайме
            // см. https://stackoverflow.com/questions/834283/is-there-a-way-to-check-if-wpf-is-currently-executing-in-design-mode-or-not
            // ответ 20
            if (Application.Current is App)
            {
                timeLabel.Content = DateTime.Now.ToString("HH:mm:ss");

                timeTimer = new DispatcherTimer();
                timeTimer.Tick += new EventHandler(TimeTimer_Tick);
                timeTimer.Interval = new TimeSpan(0, 0, 1);
                timeTimer.Start();

                // https://social.msdn.microsoft.com/Forums/vstudio/en-US/477e7e74-ccbf-4498-8ab9-ca2f3b836597/how-to-know-when-a-wpf-usercontrol-is-closing?forum=wpf
                Window window = Window.GetWindow(this);
                window.Closing += Window_Closing;
            }
        }

        DateTime lastDateTime = DateTime.MinValue;

        private void TimeTimer_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            timeLabel.Content = dateTime.ToString("HH:mm:ss");

            // TODO: проверка превышения смены 24 часа
//            if (lastDateTime == DateTime.MinValue || lastDateTime.Date == dateTime.Date)
//                lastDateTime = dateTime;
//            else
//            {
//                timeTimer.Stop();

//                DateTime dateTimeClose = dateTime.Date.AddSeconds(-1);

//                var messageBoxResult = MessageBox.Show(
//@"Сутки закончились, текущая смена будет автоматически закрыта.
//Открыть новую смену и продолжить работу?", 
//                    "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
//                if (messageBoxResult == MessageBoxResult.Yes)
//                {
//                    Mouse.OverrideCursor = Cursors.Wait;
//                    try
//                    {
//                        CashDeskLib.CashDesk.Instance.NewSession(dateTimeClose);
//                    }
//                    finally
//                    {
//                        Mouse.OverrideCursor = null;
//                    }

//                    lastDateTime = dateTime;
//                    timeTimer.Start();
//                }
//                else
//                {
//                    CashDeskLib.CashDesk.Instance.CloseSession(dateTimeClose);
//                    Application.Current.Shutdown();
//                }
//            }
        }

        private void ActivateIndicators()
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;

            string networkIndicatorImageKey = cashDesk.RemoteServiceError ? "networkErrorImage" : "networkNormalImage";
            (networkIndicator.Content as Image).Source = (ImageSource)Resources[networkIndicatorImageKey];

            networkIndicator.Tag = 
                cashDesk.RemoteServiceError ?
                "Отсутствует соединение с сервером.\nКасса работает в автономном режиме." : 
                null;
            if (cashDesk.RemoteServiceError)
                cashDesk.PaymentMethod &= (PaymentMethod.All & ~PaymentMethod.BankCard);

            var kkm = cashDesk.Devices[Device.KKM] as IKKM;
            var kkmError = cashDesk.Devices[Device.KKM].LastError;

            var cardReader = cashDesk.Devices[Device.CardReader] as ICardReader;
            var carReaderError = cashDesk.Devices[Device.CardReader].LastError;
            HasCardReader = cardReader != null && (carReaderError == null || carReaderError.ErrorCode == DeviceError.NO_ERROR);
            if (HasCardReader)
                cardReader.DataEvent += CardReader_DataEvent;
            else
                cardReader.DataEvent -= CardReader_DataEvent;

            passIndicator.Visibility = 
                (cashDesk.Configuration.PaymentMethods & PaymentMethod.Pass) == PaymentMethod.Pass ? 
                Visibility.Visible : 
                Visibility.Collapsed;
            if (passIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.Pass) == PaymentMethod.Pass)
                {
                    if (kkm == null || (kkmError?.HasError ?? false))
                    {
                        //passIndicator.Background = Brushes.Yellow;
                        (passIndicator.Content as Image).Source = (ImageSource)Resources["passWarningImage"];
                        passIndicator.Tag = "Печать чеков невозможна из-за проблем с ККМ.";
                    }
                    else
                    {
                        //passIndicator.Background = Brushes.Green;
                        (passIndicator.Content as Image).Source = (ImageSource)Resources["passNormalImage"];
                        passIndicator.Tag = null;
                    }
                }
                else
                {
                    //passIndicator.Background = Brushes.Red;
                    (passIndicator.Content as Image).Source = (ImageSource)Resources["passErrorImage"];
                    if (cardReader == null)
                        passIndicator.Tag = "Оплата по пропуску невозможна из-за отсутствия считывателя.";
                    else
                    {
                        passIndicator.Tag =
$@"Оплата по пропуску невозможна из-за ошибки считывателя:

Код ошибки: {carReaderError.ErrorCode}
Комментарий: {carReaderError.Description}";
                    }
                }
            }

            bankCardIndicator.Visibility = 
                (cashDesk.Configuration.PaymentMethods & PaymentMethod.BankCard) == PaymentMethod.BankCard ? 
                Visibility.Visible : 
                Visibility.Collapsed;
            if (bankCardIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.BankCard) == PaymentMethod.BankCard)
                {
                    (bankCardIndicator.Content as Image).Source = (ImageSource)Resources["bankCardNormalImage"];
                    bankCardIndicator.Tag = null;
                }
                else if (cashDesk.RemoteServiceError)
                {
                    (bankCardIndicator.Content as Image).Source = (ImageSource)Resources["bankCardErrorImage"];
                    bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за проблем с локальной вычислительной сетью.";
                }
                else
                {
                    (bankCardIndicator.Content as Image).Source = (ImageSource)Resources["bankCardErrorImage"];
                    var payTerminal = cashDesk.Devices[Device.PayTerminal];
                    if (kkm == null && payTerminal == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия ККМ и банковского терминала.";
                    else if (payTerminal == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия банковского терминала.";
                    else if (kkm == null)
                        bankCardIndicator.Tag = "Оплата по банковской карте невозможна из-за отсутствия ККМ.";
                    else
                    {
                        var payTerminalError = cashDesk.Devices[Device.PayTerminal].LastError;
                        if (kkmError != null && kkmError.ErrorCode != DeviceError.NO_ERROR && payTerminalError != null && payTerminalError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибок.

ККМ:
Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}

Банковский терминал:
Код ошибки: {payTerminalError.ErrorCode}
Комментарий: {payTerminalError.Description}";
                        else if (kkmError != null && kkmError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
                        else if (payTerminalError != null && payTerminalError.ErrorCode != DeviceError.NO_ERROR)
                            bankCardIndicator.Tag =
$@"Оплата по банковской карте невозможна из-за ошибки банковского терминала:

Код ошибки: {payTerminalError.ErrorCode}
Комментарий: {payTerminalError.Description}";
                        else if (!kkm.Fiscal)
                            bankCardIndicator.Tag = "Оплата по банковской карте невозможна, так как ККМ не фискализирована.";
                    }
                }
            }

            cashIndicator.Visibility = 
                (cashDesk.Configuration.PaymentMethods & PaymentMethod.Cash) == PaymentMethod.Cash ? 
                Visibility.Visible : 
                Visibility.Collapsed;
            if (cashIndicator.Visibility == Visibility.Visible)
            {
                if ((cashDesk.PaymentMethod & PaymentMethod.Cash) == PaymentMethod.Cash)
                {
                    (cashIndicator.Content as Image).Source = (ImageSource)Resources["cashNormalImage"];
                    cashIndicator.Tag = null;
                }
                else
                {
                    (cashIndicator.Content as Image).Source = (ImageSource)Resources["cashErrorImage"];
                    if (kkm == null)
                        cashIndicator.Tag = "Оплата наличными невозможна из-за отсутствия ККМ.";
                    else if (kkm.LastError.HasError)
                    {
                        cashIndicator.Tag =
$@"Оплата наличными невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
                    }
                    else if (!kkm.Fiscal)
                        cashIndicator.Tag = "Оплата наличными невозможна, так как ККМ не фискализирована.";
                }
            }

            if (kkm == null)
            {
                (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentErrorImage"];
                documentIndicator.Tag = "Отправка документов в ОФД невозможна из-за отсутствия ККМ.";
            }
            else if (kkm.LastError != null && kkm.LastError.HasError)
            {
                (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentErrorImage"];
                documentIndicator.Tag =
$@"Отправка документов в ОФД невозможна из-за ошибки ККМ:

Код ошибки: {kkmError.ErrorCode}
Комментарий: {kkmError.Description}";
            }
            else if (!kkm.Fiscal)
            {
                (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentErrorImage"];
                documentIndicator.Tag = "Отправка документов в ОФД невозможна - ККМ не фискализирована.";
            }
            else
            {
                var fnInfo = kkm.FnInfo;
                if (fnInfo.State != FnState.Fiscal)
                {
                    (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentErrorImage"];
                    documentIndicator.Tag = "Отправка документов в ОФД невозможна - ККМ не инициализирована.";
                }
                else
                {
                    DateTime fnExpireDate = fnInfo.ExpireDate;
                    DateTime fnFirstNonSendDateTime = fnInfo.FirstNonSendDateTime;
                    if (fnFirstNonSendDateTime == cashDesk.Configuration.FnNullDate)
                        fnFirstNonSendDateTime = DateTime.Now;

                    // сколько дней осталось до истечения срока действия ФН
                    int fnExpireDays = (fnExpireDate - DateTime.Now).Days;
                    // дата блокирования отправки документов в ОФД
                    DateTime lockDate = fnFirstNonSendDateTime.AddDays(cashDesk.Configuration.FnLockMaxDays);
                    // сколько дней осталось до блокирования отправки документов в ОФД
                    int lockExpireDays = (lockDate - DateTime.Now).Days;

                    if (fnExpireDays < 0 || lockExpireDays < 0)
                    {
                        string message =
                            fnExpireDays < 0 ?
                            "Отправка документов в ОФД невозможна - срок действия ФН истек." :
                            "Отправка документов в ОФД невозможна - истек срок хранения неотправленных документов.";

                        (cashIndicator.Content as Image).Source = (ImageSource)Resources["cashErrorImage"];
                        (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentErrorImage"];
                        documentIndicator.Tag = message;
                        (bankCardIndicator.Content as Image).Source = (ImageSource)Resources["bankCardErrorImage"];
                        cashIndicator.Tag = bankCardIndicator.Tag = "Оплата невозможна из-за проблем с фискальным накопителем ККМ.";

                        cashDesk.PaymentMethod &= (PaymentMethod.All & ~PaymentMethod.BankCard & ~PaymentMethod.Cash);
                    }
                    else if (fnExpireDays <= cashDesk.Configuration.FnExpireDays || lockExpireDays <= cashDesk.Configuration.FnLockDays)
                    {
                        (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentWarningImage"];
                        string message = "";
                        if (fnExpireDays <= cashDesk.Configuration.FnExpireDays)
                            message = $"Срок действия ФН истекает через {fnExpireDays} дней.";
                        if (lockExpireDays <= cashDesk.Configuration.FnLockDays)
                        {
                            if (!string.IsNullOrEmpty(message))
                                message += "\n\n";
                            message += $"Срок хранения неотправленных в ОФД документов истекает через {lockExpireDays} дней.";
                        }
                        documentIndicator.Tag = message;
                    }
                    else
                    {
                        (documentIndicator.Content as Image).Source = (ImageSource)Resources["documentNormalImage"];
                        documentIndicator.Tag = null;
                    }
                }
            }
        }

        private void CardReader_DataEvent(object sender, CardReaderEventArgs e)
        {
            CardReaderEvent?.Invoke(this, e);
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            timeTimer?.Stop();

            if (HasCardReader)
            {
                if (CashDeskLib.CashDesk.Instance.Devices[Device.CardReader] is ICardReader cardReader)
                    cardReader.DataEvent -= CardReader_DataEvent;
            }

            if (Application.Current is App)
            {
                (Application.Current as App).CheckEquipmentEvent -= AbilityIndicator_CheckEquipmentEvent;
            }
        }

        DispatcherTimer timeTimer = null;

        public string Title
        {
            get => titleLabel.Content?.ToString();
            set => titleLabel.Content = value;
        }

        public bool HasCardReader { get; private set; }

        /// <summary>
        /// Событие чтения пропуска
        /// </summary>
        public event EventHandler<CardReaderEventArgs> CardReaderEvent;

        /// <summary>
        /// Событие для подтверждения выхода из программы
        /// </summary>
        public event EventHandler<CancelEventArgs> OnExit;
    }
}
