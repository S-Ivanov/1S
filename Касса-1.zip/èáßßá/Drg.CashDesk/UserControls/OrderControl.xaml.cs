﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDesk.Dialogs;
using Drg.CashDesk.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для OrderControl.xaml
    /// </summary>
    public partial class OrderControl : UserControl, INotifyPropertyChanged
    {
        public OrderControl()
        {
            InitializeComponent();

            dataGridScroller = new DataGridScroller(orderItemsDataGrid, ButtonPageUp, ButtonPageDown);

            DataContext = this;
        }

        public Order Order
        {
            get => order;
            set
            {
                if (order != value)
                {
                    //DataContext = order = value;
                    order = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Order)));

                    //SetZpLppVisibility();
                }
            }
        }
        Order order;

        //public ICommand NewOrderCommand => new RelayCommand<Order>(
        //    o =>
        //    {
        //        if (!IsEmpty && WpfMessageBox.Show("Подтверждение", "Удалить имеющиеся строки и создать новый заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) == MessageBoxResult.Yes)
        //        {
        //            o.New();
        //        }
        //    },
        //    o => 
        //    {
        //        SetZpLppVisibility();
        //        SetButtonsEnabled();
        //    },
        //    o => o != null && o.SelectedOrderItem != null);

        private void Photo_Click(object sender, RoutedEventArgs e)
        {
            if (Order != null)
            {
                if (Order.Client != Client.Empty)
                {
                    Order.Client = Client.Empty;
                    //SetZpLppVisibility();
                }
                else
                {
                    SelectClientWindow selectClientWindow = new SelectClientWindow();
                    if (selectClientWindow.ShowDialog() == true)
                    {
                        var client = new DataModel.Client(selectClientWindow.viewModel.SelectedClient.RawClient);
                        if (WpfMessageBox.Show("Вопрос", "Нажмите ДА, если произошла ошибка пропуска", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) == MessageBoxResult.Yes)
                            client.RawClient.ManualReason = CashDeskLib.DataModel.ManualReasons.Error;
                        else
                            client.RawClient.ManualReason = CashDeskLib.DataModel.ManualReasons.User;

                        SetOrderClient(client);
                    }
                }
            }
        }

        public void SetOrderClient(Client client)
        {
            Order.Client = client;
            //SetZpLppVisibility();
        }


        //private void NewOrderButton_Click(object sender, RoutedEventArgs e)
        //{
        //    //if (!IsEmpty && MessageBox.Show("Удалить имеющиеся строки и создать новый заказ?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
        //    if (!IsEmpty && WpfMessageBox.Show("Подтверждение", "Удалить имеющиеся строки и создать новый заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) == MessageBoxResult.Yes)
        //    {
        //        NewOrder();
        //    }
        //}

        //private void NewOrder()
        //{
        //    //Order = new Order();
        //    Order.New();
        //    SetZpLppVisibility();
        //    SetButtonsEnabled();
        //}

        ///// <summary>
        ///// Добавление элемента заказа
        ///// </summary>
        ///// <param name="menuItem"></param>
        //public void AddOrderItem(DataModel.MenuItem menuItem)
        //{
        //    if (menuItem == null)
        //        return;

        //    var newOrderItem = new DataModel.OrderItem(menuItem, Order.Items.Count + 1);
        //    Order.Items.Add(newOrderItem);
        //    Order.SelectedOrderItem = newOrderItem;

        //    SetButtonsEnabled();

        //    this.orderItemsDataGrid.Focus();
        //}

        //public void Clear()
        //{
        //    NewOrder();
        //}

        //private void SetButtonsEnabled()
        //{
        //    PayButton.IsEnabled = Order.Items.Any();
        //    PayButton.Content = PayButton.IsEnabled ? $"{Order.Total:N2}" : "Оплатить";

        //    OrderItemDeleteButton.IsEnabled = OrderItemChangeCountButton.IsEnabled = Order.SelectedOrderItem != null;
        //    OrderCollapseButton.IsEnabled = !IsEmpty;
        //}

        //private void OrderItemDeleteButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (Order.SelectedOrderItem == null)
        //        return;

        //    //if (MessageBox.Show("Удалить выделенную строку заказа?", "Вопрос", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
        //    //{
        //        var orderItem = Order.SelectedOrderItem;
        //        var orderItemIndex = Order.Items.IndexOf(orderItem);
        //        Order.Items.Remove(orderItem);

        //        // сделать активной какую-то другую запись
        //        if (orderItemIndex < Order.Items.Count)
        //            Order.SelectedOrderItem = Order.Items[orderItemIndex];
        //        else if (Order.Items.Count == 0)
        //            Order.SelectedOrderItem = null;
        //        else
        //            Order.SelectedOrderItem = Order.Items.Last();

        //        SetButtonsEnabled();
        //    //}

        //    this.orderItemsDataGrid.Focus();
        //}

        //private void OrderItemChangeCountButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (Order.SelectedOrderItem == null)
        //        return;

        //    var orderItem = Order.SelectedOrderItem;

        //    ChangeCount changeCount = new ChangeCount(orderItem.Count);

        //    Window parentWindow = Window.GetWindow(this);

        //    changeCount.Top = parentWindow.Top + (parentWindow.ActualHeight - changeCount.Height) / 2;
        //    changeCount.Left = parentWindow.Left + parentWindow.ActualWidth / 2;

        //    if (changeCount.ShowDialog() == true)
        //    {
        //        orderItem.Count = changeCount.Count;
        //        Order.RecalcTotal();

        //        SetButtonsEnabled();
        //    }

        //    this.orderItemsDataGrid.Focus();
        //}

        //private void OrderCollapseButton_Click(object sender, RoutedEventArgs e)
        //{
        //    OrderCollapse();
        //}

        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            OnChangeCashDeskMode?.Invoke(this, new ChangeCashDeskModeEventArgs { CashDeskMode = CashDeskMode.OrderPay });

            // свернуть заказ до оплаты
            OrderCollapse();

            var paymentAbilities = new PaymentAbilities
            {
                Order = Order,
                Client = Order.Client
            };

            // создать низкоуровневый заказ
            var rawOrder = Order.ToRawOrder();

            (Application.Current as App).CheckEquipmentStop();
            try
            {
                while (true)
                {
                    // изначально доступные варианты оплаты
                    PaymentInfo paymentInfo = new PaymentInfo(paymentAbilities, Order.Total);

                    // вызов окна оплаты
                    paymentInfo = DoPayment(paymentInfo);
                    if (paymentInfo == null)
                    {
                        // досрочный выход по отмене пользователем
                        break;
                    }

                    // создать чек на основе выбранных вариантов оплаты и соотвествующих сумм
                    CashDeskLib.DataModel.Receipt receipt = MakeReceipt(rawOrder, paymentInfo.Payments);
                    receipt.Client = Order.Client.RawClient;

                    // попытка оплатить чек
                    Tuple<bool, CashDeskLib.DataModel.PaymentManagerExtException, IEnumerable<CashDeskLib.DataModel.Payment>> noPaymentInfo =
                        CashDeskLib.CashDesk.Instance.PayReceipt(CashDeskLib.CashDesk.Instance.Session, receipt);

                    if (noPaymentInfo.Item1)
                        continue;
                    else if (noPaymentInfo.Item2 != null || noPaymentInfo.Item3.Any())
                    {
                        if (noPaymentInfo.Item2 != null)
                        {
                            string message = MessageFormater.GetErrorMessage(noPaymentInfo.Item2);
                            //MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            WpfMessageBox.Show("Ошибка", message, MessageBoxButton.OK, Dialogs.MessageBoxImage.Error);
                        }

                        if (noPaymentInfo.Item3.Any())
                        {
                            // если есть варианты оплаты, которые нельзя использовать, значит оплатить чек нельзя - возвращаемся к формированию чека

                            paymentInfo.PaymentAbilities.SetPayments(false, noPaymentInfo.Item3);

                            // отключение зависимых видов оплаты
                            if (noPaymentInfo.Item3.Any(_ =>
                                _ == CashDeskLib.DataModel.Payment.ZP ||
                                _ == CashDeskLib.DataModel.Payment.LPP ||
                                _ == CashDeskLib.DataModel.Payment.Talon120))
                            {
                                paymentInfo.PaymentAbilities.SetPayments(
                                    false,
                                    new[]
                                    {
                                    CashDeskLib.DataModel.Payment.ZP,
                                    CashDeskLib.DataModel.Payment.LPP,
                                    CashDeskLib.DataModel.Payment.Talon120,
                                    CashDeskLib.DataModel.Payment.BankCard,
                                    CashDeskLib.DataModel.Payment.Cash,
                                    });
                            }
                        }

                        continue;
                    }
                    else 
                    {
                        // если нет вариантов оплаты, которые нельзя использовать, значит чек оплачен

                        // корректируем кэш клиентов
                        CashDeskLib.CashDesk.Instance.UpdateClient(receipt);

                        // создать новый заказ
                        Order.New();

                        // выход из цикла
                        break;
                    }
                }
            }
            finally
            {
                (Application.Current as App).CheckEquipmentStart();
            }

            OnChangeCashDeskMode?.Invoke(this, new ChangeCashDeskModeEventArgs { CashDeskMode = CashDeskMode.Work });
        }

        /// <summary>
        /// Создать чек для заказа на основе выбранных вариантов оплаты и соотвествующих сумм
        /// </summary>
        /// <param name="order">заказ</param>
        /// <param name="payments">варианты оплаты и соотвествующие суммы</param>
        /// <returns></returns>
        /// <remarks>При создании чека элементы заказа разрезаются</remarks>
        private CashDeskLib.DataModel.Receipt MakeReceipt(CashDeskLib.DataModel.Order order, Dictionary<CashDeskLib.DataModel.Payment, decimal> payments)
        {
            var splitOrderResult = CashDeskLib.ReportFO.OrderSplitter.Split(order, payments);
            order.Items = new List<CashDeskLib.DataModel.OrderItem>();
            foreach (var kvp in splitOrderResult)
            {
                foreach (var orderItem in kvp.Value)
                {
                    orderItem.Payment = kvp.Key;
                    order.Items.Add(orderItem);
                }
            }

            if (order.Id == Guid.Empty)
                order.Id = Guid.NewGuid();

            return new CashDeskLib.DataModel.Receipt
            {
                Order = order
            };
        }

        PaymentInfo DoPayment(PaymentInfo paymentInfo)
        {
            bool payConfirm = false;
            var currentPaymentInfo = paymentInfo;
            while (true)
            {
                PayWindow payWindow = new PayWindow();
                // TODO: исключить обращение к viewModel
                payWindow.viewModel.PaymentInfo = currentPaymentInfo;

                payConfirm = payWindow.ShowDialog() == true;
                currentPaymentInfo = payWindow.viewModel.PaymentInfo;

                if (!payConfirm)
                    break;
                else
                {
                    if (currentPaymentInfo.Payments.ContainsKey(CashDeskLib.DataModel.Payment.Cash) &&
                        currentPaymentInfo.Payments[CashDeskLib.DataModel.Payment.Cash] != 0)
                    {
                        CalcChangeWindow calcSurrenderWindow = new CalcChangeWindow
                        {
                            Sum = currentPaymentInfo.Payments[CashDeskLib.DataModel.Payment.Cash]
                        };

                        if (calcSurrenderWindow.ShowDialog() == true)
                            break;
                    }
                    else
                        break;
                }
            }

            return payConfirm ? currentPaymentInfo : null;
        }

        private void OrderCollapse()
        {
            var productId = (Order.SelectedOrderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct;
            Order.Collapse();
            //Order.SelectedOrderItem = Order.Items.First(item => (item.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct == productId);
            Order.SelectedOrderItem = Order.Items.FirstOrDefault(item => (item.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct == productId);

            this.orderItemsDataGrid.Focus();
        }

        public event EventHandler<ChangeCashDeskModeEventArgs> OnChangeCashDeskMode;
        public event PropertyChangedEventHandler PropertyChanged;

        private void LogoButton_Click(object sender, RoutedEventArgs e)
        {

        }

        public bool IsEmpty
        {
            get
            {
                return
                    Order.SelectedOrderItem == null ||
                    Order.Items.GroupBy(orderItem => (orderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct).Any(g => g.Count() == 0);
            }
        }

        DataGridScroller dataGridScroller;
    }
}
