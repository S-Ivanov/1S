﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drg.CashDesk.UserControls
{
    /// <summary>
    /// Логика взаимодействия для MenuFooterControl.xaml
    /// </summary>
    public partial class MenuFooterControl : UserControl
    {
        public MenuFooterControl()
        {
            InitializeComponent();
        }

        public event EventHandler ServiceEvent;

        private void ServiceButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceEvent?.Invoke(this, EventArgs.Empty);
        }

        ///// <summary>
        ///// Выбранный элемент меню
        ///// </summary>
        //public CashDeskLib.DataModel.MenuItem SelectedMenuItem { get; set; }


        public MenuControl MenuControl { get; set; }

        //public ObservableCollection<DataModel.MenuItem> MenuItems { get; set; }

        private void MoveMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            if (MenuControl?.Items == null)
                MessageBox.Show("null");
            else
            {
                var selectedItem = MenuControl.Items.FirstOrDefault(item => item.IsSelected);
                if (selectedItem == null)
                    MessageBox.Show("not selected");
                else
                    MessageBox.Show(selectedItem.RawItem.Name);
            }
        }
    }
}
