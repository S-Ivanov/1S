﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    public class MenuExt
    {
        public MenuExt(CashDeskLib.DataModel.MenuExt rawMenu)
        {
            RawMenu = rawMenu;
            Items = new ObservableCollection<MenuItemExt>(rawMenu.Items.Select(_ => new MenuItemExt(_)));
        }

        public CashDeskLib.DataModel.MenuExt RawMenu { get; private set; }

        /// <summary>
        /// Элементы меню
        /// </summary>
        public ObservableCollection<MenuItemExt> Items { get; private set; }

    }
}
