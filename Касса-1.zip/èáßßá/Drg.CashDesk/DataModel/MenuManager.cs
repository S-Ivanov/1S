﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Управление меню
    /// </summary>
    public class MenuManager
    {
        public MenuManager()
        {
            var menu = CashDeskLib.CashDesk.Instance.LoadMenusExt(DateTime.Today, 2);

            // меню отсортированы по дате в убывающем порядке
            if (menu != null && menu.Any())
            {
                if (menu[0].Date.Date != DateTime.Today)
                {
                    PreviousMenu = new Menu(menu[0]);
                }
                else
                {
                    TodayMenu = new Menu(menu[0]);
                    if (menu.Count > 1)
                    {
                        PreviousMenu = new Menu(menu[1]);
                    }
                }
            }
        }

        /// <summary>
        /// Сегодняшнее меню
        /// </summary>
        public Menu TodayMenu { get; private set; }

        /// <summary>
        /// Предыдущее меню
        /// </summary>
        public Menu PreviousMenu { get; private set; }
    }
}
