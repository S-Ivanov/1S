﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Drg.CashDesk.DataModel
{
    /// <summary>
    /// Заказ
    /// </summary>
    public class Order : INotifyPropertyChanged
    {
        /// <summary>
        /// Конструктор
        /// </summary>
        public Order()
        {
            // прочитать номер нового заказа
            Number = CashDeskLib.CashDesk.Instance.GetNewOrderNumber();

            items.CollectionChanged += Items_CollectionChanged;
        }

        public void AddOrderItem(MenuItem menuItem)
        {
            if (menuItem == null)
                return;

            var newOrderItem = new DataModel.OrderItem(menuItem, Items.Count + 1);
            Items.Add(newOrderItem);
            SelectedOrderItem = newOrderItem;

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanCollapse)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
        }

        public bool CanCollapse => 
            Items != null && 
            Items
            .GroupBy(orderItem => (orderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct)
            .Any(g => g.Count() > 1);

        public void New()
        {
            // прочитать номер нового заказа
            Number = CashDeskLib.CashDesk.Instance.GetNewOrderNumber();
            items.Clear();
            SelectedOrderItem = null;
            Client = Client.Empty;
        }

        public Order(CashDeskLib.DataModel.Order order)
        {
            Number = order.Number;
            Id = order.Id;
            DateTime = order.DateTime;
            for (int i = 0; i < order.Items.Count; i++)
            {
                Items.Add(new OrderItem(order.Items[i], i + 1));
            }
        }

        /// <summary>
        /// Идентификатор (транзакции)
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Дата+время формирования заказа
        /// </summary>
        public DateTime DateTime { get; set; }

        /// <summary>
        /// Номер заказа
        /// </summary>
        public int Number { get; private set; }

        /// <summary>
        /// Общая сумма
        /// </summary>
        public decimal Total => Items.Sum(item => item.Sum);

        public bool HasTotal => Total > 0;

        /// <summary>
        /// Свернуть позиции заказа
        /// </summary>
        public void Collapse()
        {
            if (!CanCollapse)
                return;

            var groups = Items.GroupBy(orderItem => (orderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem).IdProduct);
            var groupedItems = 
                groups
                .Select((g, index) => new OrderItem(g.First().MenuItem, index + 1, g.Sum(orderItem => orderItem.Count)))
                .ToArray();

            items.Clear();
            foreach (var item in groupedItems)
            {
                items.Add(item);
            }

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CanCollapse)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Items)));
        }

        /// <summary>
        /// Обработчик события изменения списка позиций заказа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasTotal)));

            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                // при удалении записи нужно пересчитать нумерацию
                for (int i = 0; i < items.Count; i++)
                {
                    items[i].Number = i + 1;
                }
            }
        }

        /// <summary>
        /// Элементы заказа
        /// </summary>
        public ObservableCollection<OrderItem> Items => items;
        ObservableCollection<OrderItem> items = new ObservableCollection<OrderItem>();

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged

        public CashDeskLib.DataModel.Order ToRawOrder()
        {
            return new CashDeskLib.DataModel.Order
            {
                Id = this.Id == Guid.Empty ? Guid.NewGuid() : this.Id,
                DateTime = this.DateTime == default(DateTime) ? DateTime.Now : this.DateTime,
                Number = this.Number,
                Items = this.Items.Select(orderItem => new CashDeskLib.DataModel.OrderItem
                {
                    MenuItem = orderItem.MenuItem.RawItem as CashDeskLib.DataModel.MenuItem,
                    Price = orderItem.Price,
                    Count = orderItem.Count
                }).ToList()
            };
        }

        public Client Client
        {
            get => client;
            set
            {
                if (client != value)
                {
                    client = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Client)));
                }
            }
        }
        Client client = Client.Empty;

        /// <summary>
        /// Выбранная позиция заказа
        /// </summary>
        public OrderItem SelectedOrderItem
        {
            get => selectedOrderItem;
            set
            {
                if (selectedOrderItem != value)
                {
                    selectedOrderItem = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedOrderItem)));
                }
            }
        }
        OrderItem selectedOrderItem = null;

        public void RecalcTotal()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasTotal)));
        }
    }
}
