﻿using Drg.CashDesk.Dialogs;
using Drg.CashDeskLib.Configuration;
using Drg.CashDeskLib.Utils;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Timers;
using System.Windows;
using System.Windows.Input;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += CurrentDomain_UnhandledException;

            configuration = (CashDeskConfiguration)ConfigurationManager.GetSection("CashDeskConfiguration");
            CashDeskLib.CashDesk cashDesk = CashDeskLib.CashDesk.Create(
                configuration, 
                ConfigurationManager.ConnectionStrings[ConfigurationLocalDbConnectionString].ConnectionString);

            //cashDesk.CashPaymentEvent += CashDesk_CashPaymentEvent;
            // подключить обработчики событий для cashDesk.PaymentManager
            cashDesk.PaymentManager.OnBeforePayTerminalCancel += PaymentManager_OnBeforePayTerminalCancel;
            cashDesk.BeforeOpenSessionKKM += CashDesk_BeforeOpenSessionKKM;

            var kkm = cashDesk.GetKKM();
            kkm.OnReceiptNotPrinted += Kkm_OnReceiptNotPrinted;

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            checkEquipmentTimer = new Timer(configuration.EquipmentCheckPeriod)
            {
                AutoReset = true
            };
            checkEquipmentTimer.Elapsed += CheckEquipmentTimer_Elapsed;
            checkEquipmentTimer.Start();

            exchangeDataTimer = configuration.UseFrontService && configuration.FrontServiceExchangePeriod > 0 ? new Timer(configuration.FrontServiceExchangePeriod * 1000) : null;
            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Elapsed += ExchangeDataTimer_Elapsed;
                exchangeDataTimer.AutoReset = true;
                exchangeDataTimer.Start();
            }

            menuLoadTimer = configuration.UseMenuService && configuration.MenuServiceExchangePeriod > 0 ? new Timer(configuration.MenuServiceExchangePeriod * 1000) : null;
            if (menuLoadTimer != null)
            {
                menuLoadTimer.Elapsed += MenuLoadTimer_Elapsed;
                menuLoadTimer.AutoReset = true;
                menuLoadTimer.Start();
            }

            if (configuration.HideMouseCursor)
            {
                // скрывать курсор мыши
                // см. https://social.msdn.microsoft.com/Forums/vstudio/en-US/28b71115-5a30-4811-a26a-80abfb53facb/how-to-hide-cursor-in-c-wpf-window?forum=wpf
                Mouse.OverrideCursor = Cursors.None;
            }

            StartupWindow startupWindow = new StartupWindow();
            startupWindow.ShowDialog();

            if (cashDesk.Operator != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
        }

        private void CashDesk_BeforeOpenSessionKKM(object sender, CashDeskLib.Session.SessionManager2.SessionManager2_EventArgs e)
        {
            string message = 
                e.CloseAndOpen ? 
                "Будет выполнено закрытие и открытие смены на ККМ." :
                "Будет выполнено открытие смены на ККМ.";
            WpfMessageBox.Show("Предупреждение", message, MessageBoxButton.OK, Dialogs.MessageBoxImage.Information);
        }

        private void PaymentManager_OnBeforePayTerminalCancel(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string message = "Для отмены платежа по банковской карте приложите ее к платежному терминалу.";
            //MessageBoxResult messageBoxResult =
            //    WpfMessageBox.Show("Предупреждение", message, MessageBoxButton.OKCancel, Dialogs.MessageBoxImage.Information);
            //e.Cancel = messageBoxResult == MessageBoxResult.Cancel;
            MessageBoxResult messageBoxResult =
                WpfMessageBox.Show("Предупреждение", message, MessageBoxButton.OK, Dialogs.MessageBoxImage.Information);
        }

        private void Kkm_OnReceiptNotPrinted(object sender, Equipment.KKM.CloseFiscalDocumentErrorEventArgs e)
        {
            string message = e.Message;
            message += $"\n\nКод ошибки: {e.ErrorCode}\nПояснение: {e.Description}";
            message += "\n\nНажмите OK для повтора, ОТМЕНА для отмены.";
            MessageBoxResult messageBoxResult = WpfMessageBox.Show("Ошибка", message, MessageBoxButton.OKCancel, Dialogs.MessageBoxImage.Error);
            e.Cancel = messageBoxResult == MessageBoxResult.Cancel;
        }

        public const string ConfigurationLocalDbConnectionString = "LocalDbConnectionString";

        /// <summary>
        /// Обработка всех неперехваченных в приложении ошибок
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var dateTime = DateTime.Now;
            var stack = (e.ExceptionObject as Exception).StackTrace;

            try
            {
                using (SqlConnection connection = new SqlConnection(
                    ConfigurationManager.ConnectionStrings[ConfigurationLocalDbConnectionString].ConnectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(
@"insert into Exceptions (Id, DateTime, Stack)
values (NEWID(), @DateTime, @Stack)",
                        connection);
                    command.Parameters.AddWithValue("@DateTime", dateTime);
                    command.Parameters.AddWithValue("@Stack", stack);
                    command.ExecuteNonQuery();
                }
            }
            catch
            {
                string fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Exceptions.txt"); 
                using (StreamWriter w = File.AppendText(fileName))
                {
                    w.WriteLine(new string('-', 10));
                    w.WriteLine(dateTime);
                    w.WriteLine(stack);
                }
            }
        }

        private void MenuLoadTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.MenuLoad();
        }

        private void CheckEquipmentTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;

            //cashDesk.RemoteServiceError = !System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable();
            cashDesk.RemoteServiceError = !NetworkUtils.HasPing(cashDesk.Configuration.ServerHost);

            if (!cashDesk.EquipmentIsReady)
                return;

            cashDesk.CheckEquipment();

            CheckEquipmentEvent?.Invoke(this, EventArgs.Empty);

            //if (!deviceErrorWindowVisible)
            //{
            //    foreach (var kvp in cashDesk.Devices)
            //    {
            //        if (kvp.Value.LastError == DeviceError.NoError)
            //        {
            //            confirmedDeviceErrors.TryRemove(kvp.Value, out List<int> dummy);
            //            // TODO: очистить список ошибок
            //            //for (int i = confirmedDeviceErrors.Count - 1; i >= 0; i--)
            //            //{
            //            //    if (confirmedDeviceErrors.TryPeek(out Tuple<IDevice, int> error))
            //            //    {
            //            //        if (error.Item1 == kvp.Value)
            //            //        {
            //            //            confirmedDeviceErrors.TryTake(out error);
            //            //        }
            //            //    }
            //            //}
            //        }
            //        else if (kvp.Value.LastError.IsUserError)
            //        {
            //            if (!confirmedDeviceErrors.TryGetValue(kvp.Value, out List<int> confirmedErrors) ||
            //                confirmedErrors == null ||
            //                !confirmedErrors.Contains(kvp.Value.LastError.ErrorCode))
            //            {
            //                deviceErrorWindowVisible = true;

            //                Dispatcher.Invoke(() =>
            //                {
            //                    DeviceErrorWindow deviceErrorWindow = new DeviceErrorWindow(kvp.Value, kvp.Value.LastError);
            //                    deviceErrorWindow.ShowDialog();

            //                    if (deviceErrorWindow.DeviceError != DeviceError.NoError)
            //                    {
            //                        if (confirmedDeviceErrors.TryGetValue(deviceErrorWindow.Device, out List<int> errorCodes))
            //                        {
            //                            if (!errorCodes.Contains(deviceErrorWindow.DeviceError.ErrorCode))
            //                                errorCodes.Add(deviceErrorWindow.DeviceError.ErrorCode);
            //                        }
            //                        else
            //                        {
            //                            errorCodes = new List<int> { deviceErrorWindow.DeviceError.ErrorCode };
            //                            confirmedDeviceErrors.TryAdd(deviceErrorWindow.Device, errorCodes);
            //                        }
            //                    }

            //                    deviceErrorWindowVisible = false;
            //                });
            //            }
            //        }
            //    }
            //}
        }

        /// <summary>
        /// Запустить проверку оборудования
        /// </summary>
        public void CheckEquipmentStart()
        {
            checkEquipmentTimer.Start();
        }

        /// <summary>
        /// Остановить проверку оборудования
        /// </summary>
        public void CheckEquipmentStop()
        {
            checkEquipmentTimer.Stop();
        }

        /// <summary>
        /// Таймер проверки оборудования
        /// </summary>
        Timer checkEquipmentTimer = null;

        /// <summary>
        /// Таймер обмена данными по клиентам и заказам
        /// </summary>
        Timer exchangeDataTimer;

        /// <summary>
        /// Таймер загрузки меню
        /// </summary>
        Timer menuLoadTimer;

        /// <summary>
        /// Конфигурация кассы
        /// </summary>
        CashDeskConfiguration configuration;

        /// <summary>
        /// Событие после проверки оборудования
        /// </summary>
        public event EventHandler CheckEquipmentEvent;

        protected override void OnExit(ExitEventArgs e)
        {
            if (checkEquipmentTimer != null)
            {
                checkEquipmentTimer.Stop();
                checkEquipmentTimer.Dispose();
            }

            if (exchangeDataTimer != null)
            {
                exchangeDataTimer.Stop();
                exchangeDataTimer.Dispose();
            }

            base.OnExit(e);
        }

        private void ExchangeDataTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            CashDeskLib.CashDesk.Instance.FrontDataExchange();
        }

        //private void CashDesk_CashPaymentEvent(object sender, CashDeskLib.DataModel.CashPaymentEventArgs e)
        //{
        //    //CalcChangeWindow calcSurrenderWindow = new CalcChangeWindow
        //    //{
        //    //    Sum = e.Sum
        //    //};
        //    //e.Cancel = calcSurrenderWindow.ShowDialog() != true;
        //}
    }
}
