﻿using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.Utils;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;

namespace Drg.CashDesk.ViewModels
{
    public class PayWindow : INotifyPropertyChanged
    {
        public PayWindow()
        {
            Subsidy1 = CashDeskLib.CashDesk.Instance.Nominals.Subsidy8;
            Subsidy2 = CashDeskLib.CashDesk.Instance.Nominals.Subsidy12;
            Subsidy3 = CashDeskLib.CashDesk.Instance.Nominals.Subsidy24;

            PayItems = new PayItem[]
            {
                new PayItem(),
                // номиналы талонов брать из конфигурации
                new TalonPayItem(CashDeskLib.CashDesk.Instance.Nominals.LPP),
                new TalonPayItem(CashDeskLib.CashDesk.Instance.Nominals.Talon120),
                new PayItem(),
                new PayItem()
            };
        }

        /// <summary>
        /// Размер дотации на питание 1 (57,47)
        /// </summary>
        public decimal Subsidy1 { get; private set; }

        /// <summary>
        /// Размер дотации на питание 1 (86,21)
        /// </summary>
        public decimal Subsidy2 { get; private set; }

        /// <summary>
        /// Размер дотации на питание 1 (172,41)
        /// </summary>
        public decimal Subsidy3 { get; private set; }

        /// <summary>
        /// Информация об оплате
        /// </summary>
        public PaymentInfo PaymentInfo
        {
            get => paymentInfo;
            set
            {
                if (paymentInfo != value)
                {
                    paymentInfo = value;
                    Reset();
                    if (paymentInfo != null)
                    {
                        if (paymentInfo.PaymentAbilities.Client != null)
                        {
                            // учесть лимит оплаты в счет з/п
                            PayItems[0].Limit = paymentInfo.PaymentAbilities.Client.RawClient.LimitZP;

                            //// учесть количество талонов ЛПП - не более 1 талона
                            //if (paymentInfo.PaymentAbilities.Client.RawClient.MonthLimitLPP > 0)
                            //    PayItems[1].Limit = CashDeskLib.CashDesk.Instance.Nominals.LPP;
                        }

                        PayItem payItem = null;
                        int payItemCount = 0;
                        foreach (var kvp in paymentInfo.Payments)
                        {
                            PayItems[(int)kvp.Key].Sum = kvp.Value;
                            if (kvp.Value != 0)
                            {
                                payItemCount++;
                                payItem = PayItems[(int)kvp.Key];
                            }
                        }

                        if (payItem != null && payItemCount == 1)
                        {
                            payItem.IsSelected = true;
                        }

                        // пересчитать баланс
                        RecalcBalance();
                    }
                }
            }
        }
        PaymentInfo paymentInfo;

        /// <summary>
        /// Пересчет баланса
        /// </summary>
        private void RecalcBalance()
        {
            Balance = PaymentInfo.Total - PayItems.Sum(payItem => payItem.Sum);
        }

        public PayItem[] PayItems { get; private set; }

        public decimal Balance
        {
            get => balance;
            set
            {
                if (balance != value)
                {
                    balance = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Balance)));
                }
            }
        }
        decimal balance;

        /// <summary>
        /// Команда для обработки нажатия клавиш клавиатуры
        /// </summary>
        public ICommand KeyboardCommand
        {
            get
            {
                return new RelayCommand<string>(s =>
                {
                    var selected = PayItems.FirstOrDefault(x => x.IsSelected);
                    if (selected != null)
                    {
                        string valueStr = keyboardText;

                        switch (s)
                        {
                            case "C":
                                valueStr = "";
                                break;
                            case ".":
                            case ",":
                                if (!selected.CanUseDot)
                                    return;
                                else
                                {
                                    valueStr += ",";
                                    break;
                                }
                            //case "0":
                            //case "00":
                            //    break;
                            default:
                                valueStr += s;
                                break;
                        }

                        if (selected.CanSetValueText(valueStr))
                        {
                            var oldKeyboardText = keyboardText;

                            keyboardText = valueStr;
                            selected.ValueText = keyboardText;

                            // пересчитать баланс
                            RecalcBalance();

                            if (Balance < 0)
                            {
                                keyboardText = oldKeyboardText;

                                selected.ValueText = keyboardText;

                                // пересчитать баланс
                                RecalcBalance();
                            }
                        }
                    }
                });
            }
        }

        string keyboardText = "";

        /// <summary>
        /// Команда выбора дотации
        /// </summary>
        public ICommand SubsidyCommand
        {
            get
            {
                return new RelayCommand<decimal>(value =>
                {
                    PayItems[0].Sum = value;
                    RecalcBalance();
                },
                value => PayItems[0].IsEnabled && Balance >= value);
            }
        }

        /// <summary>
        /// Команда выбора варианта оплаты
        /// </summary>
        public ICommand SelectPaymentCommand
        {
            get
            {
                return new RelayCommand<PayItem>(payItem =>
                {
                    var selected = PayItems.FirstOrDefault(x => x.IsSelected);
                    if (selected != null)
                    {
                        selected.IsSelected = false;
                        selected.FixValueText();
                    }
                    payItem.IsSelected = true;
                    if (Balance > 0)
                    {
                        payItem.Sum += Balance;
                        // пересчитать баланс
                        RecalcBalance();
                    }

                    keyboardText = "";
                },
                payItem => payItem.IsEnabled);
            }
        }

        /// <summary>
        /// Команда для обработки нажатия клавиш Ok
        /// </summary>
        public ICommand OkCommand
        {
            get
            {
                return new RelayCommand<object>(o =>
                {
                    // занести результаты в словарь платежей
                    paymentInfo.Payments.Clear();
                    for (int i = 0; i < PayItems.Length; i++)
                    {
                        if (PayItems[i].Sum != 0)
                        {
                            paymentInfo.Payments.Add((Payment)i, PayItems[i].Sum);
                        }
                    }

                    // закрыть диалог оплаты
                    OkCommandEvent?.Invoke(this, EventArgs.Empty);
                },
                o => Balance == 0);
            }
        }

        public event EventHandler OkCommandEvent;

        private void Reset()
        {
            Array.ForEach<PayItem>(PayItems, payItem => payItem.Reset());

            if (paymentInfo != null)
            {
                // устанавить доступность кнопок оплаты в соответствии с возможностями оплаты
                PayItems[(int)Payment.ZP].IsEnabled = paymentInfo.PaymentAbilities.ZP;

                // ЛПП доступно всегда, если есть питание в счет з/п
                //PayItems[(int)Payment.LPP].IsEnabled = paymentInfo.PaymentAbilities.LPP;
                PayItems[(int)Payment.LPP].IsEnabled = paymentInfo.PaymentAbilities.ZP;

                PayItems[(int)Payment.Talon120].IsEnabled = paymentInfo.PaymentAbilities.Talon120;
                PayItems[(int)Payment.BankCard].IsEnabled = paymentInfo.PaymentAbilities.Bank;
                PayItems[(int)Payment.Cash].IsEnabled = paymentInfo.PaymentAbilities.Cash;
            }
        }

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    public class PayItem : INotifyPropertyChanged
    {
        public bool IsSelected
        {
            get => isSelected;
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                }
            }
        }
        bool isSelected;

        public bool IsEnabled
        {
            get => isEnabled;
            set
            {
                if (isEnabled != value)
                {
                    isEnabled = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsEnabled)));
                }
            }
        }
        bool isEnabled;

        /// <summary>
        /// Фактическая сумма
        /// </summary>
        public decimal Sum
        {
            get => sum;
            set
            {
                if (sum != value)
                {
                    if (Limit != 0 && value > Limit)
                        value = Limit;

                    sum = GetSum(value);
                    RaisePropertyChanged(nameof(Sum));

                    // при изменении суммы нужно изменить отображаемый текст
                    valueText = GetValueText(sum);
                    RaisePropertyChanged(nameof(ValueText));
                }
            }
        }
        decimal sum;

        public decimal Limit { get; set; }

        public virtual bool CanUseDot
        {
            get => true;
        } 

        protected virtual string GetValueText(decimal sum) => sum == 0 ? string.Empty : sum.ToString("N2");

        protected virtual decimal GetSum(decimal value) => value;

        /// <summary>
        /// Текст, отображаемый в кнопке
        /// </summary>
        public string ValueText
        {
            get => GetValueText(valueText);
            set
            {
                if (valueText != value)
                {
                    valueText = value;
                    RaisePropertyChanged(nameof(ValueText));

                    // после изменения текста должна поменяться сумма
                    SetSum(valueText);
                }
            } 
        }
        string valueText;

        protected virtual void SetSum(string value)
        {
            if (value.TryToDecimal(out decimal x))
                Sum = x;
        }

        protected virtual string GetValueText(string value) => value;

        public virtual bool CanSetValueText(string value)
        {
            //bool isDecimal = value.TryToDecimal(out decimal x) && x * 100 % 1 == 0;
            //return isDecimal && !(x == 0 && Sum == 0) && (Limit == 0 || x <= Limit);
            if (value.StartsWith("0") || (value.Contains(",") && value.EndsWith("0")))
                return false;
            else
                return true;
        }

        public void FixValueText()
        {
            if (valueText.TryToDecimal(out decimal x))
            {
                valueText = x == 0 ? string.Empty : x.ToString();
                RaisePropertyChanged(nameof(ValueText));
            }
        }

        public void Reset() => IsEnabled = IsSelected = false;

        protected void RaisePropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        #region Реализация интерфейса INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Реализация интерфейса INotifyPropertyChanged
    }

    public class TalonPayItem : PayItem
    {
        public TalonPayItem(decimal nominal)
        {
            this.nominal = nominal;
        }

        public override bool CanUseDot
        {
            get => false;
        }

        protected override decimal GetSum(decimal value) => Math.Floor(value / nominal) * nominal;

        protected override void SetSum(string value)
        {
            if (value.TryToDecimal(out decimal x))
                Sum = x * nominal; 
        }

        protected override string GetValueText(string value) => string.IsNullOrEmpty(value) ? value : $"{value} = {Sum:N2}";

        protected override string GetValueText(decimal sum) => sum == 0 ? string.Empty : (sum / nominal).ToString();

        public override bool CanSetValueText(string value)
        {
            bool isInt = value.TryToDecimal(out decimal x) && x == (int)x;
            return isInt && (Limit == 0 || x <= Limit);
        }

        private decimal nominal;
    }
}
