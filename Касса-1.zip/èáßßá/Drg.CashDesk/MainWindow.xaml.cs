﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Drg.CashDesk.Commands;
using Drg.CashDesk.DataModel;
using Drg.CashDesk.Dialogs;
using Drg.CashDesk.Utils;
using Drg.CashDeskLib.DataModel;

namespace Drg.CashDesk
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            CashDeskLib.CashDesk.Instance.OnMenuLoaded -= CashDesk_OnMenuLoaded;
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var cashDesk = CashDeskLib.CashDesk.Instance;
            cashDesk.OnMenuLoaded += CashDesk_OnMenuLoaded;

            abilityIndicator.Title = $"{cashDesk.Configuration.CashDeskName}, {cashDesk.Operator.FIO}";
            abilityIndicator.CardReaderEvent += AbilityIndicator_CardReaderEvent;
            //abilityIndicator.EquipmentChecked += AbilityIndicator_EquipmentChecked;
            abilityIndicator.OnExit += AbilityIndicator_OnExit;

            //viewModel.LocalMenuItemDelete += ViewModel_LocalMenuItemDelete;
            //viewModel.AddOrderItemEvent += ViewModel_AddOrderItemEvent;
            //viewModel.CashDeskModeChangedEvent += ViewModel_CashDeskModeChangedEvent;

            OrderReturnControl.ReturnEvent += OrderReturnControl_ReturnEvent;
            //OrderReturnControl.WholeOrderReturnEvent += OrderReturnControl_WholeOrderReturnEvent; 

            order = new DataModel.Order();
            OrderControl.Order = order;
            OrderControl.OnChangeCashDeskMode += OrderControl_OnChangeCashDeskMode;

            MenuControl.MenuManager = menuManager;
            MenuControl.Menu = menuManager.TodayMenu;
            MenuControl.IsCurrentMenu = true;
            MenuControl.SelectMenuItemEvent += MenuControl_SelectMenuItemEvent;
            //MenuControl.ServiceEvent += MenuControl_ServiceEvent;

            OldMenuControl.MenuManager = menuManager;
            OldMenuControl.Menu = menuManager.PreviousMenu;
            OldMenuControl.IsCurrentMenu = false;
            //OldMenuControl.ServiceEvent += OldMenuControl_ServiceEvent;

            OrderReturnControl.PayButton.Height = OrderSourceControl.PayButton.ActualHeight;

            OrderFooterControl.Order = order;

            MenuFooterControl.MenuControl = MenuControl;

            //MenuControl.menuItemsItemsControl.get
        }

        /// <summary>
        /// заказ
        /// </summary>
        DataModel.Order order;

        private void CashDesk_OnMenuLoaded(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() => MenuControl.ReloadMenu());
        }

        private void OldMenuControl_ServiceEvent(object sender, EventArgs e)
        {
            MenuControl.AddMenuItem(OldMenuControl.SelectedMenuItem);
        }

        private void MenuControl_ServiceEvent(object sender, EventArgs e)
        {
            if (!OrderControl.IsEmpty && WpfMessageBox.Show("Подтверждение", "Удалить заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            order.New();

            if (MenuControl.IsServiceMode)
            {
                MenuControl.IsServiceMode = OldMenuControl.IsServiceMode = false;
                SetCashDeskMode(CashDeskMode.Work);
            }
            else
                SelectServiceMode();
        }

        private void MenuControl_SelectMenuItemEvent(object sender, DataModelEventArgs<DataModel.MenuItem> e)
        {
            if (viewModel.CashDeskMode == CashDeskMode.Work)
                order.AddOrderItem(e.Data);
            else
            {
                //TODO: обработка правой панели управления меню
            }
        }

        MenuManager menuManager = new MenuManager();

        private void OrderControl_OnChangeCashDeskMode(object sender, ChangeCashDeskModeEventArgs e)
        {
            viewModel.CashDeskMode = e.CashDeskMode;
        }

        private void OrderReturnControl_ReturnEvent(object sender, EventArgs e)
        {
            SetCashDeskMode(CashDeskMode.Work);
        }

        async private void AbilityIndicator_OnExit(object sender, CancelEventArgs e)
        {
            if (!OrderControl.IsEmpty && WpfMessageBox.Show("Подтверждение", "Удалить заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) != MessageBoxResult.Yes)

            {
                e.Cancel = true;
                return;
            }

            (Application.Current as App).CheckEquipmentStop();
            try
            {
                order.New();

                bool synchronize = 
                    CashDeskLib.CashDesk.Instance.Configuration.UseFrontService && 
                    CashDeskLib.CashDesk.Instance.HasOrders;

                MessageBoxResult messageBoxResult = WpfMessageBox.Show("Подтверждение", "Закрыть текущую смену?", MessageBoxButton.YesNoCancel, Dialogs.MessageBoxImage.Question);
                bool closeSession = messageBoxResult == MessageBoxResult.Yes;

                if (synchronize || closeSession)
                {
                    ProgressBarDialog w = new ProgressBarDialog("Выполняется синхронизация данных", false);
                    Task work = Go(w, synchronize, closeSession);
                    w.ShowDialog();
                    await work;
                }

                e.Cancel = messageBoxResult == MessageBoxResult.Cancel;
            }
            finally
            {
                (Application.Current as App).CheckEquipmentStart();
            }
        }

        async Task Go(Window w, bool synchronize, bool closeSession)
        {
            await Task.Run(() => {
                // синхронизация данных по выходу из программы
                if (synchronize)
                    CashDeskLib.CashDesk.Instance.FrontDataExchange();

                if (closeSession)
                    CashDeskLib.CashDesk.Instance.CloseSession();
            });

            w.Close();
        }

        private void AbilityIndicator_CardReaderEvent(object sender, Equipment.CardReader.CardReaderEventArgs e)
        {
            Dispatcher.BeginInvoke(
                DispatcherPriority.Background,
                new Action(() =>
                {
                    if (viewModel.CashDeskMode == CashDeskMode.Work && OrderControl.Order.Client.RawClient.CardCode != e.CardCode)
                    {
                        CashDeskLib.DataModel.Client client = CashDeskLib.CashDesk.Instance.GetClient(e.CardCode);
                        OrderControl.SetOrderClient(client == null ? DataModel.Client.Empty : new DataModel.Client(client));
                    }
                }));
        }

        //private void ServiceButton_Click(object sender, RoutedEventArgs e)
        //{
        //    SelectServiceMode();
        //}

        private void SelectServiceMode()
        {
            CashDeskMode cashDeskMode = viewModel.CashDeskMode;
            switch (cashDeskMode)
            {
                // переходы из рабочего состояния
                case CashDeskMode.Work:
                    viewModel.CashDeskMode = CashDeskMode.None;
                    SelectModeDialog selectModeDialog = new SelectModeDialog();
                    if (selectModeDialog.ShowDialog() == true)
                    {
                        var serviceCashDeskMode = selectModeDialog.CashDeskMode;
                        switch (serviceCashDeskMode)
                        {
                            case CashDeskMode.MenuService:
                                SetCashDeskMode(CashDeskMode.MenuService);
                                return;
                            case CashDeskMode.OrderReturn:
                                if (StartReturnOrder())
                                {
                                    SetCashDeskMode(CashDeskMode.OrderReturn);
                                    return;
                                }
                                break;
                            case CashDeskMode.TotalMoney:
                                ShowTotalMoneyReport();
                                break;
                            case CashDeskMode.TotalProduct:
                                ShowTotalProductReport();
                                break;
                        }
                    }
                    break;
                case CashDeskMode.MenuService:
                    SetCashDeskMode(CashDeskMode.Work);
                    return;
                case CashDeskMode.OrderReturn:
                    SetCashDeskMode(CashDeskMode.Work);
                    return;
            }

            viewModel.CashDeskMode = CashDeskMode.Work;
        }

        private void ShowTotalProductReport()
        {
            Session session = CashDeskLib.CashDesk.Instance.Session;
            List<CashDeskLib.DataModel.ProductReportItem> productReportItems = CashDeskLib.CashDesk.Instance.LoadProductReportItemList();
            if (productReportItems.Any())
            {
                TotalProductReport totalProductReport = new TotalProductReport(session, productReportItems);
                totalProductReport.ShowDialog();
            }
            else
            {
                //MessageBox.Show("Нет данных для отображения", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                WpfMessageBox.Show("Сообщение", "Нет данных для отображения", MessageBoxButton.OK, Dialogs.MessageBoxImage.Information);
            }
        }

        private void ShowTotalMoneyReport()
        {
            Session session = CashDeskLib.CashDesk.Instance.Session;
            List<CashDeskLib.DataModel.MoneyReportItem> moneyReportItems = CashDeskLib.CashDesk.Instance.LoadMoneyReportItems();
            Tuple<int, int> orderCountInfo = CashDeskLib.CashDesk.Instance.LoadOrderCountInfo();
            if (moneyReportItems.Any())
            {
                TotalMoneyReport totalMoneyReport = new TotalMoneyReport(session, moneyReportItems, orderCountInfo.Item1, orderCountInfo.Item2);
                totalMoneyReport.ShowDialog();
            }
            else
            {
                WpfMessageBox.Show("Сообщение", "Нет данных для отображения", MessageBoxButton.OK, Dialogs.MessageBoxImage.Information);
            }
        }

        bool StartReturnOrder()
        {
            var orders = CashDeskLib.CashDesk.Instance.LoadLocalOrders().Where(o => !o.HasReturns);
            if (!orders.Any())
            {
                WpfMessageBox.Show("Сообщение", "Нет данных для отображения", MessageBoxButton.OK, Dialogs.MessageBoxImage.Information);
                return false;
            }
            else
            {
                // вызвать диалог для выбора заказа для возврата
                SelectOrderDialog selectOrderDialog = new SelectOrderDialog(orders);
                if (selectOrderDialog.ShowDialog() != true)
                    return false;
                else
                {
                    // TODO: возврат заказа:

                    // загрузить детальную информацию об исходном заказе
                    var orderToReturn = selectOrderDialog.viewModel.SelectedOrder.Order;
                    DataModel.Client client = orderToReturn.Client == null ? DataModel.Client.Empty : new DataModel.Client(orderToReturn.Client);

                    var orderInfo = CashDeskLib.CashDesk.Instance.LoadOrder(orderToReturn.Id);

                    ObservableCollection<OrderReturnItem> orderReturnAllItems = new ObservableCollection<OrderReturnItem>();

                    DataModel.OrderReturn orderReturn = new DataModel.OrderReturn(orderReturnAllItems);

                    DataModel.OrderSource orderSource = new DataModel.OrderSource(client, orderInfo.Item2, orderReturn);

                    orderReturn.OrderSource = orderSource;

                    OrderSourceControl.OrderSource = orderSource;

                    OrderReturnControl.OrderReturn = orderReturn;
                    OrderReturnControl.SourceOrder = orderInfo.Item2;
                    OrderReturnControl.Client = orderToReturn.Client;

                    ReturnFooterControl.OrderSource = orderSource;

                    return true;
                }
            }
        }

        /// <summary>
        /// Переключение режимов работы
        /// </summary>
        /// <param name="cashDeskMode">режим, который нужно включить</param>
        private void SetCashDeskMode(CashDeskMode cashDeskMode)
        {
            // viewModel.CashDeskMode - текущий режим
            if (viewModel.CashDeskMode != cashDeskMode)
            {
                viewModel.CashDeskMode = cashDeskMode;
                switch (cashDeskMode)
                {
                    case CashDeskMode.Work:
                        OrderControl.Visibility = MenuControl.Visibility = Visibility.Visible;
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Hidden;
                        OldMenuControl.Visibility = Visibility.Hidden;
                        OrderFooterControl.Visibility = Visibility.Visible;
                        MenuFooterControl.Visibility = ReturnFooterControl.Visibility = Visibility.Collapsed;
                        break;
                    case CashDeskMode.MenuService:
                        OrderControl.Visibility = OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Hidden;
                        MenuControl.Visibility = OldMenuControl.Visibility = Visibility.Visible;
                        OrderFooterControl.Visibility = ReturnFooterControl.Visibility = Visibility.Collapsed;
                        MenuFooterControl.Visibility = Visibility.Visible;
                        break;
                    case CashDeskMode.OrderReturn:
                        OrderSourceControl.Visibility = OrderReturnControl.Visibility = Visibility.Visible;
                        OrderControl.Visibility = MenuControl.Visibility = OldMenuControl.Visibility = Visibility.Hidden;
                        OrderFooterControl.Visibility = MenuFooterControl.Visibility = Visibility.Collapsed;
                        ReturnFooterControl.Visibility = Visibility.Visible;
                        break;
                }
            }
        }

        private void OrderFooterControl_ServiceEvent(object sender, EventArgs e)
        {
            if (order.Items.Any() && WpfMessageBox.Show("Подтверждение", "Удалить заказ?", MessageBoxButton.YesNo, Dialogs.MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            order.New();

            //if (MenuControl.IsServiceMode)
            //{
            //    MenuControl.IsServiceMode = OldMenuControl.IsServiceMode = false;
            //    SetCashDeskMode(CashDeskMode.Work);
            //}
            //else
                SelectServiceMode();
        }

        private void MenuFooterControl_ServiceEvent(object sender, EventArgs e)
        {
            SelectServiceMode();
        }

        private void ReturnFooterControl_ServiceEvent(object sender, EventArgs e)
        {
            SelectServiceMode();
        }

    }
}
