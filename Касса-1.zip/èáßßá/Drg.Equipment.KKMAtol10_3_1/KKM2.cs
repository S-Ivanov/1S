﻿using Drg.Equipment.KKM;
using System;
using System.Collections.Generic;
using System.Linq;
using Atol.Drivers10.Fptr;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Threading;

namespace Drg.Equipment.KKMAtol10_3_1
{
    /// <summary>
    /// ККМ
    /// </summary>
    /// <remarks>
    /// Используется библиотека интеграции с драйвером Атол ККМ 10.х - см. http://integration.atol.ru/
    /// </remarks>
    public class KKM2 : DeviceBase, IKKM, IKKMPayment2
    {
        public KKM2(int timeoutMilliseconds)
        {
            this.timeoutMilliseconds = timeoutMilliseconds;

            try
            {
                fptr = new Fptr();

                OpenDriver();

                ReadFnInfo();
            }
            catch
            {
                FixLastError(-1, "Ошибка подключения ККМ");
            }
        }

        private bool OpenDriver()
        {
            if (!isOpened)
            {
                // настройка драйвера
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_MODEL, Constants.LIBFPTR_MODEL_ATOL_AUTO.ToString());
                fptr.setSingleSetting(Constants.LIBFPTR_SETTING_PORT, Constants.LIBFPTR_PORT_USB.ToString());
                fptr.applySingleSettings();

                // открытие драйвера
                fptr.open();

                // проверить фактическое открытие драйвера
                isOpened = fptr.isOpened();

                if (isOpened)
                {
                    // чтение настроек
                    ReadProperties();
                }
                else
                {
                    FixLastError(-1, "Ошибка подключения ККМ");
                }
            }

            return isOpened;
        }

        bool isOpened = false;

        private void ReadProperties()
        {
            ReadSessionInfo();

            // Запрос данных о ККМ
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
            fptr.queryData();

            bool isFiscalDevice = fptr.getParamBool(Constants.LIBFPTR_PARAM_FISCAL);
            bool isFiscalFN = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_FISCAL);
            Fiscal = isFiscalDevice && isFiscalFN;

            LineLength = fptr.getParamInt(Constants.LIBFPTR_PARAM_RECEIPT_LINE_LENGTH);
        }

        /// <summary>
        /// Запрос о состоянии смены
        /// </summary>
        private void ReadSessionInfo()
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_SHIFT_STATE);
            fptr.queryData();

            SessionState = (SessionState)fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_STATE);
            SessionNumber = fptr.getParamInt(Constants.LIBFPTR_PARAM_SHIFT_NUMBER);
        }

        public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument)
        {
            if (OpenDriver())
                DoAction((int)PrintAction.PrintNotFiscal, Tuple.Create(textInfo, closeDocument));
        }

        void DoPrintNonFiscalDocument(Tuple<IEnumerable<TextInfo>, bool> data)
        {
            if (OpenDriver())
                PrintNonFiscalDocument(data.Item1, new CancellationToken(), null, null, data.Item2);
        }

        void PrintNonFiscalDocument(
            IEnumerable<TextInfo> textInfo, 
            CancellationToken token, 
            Action itemCompletedAction, 
            Action finishAction, 
            bool closeDocument)
        {
            if (textInfo == null || !textInfo.Any())
                return;

            if (!OpenDriver())
                return;

            //Dictionary<string, object> dict = new Dictionary<string, object>
            //{
            //    { "type", "nonFiscal" },
            //};
            //dict.Add(
            //    "items",
            //    textInfo
            //    .Select(_ => new Dictionary<string, object>
            //    {
            //        { "type", "text" },
            //        { "text", _.Text },
            //        { "alignment", _.Alignment },
            //        { "font", _.Font },
            //        { "doubleWidth", _.DoubleWidth },
            //        { "doubleHeight", _.DoubleHeight },
            //    })
            //    .ToList()
            //);

            //var serializer = new JavaScriptSerializer();
            //string json = serializer.Serialize(dict);

            //fptr.setParam(Constants.LIBFPTR_PARAM_JSON_DATA, json);
            //fptr.processJson();

            //CheckErrors();

            //bool documentOpened = false;

            LastError = DeviceError.NoError;

            try
            {
                DoLowMethod(() => fptr.beginNonfiscalDocument());
                //documentOpened = true;

                foreach (var ti in textInfo)
                {
                    if (token.CanBeCanceled && token.IsCancellationRequested)
                    {
                        PrintLine(
                            new TextInfo
                            {
                                Text = "Печать прервана пользователем"
                            });
                        break;
                    }

                    PrintLine(ti);
                    itemCompletedAction?.Invoke();
                }

                //if (closeDocument && documentOpened)
                if (closeDocument)
                    DoLowMethod(() => fptr.endNonfiscalDocument());

                finishAction?.Invoke();
            }
            catch (DeviceException ex)
            {
                LastError = ex.DeviceError;
                throw;
            }
        }

        private void PrintLine(TextInfo ti)
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT, ti.Text);
            fptr.setParam(Constants.LIBFPTR_PARAM_ALIGNMENT, (int)ti.Alignment);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT, ti.Font);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_WIDTH, ti.DoubleWidth);
            fptr.setParam(Constants.LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT, ti.DoubleHeight);
            fptr.setParam(Constants.LIBFPTR_PARAM_TEXT_WRAP, (int)ti.Wrap);
            fptr.setParam(Constants.LIBFPTR_PARAM_LINESPACING, ti.LineSpacing);
            fptr.setParam(Constants.LIBFPTR_PARAM_BRIGHTNESS, ti.Brightness);

            DoLowMethod(() => fptr.printText());
        }

        public Task PrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            OpenDriver();
            return DoActionAsync((int)PrintAction.PrintNotFiscal, textInfo, token, itemCompletedAction, finishAction);
        }

        Task DoPrintNonFiscalDocumentAsync(IEnumerable<TextInfo> textInfo, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            OpenDriver();
            return Task.Run(() =>
            {
                PrintNonFiscalDocument(textInfo, token, itemCompletedAction, finishAction, true);
            });
        }

        void DoLowMethod(Func<int> func)
        {
            int errorCode = func();
            if (errorCode != 0)
            {
                FixLastError();
                throw new DeviceException(LastError);
            }
        }

        /// <summary>
        /// Ширина чековой ленты, символов
        /// </summary>
        public uint LineLength { get; private set; }

        public bool Fiscal { get; private set; }

        public uint SessionNumber { get; private set; }

        //public string FnNumber { get; private set; }

        public SessionState SessionState { get; private set; }

        /// <summary>
        /// Информация о фискальном накопителе
        /// </summary>
        public FnInfo FnInfo { get; } = new FnInfo();

        public string FnNumber => FnInfo.FnNumber;

        public void ReadFnInfo()
        {
            if (!OpenDriver())
                return;

            // Запрос данных о ФН
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_REG_INFO);
            fptr.fnQueryData();
            FnInfo.FnNumber = fptr.getParamString(1037);

            // Информация о ФН
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_FN_INFO);
            fptr.fnQueryData();

            FnInfo.State = (FnState)fptr.getParamInt(Constants.LIBFPTR_PARAM_FN_STATE);
            FnInfo.NeedReplacement = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_NEED_REPLACEMENT);
            FnInfo.Exhausted = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_RESOURCE_EXHAUSTED);
            FnInfo.MemoryOverflow = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_MEMORY_OVERFLOW);
            FnInfo.CriticalError = fptr.getParamBool(Constants.LIBFPTR_PARAM_FN_CRITICAL_ERROR);

            // Срок действия ФН
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_VALIDITY);
            fptr.fnQueryData();

            FnInfo.ExpireDate = fptr.getParamDateTime(Constants.LIBFPTR_PARAM_DATE_TIME);

            // Статус информационного обмена
            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_OFD_EXCHANGE_STATUS);
            fptr.fnQueryData();

            FnInfo.FirstNonSendDateTime = fptr.getParamDateTime(Constants.LIBFPTR_PARAM_DATE_TIME);
        }

        #region Реализация интерфейса IKKM

        protected override void CheckErrorsInternal()
        {
            if (!OpenDriver())
                return;

            LastError = DeviceError.NoError;

            if (fptr == null)
                return;

            var task = new Task(() =>
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_DATA_TYPE, Constants.LIBFPTR_DT_STATUS);
                fptr.queryData();

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_ERROR))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_MECHANICAL_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_CONNECTION_LOST))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_PRINTER_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_CUT_ERROR))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_CUTTER_FAULT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_PRINTER_OVERHEAT))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_PRINTER_OVERHEAT);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_COVER_OPENED))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_COVER_OPENED);
                    return;
                }

                if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_RECEIPT_PAPER_PRESENT))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_NO_PAPER);
                    return;
                }

                if (fptr.getParamBool(Constants.LIBFPTR_PARAM_BLOCKED))
                {
                    FixLastError(Constants.LIBFPTR_ERROR_INTERRUPTED_BY_PREVIOUS_ERRORS);
                    return;
                }

                // проверяем состояние смены
                ReadSessionInfo();
                if (SessionState == SessionState.Expired)
                {
                    FixLastError(Constants.LIBFPTR_ERROR_SHIFT_EXPIRED);
                    return;
                }
            });
            task.Start();

            var result = task.Wait(timeoutMilliseconds);
            if (!result)
            {
                FixLastError(Constants.LIBFPTR_ERROR_NO_CONNECTION);
                return;
            }

            ReadFnInfo();
        }

        void FixLastError()
        {
            FixLastError(fptr.errorCode(), fptr.errorDescription());
        }

        void FixLastError(int errorCode, string errorDescription = null)
        {
            LastError = new DeviceError { ErrorCode = errorCode, Description = errorDescription };
            if (ErrorInfo.TryGetValue(errorCode, out Tuple<bool, string, string> errorInfo))
            {
                LastError.IsUserError = errorInfo.Item1;
                if (string.IsNullOrEmpty(LastError.Description))
                    LastError.Description = errorInfo.Item2;
                LastError.Recomendation = errorInfo.Item3;
            }
            else
            {
                LastError.IsUserError = false;
                LastError.Recomendation = string.Empty;
            }

            if (errorCode != 0)
                SessionState = SessionState.Unknown;
        }

        protected override void DisposeInternal()
        {
            fptr.close();
        }

        protected override void DoActionInternal<T>(int actionType, T parameters)
        {
            if (!OpenDriver())
                return;

            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    //if (parameters is IEnumerable<TextInfo>)
                    //{
                    //    DoPrintNonFiscalDocument(parameters as IEnumerable<TextInfo>);
                    //}
                    if (parameters is Tuple<IEnumerable<TextInfo>, bool>)
                    {
                        DoPrintNonFiscalDocument(parameters as Tuple<IEnumerable<TextInfo>, bool>);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
                case (int)PrintAction.PrintReceipt:
                    if (parameters is Receipt)
                    {
                        DoPrintReceipt(parameters as Receipt);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }
        }

        public void PrintReceipt(Receipt receipt)
        {
            if (!OpenDriver())
                return;

            DoAction((int)PrintAction.PrintReceipt, receipt);
        }

        private void DoPrintReceipt(Receipt receipt)
        {
            if (!OpenDriver())
                return;

            // регистрировать кассира
            RegisterOperator();

            // открыть чек
            fptr.setParam(Constants.LIBFPTR_PARAM_RECEIPT_TYPE, (int)receipt.ReceiptType);
            fptr.openReceipt();

            // регистрировать товарные позиции чека
            foreach (var item in receipt.Items)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_COMMODITY_NAME, item.Name);
                fptr.setParam(Constants.LIBFPTR_PARAM_PRICE, item.Price);
                fptr.setParam(Constants.LIBFPTR_PARAM_QUANTITY, item.Count);
                if (item.TaxType == TaxType.CUSTOM)
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, Math.Round(item.Price * item.Count * item.VATCoefficient, 2));
                }
                else
                {
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_TYPE, (int)item.TaxType);
                    fptr.setParam(Constants.LIBFPTR_PARAM_TAX_SUM, 0);
                }
                fptr.registration();
            }

            // Зарегистрировать оплату
            foreach (var kvp in receipt.Payments)
            {
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_TYPE, (int)kvp.Key);
                fptr.setParam(Constants.LIBFPTR_PARAM_PAYMENT_SUM, kvp.Value);
                fptr.payment();
            }

            //fptr.setParam(Constants.LIBFPTR_PARAM_SUM, receipt.Payments.Sum(kvp => kvp.Value));
            //fptr.receiptTotal();

            // Закрытие полностью оплаченного чека
            CloseFiscalDocument();
            FixLastError();

            //// Проверка закрытия документа(на примере закрытия фискального чека)
            //// http://integration.atol.ru/#804811a4ee
            //fptr.closeReceipt();

            //while (fptr.checkDocumentClosed() < 0)
            //{
            //    // Не удалось проверить состояние документа. Вывести пользователю текст ошибки, попросить устранить неполадку и повторить запрос
            //    Console.WriteLine(fptr.errorDescription());
            //    continue;
            //}

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED))
            //{
            //    // Документ не закрылся. Требуется его отменить (если это чек) и сформировать заново
            //    fptr.cancelReceipt();
            //    return;
            //}

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            //{
            //    // Можно сразу вызвать метод допечатывания документа, он завершится с ошибкой, если это невозможно
            //    while (fptr.continuePrint() < 0)
            //    {
            //        // Если не удалось допечатать документ - показать пользователю ошибку и попробовать еще раз.
            //        Console.WriteLine(String.Format("Не удалось напечатать документ (Ошибка \"{0}\"). Устраните неполадку и повторите.", fptr.errorDescription()));
            //        continue;
            //    }
            //}
        }

        private void CloseFiscalDocument()
        {
            int result = fptr.closeReceipt();

            // OnCloseFiscalDocumentError

            //if (result != 0)
            //{
            //while (fptr.checkDocumentClosed() < 0)
            while (result != 0)
            {
                bool cancel = true;

                // Не удалось проверить состояние документа. Вывести пользователю текст ошибки, попросить устранить неполадку и повторить запрос
                if (OnReceiptNotPrinted != null)
                {
                    CloseFiscalDocumentErrorEventArgs args = new CloseFiscalDocumentErrorEventArgs
                    {
                        Message = "Не удалось закрыть фискальный чек",
                        ErrorCode = fptr.errorCode(),
                        Description = fptr.errorDescription()
                    };
                    OnReceiptNotPrinted(this, args);
                    cancel = args.Cancel;
                }

                if (cancel)
                {
                    FixLastError();
                    fptr.cancelReceipt();
                    throw new DeviceException(LastError);
                    //return;
                }
                else
                {
                    result = fptr.closeReceipt();
                }
                //    continue;
            }
            //}

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_CLOSED))
            //{
            //    // Документ не закрылся. Требуется его отменить (если это чек) и сформировать заново
            //    FixLastError();
            //    fptr.cancelReceipt();
            //    //if (LastError.HasError)

            //    throw new DeviceException(LastError);
            //}

            //if (!fptr.getParamBool(Constants.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            //{
            //    // Можно сразу вызвать метод допечатывания документа, он завершится с ошибкой, если это невозможно
            //    while (fptr.continuePrint() < 0)
            //    {
            //        // Если не удалось допечатать документ - показать пользователю ошибку и попробовать еще раз.
            //        bool cancel = true;

            //        if (OnCloseFiscalDocumentError != null)
            //        {
            //            CloseFiscalDocumentErrorEventArgs args = new CloseFiscalDocumentErrorEventArgs
            //            {
            //                Message = "Не удалось допечатать фискальный чек",
            //                ErrorCode = fptr.errorCode(),
            //                Description = fptr.errorDescription()
            //            };
            //            OnCloseFiscalDocumentError(this, args);
            //            cancel = args.Cancel;
            //        }

            //        if (cancel)
            //            return;
            //        else
            //            continue;
            //    }
            //}
        }

        protected override Task DoActionInternalAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
        {
            // проверить actionType на соответствие PrintAction
            CheckActionType(actionType);

            //CheckErrors();

            switch (actionType)
            {
                case (int)PrintAction.PrintNotFiscal:
                    if (parameters is IEnumerable<TextInfo>)
                    {
                        return DoPrintNonFiscalDocumentAsync(parameters as IEnumerable<TextInfo>, token, itemCompletedAction, finishAction);
                    }
                    else
                    {
                        // TODO: ошибка параметров
                    }
                    break;
            }

            return null;
        }

        void CheckActionType(int actionType)
        {
            if (!Enum.IsDefined(typeof(PrintAction), actionType))
                throw new ArgumentException(nameof(actionType));
        }

        void RegisterOperator()
        {
            if (!OpenDriver())
                return;

            if (!string.IsNullOrEmpty(operatorInfo))
            {
                fptr.setParam(1021, operatorInfo);
                fptr.setParam(1203, operatorINN);
                fptr.operatorLogin();
            }
        }

        public void OpenSession(string operatorInfo, string operatorINN)
        {
            if (!OpenDriver())
                return;

            if (string.IsNullOrWhiteSpace(operatorInfo))
                throw new ArgumentException(nameof(operatorInfo));
            if (string.IsNullOrWhiteSpace(operatorINN))
                throw new ArgumentException(nameof(operatorINN));

            this.operatorInfo = operatorInfo;
            this.operatorINN = operatorINN;

            RegisterOperator();
            fptr.openShift();

            // TODO: зачем закрывать документ ?
            // CloseFiscalDocument();

            // Перечитать номер смены
            ReadSessionInfo();
        }

        public void CloseSession()
        {
            if (!OpenDriver())
                return;

            // регистрировать кассира
            RegisterOperator();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_CLOSE_SHIFT);
            fptr.report();
            SessionState = SessionState.Closed;
        }

        public void CancelReceipt()
        {
            if (!OpenDriver())
                return;

            fptr.cancelReceipt();
        }

        public void CasheChange(decimal sum)
        {
            if (sum == 0)
                return;

            if (!OpenDriver())
                return;

            fptr.setParam(Constants.LIBFPTR_PARAM_SUM, (double)sum);
            if (sum > 0)
                fptr.cashIncome();
            else
                fptr.cashOutcome();
        }

        public void CloseSession(string operatorInfo, string operatorINN)
        {
            this.operatorInfo = operatorInfo;
            this.operatorINN = operatorINN;
            CloseSession();
        }

        #endregion Реализация интерфейса IKKM

        public void PrintNonFiscalDocument2(IEnumerable<TextInfo> document)
        {
            if (document == null)
                throw new ArgumentNullException(nameof(document));

            if (document.Any())
            {
                Dictionary<string, object> dict = new Dictionary<string, object>
                {
                    { "type", "nonFiscal" },
                    { "items", document.Select(textInfo => TextInfoToDictionary(textInfo)).ToList() }
                };

                string json = (new JavaScriptSerializer()).Serialize(dict);
                // результат не обрабатываем
                ProcessJson(json);
            }
        }

        /// <summary>
        /// Код ошибки - фискальный чек не допечатан
        /// </summary>
        public const int ReceiptNoPrintedError = -100;

        void RegisterOperator(string @operator, string operatorINN)
        {
            this.operatorInfo = @operator;
            this.operatorINN = operatorINN;
            RegisterOperator();
        }

        public void PrintReceipt2(
            IEnumerable<TextInfo> notFiscalHeader,
            Receipt receipt,
            string paymentsPlace,
            string @operator,
            string operatorINN)
        {
            if (receipt == null)
                throw new ArgumentNullException(nameof(receipt));

            RegisterOperator(@operator, operatorINN);

            string json = PrepareReceiptJson(notFiscalHeader, receipt, paymentsPlace, @operator, operatorINN);
            string result = ProcessJson(json);

            // разобрать результат
            dynamic response = (new JavaScriptSerializer()).Deserialize<object>(result);
            if (response["warnings"] != null && response["warnings"]["notPrinted"] && OnReceiptNotPrinted != null)
            {
                // если есть предупреждения, нужно допечатать чек
                bool canceled = false;
                while (!canceled)
                {
                    CloseFiscalDocumentErrorEventArgs args = new CloseFiscalDocumentErrorEventArgs
                    {
                        ErrorCode = ReceiptNoPrintedError
                    };
                    args.Description = args.Message = "Фискальный чек не допечатан";
                    OnReceiptNotPrinted(this, args);
                    canceled = args.Cancel;

                    if (!canceled)
                    {
                        try
                        {
                            ProcessJson(@"{ ""type"": ""continuePrint"" }");
                            canceled = true;
                        }
                        catch
                        {
                            //canceled = false;
                        }
                    }
                }
            }
        }

        public void PrintLastReceiptCopy()
        {
            ProcessJson(@"{ ""type"": ""printLastReceiptCopy"" }");
        }

        /// <summary>
        /// Выполнить задание JSON
        /// </summary>
        /// <param name="json"></param>
        /// <returns>результат выполнения, зависит от задания</returns>
        string ProcessJson(string json)
        {
            fptr.setParam(Constants.LIBFPTR_PARAM_JSON_DATA, json);
            DoLowMethod(() => fptr.processJson());
            return fptr.getParamString(Constants.LIBFPTR_PARAM_JSON_DATA);
        }

        public static string PrepareReceiptJson(IEnumerable<TextInfo> notFiscalHeader, Receipt receipt, string paymentsPlace, string @operator, string operatorINN)
        {
            if (receipt == null)
                throw new ArgumentNullException(nameof(receipt));
            if (string.IsNullOrEmpty(@operator))
                throw new ArgumentNullException(nameof(@operator));
            if (string.IsNullOrEmpty(operatorINN))
                throw new ArgumentNullException(nameof(operatorINN));

            // обрабатываем только чеки продажи и возврата продажи
            if (!(receipt.ReceiptType == ReceiptType.LIBFPTR_RT_SELL || receipt.ReceiptType == ReceiptType.LIBFPTR_RT_SELL_RETURN))
                throw new ArgumentException(nameof(receipt));

            // оплата только наличными или безналичными
            if (!receipt.Payments.All(payment => payment.Key == PaymentType.LIBFPTR_PT_CASH || payment.Key == PaymentType.LIBFPTR_PT_ELECTRONICALLY))
                throw new ArgumentException(nameof(receipt));

            var items = new List<Dictionary<string, object>>();

            // сформировать нефискальный заголовок
            if (notFiscalHeader != null)
                items.AddRange(notFiscalHeader.Select(textInfo => TextInfoToDictionary(textInfo)).Where(ti => ti != null));

            // сформировать фискальную часть чека
            items.AddRange(receipt.Items.Select(item => ReceiptItemToDictionary(item)));

            Dictionary<string, object> dict = new Dictionary<string, object>
            {
                { "type", receipt.ReceiptType == ReceiptType.LIBFPTR_RT_SELL ? "sell" : "sellReturn" },
                { "ignoreNonFiscalPrintErrors", false },
                { "taxationType", "osn" },
                {
                    "operator",
                    new Dictionary<string, object>
                    {
                        { "name", @operator },
                        { "vatin", operatorINN },
                    }
                },
                { "items", items },
                { "payments", receipt.Payments.Select(kvp => ReceiptPaymentToDictionary(kvp.Key, kvp.Value)).ToList() },
                { "total", receipt.Payments.Sum(kvp => kvp.Value) }
            };

            if (!string.IsNullOrEmpty(paymentsPlace))
                dict.Add("paymentsPlace", paymentsPlace);

            return (new JavaScriptSerializer()).Serialize(dict);
        }

        static Dictionary<string, object> TextInfoToDictionary(TextInfo textInfo)
        {
            // локальная функция для преобразования способа выравнивания
            string GetAlignment(TextAlignment alignment)
            {
                switch (alignment)
                {
                    case TextAlignment.Center:
                        return "center";
                    case TextAlignment.Left:
                        return "left";
                    case TextAlignment.Right:
                    default:
                        return "right";
                }
            }

            // локальная функция для преобразования способа выравнивания
            string GetWrap(TextWrap wrap)
            {
                switch (wrap)
                {
                    case TextWrap.Chars:
                        return "chars";
                    case TextWrap.None:
                        return "none";
                    case TextWrap.Words:
                    default:
                        return "words";
                }
            }

            if (textInfo == null)
                return null;

            return 
                new Dictionary<string, object>
                {
                    { "type", "text" },
                    { "text", textInfo.Text },
                    { "alignment", GetAlignment(textInfo.Alignment) },
                    { "wrap", GetWrap(textInfo.Wrap) },
                    { "font", textInfo.Font },
                    { "doubleWidth", textInfo.DoubleWidth },
                    { "doubleHeight", textInfo.DoubleHeight },
                };
        }

        static Dictionary<string, object> ReceiptItemToDictionary(ReceiptItem receiptItem)
        {
            // локальная функция для определения налога на позицию
            Dictionary<string, object> GetTax()
            {
                var tax = new Dictionary<string, object>();
                switch (receiptItem.TaxType)
                {
                    case TaxType.LIBFPTR_TAX_NO:
                        tax.Add("type", "none");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT0:
                        tax.Add("type", "vat0");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT10:
                        tax.Add("type", "vat10");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT110:
                        tax.Add("type", "vat110");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT118:
                        tax.Add("type", "vat118");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT18:
                        tax.Add("type", "vat18");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT20:
                        tax.Add("type", "vat20");
                        break;
                    case TaxType.LIBFPTR_TAX_VAT120:
                        tax.Add("type", "vat120");
                        break;
                    case TaxType.CUSTOM:
                    default:
                        tax.Add("type", "vat18");
                        tax.Add("sum", Math.Round(receiptItem.Price * receiptItem.Count * receiptItem.VATCoefficient, 2));
                        break;
                }

                return tax;
            }

            return new Dictionary<string, object>
            {
                { "type", "position" },
                { "name", receiptItem.Name },
                { "price", receiptItem.Price },
                { "quantity", receiptItem.Count },
                { "amount", Math.Round( receiptItem.Price * receiptItem.Count, 2) },
                { "tax", GetTax() }
            };
        }

        static Dictionary<string, object> ReceiptPaymentToDictionary(PaymentType paymentType, double sum)
        {
            return new Dictionary<string, object>
            {
                { "type", paymentType == PaymentType.LIBFPTR_PT_CASH ? "cash" : "electronically" },
                { "sum", sum }
            };
        }

        readonly Dictionary<int, Tuple<bool, string, string>> ErrorInfo = new Dictionary<int, Tuple<bool, string, string>>
        {
            {
                Constants.LIBFPTR_ERROR_NO_CONNECTION,
                new Tuple<bool, string, string>(true, "Нет связи", "Проверьте питание ККМ, пошевелите провода")
            },
            {
                Constants.LIBFPTR_ERROR_NO_PAPER,
                new Tuple<bool, string, string>(true, "Нет бумаги", "Вставьте бумагу в ККМ")
            },
            {
                Constants.LIBFPTR_ERROR_COVER_OPENED,
                new Tuple<bool, string, string>(true, "Открыта крышка", "Закройте крышку ККМ")
            },
            {
                Constants.LIBFPTR_ERROR_PRINTER_FAULT,
                new Tuple<bool, string, string>(true, "Нет связи с принтером чеков", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_MECHANICAL_FAULT,
                new Tuple<bool, string, string>(false, "Механическая ошибка печатающего устройства", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_CUTTER_FAULT,
                new Tuple<bool, string, string>(false, "Ошибка отрезчика", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_PRINTER_OVERHEAT,
                new Tuple<bool, string, string>(true, "Перегрев головки принтера", "Выключите ККМ, откройте крышку для охлаждения головки принтера")
            },
            {
                Constants.LIBFPTR_ERROR_INTERRUPTED_BY_PREVIOUS_ERRORS,
                new Tuple<bool, string, string>(false, "Выполнение прервано из-за предыдущих ошибок", string.Empty)
            },
            {
                Constants.LIBFPTR_ERROR_SHIFT_EXPIRED,
                new Tuple<bool, string, string>(true, "Смена превысила 24 часа", "Выйдите из программы с закрытием смены")
            },
        };

        public event EventHandler<CloseFiscalDocumentErrorEventArgs> OnReceiptNotPrinted;

        IFptr fptr = null;
        int timeoutMilliseconds;
        string operatorInfo, operatorINN;
    }
}
