﻿using System;
using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.Session;
using Drg.Equipment.KKM;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class SessionManager2_Tests
    {
        //[TestMethod]
        //[ExpectedException(typeof(ArgumentNullException))]
        //public void SessionManagerExt_ctor1_Test()
        //{
        //    SessionManagerExt sessionManagerExt = new SessionManagerExt(null, null);
        //}

        /// <summary>
        /// Тест метода Start:
        /// - ККМ неисправна
        /// - смены в БД нет
        /// </summary>
        [TestMethod]
        public void SessionManager2_Start_01_Test()
        {
            var dbSession = new DbSession2_Test(null);
            var kkmSession = new KkmSession2_Test(SessionState.Unknown);
            var kkmEvents = new List<string>();

            var @operator =
                new Operator
                {
                    Id = Guid.NewGuid(),
                };

            SessionManager2 sessionManager = new SessionManager2(dbSession, kkmSession);
            sessionManager.BeforeOpenSessionKKM += (_, e) =>
            {
                if (e.CloseAndOpen)
                    kkmEvents.Add("Close");

                kkmEvents.Add("Open");
            };

            sessionManager.Start(@operator);

            Assert.IsFalse(dbSession.IsLastSessionClosed);
            Assert.IsNotNull(dbSession.Session);
            Assert.IsFalse(dbSession.Session.IsEmpty);
            Assert.IsFalse(dbSession.Session.IsClosed);
            Assert.AreEqual(0, kkmEvents.Count);
        }

        /// <summary>
        /// Тест метода Start:
        /// - ККМ неисправна
        /// - смена в БД закрыта
        /// </summary>
        [TestMethod]
        public void SessionManager2_Start_02_Test()
        {
            var dbSession = new DbSession2_Test(
                new Session
                {
                    Begin = DateTime.Now.AddHours(-1),
                    End = DateTime.Now.AddMinutes(-10)
                });
            var kkmSession = new KkmSession2_Test(SessionState.Unknown);
            var kkmEvents = new List<string>();

            var @operator =
                new Operator
                {
                    Id = Guid.NewGuid(),
                };

            SessionManager2 sessionManager = new SessionManager2(dbSession, kkmSession);
            sessionManager.BeforeOpenSessionKKM += (_, e) =>
            {
                if (e.CloseAndOpen)
                    kkmEvents.Add("Close");

                kkmEvents.Add("Open");
            };

            sessionManager.Start(@operator);

            Assert.IsFalse(dbSession.IsLastSessionClosed);
            Assert.IsNotNull(dbSession.Session);
            Assert.IsFalse(dbSession.Session.IsEmpty);
            Assert.IsFalse(dbSession.Session.IsClosed);
            Assert.AreEqual(0, kkmEvents.Count);
        }

        /// <summary>
        /// Тест метода Start:
        /// - ККМ неисправна
        /// - смена в БД открыта
        /// </summary>
        [TestMethod]
        public void SessionManager2_Start_03_Test()
        {
            var lastOperatorId = Guid.NewGuid();
            var dbSession = new DbSession2_Test(
                new Session
                {
                    Id = Guid.NewGuid(),
                    Begin = DateTime.Now.AddHours(-1),
                    OperatorId = lastOperatorId
                });
            var kkmSession = new KkmSession2_Test(SessionState.Unknown);
            var kkmEvents = new List<string>();

            var @operator =
                new Operator
                {
                    Id = Guid.NewGuid(),
                };

            SessionManager2 sessionManager = new SessionManager2(dbSession, kkmSession);
            sessionManager.BeforeOpenSessionKKM += (_, e) =>
            {
                if (e.CloseAndOpen)
                    kkmEvents.Add("Close");

                kkmEvents.Add("Open");
            };

            sessionManager.Start(@operator);

            Assert.IsFalse(dbSession.IsLastSessionClosed);
            Assert.IsNotNull(dbSession.Session);
            Assert.IsFalse(dbSession.Session.IsEmpty);
            Assert.IsFalse(dbSession.Session.IsClosed);
            Assert.AreNotEqual(lastOperatorId, dbSession.Session.OperatorId);
            Assert.AreEqual(@operator.Id, dbSession.Session.OperatorId);
            Assert.AreEqual(0, kkmEvents.Count);
        }

        /// <summary>
        /// Тест метода Start:
        /// - смена в ККМ просрочена
        /// - смена в БД открыта
        /// </summary>
        [TestMethod]
        public void SessionManager2_Start_04_Test()
        {
            var lastOperatorId = Guid.NewGuid();
            var dbSession = new DbSession2_Test(
                new Session
                {
                    Id = Guid.NewGuid(),
                    Begin = DateTime.Now.AddHours(-1),
                    OperatorId = lastOperatorId
                });
            var kkmSession = new KkmSession2_Test(SessionState.Expired, 123, "123");
            var kkmEvents = new List<string>();

            var @operator =
                new Operator
                {
                    Id = Guid.NewGuid(),
                };

            SessionManager2 sessionManager = new SessionManager2(dbSession, kkmSession);
            sessionManager.BeforeOpenSessionKKM += (_, e) =>
            {
                if (e.CloseAndOpen)
                    kkmEvents.Add("Close");

                kkmEvents.Add("Open");
            };

            sessionManager.Start(@operator);

            Assert.IsTrue(dbSession.IsLastSessionClosed);
            Assert.IsNotNull(dbSession.Session);
            Assert.IsFalse(dbSession.Session.IsEmpty);
            Assert.IsFalse(dbSession.Session.IsClosed);
            Assert.AreNotEqual(lastOperatorId, dbSession.Session.OperatorId);
            Assert.AreEqual(@operator.Id, dbSession.Session.OperatorId);
            Assert.AreEqual(2, kkmEvents.Count);
            Assert.AreEqual("Close", kkmEvents[0]);
            Assert.AreEqual("Open", kkmEvents[1]);
            Assert.AreEqual(SessionState.Opened, kkmSession.SessionState);
        }

        class KkmSession2_Test : IKkmSession2
        {
            public KkmSession2_Test(SessionState startSessionState, uint sessionNumber = 0, string fnNumber = null)
            {
                SessionState = startSessionState;
                SessionNumber = sessionNumber;
                FnNumber = fnNumber;
            }

            public SessionState SessionState { get; private set; }

            public string FnNumber { get; private set; }

            public uint SessionNumber { get; private set; }

            public void CloseSession(string operatorInfo, string operatorINN)
            {
                //Console.WriteLine($"KKM.CloseSession: operatorInfo = {operatorInfo}, operatorInn = {operatorINN}");
                SessionState = SessionState.Closed;
            }

            public void OpenSession(string operatorInfo, string operatorINN)
            {
                //Console.WriteLine($"KKM.OpenSession: operatorInfo = {operatorInfo}, operatorInn = {operatorINN}");
                SessionState = SessionState.Opened;
            }
        }

        class DbSession2_Test : IDbSession2
        {
            public DbSession2_Test(Session startSession)
            {
                Session = startSession;
            }

            public void CloseSession(Guid sessionId)
            {
            }

            public Session LoadLastSession()
            {
                return Session;
            }

            public Session ReopenSession(Guid sessionId, Guid operatorId, string fnNumber)
            {
                if (sessionId != Guid.Empty)
                    IsLastSessionClosed = true;

                Session = new Session
                {
                    Id = Guid.NewGuid(),
                    Begin = DateTime.Now,
                    OperatorId = operatorId,
                    IdFN = fnNumber
                };

                return Session;
            }

            public void UpdateSessionOperator(Guid sessionId, Guid operatorId)
            {
            }

            public bool IsLastSessionClosed { get; private set; }

            public Session Session { get; private set; }
        }
    }
}
