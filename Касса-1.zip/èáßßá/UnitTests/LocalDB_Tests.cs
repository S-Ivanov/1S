﻿using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.CashDeskLib.MenuReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace UnitTests
{
    [TestClass]
    public class LocalDB_Tests
    {
        //const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Проекты\Касса\Drg.CashDeskLib\Database.mdf;Integrated Security=True;Connection Timeout=60";
        const string ConnectionString = @"Data Source=.\sqlexpress;Initial Catalog=Касса;Persist Security Info=True;User ID=sa;Password=zto1f5;Connection Timeout=60";

        [TestMethod]
        public void LocalDB_SaveAuthorizationInfo_Test()
        {
            Guid authorizationInfoId = new Guid("21FEBC62-CE59-458A-A1D3-2305DE7DB5AE");
            Drg.Equipment.PayTerminal.AuthorizationInfo authorizationInfo = new Drg.Equipment.PayTerminal.AuthorizationInfo
            {

                AuthCode = "1",
                TransType = 1,
                OperationType = 1,
                Sum = 100,
                CardNumber = "1",
                SlipNumber = 1,
                TransDate = "01.01.2018",
                TransTime = "11:11:11",
                MsgNumber = 1,
                TerminalID = "1",
                ReferenceNumber = "1",
                ResponseCode = "1"
            };
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SaveAuthorizationInfo(authorizationInfoId, Guid.NewGuid(), Guid.NewGuid(), authorizationInfo);
            Assert.IsNotNull(localDB);
        }

        [TestMethod]
        public void LocalDB_SavePayment_Test()
        {
            Guid sessionId = new Guid("9ef2702c-4628-467a-b1f8-03db60f7dec4");
            Order order = new Order
            {
                Id = new Guid("30B3A099-88DA-47E2-BC39-B765FC31947C"),
                Number = 101,
                DateTime = DateTime.Now,
                Items = new List<OrderItem>
                {
                    new OrderItem
                    {
                        Payment = Payment.BankCard,
                        MenuItem = new MenuItem
                        {
                            IdProduct = new Guid("0994a214-bfbf-48ae-b36b-012a2a69341c"),
                            Price = 100
                        },
                        Count = 1,
                        Sum = 100
                    }
                }
            };
            string tabNum = string.Empty;
            Receipt receipt = new Receipt
            {
                Order = order
            };
            bool isTestMode = true;
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SavePayment(sessionId, receipt, isTestMode);
            Assert.IsNotNull(localDB);
        }

        [TestMethod]
        public void LocalDB_SavePayTerminalReturnError_Test()
        {
            Guid authorizationInfoId = new Guid("5f6870e4-1994-4e3e-8b80-0d70f3756563");
            int sessionNumber = 101;
            int checkNumber = 101;
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SavePayTerminalReturnError(authorizationInfoId, sessionNumber, checkNumber);
            Assert.IsNotNull(localDB);
        }

        [TestMethod]
        public void LocalDB_GetVATCoefficient_Test()
        {
            decimal vat18 = LocalDB.GetVATCoefficient("18 / 100");
            Assert.AreEqual(Math.Round(18M / 100, 6), Math.Round(vat18, 6));
        }


        [TestMethod]
        public void LocalDB_LoadMenus_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var menu = localDB.LoadMenu(DateTime.Today, 2);
            Assert.IsNotNull(menu);
        }

        [TestMethod]
        public void LocalDB_LoadLastSession_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var session = localDB.LoadLastSession();
            Assert.IsNotNull(session);
        }

        [TestMethod]
        public void LocalDB_LoadOrder_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderInfo = localDB.LoadOrder(new Guid("1a73a5fd-ba8d-4765-9b3d-6ff2bf37613b"));
            Assert.IsNotNull(orderInfo);
        }

        [TestMethod]
        public void LocalDB_LoadReturns_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderReturns = localDB.LoadReturns(new Guid("1a73a5fd-ba8d-4765-9b3d-6ff2bf37613b"));
            Assert.IsNotNull(orderReturns);
        }

        [TestMethod]
        public void LocalDB_SaveMenus_Test()
        {
            Menus menus = MenuReader.Read(@"C:\Проекты\Касса\Drg.CashDeskLib\MenuReader\ToFront.xml");
            LocalDB localDB = new LocalDB(ConnectionString);
            localDB.SaveMenus(menus);
        }

        [TestMethod]
        public void LocalDB_GetNewOrderNumber_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var orderNumber = localDB.GetNewOrderNumber();
            Assert.AreNotEqual(0, orderNumber);
        }

        [TestMethod]
        public void LocalDB_LoadOrderSources_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            List<OrderSource> orderSources = localDB.LoadOrderSources(true);
            Assert.IsNotNull(orderSources);
        }

        [TestMethod]
        public void LocalDB_LoadClients_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            bool allNew = false;
            bool isTest = false;
            List<string> tabNums = new List<string> { "5188" };
            var clients = localDB.LoadClients(allNew, isTest, tabNums);
            Assert.IsNotNull(clients);
        }

        [TestMethod]
        public void LocalDB_LoadReportFO_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var reportFO = localDB.LoadReportFO(new Guid("6360bf3f-ca40-4464-8225-0f0af6dedf9a"));
            Assert.IsNotNull(reportFO);
        }

        [TestMethod]
        public void LocalDB_LoadTransactionDocument_Test()
        {
            LocalDB localDB = new LocalDB(ConnectionString);
            var transactionDocument = localDB.LoadTransactionDocument(null, DateTime.UtcNow, true);
            Assert.IsNotNull(transactionDocument);
        }

        /// <summary>
        /// Тест записи иерархических данных
        /// </summary>
        /// <remarks>
        /// По результатам теста: иерархия должна записываться последовательно от верхнего уровня к нижним
        /// </remarks>
        [TestMethod]
        public void LocalDB_SaveHierarchy_Test()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    SqlCommand command = new SqlCommand(
@"insert into Номенклатура (Id, Наименование, IdРодителя)
values (@Id, @Наименование, @IdРодителя)", 
                        connection, transaction);
                    command.Parameters.Add("@Id", SqlDbType.VarChar, 15);
                    command.Parameters.Add("@Наименование", SqlDbType.NVarChar, 100);
                    command.Parameters.Add("@IdРодителя", SqlDbType.VarChar, 15);

                    command.Parameters["@Id"].Value = "99-00000002";
                    command.Parameters["@Наименование"].Value = "Тест 1";
                    command.Parameters["@IdРодителя"].Value = "99-00000001";
                    command.ExecuteNonQuery();

                    command.Parameters["@Id"].Value = "99-00000001";
                    command.Parameters["@Наименование"].Value = "Тест 1 - родитель";
                    command.Parameters["@IdРодителя"].Value = DBNull.Value;
                    command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        //[TestMethod]
        //public void LocalDB_SaveExchangeData_Test()
        //{
        //    LocalDB localDB = new LocalDB(ConnectionString);

        //    DateTime? lastExchangeDateTime = localDB.GetLastExchangeDateTime();

        //    using (FrontServiceReference.FrontServicePortTypeClient frontServiceClient = new FrontServiceReference.FrontServicePortTypeClient("FrontServiceSoap12"))
        //    {
        //        FrontServiceReference.Parameter parameter = new FrontServiceReference.Parameter
        //        {
        //            IdCashDesk = "00000006",
        //            //TransactionDocument = new FrontServiceReference.Transaction[]
        //        };

        //        // дата/время последнего сеанса обмена данными
        //        if (lastExchangeDateTime != null)
        //            parameter.ClientTimeStamp = lastExchangeDateTime.Value;

        //        FrontServiceReference.ResultData resultData = frontServiceClient.ExchangeData(parameter);

        //        // записать полученные данные
        //        localDB.SaveExchangeData(TranslateResultData(resultData), 248);
        //    }
        //}

        //Drg.CashDeskLib.FrontServiceReference.ResultData TranslateResultData(FrontServiceReference.ResultData resultData)
        //{
        //    return new Drg.CashDeskLib.FrontServiceReference.ResultData
        //    {
        //        TimeStamp = resultData.TimeStamp,
        //        ClientDocument =
        //            resultData
        //            .ClientDocument
        //            .Select(client => new Drg.CashDeskLib.FrontServiceReference.Client
        //            {
        //                TabNum = client.TabNum,
        //                FIO = client.FIO,
        //                CardCode = client.CardCode,
        //                IsZP = client.IsZP,
        //                LimitZP = client.LimitZP
        //            })
        //            .ToArray(),
        //        LPPDocument = 
        //            resultData
        //            .LPPDocument
        //            .Select(lpp => new Drg.CashDeskLib.FrontServiceReference.LPP
        //            {
        //                TabNum = lpp.TabNum,
        //                MonthLPP = lpp.MonthLPP,
        //                SumLPP = lpp.SumLPP
        //            })
        //            .ToArray(),
        //        PhotoDocument = 
        //            resultData
        //            .PhotoDocument
        //            .Select(photo => new Drg.CashDeskLib.FrontServiceReference.Photo
        //            {
        //                TabNum = photo.TabNum,
        //                Data = photo.Data
        //            })
        //            .ToArray()
        //    };
        //}
    }
}
