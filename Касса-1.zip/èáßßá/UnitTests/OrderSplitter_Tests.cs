﻿using System.Collections.Generic;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.ReportFO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class OrderSplitter_Tests
    {
        //[TestMethod]
        //public void OrderSplitter_SplitByOne_Test()
        //{
        //    List<OrderItem> orderItems;
        //    List<OrderItem> orderItemsByOne;

        //    orderItems = new List<OrderItem>
        //    {
        //        new OrderItem
        //        {
        //            Count = 1.5m,
        //            MenuItem = new MenuItem
        //            {
        //                Name = "Элемент меню 1",
        //                Price = 100
        //            }
        //        }
        //    };
        //    orderItemsByOne = OrderSplitter.SplitByOne(orderItems);
        //    Assert.AreEqual(2, orderItemsByOne.Count);
        //}

        //[TestMethod]
        //public void OrderSplitter_Split_Test()
        //{
        //    Order order;
        //    Dictionary<Payment, decimal> payments;
        //    IDictionary<Payment, List<OrderItem>> splited;

        //    order = new Order
        //    {
        //        Items = new List<OrderItem>
        //        {
        //            new OrderItem
        //            {
        //                Count = 1.5m,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 1",
        //                    Price = 100
        //                }
        //            }
        //        }
        //    };
        //    payments = new Dictionary<Payment, decimal>
        //    {
        //        { Payment.ZP, 150 }
        //    };
        //    splited = OrderSplitter.Split(order, payments);
        //    Assert.AreEqual(1, splited.Count);

        //    // 100, 100, 100, 200, 200, 300, 400 => 800, 600
        //    order = new Order
        //    {
        //        Items = new List<OrderItem>
        //        {
        //            new OrderItem
        //            {
        //                Count = 3 + 5,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 1",
        //                    Price = 100
        //                }
        //            },
        //            new OrderItem
        //            {
        //                Count = 2 + 2,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 2",
        //                    Price = 200
        //                }
        //            },
        //            new OrderItem
        //            {
        //                Count = 1 + 2,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 3",
        //                    Price = 300
        //                }
        //            },
        //            new OrderItem
        //            {
        //                Count = 1,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 4",
        //                    Price = 400
        //                }
        //            },
        //        }
        //    };
        //    payments = new Dictionary<Payment, decimal>
        //    {
        //        { Payment.ZP, 800 + 500 },
        //        { Payment.LPP, 600 + 1000 },
        //    };
        //    splited = OrderSplitter.Split(order, payments);
        //    Assert.AreEqual(2, splited.Count);

        //    // 101, 101, 101 => 248, 55
        //    order = new Order
        //    {
        //        Items = new List<OrderItem>
        //        {
        //            new OrderItem
        //            {
        //                Count = 3,
        //                MenuItem = new MenuItem
        //                {
        //                    Name = "Элемент меню 1",
        //                    Price = 101
        //                }
        //            },
        //        }
        //    };
        //    payments = new Dictionary<Payment, decimal>
        //    {
        //        { Payment.ZP, 55 },
        //        { Payment.LPP, 248 },
        //    };
        //    splited = OrderSplitter.Split(order, payments, 3);
        //    Assert.AreEqual(2, splited.Count);
        //}
    }
}
