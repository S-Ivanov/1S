﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Drg.CashDeskLib.DataModel;
using Drg.CashDeskLib.DB;
using Drg.Equipment;
using Drg.Equipment.KKM;
using Drg.Equipment.PayTerminal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Drg.CashDeskLib.Payment;

namespace UnitTests
{
    [TestClass]
    public class PaymentManager_Tests
    {
        const string KkmNotFiscal = "Нефискальная печать";
        const string KkmFiscal = "Фискальная печать";
        const string KkmNotFiscalError = "Нефискальная печать с ошибкой";
        const string PayTerminal = "Оплата по карте";
        const string PayTerminalError = "Оплата по карте с ошибкой";
        const string PayTerminalUndo = "Откат по карте";
        const string PayTerminalUndoError = "Откат по карте с ошибкой";
        const string PayTerminalUndoCancel = "Отмена отката по карте";
        const string SaveAuthorization = "Авторизация оплаты";
        const string SavePaymentDB = "Сохранение оплаты";
        const string SavePayTerminalReturnErrorDB = "Сохранение ошибки отмены по карте";


        /// <summary>
        /// Оплата в счет ЗП
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_01_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.ZP);

            var result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            Assert.IsTrue(result);
            CollectionAssert.AreEqual(new List<string> { KkmNotFiscal, SavePaymentDB }, steps);
        }

        /// <summary>
        /// Оплата в счет ЗП с ошибкой ККМ
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_02_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.ZP);

            bool? result = null;
            try
            {
                result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            }
            catch (Exception ex)
            {
                PaymentManagerExtException paymentManagerExtException = ex as PaymentManagerExtException;
                Assert.IsNotNull(paymentManagerExtException);
                Assert.AreEqual(Device.KKM, paymentManagerExtException.Device);
                Assert.AreEqual(2, paymentManagerExtException.DeviceError.ErrorCode);
            }
            Assert.IsNull(result);
            CollectionAssert.AreEqual(new List<string> { KkmNotFiscalError }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_03_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            var result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            Assert.IsTrue(result);
            // оплата по карте, авторизация оплаты, фискальный чек, сохранение
            CollectionAssert.AreEqual(new List<string> { PayTerminal, SaveAuthorization, KkmNotFiscal, KkmFiscal, SavePaymentDB }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте с регистрируемой ошибкой терминала во время оплаты
        /// </summary>
        [TestMethod]
        //[ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_04_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, new DeviceError { ErrorCode = 2, Description = "Регистрируемая ошибка терминала" }, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            bool? result = null;
            try
            {
                result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            }
            catch (Exception ex)
            {
                PaymentManagerExtException paymentManagerExtException = ex as PaymentManagerExtException;
                Assert.IsNotNull(paymentManagerExtException);
                Assert.AreEqual(Device.PayTerminal, paymentManagerExtException.Device);
                Assert.AreEqual(2, paymentManagerExtException.DeviceError.ErrorCode);
            }
            Assert.IsNull(result);
            // оплата по карте с ошибкой, авторизация оплаты
            CollectionAssert.AreEqual(new List<string> { PayTerminalError, SaveAuthorization }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте с ошибкой ККМ во время оплаты
        /// </summary>
        [TestMethod]
        //[ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_05_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            bool? result = null;
            try
            {
                result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            }
            catch (Exception ex)
            {
                PaymentManagerExtException paymentManagerExtException = ex as PaymentManagerExtException;
                Assert.IsNotNull(paymentManagerExtException);
                Assert.AreEqual(Device.KKM, paymentManagerExtException.Device);
                Assert.AreEqual(2, paymentManagerExtException.DeviceError.ErrorCode);
            }
            Assert.IsNull(result);
            // оплата по карте, авторизация оплаты, ошибка печати слипа, отмена оплаты по карте, авторизация оплаты
            CollectionAssert.AreEqual(new List<string> { PayTerminal, SaveAuthorization, KkmNotFiscalError, PayTerminalUndo, SaveAuthorization }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой оплаты
        /// </summary>
        [TestMethod]
        public void PaymentManager_PayReceipt_06_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, DeviceError.NoError);
            IPayTerminal payTerminal = new PayTerminalMock(steps, true, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            var result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            Assert.IsFalse(result);
            // оплата по карте
            CollectionAssert.AreEqual(new List<string> { PayTerminal }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой отката оплаты при ошибке ККМ
        /// </summary>
        [TestMethod]
        //[ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_07_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, true, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            bool? result = null;
            try
            {
                result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            }
            catch (Exception ex)
            {
                PaymentManagerExtException paymentManagerExtException = ex as PaymentManagerExtException;
                Assert.IsNotNull(paymentManagerExtException);
                Assert.AreEqual(Device.KKM, paymentManagerExtException.Device);
                Assert.AreEqual(2, paymentManagerExtException.DeviceError.ErrorCode);
            }
            Assert.IsNull(result);
            // оплата по карте, авторизация оплаты, ошибка печати слипа, откат отмены оплаты по карте, сохранение информации об отмене
            CollectionAssert.AreEqual(new List<string> { PayTerminal, SaveAuthorization, KkmNotFiscalError, PayTerminalUndoCancel, SavePayTerminalReturnErrorDB }, steps);
        }

        /// <summary>
        /// Оплата по банковской карте с отменой отката оплаты при ошибке ККМ - отмена возврата пользователем
        /// </summary>
        [TestMethod]
        //[ExpectedException(typeof(PaymentManagerExtException))]
        public void PaymentManager_PayReceipt_08_Test()
        {
            List<string> steps = new List<string>();
            var kkm = new KKMMock(steps, new DeviceError { ErrorCode = 2, Description = "Нет бумаги" });
            IPayTerminal payTerminal = new PayTerminalMock(steps, false, false, DeviceError.NoError, DeviceError.NoError);
            ILocalDBPayment localDB = new LocalDBPaymentMock(steps);

            PaymentManager paymentManager = CreatePaymentManager(kkm, payTerminal, localDB);
            paymentManager.OnBeforePayTerminalCancel += (sender, e) => e.Cancel = true;

            Drg.CashDeskLib.DataModel.Receipt receipt = CreateReceipt<Order>(Payment.BankCard);

            bool? result = null;
            try
            {
                result = paymentManager.PayReceipt(session, receipt, "Иванов С.В.", "123456789012");
            }
            catch (Exception ex)
            {
                PaymentManagerExtException paymentManagerExtException = ex as PaymentManagerExtException;
                Assert.IsNotNull(paymentManagerExtException);
                Assert.AreEqual(Device.KKM, paymentManagerExtException.Device);
                Assert.AreEqual(2, paymentManagerExtException.DeviceError.ErrorCode);
            }
            Assert.IsNull(result);
            // оплата по карте, авторизация оплаты, ошибка печати слипа, сохранение информации об отмене
            CollectionAssert.AreEqual(new List<string> { PayTerminal, SaveAuthorization, KkmNotFiscalError, SavePayTerminalReturnErrorDB }, steps);
        }


        PaymentManager CreatePaymentManager(IKKMPayment2 kkm, IPayTerminal payTerminal, ILocalDBPayment localDB)
        {
            return new PaymentManager(kkm, payTerminal, localDB, null, configuration);
        }

        Drg.CashDeskLib.DataModel.Receipt CreateReceipt<T>(params Payment[] payments) where T: Order, new()
        {
            return new Drg.CashDeskLib.DataModel.Receipt
            {
                Order = new T
                {
                    Number = 1,
                    DateTime = DateTime.Now,
                    Items = payments
                        .Select(
                            (payment, i) => new OrderItem
                            {
                                Payment = payment,
                                MenuItem = new MenuItem
                                {
                                    Name = $"Блюдо {i + 1}",
                                    Price = 100 * (i + 1),
                                    VATCode = 1,
                                    VATCoefficient = 0
                                },
                                Price = 100 * (i + 1),
                                Count = i + 1
                            })
                        .ToList()
                }
            };
        }


        PaymentManagerConfiguration configuration = new PaymentManagerConfiguration
        {
            SlipCount = 1,
            IsTestMode = false,
            ReturnCopies = 1,
            NominalLPP = 250,
            NominalTalon120 = 120,
            PaymentsPlace = "Столовая №21"
        };

        Session session = new Session { Id = Guid.NewGuid(), Number = 100 };

        class TraceSteps
        {
            public TraceSteps(List<string> steps)
            {
                this.steps = steps;
            }

            protected List<string> steps;
        }

        class LocalDBPaymentMock : TraceSteps, ILocalDBPayment
        {
            public LocalDBPaymentMock(List<string> steps)
                : base(steps)
            {
            }

            public void SaveAuthorizationInfo(Guid authorizationInfoId, Guid sessionId, Guid orderId, AuthorizationInfo authorizationInfo)
            {
                steps.Add(SaveAuthorization);
            }

            public void SavePayment(Guid sessionId, Drg.CashDeskLib.DataModel.Receipt receipt, bool isTestMode)
            {
                steps.Add(SavePaymentDB);
            }

            public void SavePayTerminalReturnError(Guid authorizationInfoId, int sessionNumber, int checkNumber)
            {
                steps.Add(SavePayTerminalReturnErrorDB);
            }
        }

        class PayTerminalMock : TraceSteps, IPayTerminal
        {
            public PayTerminalMock(List<string> steps, bool cancelPay, bool cancelUndo, DeviceError payError, DeviceError cancelError)
                : base(steps)
            {
                this.cancelPay = cancelPay;
                this.cancelUndo = cancelUndo;
                this.payError = payError;
                this.cancelError = cancelError;
            }

            public PayResult Pay(int sessionNumber, int checkNumber, decimal sum)
            {
                steps.Add(payError == null || payError.ErrorCode == DeviceError.NO_ERROR ? PayTerminal : PayTerminalError);

                if (cancelPay)
                    return null;
                else
                    return new PayResult
                    {
                        DeviceError = payError,
                        SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                        AuthorizationInfo = new AuthorizationInfo
                        {
                            Sum = sum
                        }
                    };
            }

            public PayResult ReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                Console.WriteLine("PayTerminal.ReturnPay:");
                PayResult payResult = new PayResult
                {
                    DeviceError = DeviceError.NoError,
                    SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                    AuthorizationInfo = new AuthorizationInfo
                    {
                        Sum = sum
                    }
                };
                return payResult;
            }

            public bool IsBusy => false;

            public DeviceError LastError => DeviceError.NoError;

            public uint LineLength { get; set; }

            public void CheckErrors()
            {
            }

            public void Dispose()
            {
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public string Report(ReportType reportType, IEnumerable<AuthorizationInfo> authorizationInfoCollection)
            {
                throw new NotImplementedException();
            }

            public PayResult CancelPay(int sessionNumber, int checkNumber, decimal sum)
            {
                if (cancelUndo)
                    steps.Add(PayTerminalUndoCancel);
                else
                    steps.Add(cancelError == null || cancelError.ErrorCode == DeviceError.NO_ERROR ? PayTerminalUndo : PayTerminalUndoError);

                if (cancelUndo)
                    return null;
                else
                    return new PayResult
                    {
                        DeviceError = cancelError,
                        SlipText = $"Слип: sessionNumber = {sessionNumber}, checkNumber = {checkNumber}, sum = {sum}",
                        AuthorizationInfo = new AuthorizationInfo
                        {
                            Sum = sum
                        }
                    };
            }

            public PayResult CancelReturnPay(int sessionNumber, int checkNumber, decimal sum)
            {
                throw new NotImplementedException();
            }

            DeviceError payError;
            DeviceError cancelError;
            private bool cancelPay;
            private bool cancelUndo;
        }

        class KKMMock : TraceSteps, IKKMPayment2
        {
            public KKMMock(List<string> steps, DeviceError error)
                : base(steps)
            {
                this.error = error;
            }

            public uint LineLength => 48;

            public bool IsBusy => false;

            public DeviceError LastError => error;

            public void CheckErrors()
            {
            }

            public void Dispose()
            {
            }

            public void DoAction<T>(int actionType, T parameters)
            {
                throw new NotImplementedException();
            }

            public Task DoActionAsync<T>(int actionType, T parameters, CancellationToken token, Action itemCompletedAction, Action finishAction)
            {
                throw new NotImplementedException();
            }

            public void PrintNonFiscalDocument(IEnumerable<TextInfo> textInfo, bool closeDocument)
            {
                if (error.HasError)
                {
                    steps.Add(KkmNotFiscalError);
                    throw new DeviceException(LastError);
                }
                else
                {
                    steps.Add(KkmNotFiscal);

                    Console.WriteLine("PrintNonFiscalDocument:");
                    foreach (var ti in textInfo)
                    {
                        Console.WriteLine("  " + ti.ToString((int)LineLength));
                    }
                }
            }

            public void PrintReceipt(Drg.Equipment.KKM.Receipt receipt)
            {
                steps.Add(KkmFiscal);
            }

            public void PrintNonFiscalDocument2(IEnumerable<TextInfo> textInfo)
            {
                if (error.HasError)
                {
                    steps.Add(KkmNotFiscalError);
                    throw new DeviceException(LastError);
                }
                else
                {
                    steps.Add(KkmNotFiscal);

                    Console.WriteLine("PrintNonFiscalDocument:");
                    foreach (var ti in textInfo)
                    {
                        Console.WriteLine("  " + ti.ToString((int)LineLength));
                    }
                }
            }

            public void PrintReceipt2(IEnumerable<TextInfo> notFiscalHeader, Drg.Equipment.KKM.Receipt receipt, string paymentsPlace, string @operator, string operatorINN)
            {
                steps.Add(KkmFiscal);
            }

            public void PrintLastReceiptCopy()
            {
                throw new NotImplementedException();
            }

            DeviceError error;
        }
    }
}
