﻿using System;
using Drg.CashDeskLib.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class CheckINN_Tests
    {
        [TestMethod]
        public void CheckINN_Test()
        {
            Assert.IsTrue(CheckINN.IsINN("400100889169"));
            Assert.IsTrue(CheckINN.IsINN("123456789047"));
            Assert.IsTrue(CheckINN.IsINN("672606718838"));
            Assert.IsTrue(CheckINN.IsINN("670400744333"));
            Assert.IsTrue(CheckINN.IsINN("670400681330"));
            Assert.IsTrue(CheckINN.IsINN("670402366528"));
            Assert.IsTrue(CheckINN.IsINN("670401854152"));
            Assert.IsTrue(CheckINN.IsINN("670401472971"));
            Assert.IsTrue(CheckINN.IsINN("670401619825"));

            Assert.IsFalse(CheckINN.IsINN("123456789012"));
        }
    }
}
