﻿using System;
using System.Collections.Generic;
using Drg.Equipment.KKM;
using Drg.Equipment.KKMAtol10_3_1;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class KKM2_Tests
    {
        [TestMethod]
        public void KKM2_PrepareReceiptJson_Test()
        {
            var receiptHeader = new List<TextInfo>()
            {
                new TextInfo
                {
                    Text = "Заголовок чека",
                    Alignment = TextAlignment.Center,
                    Wrap = TextWrap.None
                }
            };
            Receipt receipt = new Receipt
            {
                ReceiptType = ReceiptType.LIBFPTR_RT_SELL,
                Items =
                {
                    new ReceiptItem
                    {
                        Name = "Пакет упаковочный",
                        Price = 0.46,
                        Count = 1,
                        TaxType = TaxType.LIBFPTR_TAX_VAT20
                    }
                },
                Payments =
                {
                    { PaymentType.LIBFPTR_PT_CASH, 0.46 }
                }
            };
            string paymentsPlace = "Столовая №21";
            string @operator = "Иванов С.В.";
            string operatorINN = "123456789047";

            string json = KKM2.PrepareReceiptJson(receiptHeader, receipt, paymentsPlace, @operator, operatorINN);
            Assert.IsNotNull(json);

            Console.WriteLine(json);
        }
    }
}
